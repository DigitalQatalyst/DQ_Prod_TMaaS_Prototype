# PS.NOTIF — Notifications Service

| | |
|---|---|
| Registry ID | `PS.NOTIF` |
| Atomic class | Integration |
| Package | `@dbp/ps-notif` (semver, independently versioned — currently `0.1.0`) |
| Contract | `contract.yaml` (OpenAPI 3.0.3, GENERATED from Zod per ADR-0013 — never edit by hand) |
| Base path | `/api/platform/notif` |

## Purpose

Deliver and manage notifications across channels (in-app, email, sms). Built once at Layer 06;
solutions consume the client SDK and never re-implement notification delivery. The top-bar
notification bell (Phase 4) binds to `useNotifications()` from this service — it is not a
per-solution build.

## Surface

- **Server** (`@dbp/ps-notif/server`): framework-free fetch-API handlers
  (`(req: Request) => Promise<Response>`, Next 15 route-handler compatible).
  - `POST /api/platform/notif/send` — dispatch to channel adapter; in-app also persists.
  - `POST /api/platform/notif/email` — **transactional email** (HTML/text body, replyTo, cc); rate-limited 5/IP/10min.
  - `GET /api/platform/notif/notifications` — list for session user + unread count (requires `x-dbp-session`).
  - `POST /api/platform/notif/notifications/:id/read` — mark one notification read.
  - `POST /api/platform/notif/notifications/read-all` — mark all read for session user.
  - `GET /api/platform/notif/stream` — SSE stream for live in-app notifications (requires `x-dbp-session`).
  - `routes` manifest, `dispatch(req)` router.
- **Client** (`@dbp/ps-notif/client`):
  - `useNotifications(sessionHeader?)` → `{ items, unread, markRead, markAllRead }` (TanStack Query; refetches on mutation).
  - `send({ to, type, message, link?, channel })` → `Promise<void>` — plain async function.
  - `sendEmail({ to, subject, html?, text?, replyTo?, cc? })` → `Promise<void>` — transactional email.
  - `useSendEmail()` → `{ sendEmail, isPending, error }` — TanStack Query mutation hook.
  - `configureNotifClient({ baseUrl?, fetch? })`, `getNotifClientConfig()`, `resetNotifClient()`.

## Channel adapters (ADR-0014)

| Channel | Implementation | Dev behaviour | Production path |
|---|---|---|---|
| `in-app` | Service-owned store + SSE | Persists immediately; SSE streams to live listeners | Same — no external dependency |
| `email` | `EmailTransport` (see below) | Captures in `renderedEmails[]` via `jsonTransport` or capture seam | Set `NOTIF_EMAIL_TRANSPORT` + relevant env vars |
| `sms` | Interface present | Throws `NotImplemented` with ADR-0014 reference | Vendor ADR (Twilio-class) required |

## Transactional Email

`POST /api/platform/notif/email` accepts `{ to, subject, html?, text?, replyTo?, cc? }` and delivers
via the configured email transport. This path is distinct from the notification-channel email path
(`POST /send?channel=email`) — it accepts rich HTML bodies and is intended for transactional use cases
(contact forms, receipts, etc.).

### Email transport abstraction (`server/transport.ts`)

The `EmailTransport` interface (`{ send(msg: EmailMessage): Promise<void> }`) decouples delivery from
channel dispatch. A single factory `getEmailTransport()` reads `NOTIF_EMAIL_TRANSPORT` (default `smtp`)
and returns a memoised transport instance. Both the notification email channel adapter and the
`/email` handler use this factory.

| Transport | Env var | Dev/test behaviour | Production config |
|---|---|---|---|
| `SmtpTransport` | `NOTIF_EMAIL_TRANSPORT=smtp` (default) | `jsonTransport` when `SMTP_URL` absent — captures into `renderedEmails[]` | Set `SMTP_URL=smtps://user:pass@host:465`; optionally `SMTP_FROM` |
| `MsGraphTransport` | `NOTIF_EMAIL_TRANSPORT=msgraph` | Captures into `renderedEmails[]` when `NOTIF_EMAIL_CAPTURE=1` or MSGRAPH env vars absent | Requires all four `MSGRAPH_*` vars (see below) |

### MS Graph environment variables

| Variable | Required | Description |
|---|---|---|
| `MSGRAPH_TENANT_ID` | Yes (msgraph) | Azure AD tenant ID |
| `MSGRAPH_CLIENT_ID` | Yes (msgraph) | App registration client ID |
| `MSGRAPH_CLIENT_SECRET` | Yes (msgraph) | App registration client secret |
| `MSGRAPH_SENDER_UPN` | Yes (msgraph) | UPN of the mailbox to send from (e.g. `noreply@example.com`) |
| `NOTIF_EMAIL_CAPTURE` | No | Set to `"1"` to capture emails in-process instead of sending (useful in staging/test) |

The MS Graph transport uses client-credentials OAuth2 (`https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token`
with `scope=https://graph.microsoft.com/.default`) and sends via `POST /v1.0/users/{UPN}/sendMail`.
An in-memory token cache avoids redundant token requests (refreshes 60 s before expiry).

### SMTP deferral

When `SMTP_URL` is not set, `SmtpTransport` uses `nodemailer`'s built-in `jsonTransport`.
Mail is rendered and captured in `renderedEmails` (exported from server for test inspection)
but never delivered. To test real SMTP: set `SMTP_URL=smtps://user:pass@host:465` and
optionally `SMTP_FROM=sender@example.com`.

### SMS deferral

`SmsChannelAdapter.deliver()` throws unconditionally with a clear message pointing to ADR-0014.
The interface seam is stable — swapping in a Twilio adapter requires implementing `ChannelAdapter`
and wiring it into `service.ts`. No contract or SDK change needed.

## SSE design

`GET /stream` opens a `ReadableStream` per authenticated connection. Architecture:

- **Registry**: `sseSubscribers` (module-level `Map<tenantId, Map<userId, Set<controller>>>`)
  in `service.ts`. Controllers are registered on stream open, unregistered on cancel.
- **Broadcast**: `service.broadcast(tenantId, userId, notification)` enqueues `data: <JSON>\n\n`
  to all active controllers for that user+tenant.
- **Heartbeat**: SSE comment `": heartbeat\n\n"` sent every 15 s. Prevents proxy/load-balancer
  idle-connection timeouts.
- **Reconnect semantics**: the server does NOT replay history on reconnect — the in-memory store
  has no reliable ordering index for cursor-based SSE resumption in Phase 2. On reconnect clients
  MUST call `GET /notifications` to re-hydrate. Reconnect interval suggested to client: 30 s.
- **History replay**: deferred to a future ADR once a persistent store with event ordering is in place.

## SLO

**send→in-app visible p95 < 50ms.**

Measured by `tests/handlers.test.ts` ("SLO probe"): 100 sequential in-process send+persist
round-trips, p95 asserted `< 50ms` on every test run. The SLO is achievable because the in-app
path is a pure in-memory `Map` write with no I/O. Once a deployment target exists, the APM concern
is handler latency at the network boundary — the in-process path tested here is the lower bound.

## Contract workflow

`pnpm --filter @dbp/ps-notif contracts:gen` regenerates `contract.yaml` from the Zod endpoint
definitions; `contracts:check` regenerates and diffs, failing on drift. The generated file is
committed. The SSE endpoint is documented in the contract as `text/event-stream` per the spec.

## Pact

Consumer test drives this package's own SDK against a Pact mock; provider verification replays
the pact against the real handlers on a `node:http` server (ADR-0007). SSE is excluded from Pact
(Pact has no SSE interaction type; SSE is tested directly in `sse.test.ts`).
`@pact-foundation/pact-core` ships no native binary for `win32-arm64`, so the Pact suite
self-skips on that platform with a notice; it runs everywhere else (CI runners are x64).

## Storage and tenancy

Notifications are stored in-memory per ADR-0008. The store is tenant-scoped (every notification
carries a `tenantId`; the list/get/update operations take a `tenantId` argument). Recipient
scoping is by `to` (userId). No durability across process restarts — acceptable for the blueprint
proof. A production-storage ADR is mandatory before real deployment.

The `x-dbp-session` header (base64-encoded JSON Session from PS.AUTH) carries the userId+tenantId
for the read/stream endpoints. The send endpoint uses `x-tenant-id` (the same convention as other
stateful PS.* services) so background server tasks can send notifications without a full session.

## Semver policy

- Patch: bug fixes; new env var support (e.g. SMTP_FROM); heartbeat interval tuning.
- Minor: new channel adapter implementations; new optional notification fields; new SDK exports.
- Major: breaking changes to wire types (Notification schema), contract shape, or SDK signatures.
