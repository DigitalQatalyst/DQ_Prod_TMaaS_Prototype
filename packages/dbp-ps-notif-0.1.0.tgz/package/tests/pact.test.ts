// @vitest-environment node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { beforeAll, describe, expect, it } from "vitest";
import {
  configureNotifClient,
  getNotifications,
  markAllRead,
  markRead,
  send,
} from "../client/index";
import {
  SEED_TENANT_ID,
  SEED_USER_ID,
  getNotifService,
  resetNotifService,
  seedNotifService,
  seedNotifications,
} from "../server/index";
import { startHandlerServer } from "./helpers/node-server";
import { makeSessionHeader } from "./helpers/bind";

/*
 * pact-core ships native binaries for these platforms only. Importing
 * @pact-foundation/pact on any other platform throws at module load, so the
 * import is dynamic and the suite self-skips (CI on linux-x64 always runs it).
 */
const PACT_PLATFORMS = ["darwin-arm64", "darwin-x64", "linux-arm64", "linux-x64", "win32-x64"];
const hostPlatform = `${process.platform}-${process.arch}`;
const pactSupported = PACT_PLATFORMS.includes(hostPlatform);
if (!pactSupported) {
  console.warn(
    `PACT TESTS SKIPPED: pact-core has no native binary for ${hostPlatform}. ` +
      `Run the suite on one of: ${PACT_PLATFORMS.join(", ")}.`,
  );
}

type PactModule = typeof import("@pact-foundation/pact");
let pact: PactModule;

const pactDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "pacts");
const CONSUMER = "dbp-ps-notif-client";
const PROVIDER = "dbp-ps-notif";

const TEST_TENANT = SEED_TENANT_ID;
const TEST_USER = SEED_USER_ID;
const EXISTING_ID = seedNotifications[0]!.id;

const sessionHeader = makeSessionHeader(TEST_USER, TEST_TENANT);
const tenantHeaders = { "x-tenant-id": TEST_TENANT };
const sessionHeaders = { "x-dbp-session": sessionHeader };
const jsonTenantHeaders = { ...tenantHeaders, "content-type": "application/json" };

function newPact(): InstanceType<PactModule["PactV3"]> {
  return new pact.PactV3({ consumer: CONSUMER, provider: PROVIDER, dir: pactDir });
}

function bindClientTo(mockServerUrl: string): void {
  configureNotifClient({
    baseUrl: `${mockServerUrl}/api/platform/notif`,
    fetch: (input, init) => globalThis.fetch(input, init),
    tenantId: TEST_TENANT,
  });
}

function notifMatcher() {
  const { like, uuid, datetime, string } = pact.MatchersV3;
  return {
    id: uuid(EXISTING_ID),
    to: like(TEST_USER),
    type: like("invoice.submitted"),
    message: like("Invoice INV-001 has been submitted for approval."),
    channel: like("in-app"),
    status: like("unread"),
    ts: datetime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "2026-01-01T09:00:00.000Z"),
    tenantId: like(TEST_TENANT),
    link: string("https://example.com/invoices/e-001"),
  };
}

describe.skipIf(!pactSupported)(
  "Pact — consumer (client SDK against the mock provider)",
  () => {
    beforeAll(async () => {
      pact = await import("@pact-foundation/pact");
    });

    it("sends a notification (POST /send)", async () => {
      const provider = newPact();
      provider
        .given("tenant is ready to receive notifications")
        .uponReceiving("a request to send an in-app notification")
        .withRequest({
          method: "POST",
          path: "/api/platform/notif/send",
          headers: jsonTenantHeaders,
          body: {
            to: TEST_USER,
            type: "invoice.submitted",
            message: "Invoice INV-001 has been submitted for approval.",
            channel: "in-app",
            link: "https://example.com/invoices/e-001",
          },
        })
        .willRespondWith({
          status: 201,
          headers: { "content-type": "application/json" },
          body: notifMatcher(),
        });

      await provider.executeTest(async (mockServer) => {
        bindClientTo(mockServer.url);
        await expect(
          send({
            to: TEST_USER,
            type: "invoice.submitted",
            message: "Invoice INV-001 has been submitted for approval.",
            channel: "in-app",
            link: "https://example.com/invoices/e-001",
          }),
        ).resolves.toBeUndefined();
      });
    });

    it("fetches notifications (GET /notifications)", async () => {
      const { eachLike } = pact.MatchersV3;
      const provider = newPact();
      provider
        .given("the tenant has seeded notifications")
        .uponReceiving("a request to get notifications for the session user")
        .withRequest({
          method: "GET",
          path: "/api/platform/notif/notifications",
          headers: sessionHeaders,
        })
        .willRespondWith({
          status: 200,
          headers: { "content-type": "application/json" },
          body: {
            items: eachLike(notifMatcher()),
            unread: pact.MatchersV3.like(1),
          },
        });

      await provider.executeTest(async (mockServer) => {
        bindClientTo(mockServer.url);
        const result = await getNotifications(sessionHeader);
        expect(result.items.length).toBeGreaterThan(0);
      });
    });

    it("marks a notification read (POST /notifications/:id/read)", async () => {
      const provider = newPact();
      provider
        .given("the tenant has seeded notifications")
        .uponReceiving("a request to mark a notification as read")
        .withRequest({
          method: "POST",
          path: `/api/platform/notif/notifications/${EXISTING_ID}/read`,
          headers: sessionHeaders,
        })
        .willRespondWith({
          status: 200,
          headers: { "content-type": "application/json" },
          body: { ...notifMatcher(), status: pact.MatchersV3.like("read") },
        });

      await provider.executeTest(async (mockServer) => {
        bindClientTo(mockServer.url);
        await expect(markRead(EXISTING_ID, sessionHeader)).resolves.toBeUndefined();
      });
    });

    it("marks all notifications read (POST /notifications/read-all)", async () => {
      const { like } = pact.MatchersV3;
      const provider = newPact();
      provider
        .given("the tenant has seeded notifications")
        .uponReceiving("a request to mark all notifications as read")
        .withRequest({
          method: "POST",
          path: "/api/platform/notif/notifications/read-all",
          headers: sessionHeaders,
        })
        .willRespondWith({
          status: 200,
          headers: { "content-type": "application/json" },
          body: { updated: like(0) },
        });

      await provider.executeTest(async (mockServer) => {
        bindClientTo(mockServer.url);
        await expect(markAllRead(sessionHeader)).resolves.toBeUndefined();
      });
    });
  },
);

describe.skipIf(!pactSupported)(
  "Pact — provider (handlers on node:http verify the pact)",
  () => {
    beforeAll(async () => {
      pact = await import("@pact-foundation/pact");
    });

    it("verifies every interaction in the generated pact file", async () => {
      const pactFile = path.join(pactDir, `${CONSUMER}-${PROVIDER}.json`);
      expect(fs.existsSync(pactFile)).toBe(true);

      const server = await startHandlerServer();
      try {
        const output = await new pact.Verifier({
          provider: PROVIDER,
          providerBaseUrl: server.url,
          pactUrls: [pactFile],
          logLevel: "error",
          stateHandlers: {
            "tenant is ready to receive notifications": async () => {
              resetNotifService();
              return "reset";
            },
            "the tenant has seeded notifications": async () => {
              resetNotifService();
              await seedNotifService();
              // Ensure the pact session user matches seeded data
              const existing = await getNotifService().storage.get(TEST_TENANT, EXISTING_ID);
              if (!existing) {
                // Add the specific notification if not already seeded for that user
                await getNotifService().storage.put(TEST_TENANT, {
                  ...seedNotifications[0]!,
                  to: TEST_USER,
                  tenantId: TEST_TENANT,
                });
              }
              return "seeded";
            },
          },
        }).verifyProvider();
        expect(output).toContain("finished");
      } finally {
        await server.close();
      }
    });
  },
);
