import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { renderHook, act, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it } from "vitest";
import { configureNotifClient, resetNotifClient, useNotifications } from "../client/index";
import { dispatch } from "../server/index";
import { resetNotifService } from "../server/index";
import {
  TEST_TENANT,
  TEST_USER,
  makeSessionHeader,
} from "./helpers/bind";
import type { Notification } from "../client/types";

const sessionHeader = makeSessionHeader(TEST_USER, TEST_TENANT);

function wrapper() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client }, children);
}

beforeEach(() => {
  resetNotifService();
  resetNotifClient();
  configureNotifClient({
    baseUrl: "http://ps-notif.test/api/platform/notif",
    fetch: (input, init) => dispatch(new Request(input, init)),
  });
});

async function seedNotification(to = TEST_USER): Promise<Notification> {
  const body = { to, type: "test.event", message: "Hook test", channel: "in-app" };
  const req = new Request("http://ps-notif.test/api/platform/notif/send", {
    method: "POST",
    headers: { "content-type": "application/json", "x-tenant-id": TEST_TENANT },
    body: JSON.stringify(body),
  });
  const res = await dispatch(req);
  return (await res.json()) as Notification;
}

describe("useNotifications hook", () => {
  it("returns items and unread count", async () => {
    await seedNotification();
    await seedNotification();

    const { result } = renderHook(() => useNotifications(sessionHeader), { wrapper: wrapper() });

    await waitFor(() => expect(result.current.isLoading).toBe(false));

    expect(result.current.items).toHaveLength(2);
    expect(result.current.unread).toBe(2);
  });

  it("markRead reduces unread count", async () => {
    const notif = await seedNotification();

    const { result } = renderHook(() => useNotifications(sessionHeader), { wrapper: wrapper() });
    await waitFor(() => expect(result.current.items).toHaveLength(1));

    act(() => {
      result.current.markRead(notif.id);
    });

    await waitFor(() => expect(result.current.unread).toBe(0));
  });

  it("markAllRead clears all unread", async () => {
    await seedNotification();
    await seedNotification();

    const { result } = renderHook(() => useNotifications(sessionHeader), { wrapper: wrapper() });
    await waitFor(() => expect(result.current.unread).toBe(2));

    act(() => {
      result.current.markAllRead();
    });

    await waitFor(() => expect(result.current.unread).toBe(0));
  });
});
