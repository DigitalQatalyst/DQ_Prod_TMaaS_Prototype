import http from "node:http";
import type { AddressInfo } from "node:net";
import { dispatch } from "../../server/index";

export type RunningServer = { url: string; close: () => Promise<void> };

export async function startHandlerServer(): Promise<RunningServer> {
  const server = http.createServer((incoming, outgoing) => {
    const chunks: Buffer[] = [];
    incoming.on("data", (chunk: Buffer) => chunks.push(chunk));
    incoming.on("end", () => {
      void (async () => {
        const headers = new Headers();
        for (const [name, value] of Object.entries(incoming.headers)) {
          if (typeof value === "string") headers.set(name, value);
          else if (Array.isArray(value)) headers.set(name, value.join(", "));
        }
        const method = incoming.method ?? "GET";
        const body = Buffer.concat(chunks);
        const request = new Request(`http://127.0.0.1${incoming.url ?? "/"}`, {
          method,
          headers,
          body: method === "GET" || method === "HEAD" || body.length === 0 ? null : body,
        });
        const response = await dispatch(request);
        outgoing.writeHead(response.status, Object.fromEntries(response.headers.entries()));
        outgoing.end(Buffer.from(await response.arrayBuffer()));
      })().catch((error) => {
        outgoing.writeHead(500, { "content-type": "application/json" });
        outgoing.end(JSON.stringify({ error: String(error) }));
      });
    });
  });

  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const { port } = server.address() as AddressInfo;
  return {
    url: `http://127.0.0.1:${port}`,
    close: () =>
      new Promise<void>((resolve, reject) =>
        server.close((error) => (error ? reject(error) : resolve())),
      ),
  };
}
