import type { Session } from "@dbp/contracts/session";
import { configureNotifClient } from "../../client/index";
import { dispatch } from "../../server/index";

export const TEST_TENANT = "tenant-a";
export const OTHER_TENANT = "tenant-b";
export const TEST_USER = "u-test";
export const OTHER_USER = "u-other";

export function makeSessionHeader(userId: string, tenantId: string): string {
  const session: Session = {
    userId,
    email: `${userId}@example.com`,
    roles: ["member"],
    tenantId,
    exp: Math.floor(Date.now() / 1000) + 3600,
  };
  return Buffer.from(JSON.stringify(session)).toString("base64");
}

export function bindClientToHandlers(): void {
  configureNotifClient({
    baseUrl: "http://ps-notif.test/api/platform/notif",
    fetch: (input, init) => dispatch(new Request(input, init)),
  });
}

export function rawRequest(
  method: string,
  path: string,
  options: {
    body?: unknown;
    tenantId?: string | null;
    sessionHeader?: string | null;
  } = {},
): Promise<Response> {
  const headers: Record<string, string> = {};
  if (options.tenantId !== null) {
    headers["x-tenant-id"] = options.tenantId ?? TEST_TENANT;
  }
  if (options.sessionHeader !== null && options.sessionHeader !== undefined) {
    headers["x-dbp-session"] = options.sessionHeader;
  }
  if (options.body !== undefined) headers["content-type"] = "application/json";
  return dispatch(
    new Request(`http://ps-notif.test/api/platform/notif${path}`, {
      method,
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : null,
    }),
  );
}
