// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import type { Notification } from "../client/types";
import {
  SEED_TENANT_ID,
  SEED_USER_ID,
  getNotifService,
  renderedEmails,
  resetEmailTransporter,
  resetNotifService,
  seedNotifService,
} from "../server/index";
import {
  OTHER_TENANT,
  OTHER_USER,
  TEST_TENANT,
  TEST_USER,
  makeSessionHeader,
  rawRequest,
} from "./helpers/bind";

type NotifListBody = { items: Notification[]; unread: number };

const defaultSession = makeSessionHeader(TEST_USER, TEST_TENANT);
const otherUserSession = makeSessionHeader(OTHER_USER, TEST_TENANT);
const otherTenantSession = makeSessionHeader(TEST_USER, OTHER_TENANT);

async function sendNotif(
  overrides: Partial<{
    to: string;
    type: string;
    message: string;
    channel: "in-app" | "email" | "sms";
    link: string;
    tenantId: string;
  }> = {},
): Promise<Notification> {
  const body = {
    to: overrides.to ?? TEST_USER,
    type: overrides.type ?? "test.event",
    message: overrides.message ?? "Test notification",
    channel: overrides.channel ?? ("in-app" as const),
    ...(overrides.link ? { link: overrides.link } : {}),
  };
  const response = await rawRequest("POST", "/send", {
    body,
    tenantId: overrides.tenantId ?? TEST_TENANT,
  });
  expect(response.status).toBe(201);
  return (await response.json()) as Notification;
}

beforeEach(() => {
  resetNotifService();
  resetEmailTransporter();
});

// ---------------------------------------------------------------------------
// POST /send
// ---------------------------------------------------------------------------

describe("POST /send", () => {
  it("sends an in-app notification and persists it", async () => {
    const notif = await sendNotif();
    expect(notif.id).toMatch(/^[0-9a-f-]{36}$/);
    expect(notif.to).toBe(TEST_USER);
    expect(notif.channel).toBe("in-app");
    expect(notif.status).toBe("unread");
    expect(notif.tenantId).toBe(TEST_TENANT);

    const stored = await getNotifService().storage.get(TEST_TENANT, notif.id);
    expect(stored).toBeDefined();
    expect(stored?.id).toBe(notif.id);
  });

  it("sends an email notification and captures via jsonTransport", async () => {
    const notif = await sendNotif({ channel: "email", to: "user@example.com" });
    expect(notif.channel).toBe("email");
    expect(renderedEmails).toHaveLength(1);
    expect(renderedEmails[0]?.to).toBe("user@example.com");
    expect(renderedEmails[0]?.subject).toContain("test.event");

    // Email channel does not persist in-app store.
    const stored = await getNotifService().storage.get(TEST_TENANT, notif.id);
    expect(stored).toBeUndefined();
  });

  it("email with link includes link in text", async () => {
    await sendNotif({ channel: "email", to: "u@example.com", link: "https://example.com/foo" });
    expect(renderedEmails[0]?.text).toContain("https://example.com/foo");
  });

  it("wires sms adapter but it throws NotImplemented", async () => {
    const response = await rawRequest("POST", "/send", {
      body: { to: TEST_USER, type: "test", message: "hello", channel: "sms" },
      tenantId: TEST_TENANT,
    });
    expect(response.status).toBe(500);
  });

  it("requires x-tenant-id header", async () => {
    const response = await rawRequest("POST", "/send", {
      body: { to: TEST_USER, type: "t", message: "m", channel: "in-app" },
      tenantId: null,
    });
    expect(response.status).toBe(400);
  });

  it("rejects invalid body", async () => {
    const response = await rawRequest("POST", "/send", {
      body: { message: "missing required fields" },
      tenantId: TEST_TENANT,
    });
    expect(response.status).toBe(400);
    const body = (await response.json()) as { issues?: unknown[] };
    expect(body.issues?.length).toBeGreaterThan(0);
  });

  it("rejects invalid channel", async () => {
    const response = await rawRequest("POST", "/send", {
      body: { to: TEST_USER, type: "t", message: "m", channel: "fax" },
      tenantId: TEST_TENANT,
    });
    expect(response.status).toBe(400);
  });
});

// ---------------------------------------------------------------------------
// GET /notifications
// ---------------------------------------------------------------------------

describe("GET /notifications", () => {
  it("returns notifications for the session user", async () => {
    await sendNotif({ to: TEST_USER });
    await sendNotif({ to: TEST_USER });
    await sendNotif({ to: OTHER_USER });

    const response = await rawRequest("GET", "/notifications", {
      sessionHeader: defaultSession,
    });
    expect(response.status).toBe(200);
    const body = (await response.json()) as NotifListBody;
    expect(body.items).toHaveLength(2);
    expect(body.items.every((n) => n.to === TEST_USER)).toBe(true);
    expect(body.unread).toBe(2);
  });

  it("returns correct unread count", async () => {
    await sendNotif({ to: TEST_USER });
    const second = await sendNotif({ to: TEST_USER });

    // Mark one read directly in storage.
    await getNotifService().storage.update(TEST_TENANT, second.id, { status: "read" });

    const response = await rawRequest("GET", "/notifications", {
      sessionHeader: defaultSession,
    });
    const body = (await response.json()) as NotifListBody;
    expect(body.items).toHaveLength(2);
    expect(body.unread).toBe(1);
  });

  it("requires valid session header", async () => {
    const response = await rawRequest("GET", "/notifications");
    expect(response.status).toBe(401);
  });
});

// ---------------------------------------------------------------------------
// POST /notifications/:id/read
// ---------------------------------------------------------------------------

describe("POST /notifications/:id/read", () => {
  it("marks a notification as read", async () => {
    const notif = await sendNotif({ to: TEST_USER });

    const response = await rawRequest("POST", `/notifications/${notif.id}/read`, {
      sessionHeader: defaultSession,
    });
    expect(response.status).toBe(200);
    const body = (await response.json()) as Notification;
    expect(body.status).toBe("read");
    expect(body.id).toBe(notif.id);
  });

  it("404s for another user's notification", async () => {
    const notif = await sendNotif({ to: TEST_USER });
    const response = await rawRequest("POST", `/notifications/${notif.id}/read`, {
      sessionHeader: otherUserSession,
    });
    expect(response.status).toBe(404);
  });

  it("requires valid session", async () => {
    const notif = await sendNotif({ to: TEST_USER });
    const response = await rawRequest("POST", `/notifications/${notif.id}/read`);
    expect(response.status).toBe(401);
  });
});

// ---------------------------------------------------------------------------
// POST /notifications/read-all
// ---------------------------------------------------------------------------

describe("POST /notifications/read-all", () => {
  it("marks all unread notifications for the session user as read", async () => {
    await sendNotif({ to: TEST_USER });
    await sendNotif({ to: TEST_USER });
    await sendNotif({ to: OTHER_USER });

    const response = await rawRequest("POST", "/notifications/read-all", {
      sessionHeader: defaultSession,
    });
    expect(response.status).toBe(200);

    const listResponse = await rawRequest("GET", "/notifications", {
      sessionHeader: defaultSession,
    });
    const body = (await listResponse.json()) as NotifListBody;
    expect(body.unread).toBe(0);
    expect(body.items).toHaveLength(2);

    // Other user's notification is unaffected.
    const otherResponse = await rawRequest("GET", "/notifications", {
      sessionHeader: otherUserSession,
    });
    const otherBody = (await otherResponse.json()) as NotifListBody;
    expect(otherBody.unread).toBe(1);
  });

  it("requires valid session", async () => {
    const response = await rawRequest("POST", "/notifications/read-all");
    expect(response.status).toBe(401);
  });
});

// ---------------------------------------------------------------------------
// Tenant isolation
// ---------------------------------------------------------------------------

describe("tenant isolation", () => {
  it("notifications are scoped to the session tenant", async () => {
    await sendNotif({ to: TEST_USER, tenantId: TEST_TENANT });
    await sendNotif({ to: TEST_USER, tenantId: OTHER_TENANT });

    const mine = await rawRequest("GET", "/notifications", { sessionHeader: defaultSession });
    const theirs = await rawRequest("GET", "/notifications", {
      sessionHeader: otherTenantSession,
    });

    const mineBody = (await mine.json()) as NotifListBody;
    const theirsBody = (await theirs.json()) as NotifListBody;

    expect(mineBody.items).toHaveLength(1);
    expect(theirsBody.items).toHaveLength(1);
    expect(mineBody.items[0]?.tenantId).toBe(TEST_TENANT);
    expect(theirsBody.items[0]?.tenantId).toBe(OTHER_TENANT);
  });
});

// ---------------------------------------------------------------------------
// Seed fixtures
// ---------------------------------------------------------------------------

describe("seed fixtures", () => {
  it("seeds deterministic demo data", async () => {
    await seedNotifService();
    const session = makeSessionHeader(SEED_USER_ID, SEED_TENANT_ID);
    const response = await rawRequest("GET", "/notifications", { sessionHeader: session });
    const body = (await response.json()) as NotifListBody;
    expect(body.items.length).toBeGreaterThan(0);
    expect(body.items.some((n) => n.type === "invoice.submitted")).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// Dispatch
// ---------------------------------------------------------------------------

describe("dispatch", () => {
  it("404s unknown routes", async () => {
    const response = await rawRequest("GET", "/nope");
    expect(response.status).toBe(404);
  });
});

// ---------------------------------------------------------------------------
// SLO probe: send→in-app visible p95 < 50ms
// ---------------------------------------------------------------------------

describe("SLO — send→in-app p95 < 50ms", () => {
  it("p95 of 100 send+persist round-trips is under 50ms", async () => {
    const N = 100;
    const times: number[] = [];

    for (let i = 0; i < N; i += 1) {
      const start = performance.now();
      await sendNotif({ to: TEST_USER, message: `SLO probe ${i}` });
      times.push(performance.now() - start);
    }

    times.sort((a, b) => a - b);
    const p95 = times[Math.floor(N * 0.95)]!;
    expect(p95).toBeLessThan(50);
  });
});
