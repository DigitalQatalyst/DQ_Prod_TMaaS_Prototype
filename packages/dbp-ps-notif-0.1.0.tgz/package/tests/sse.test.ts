// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import type { Notification } from "../client/types";
import { resetNotifService } from "../server/index";
import { sendHandler, streamHandler } from "../server/handlers";
import {
  TEST_TENANT,
  TEST_USER,
  makeSessionHeader,
} from "./helpers/bind";

function makeRequest(path: string, options: { sessionHeader?: string; tenantId?: string; body?: unknown; method?: string } = {}): Request {
  const headers: Record<string, string> = {};
  if (options.sessionHeader) headers["x-dbp-session"] = options.sessionHeader;
  if (options.tenantId) headers["x-tenant-id"] = options.tenantId;
  if (options.body) headers["content-type"] = "application/json";
  return new Request(`http://ps-notif.test/api/platform/notif${path}`, {
    method: options.method ?? "GET",
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : null,
  });
}

beforeEach(() => {
  resetNotifService();
});

describe("GET /stream", () => {
  it("requires valid session header", async () => {
    const response = await streamHandler(makeRequest("/stream"));
    expect(response.status).toBe(401);
  });

  it("returns SSE content-type for authenticated session", async () => {
    const session = makeSessionHeader(TEST_USER, TEST_TENANT);
    const response = await streamHandler(makeRequest("/stream", { sessionHeader: session }));
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toBe("text/event-stream");

    // Cancel the stream to avoid leaking the interval timer.
    await response.body?.cancel();
  });

  it("delivers a published notification then closes cleanly", async () => {
    const session = makeSessionHeader(TEST_USER, TEST_TENANT);
    const response = await streamHandler(makeRequest("/stream", { sessionHeader: session }));
    expect(response.status).toBe(200);

    const reader = response.body?.getReader();
    if (!reader) throw new Error("No body reader");

    const decoder = new TextDecoder();
    const received: string[] = [];

    // Read the first chunk (initial heartbeat).
    const heartbeatChunk = await reader.read();
    expect(heartbeatChunk.done).toBe(false);
    const heartbeatText = decoder.decode(heartbeatChunk.value);
    expect(heartbeatText).toContain(": heartbeat");

    // Now publish a notification via the send handler.
    const sendReq = makeRequest("/send", {
      method: "POST",
      tenantId: TEST_TENANT,
      body: { to: TEST_USER, type: "invoice.created", message: "hello SSE", channel: "in-app" },
    });
    const sendResponse = await sendHandler(sendReq);
    expect(sendResponse.status).toBe(201);
    const sentNotif = (await sendResponse.json()) as Notification;

    // Read the SSE data chunk.
    const dataChunk = await reader.read();
    expect(dataChunk.done).toBe(false);
    const dataText = decoder.decode(dataChunk.value);
    expect(dataText).toContain("data:");
    const parsed = JSON.parse(dataText.replace(/^data: /, "").trim()) as Notification;
    expect(parsed.id).toBe(sentNotif.id);
    expect(parsed.message).toBe("hello SSE");

    received.push(dataText);

    // Cancel and verify stream closes.
    await reader.cancel();
    expect(received).toHaveLength(1);
  });
});
