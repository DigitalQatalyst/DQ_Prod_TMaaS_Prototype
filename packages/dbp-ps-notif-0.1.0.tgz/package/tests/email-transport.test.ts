// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import {
  MsGraphTransport,
  SmtpTransport,
  _lastGraphPayload,
  getEmailTransport,
  renderedEmails,
  resetEmailTransport,
} from "../server/transport";
import {
  renderedEmails as adapterRenderedEmails,
  resetEmailTransporter,
} from "../server/adapters";
import {
  resetEmailRateLimiter,
  resetNotifService,
} from "../server/index";
import { rawRequest, TEST_TENANT, TEST_USER } from "./helpers/bind";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function setEnv(vars: Record<string, string>) {
  for (const [k, v] of Object.entries(vars)) {
    process.env[k] = v;
  }
}

function delEnv(...keys: string[]) {
  for (const k of keys) {
    delete process.env[k];
  }
}

beforeEach(() => {
  resetEmailTransport();
  resetEmailTransporter();
  resetNotifService();
  resetEmailRateLimiter();
  delEnv(
    "NOTIF_EMAIL_TRANSPORT",
    "NOTIF_EMAIL_CAPTURE",
    "SMTP_URL",
    "MSGRAPH_TENANT_ID",
    "MSGRAPH_CLIENT_ID",
    "MSGRAPH_CLIENT_SECRET",
    "MSGRAPH_SENDER_UPN",
  );
});

// ---------------------------------------------------------------------------
// Transport selection
// ---------------------------------------------------------------------------

describe("transport selection", () => {
  it("defaults to SmtpTransport when NOTIF_EMAIL_TRANSPORT is unset", () => {
    const transport = getEmailTransport();
    expect(transport).toBeInstanceOf(SmtpTransport);
  });

  it("returns SmtpTransport when NOTIF_EMAIL_TRANSPORT=smtp", () => {
    setEnv({ NOTIF_EMAIL_TRANSPORT: "smtp" });
    const transport = getEmailTransport();
    expect(transport).toBeInstanceOf(SmtpTransport);
  });

  it("returns MsGraphTransport when NOTIF_EMAIL_TRANSPORT=msgraph", () => {
    setEnv({ NOTIF_EMAIL_TRANSPORT: "msgraph" });
    const transport = getEmailTransport();
    expect(transport).toBeInstanceOf(MsGraphTransport);
  });

  it("memoises — same instance returned on second call", () => {
    const a = getEmailTransport();
    const b = getEmailTransport();
    expect(a).toBe(b);
  });

  it("resetEmailTransport clears the memo so a new transport is created", () => {
    const a = getEmailTransport();
    resetEmailTransport();
    setEnv({ NOTIF_EMAIL_TRANSPORT: "msgraph" });
    const b = getEmailTransport();
    expect(b).not.toBe(a);
    expect(b).toBeInstanceOf(MsGraphTransport);
  });
});

// ---------------------------------------------------------------------------
// SmtpTransport dev capture
// ---------------------------------------------------------------------------

describe("SmtpTransport — dev capture (no SMTP_URL)", () => {
  it("captures a plain-text email into renderedEmails without network", async () => {
    const transport = new SmtpTransport();
    await transport.send({ to: "a@example.com", subject: "Hello", text: "World" });
    expect(renderedEmails).toHaveLength(1);
    expect(renderedEmails[0]?.to).toBe("a@example.com");
    expect(renderedEmails[0]?.subject).toBe("Hello");
    expect(renderedEmails[0]?.text).toBe("World");
  });

  it("captures an html email", async () => {
    const transport = new SmtpTransport();
    await transport.send({ to: "b@example.com", subject: "Rich", html: "<b>Bold</b>", text: "Bold" });
    expect(renderedEmails[0]?.html).toBe("<b>Bold</b>");
  });
});

// ---------------------------------------------------------------------------
// MsGraphTransport — capture mode (NOTIF_EMAIL_CAPTURE=1)
// ---------------------------------------------------------------------------

describe("MsGraphTransport — capture mode", () => {
  beforeEach(() => {
    setEnv({
      NOTIF_EMAIL_TRANSPORT: "msgraph",
      NOTIF_EMAIL_CAPTURE: "1",
      MSGRAPH_TENANT_ID: "test-tenant",
      MSGRAPH_CLIENT_ID: "test-client",
      MSGRAPH_CLIENT_SECRET: "test-secret",
      MSGRAPH_SENDER_UPN: "sender@example.com",
    });
  });

  it("captures email without hitting the network", async () => {
    const transport = new MsGraphTransport();
    await transport.send({
      to: "recipient@example.com",
      subject: "Test subject",
      html: "<p>Hello world</p>",
      replyTo: "reply@example.com",
      cc: "cc@example.com",
    });
    expect(renderedEmails).toHaveLength(1);
    expect(renderedEmails[0]?.to).toBe("recipient@example.com");
    expect(renderedEmails[0]?.subject).toBe("Test subject");
    expect(renderedEmails[0]?.html).toBe("<p>Hello world</p>");
  });

  it("builds a well-formed MS Graph sendMail payload", async () => {
    const { _lastGraphPayload: payload, renderedEmails: re } = await import("../server/transport");
    const transport = new MsGraphTransport();
    await transport.send({
      to: "recipient@example.com",
      subject: "Graph payload test",
      html: "<p>Hello</p>",
      replyTo: "reply@example.com",
      cc: ["cc1@example.com", "cc2@example.com"],
    });

    // Inspect via the last captured payload
    const captured = re[0]?.raw as {
      message: {
        subject: string;
        body: { contentType: string; content: string };
        toRecipients: { emailAddress: { address: string } }[];
        replyTo: { emailAddress: { address: string } }[];
        ccRecipients: { emailAddress: { address: string } }[];
      };
    };

    expect(captured.message.subject).toBe("Graph payload test");
    expect(captured.message.body.contentType).toBe("HTML");
    expect(captured.message.body.content).toBe("<p>Hello</p>");
    expect(captured.message.toRecipients[0]?.emailAddress.address).toBe("recipient@example.com");
    expect(captured.message.replyTo[0]?.emailAddress.address).toBe("reply@example.com");
    expect(captured.message.ccRecipients).toHaveLength(2);
    expect(captured.message.ccRecipients[0]?.emailAddress.address).toBe("cc1@example.com");
    expect(captured.message.ccRecipients[1]?.emailAddress.address).toBe("cc2@example.com");
  });

  it("uses Text contentType when only text is provided", async () => {
    const transport = new MsGraphTransport();
    await transport.send({ to: "t@example.com", subject: "Text only", text: "Plain text" });
    const captured = renderedEmails[0]?.raw as { message: { body: { contentType: string } } };
    expect(captured.message.body.contentType).toBe("Text");
  });
});

// ---------------------------------------------------------------------------
// MsGraphTransport — no-env capture fallback (env vars absent)
// ---------------------------------------------------------------------------

describe("MsGraphTransport — no-env capture fallback", () => {
  it("captures into renderedEmails when MSGRAPH env vars are absent", async () => {
    setEnv({ NOTIF_EMAIL_TRANSPORT: "msgraph" });
    // No MSGRAPH_* vars set, no NOTIF_EMAIL_CAPTURE
    const transport = new MsGraphTransport();
    await transport.send({ to: "x@example.com", subject: "No env", text: "body" });
    expect(renderedEmails).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------
// POST /email handler — happy path
// ---------------------------------------------------------------------------

describe("POST /email — happy path", () => {
  it("returns 202 and captures the email (smtp dev mode)", async () => {
    const response = await rawRequest("POST", "/email", {
      body: { to: "user@example.com", subject: "Welcome", text: "Hello there" },
    });
    expect(response.status).toBe(202);
    const body = (await response.json()) as { sent: boolean };
    expect(body.sent).toBe(true);
    expect(renderedEmails).toHaveLength(1);
    expect(renderedEmails[0]?.to).toBe("user@example.com");
    expect(renderedEmails[0]?.subject).toBe("Welcome");
  });

  it("accepts html + text together", async () => {
    const response = await rawRequest("POST", "/email", {
      body: { to: "u@example.com", subject: "Rich", html: "<p>Hi</p>", text: "Hi" },
    });
    expect(response.status).toBe(202);
    expect(renderedEmails[0]?.html).toBe("<p>Hi</p>");
  });

  it("accepts replyTo and cc fields", async () => {
    const response = await rawRequest("POST", "/email", {
      body: {
        to: "u@example.com",
        subject: "With extras",
        text: "body",
        replyTo: "reply@example.com",
        cc: ["cc1@example.com", "cc2@example.com"],
      },
    });
    expect(response.status).toBe(202);
  });
});

// ---------------------------------------------------------------------------
// POST /email — validation 400
// ---------------------------------------------------------------------------

describe("POST /email — validation errors", () => {
  it("400 when to is missing", async () => {
    const response = await rawRequest("POST", "/email", {
      body: { subject: "No to", text: "body" },
    });
    expect(response.status).toBe(400);
    const body = (await response.json()) as { error: string; issues?: unknown[] };
    expect(body.issues?.length).toBeGreaterThan(0);
  });

  it("400 when subject is missing", async () => {
    const response = await rawRequest("POST", "/email", {
      body: { to: "u@example.com", text: "body" },
    });
    expect(response.status).toBe(400);
  });

  it("400 when neither html nor text is present", async () => {
    const response = await rawRequest("POST", "/email", {
      body: { to: "u@example.com", subject: "No body" },
    });
    expect(response.status).toBe(400);
    const body = (await response.json()) as { error: string; issues?: { message: string }[] };
    expect(body.issues?.some((i) => i.message.includes("html") || i.message.includes("text"))).toBe(
      true,
    );
  });

  it("400 when replyTo is not a valid email", async () => {
    const response = await rawRequest("POST", "/email", {
      body: { to: "u@example.com", subject: "Bad replyTo", text: "body", replyTo: "not-an-email" },
    });
    expect(response.status).toBe(400);
  });
});

// ---------------------------------------------------------------------------
// POST /email — IP rate limiting (429 after 5 requests)
// ---------------------------------------------------------------------------

describe("POST /email — rate limiting", () => {
  it("429 after 5 requests from the same IP", async () => {
    const payload = { to: "u@example.com", subject: "Rate test", text: "body" };

    for (let i = 0; i < 5; i++) {
      const res = await rawRequest("POST", "/email", { body: payload });
      expect(res.status).toBe(202);
    }

    const res6 = await rawRequest("POST", "/email", { body: payload });
    expect(res6.status).toBe(429);
    const body = (await res6.json()) as { error: string };
    expect(body.error).toContain("Too many requests");
  });
});

// ---------------------------------------------------------------------------
// Back-compat: EmailChannelAdapter (notification → email) still captures
// ---------------------------------------------------------------------------

describe("EmailChannelAdapter back-compat", () => {
  it("notification sent via email channel still captures in renderedEmails", async () => {
    const response = await rawRequest("POST", "/send", {
      body: { to: "user@example.com", type: "test.event", message: "Test message", channel: "email" },
      tenantId: TEST_TENANT,
    });
    expect(response.status).toBe(201);
    // Both adapterRenderedEmails (re-export) and renderedEmails (transport) are the same array
    expect(adapterRenderedEmails).toHaveLength(1);
    expect(adapterRenderedEmails[0]?.to).toBe("user@example.com");
    expect(adapterRenderedEmails[0]?.subject).toContain("test.event");
  });
});
