import { SessionSchema } from "@dbp/contracts/session";
import {
  NotificationSchema,
  NotificationsResponseSchema,
  SendEmailRequestSchema,
  SendNotificationRequestSchema,
  type ValidationIssue,
} from "../client/types";
import { InAppChannelAdapter } from "./adapters";
import {
  getNotifService,
  registerSsePusher,
  unregisterSsePusher,
  type SsePusher,
} from "./service";
import { getEmailTransport } from "./transport";

export const BASE_PATH = "/api/platform/notif";

export type RouteHandler = (req: Request) => Promise<Response>;

export type RouteDefinition = {
  method: "GET" | "POST" | "PATCH" | "DELETE";
  path: string;
  handler: RouteHandler;
};

const json = (status: number, body: unknown): Response =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });

const errorResponse = (status: number, message: string, issues?: ValidationIssue[]): Response =>
  json(status, issues && issues.length > 0 ? { error: message, issues } : { error: message });

function pathSegments(req: Request): string[] {
  const { pathname } = new URL(req.url);
  if (!pathname.startsWith(BASE_PATH)) return [];
  return pathname
    .slice(BASE_PATH.length)
    .split("/")
    .filter(Boolean)
    .map(decodeURIComponent);
}

function tenantOf(req: Request): string | null {
  const tenantId = req.headers.get("x-tenant-id")?.trim();
  return tenantId ? tenantId : null;
}

function sessionOf(req: Request): { userId: string; tenantId: string } | null {
  const raw = req.headers.get("x-dbp-session");
  if (!raw) return null;
  try {
    const decoded = JSON.parse(Buffer.from(raw, "base64").toString("utf8")) as unknown;
    const parsed = SessionSchema.safeParse(decoded);
    return parsed.success ? { userId: parsed.data.userId, tenantId: parsed.data.tenantId } : null;
  } catch {
    return null;
  }
}

async function readJsonBody(req: Request): Promise<{ ok: true; value: unknown } | { ok: false }> {
  try {
    return { ok: true, value: await req.json() };
  } catch {
    return { ok: false };
  }
}

const zodIssues = (issues: { path: (string | number)[]; message: string }[]): ValidationIssue[] =>
  issues.map((issue) => ({ path: issue.path.join(".") || "(root)", message: issue.message }));

// ---------------------------------------------------------------------------
// POST /send — validate, dispatch to channel adapter, persist in-app
// ---------------------------------------------------------------------------

export const sendHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");

  const parsed = SendNotificationRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid send notification request", zodIssues(parsed.error.issues));
  }

  const svc = getNotifService();
  const notification = NotificationSchema.parse({
    id: crypto.randomUUID(),
    to: parsed.data.to,
    type: parsed.data.type,
    message: parsed.data.message,
    link: parsed.data.link,
    channel: parsed.data.channel,
    status: "unread",
    ts: new Date().toISOString(),
    tenantId,
  });

  const channel = parsed.data.channel;

  try {
    if (channel === "in-app") {
      // In-app: persist and broadcast via SSE.
      const inAppAdapter = new InAppChannelAdapter(
        svc.storage,
        tenantId,
        (userId, notif) => svc.broadcast(tenantId, userId, notif),
      );
      await inAppAdapter.deliver(notification);
    } else {
      // Email/SMS: use the service-level adapter (no persistence for non-in-app).
      const adapter = svc.adapters[channel];
      await adapter.deliver(notification);
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return json(500, { error: message });
  }

  return json(201, notification);
};

// ---------------------------------------------------------------------------
// GET /notifications — list for the session user, with unread count
// ---------------------------------------------------------------------------

export const getNotificationsHandler: RouteHandler = async (req) => {
  const session = sessionOf(req);
  if (!session) return errorResponse(401, "Valid x-dbp-session header is required");

  const svc = getNotifService();
  const result = await svc.storage.list(session.tenantId, { userId: session.userId });
  const unread = result.items.filter((n) => n.status === "unread").length;

  return json(
    200,
    NotificationsResponseSchema.parse({ items: result.items, unread }),
  );
};

// ---------------------------------------------------------------------------
// POST /notifications/:id/read — mark a single notification read
// ---------------------------------------------------------------------------

export const markReadHandler: RouteHandler = async (req) => {
  const session = sessionOf(req);
  if (!session) return errorResponse(401, "Valid x-dbp-session header is required");

  const segments = pathSegments(req);
  // segments: ["notifications", ":id", "read"]
  const id = segments[1];
  if (!id) return errorResponse(404, "notification not found");

  const svc = getNotifService();
  const existing = await svc.storage.get(session.tenantId, id);
  if (!existing) return errorResponse(404, `no notification with id ${id}`);
  if (existing.to !== session.userId) return errorResponse(404, `no notification with id ${id}`);

  const updated = await svc.storage.update(session.tenantId, id, { status: "read" });
  return json(200, updated);
};

// ---------------------------------------------------------------------------
// POST /notifications/read-all — mark all notifications for the session user read
// ---------------------------------------------------------------------------

export const markAllReadHandler: RouteHandler = async (req) => {
  const session = sessionOf(req);
  if (!session) return errorResponse(401, "Valid x-dbp-session header is required");

  const svc = getNotifService();
  const result = await svc.storage.list(session.tenantId, { userId: session.userId });
  for (const notif of result.items) {
    if (notif.status === "unread") {
      await svc.storage.update(session.tenantId, notif.id, { status: "read" });
    }
  }
  return json(200, { updated: result.items.filter((n) => n.status === "unread").length });
};

// ---------------------------------------------------------------------------
// GET /stream — SSE stream for in-app notifications
//
// Reconnect semantics:
//   - Client sends Last-Event-ID header; the server does not replay history
//     (in-memory store has no ordering index for resumption in Phase 2).
//   - Client should reconnect after 30 s of no heartbeat.
//   - Heartbeats are sent as SSE comment lines (": heartbeat") every 15 s.
//   - On reconnect, the client should call GET /notifications to re-hydrate state.
// ---------------------------------------------------------------------------

const SSE_HEARTBEAT_INTERVAL_MS = 15_000;

export const streamHandler: RouteHandler = async (req) => {
  const session = sessionOf(req);
  if (!session) {
    return errorResponse(401, "Valid x-dbp-session header is required");
  }

  const { tenantId, userId } = session;

  const encoder = new TextEncoder();
  let heartbeatTimer: ReturnType<typeof setInterval> | undefined;
  let pusher!: SsePusher;

  const byteStream = new ReadableStream<Uint8Array>({
    start(ctrl) {
      pusher = (data: string) => ctrl.enqueue(encoder.encode(data));
      registerSsePusher(tenantId, userId, pusher);

      // Send initial heartbeat so the client knows the connection is live.
      ctrl.enqueue(encoder.encode(": heartbeat\n\n"));

      heartbeatTimer = setInterval(() => {
        try {
          ctrl.enqueue(encoder.encode(": heartbeat\n\n"));
        } catch {
          clearInterval(heartbeatTimer);
        }
      }, SSE_HEARTBEAT_INTERVAL_MS);
    },
    cancel() {
      clearInterval(heartbeatTimer);
      unregisterSsePusher(tenantId, userId, pusher);
    },
  });

  return new Response(byteStream, {
    status: 200,
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache",
      connection: "keep-alive",
    },
  });
};

// ---------------------------------------------------------------------------
// POST /email — transactional email (IP rate-limited: 5 per IP per 10 min)
// ---------------------------------------------------------------------------

const EMAIL_WINDOW_MS = 10 * 60 * 1000;
const EMAIL_MAX_REQUESTS = 5;
const emailIpTimestamps = new Map<string, number[]>();

function isEmailRateLimited(ip: string): boolean {
  const now = Date.now();
  const windowStart = now - EMAIL_WINDOW_MS;
  const timestamps = (emailIpTimestamps.get(ip) ?? []).filter((t) => t > windowStart);
  if (timestamps.length >= EMAIL_MAX_REQUESTS) return true;
  emailIpTimestamps.set(ip, [...timestamps, now]);
  return false;
}

/** Exposed for tests to reset rate-limiter state between runs. */
export function resetEmailRateLimiter(): void {
  emailIpTimestamps.clear();
}

export const sendEmailHandler: RouteHandler = async (req) => {
  const forwarded = req.headers.get("x-forwarded-for");
  const ip =
    (forwarded ? forwarded.split(",")[0]?.trim() : undefined) ??
    req.headers.get("x-real-ip") ??
    "unknown";

  if (isEmailRateLimited(ip)) {
    return errorResponse(429, "Too many requests. Please try again later.");
  }

  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");

  const parsed = SendEmailRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid send email request", zodIssues(parsed.error.issues));
  }

  const { to, subject, html, text, replyTo, cc } = parsed.data;
  try {
    await getEmailTransport().send({
      to,
      subject,
      ...(html !== undefined && { html }),
      ...(text !== undefined && { text }),
      ...(replyTo !== undefined && { replyTo }),
      ...(cc !== undefined && { cc }),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return json(500, { error: message });
  }

  return json(202, { sent: true });
};

// ---------------------------------------------------------------------------
// Routes manifest + dispatch
// ---------------------------------------------------------------------------

export const routes: RouteDefinition[] = [
  { method: "POST", path: `${BASE_PATH}/send`, handler: sendHandler },
  { method: "POST", path: `${BASE_PATH}/email`, handler: sendEmailHandler },
  { method: "GET", path: `${BASE_PATH}/notifications`, handler: getNotificationsHandler },
  { method: "POST", path: `${BASE_PATH}/notifications/:id/read`, handler: markReadHandler },
  { method: "POST", path: `${BASE_PATH}/notifications/read-all`, handler: markAllReadHandler },
  { method: "GET", path: `${BASE_PATH}/stream`, handler: streamHandler },
];

function matchesPattern(pattern: string, pathname: string): boolean {
  const expected = pattern.split("/").filter(Boolean);
  const actual = pathname.split("/").filter(Boolean);
  if (expected.length !== actual.length) return false;
  return expected.every((segment, index) => segment.startsWith(":") || segment === actual[index]);
}

export const dispatch: RouteHandler = async (req) => {
  const { pathname } = new URL(req.url);
  for (const route of routes) {
    if (route.method === req.method && matchesPattern(route.path, pathname)) {
      return route.handler(req);
    }
  }
  return errorResponse(404, `no PS.NOTIF route for ${req.method} ${pathname}`);
};
