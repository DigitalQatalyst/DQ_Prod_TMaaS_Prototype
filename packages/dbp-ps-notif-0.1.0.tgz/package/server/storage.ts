import type { Notification } from "../client/types";

export type NotifStorageListOptions = {
  userId?: string;
  limit?: number;
};

export type NotifStorageListResult = {
  items: Notification[];
};

export interface NotifStorageAdapter {
  put(tenantId: string, notification: Notification): Promise<void>;
  get(tenantId: string, id: string): Promise<Notification | undefined>;
  list(tenantId: string, options: NotifStorageListOptions): Promise<NotifStorageListResult>;
  update(tenantId: string, id: string, patch: Partial<Notification>): Promise<Notification | undefined>;
}

export class InMemoryNotifStorageAdapter implements NotifStorageAdapter {
  /** Per-tenant store: tenantId → Map<id, Notification> (insertion order). */
  private readonly buckets = new Map<string, Map<string, Notification>>();

  private bucket(tenantId: string): Map<string, Notification> {
    let b = this.buckets.get(tenantId);
    if (!b) {
      b = new Map();
      this.buckets.set(tenantId, b);
    }
    return b;
  }

  async put(tenantId: string, notification: Notification): Promise<void> {
    this.bucket(tenantId).set(notification.id, { ...notification });
  }

  async get(tenantId: string, id: string): Promise<Notification | undefined> {
    const stored = this.bucket(tenantId).get(id);
    return stored ? { ...stored } : undefined;
  }

  async list(tenantId: string, options: NotifStorageListOptions): Promise<NotifStorageListResult> {
    const all = [...this.bucket(tenantId).values()].reverse();
    const filtered = options.userId ? all.filter((n) => n.to === options.userId) : all;
    const page = options.limit !== undefined ? filtered.slice(0, options.limit) : filtered;
    return { items: page.map((n) => ({ ...n })) };
  }

  async update(
    tenantId: string,
    id: string,
    patch: Partial<Notification>,
  ): Promise<Notification | undefined> {
    const existing = this.bucket(tenantId).get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...patch };
    this.bucket(tenantId).set(id, updated);
    return { ...updated };
  }

  /** For tests: find all items for a userId across all their notifications in a tenant. */
  async listByUserId(tenantId: string, userId: string): Promise<Notification[]> {
    return (await this.list(tenantId, { userId })).items;
  }

  clear(): void {
    this.buckets.clear();
  }
}
