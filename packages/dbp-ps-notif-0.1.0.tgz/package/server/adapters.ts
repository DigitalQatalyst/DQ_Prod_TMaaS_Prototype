import type { Notification } from "../client/types";
import type { NotifStorageAdapter } from "./storage";
import {
  getEmailTransport,
  renderedEmails,
  resetEmailTransport,
  type RenderedEmail,
} from "./transport";

export interface ChannelAdapter {
  deliver(notification: Notification): Promise<void>;
}

// ---------------------------------------------------------------------------
// In-app adapter: persists to storage so GET /notifications can serve it.
// Also publishes to any active SSE listeners for the recipient.
// ---------------------------------------------------------------------------

export class InAppChannelAdapter implements ChannelAdapter {
  constructor(
    private readonly storage: NotifStorageAdapter,
    private readonly tenantId: string,
    /** Optional SSE broadcast callback — injected per-request in handlers.ts. */
    private readonly publish?: (userId: string, notification: Notification) => void,
  ) {}

  async deliver(notification: Notification): Promise<void> {
    await this.storage.put(this.tenantId, notification);
    this.publish?.(notification.to, notification);
  }
}

// ---------------------------------------------------------------------------
// Email adapter: delegates to the env-selectable EmailTransport.
// In dev/test (no SMTP_URL / no NOTIF_EMAIL_TRANSPORT) the transport captures
// rendered emails into `renderedEmails` via jsonTransport/capture seam.
// ---------------------------------------------------------------------------

export class EmailChannelAdapter implements ChannelAdapter {
  async deliver(notification: Notification): Promise<void> {
    const subject = `[${notification.type}] ${notification.message.slice(0, 60)}`;
    const text = notification.link
      ? `${notification.message}\n\n${notification.link}`
      : notification.message;

    await getEmailTransport().send({ to: notification.to, subject, text });
  }
}

// ---------------------------------------------------------------------------
// Back-compat re-exports — callers that imported from adapters.ts continue to
// work unchanged; the canonical store now lives in transport.ts.
// ---------------------------------------------------------------------------

export { renderedEmails, resetEmailTransport as resetEmailTransporter, type RenderedEmail };

// ---------------------------------------------------------------------------
// SMS adapter: interface present; implementation deferred per ADR-0014.
// A vendor ADR (Twilio-class SDK) is required before this is functional.
// ---------------------------------------------------------------------------

export class SmsChannelAdapter implements ChannelAdapter {
  async deliver(notification: Notification): Promise<void> {
    void notification;
    throw new Error(
      "PS.NOTIF SMS adapter is not implemented. " +
        "A vendor ADR (Twilio-class SMS SDK) is required before SMS delivery is functional. " +
        "See ADR-0014.",
    );
  }
}
