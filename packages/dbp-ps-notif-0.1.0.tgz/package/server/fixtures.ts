import type { Notification } from "../client/types";
import { getNotifService, type NotifService } from "./service";

export const SEED_TENANT_ID = "tenant-demo";
export const SEED_USER_ID = "u-001";

export const seedNotifications: Notification[] = [
  {
    id: "a1b2c3d4-0001-4000-8000-000000000001",
    to: SEED_USER_ID,
    type: "invoice.submitted",
    message: "Invoice INV-001 has been submitted for approval.",
    link: "https://example.com/invoices/e-001",
    channel: "in-app",
    status: "unread",
    ts: "2026-01-01T09:00:00.000Z",
    tenantId: SEED_TENANT_ID,
  },
  {
    id: "a1b2c3d4-0002-4000-8000-000000000002",
    to: SEED_USER_ID,
    type: "invoice.approved",
    message: "Invoice INV-001 was approved.",
    channel: "in-app",
    status: "read",
    ts: "2026-01-02T10:00:00.000Z",
    tenantId: SEED_TENANT_ID,
  },
  {
    id: "a1b2c3d4-0003-4000-8000-000000000003",
    to: "u-002",
    type: "contract.created",
    message: "A new contract has been created.",
    channel: "email",
    status: "unread",
    ts: "2026-01-03T11:00:00.000Z",
    tenantId: SEED_TENANT_ID,
  },
];

export async function seedNotifService(target: NotifService = getNotifService()): Promise<void> {
  for (const notification of seedNotifications) {
    await target.storage.put(SEED_TENANT_ID, notification);
  }
}
