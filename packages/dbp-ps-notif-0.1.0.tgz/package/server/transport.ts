import nodemailer from "nodemailer";

// ---------------------------------------------------------------------------
// Shared email message type
// ---------------------------------------------------------------------------

export type EmailMessage = {
  to: string;
  subject: string;
  html?: string;
  text?: string;
  from?: string;
  replyTo?: string;
  cc?: string | string[];
};

// ---------------------------------------------------------------------------
// Transport interface
// ---------------------------------------------------------------------------

export interface EmailTransport {
  send(msg: EmailMessage): Promise<void>;
}

// ---------------------------------------------------------------------------
// Captured rendered emails (shared across transports for dev/test inspection)
// ---------------------------------------------------------------------------

export type RenderedEmail = {
  to: string;
  subject: string;
  text: string;
  html?: string;
  raw: unknown;
};

export const renderedEmails: RenderedEmail[] = [];

// ---------------------------------------------------------------------------
// SMTP transport — wraps nodemailer; uses jsonTransport in dev (no SMTP_URL).
// ---------------------------------------------------------------------------

export class SmtpTransport implements EmailTransport {
  async send(msg: EmailMessage): Promise<void> {
    const smtpUrl = process.env["SMTP_URL"];
    const transporter = smtpUrl
      ? nodemailer.createTransport(smtpUrl)
      : nodemailer.createTransport({ jsonTransport: true });

    const from = msg.from ?? process.env["SMTP_FROM"] ?? "noreply@dbp.local";

    const info = await transporter.sendMail({
      from,
      to: msg.to,
      subject: msg.subject,
      ...(msg.html !== undefined && { html: msg.html }),
      ...(msg.text !== undefined && { text: msg.text }),
      ...(msg.replyTo !== undefined && { replyTo: msg.replyTo }),
      ...(msg.cc !== undefined && { cc: msg.cc }),
    });

    // jsonTransport attaches a `message` string — capture for dev/test inspection.
    // We use unknown cast because the generic Transporter return type doesn't expose
    // JSONTransport.SentMessageInfo.message directly.
    const maybeJson = info as { message?: string };
    if (maybeJson.message) {
      renderedEmails.push({
        to: msg.to,
        subject: msg.subject,
        text: msg.text ?? "",
        ...(msg.html !== undefined && { html: msg.html }),
        raw: maybeJson.message,
      });
    }
  }
}

// ---------------------------------------------------------------------------
// MS Graph transport — OAuth2 client-credentials + sendMail.
// In dev/test (env vars absent or NOTIF_EMAIL_CAPTURE=1), captures into
// renderedEmails instead of making real network calls.
// ---------------------------------------------------------------------------

// Token cache
let _cachedAccessToken: string | null = null;
let _tokenExpiresAt = 0;

export async function _getAccessToken(): Promise<string> {
  const now = Date.now();
  if (_cachedAccessToken && now < _tokenExpiresAt - 60_000) {
    return _cachedAccessToken;
  }

  const tenantId = process.env["MSGRAPH_TENANT_ID"];
  const clientId = process.env["MSGRAPH_CLIENT_ID"];
  const clientSecret = process.env["MSGRAPH_CLIENT_SECRET"];

  if (!tenantId || !clientId || !clientSecret) {
    throw new Error("[PS.NOTIF] MsGraphTransport: MSGRAPH_TENANT_ID, MSGRAPH_CLIENT_ID, and MSGRAPH_CLIENT_SECRET are required.");
  }

  const params = new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    scope: "https://graph.microsoft.com/.default",
    grant_type: "client_credentials",
  });

  const res = await fetch(
    `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    },
  );

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`[PS.NOTIF] MS Graph token request failed: ${text}`);
  }

  const data = (await res.json()) as { access_token: string; expires_in?: number };
  _cachedAccessToken = data.access_token;
  _tokenExpiresAt = now + (data.expires_in ?? 3600) * 1000;
  return _cachedAccessToken;
}

export function _resetMsGraphTokenCache(): void {
  _cachedAccessToken = null;
  _tokenExpiresAt = 0;
}

/** The last raw MS Graph sendMail payload sent — captured in test/dev mode for inspection. */
export let _lastGraphPayload: unknown = null;

export class MsGraphTransport implements EmailTransport {
  async send(msg: EmailMessage): Promise<void> {
    const senderUpn = process.env["MSGRAPH_SENDER_UPN"];
    const capture = process.env["NOTIF_EMAIL_CAPTURE"] === "1";
    const hasEnv =
      !!process.env["MSGRAPH_TENANT_ID"] &&
      !!process.env["MSGRAPH_CLIENT_ID"] &&
      !!process.env["MSGRAPH_CLIENT_SECRET"] &&
      !!senderUpn;

    const mailPayload = {
      message: {
        subject: msg.subject,
        body: {
          contentType: msg.html ? "HTML" : "Text",
          content: msg.html ?? msg.text ?? "",
        },
        toRecipients: [{ emailAddress: { address: msg.to } }],
        ...(msg.replyTo !== undefined && {
          replyTo: [{ emailAddress: { address: msg.replyTo } }],
        }),
        ...(msg.cc !== undefined && {
          ccRecipients: (Array.isArray(msg.cc) ? msg.cc : [msg.cc]).map((addr) => ({
            emailAddress: { address: addr },
          })),
        }),
      },
    };

    // Capture mode: store payload and return without hitting the network.
    if (capture || !hasEnv) {
      _lastGraphPayload = mailPayload;
      renderedEmails.push({
        to: msg.to,
        subject: msg.subject,
        text: msg.text ?? "",
        ...(msg.html !== undefined && { html: msg.html }),
        raw: mailPayload,
      });
      return;
    }

    const token = await _getAccessToken();

    const sendRes = await fetch(
      `https://graph.microsoft.com/v1.0/users/${senderUpn}/sendMail`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(mailPayload),
      },
    );

    if (!sendRes.ok) {
      const text = await sendRes.text();
      throw new Error(`[PS.NOTIF] sendMail failed: ${text}`);
    }
  }
}

// ---------------------------------------------------------------------------
// Factory — env-selectable, memoised
// ---------------------------------------------------------------------------

let _emailTransport: EmailTransport | null = null;

export function getEmailTransport(): EmailTransport {
  if (_emailTransport) return _emailTransport;
  const selector = process.env["NOTIF_EMAIL_TRANSPORT"] ?? "smtp";
  _emailTransport = selector === "msgraph" ? new MsGraphTransport() : new SmtpTransport();
  return _emailTransport;
}

export function resetEmailTransport(): void {
  _emailTransport = null;
  _lastGraphPayload = null;
  _resetMsGraphTokenCache();
  renderedEmails.splice(0, renderedEmails.length);
}
