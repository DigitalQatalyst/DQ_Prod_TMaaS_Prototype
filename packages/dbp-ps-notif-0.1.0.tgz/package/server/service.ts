import type { Notification } from "../client/types";
import {
  EmailChannelAdapter,
  InAppChannelAdapter,
  SmsChannelAdapter,
  type ChannelAdapter,
} from "./adapters";
import { InMemoryNotifStorageAdapter, type NotifStorageAdapter } from "./storage";


export type NotifService = {
  storage: NotifStorageAdapter;
  adapters: {
    "in-app": ChannelAdapter;
    email: ChannelAdapter;
    sms: ChannelAdapter;
  };
  /** Broadcast an in-app notification to SSE listeners for a given userId+tenantId. */
  broadcast: (tenantId: string, userId: string, notification: Notification) => void;
};

/** Push function for an active SSE connection: receives SSE-formatted text and sends it. */
export type SsePusher = (data: string) => void;

/** Per-tenant SSE subscriber registry: tenantId → userId → Set<pusher>. */
type SseRegistry = Map<string, Map<string, Set<SsePusher>>>;

const sseSubscribers: SseRegistry = new Map();

function broadcastToSse(tenantId: string, userId: string, notification: Notification): void {
  const tenantMap = sseSubscribers.get(tenantId);
  if (!tenantMap) return;
  const pushers = tenantMap.get(userId);
  if (!pushers || pushers.size === 0) return;
  const data = `data: ${JSON.stringify(notification)}\n\n`;
  for (const push of pushers) {
    try {
      push(data);
    } catch {
      // Pusher closed — remove it.
      pushers.delete(push);
    }
  }
}

export function registerSsePusher(tenantId: string, userId: string, pusher: SsePusher): void {
  let tenantMap = sseSubscribers.get(tenantId);
  if (!tenantMap) {
    tenantMap = new Map();
    sseSubscribers.set(tenantId, tenantMap);
  }
  let userSet = tenantMap.get(userId);
  if (!userSet) {
    userSet = new Set();
    tenantMap.set(userId, userSet);
  }
  userSet.add(pusher);
}

export function unregisterSsePusher(tenantId: string, userId: string, pusher: SsePusher): void {
  sseSubscribers.get(tenantId)?.get(userId)?.delete(pusher);
}

function buildService(storage: NotifStorageAdapter): NotifService {
  const broadcast = (tenantId: string, userId: string, notification: Notification) =>
    broadcastToSse(tenantId, userId, notification);

  return {
    storage,
    adapters: {
      "in-app": new InAppChannelAdapter(
        storage,
        /* tenantId is injected per-request in handlers.ts */ "",
        undefined,
      ),
      email: new EmailChannelAdapter(),
      sms: new SmsChannelAdapter(),
    },
    broadcast,
  };
}

let service: NotifService = buildService(new InMemoryNotifStorageAdapter());

export function getNotifService(): NotifService {
  return service;
}

export function configureNotifService(overrides: Partial<NotifService>): NotifService {
  service = { ...service, ...overrides };
  return service;
}

export function resetNotifService(): NotifService {
  sseSubscribers.clear();
  const storage = new InMemoryNotifStorageAdapter();
  service = buildService(storage);
  return service;
}
