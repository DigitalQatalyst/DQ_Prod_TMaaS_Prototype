import { getNotifClientConfig } from "./config";
import { ErrorResponseSchema, type ErrorResponse } from "./types";

export class NotifServiceError extends Error {
  readonly status: number;
  readonly issues: ErrorResponse["issues"];

  constructor(status: number, body: ErrorResponse) {
    super(body.error);
    this.name = "NotifServiceError";
    this.status = status;
    this.issues = body.issues;
  }
}

type RequestOptions = {
  body?: unknown;
  query?: Record<string, string>;
  sessionHeader?: string;
  /** Forward the configured tenantId as `x-tenant-id` (tenant-scoped writes). */
  tenant?: boolean;
};

export async function request<T>(
  method: string,
  path: string,
  options: RequestOptions = {},
): Promise<T> {
  const { baseUrl, fetch, tenantId } = getNotifClientConfig();
  const query =
    options.query && Object.keys(options.query).length > 0
      ? `?${new URLSearchParams(options.query).toString()}`
      : "";
  const headers: Record<string, string> = {};
  if (options.sessionHeader !== undefined) headers["x-dbp-session"] = options.sessionHeader;
  if (options.tenant && tenantId !== undefined) headers["x-tenant-id"] = tenantId;
  if (options.body !== undefined) headers["content-type"] = "application/json";
  const response = await fetch(`${baseUrl}${path}${query}`, {
    method,
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : null,
  });
  if (response.status === 204) return undefined as T;
  const payload = (await response.json()) as unknown;
  if (!response.ok) {
    const parsed = ErrorResponseSchema.safeParse(payload);
    throw new NotifServiceError(
      response.status,
      parsed.success
        ? parsed.data
        : { error: `PS.NOTIF request failed with status ${response.status}` },
    );
  }
  return payload as T;
}
