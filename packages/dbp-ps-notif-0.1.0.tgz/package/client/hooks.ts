import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getNotifications, markAllRead, markRead, send, sendEmail, type SendEmailInput, type SendInput } from "./sdk";
import type { Notification, NotificationsResponse } from "./types";

const notifKeys = {
  list: (userId: string) => ["ps-notif", "notifications", userId] as const,
};

export type NotificationsResult = {
  items: Notification[];
  unread: number;
  markRead: (id: string) => void;
  markAllRead: () => void;
  isLoading: boolean;
  error: Error | null;
};

export function useNotifications(sessionHeader?: string): NotificationsResult {
  const userId = sessionHeader ?? "__anon__";
  const queryClient = useQueryClient();

  const query = useQuery<NotificationsResponse, Error>({
    queryKey: notifKeys.list(userId),
    queryFn: () => getNotifications(sessionHeader),
    enabled: true,
  });

  const markReadMutation = useMutation({
    mutationFn: (id: string) => markRead(id, sessionHeader),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: notifKeys.list(userId) });
    },
  });

  const markAllReadMutation = useMutation({
    mutationFn: () => markAllRead(sessionHeader),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: notifKeys.list(userId) });
    },
  });

  return {
    items: query.data?.items ?? [],
    unread: query.data?.unread ?? 0,
    markRead: (id: string) => markReadMutation.mutate(id),
    markAllRead: () => markAllReadMutation.mutate(),
    isLoading: query.isLoading,
    error: query.error,
  };
}

export type SendResult = {
  send: (input: SendInput) => void;
  isPending: boolean;
  error: Error | null;
};

export function useSend(sessionHeader?: string): SendResult {
  const userId = sessionHeader ?? "__anon__";
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (input: SendInput) => send(input),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: notifKeys.list(userId) });
    },
  });

  return {
    send: (input: SendInput) => mutation.mutate(input),
    isPending: mutation.isPending,
    error: mutation.error,
  };
}

export type SendEmailResult = {
  sendEmail: (input: SendEmailInput) => void;
  isPending: boolean;
  error: Error | null;
};

export function useSendEmail(): SendEmailResult {
  const mutation = useMutation({
    mutationFn: (input: SendEmailInput) => sendEmail(input),
  });

  return {
    sendEmail: (input: SendEmailInput) => mutation.mutate(input),
    isPending: mutation.isPending,
    error: mutation.error,
  };
}
