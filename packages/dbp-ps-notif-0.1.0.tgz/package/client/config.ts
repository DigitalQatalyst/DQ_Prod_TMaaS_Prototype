export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

export type NotifClientConfig = {
  baseUrl: string;
  fetch: FetchLike;
  /**
   * Tenant context for tenant-scoped writes (e.g. POST /send), forwarded as the
   * `x-tenant-id` header on those calls. Session-scoped reads derive their tenant
   * from `x-dbp-session` instead and ignore this.
   */
  tenantId?: string;
};

const defaults: NotifClientConfig = {
  baseUrl: "/api/platform/notif",
  fetch: (input, init) => globalThis.fetch(input, init),
};

let current: NotifClientConfig = { ...defaults };

export function configureNotifClient(overrides: Partial<NotifClientConfig>): void {
  current = { ...current, ...overrides };
}

export function getNotifClientConfig(): NotifClientConfig {
  return current;
}

export function resetNotifClient(): void {
  current = { ...defaults };
}
