import { z } from "zod";

export const NotificationChannelSchema = z.enum(["in-app", "email", "sms"]);
export type NotificationChannel = z.infer<typeof NotificationChannelSchema>;

export const NotificationStatusSchema = z.enum(["unread", "read"]);
export type NotificationStatus = z.infer<typeof NotificationStatusSchema>;

export const NotificationSchema = z
  .object({
    id: z.string().uuid(),
    to: z.string().min(1),
    type: z.string().min(1),
    message: z.string().min(1),
    link: z.string().url().optional(),
    channel: NotificationChannelSchema,
    status: NotificationStatusSchema,
    ts: z.string().datetime(),
    tenantId: z.string().min(1),
  })
  .strict();
export type Notification = z.infer<typeof NotificationSchema>;

export const SendNotificationRequestSchema = z
  .object({
    to: z.string().min(1),
    type: z.string().min(1),
    message: z.string().min(1),
    link: z.string().url().optional(),
    channel: NotificationChannelSchema,
  })
  .strict();
export type SendNotificationRequest = z.infer<typeof SendNotificationRequestSchema>;

export const NotificationsResponseSchema = z
  .object({
    items: z.array(NotificationSchema),
    unread: z.number().int().nonnegative(),
  })
  .strict();
export type NotificationsResponse = z.infer<typeof NotificationsResponseSchema>;

export const ValidationIssueSchema = z
  .object({ path: z.string(), message: z.string() })
  .strict();
export type ValidationIssue = z.infer<typeof ValidationIssueSchema>;

export const ErrorResponseSchema = z
  .object({
    error: z.string(),
    issues: z.array(ValidationIssueSchema).optional(),
  })
  .strict();
export type ErrorResponse = z.infer<typeof ErrorResponseSchema>;

export const SendEmailRequestSchema = z
  .object({
    to: z.string().min(1),
    subject: z.string().min(1),
    html: z.string().optional(),
    text: z.string().optional(),
    replyTo: z.string().email().optional(),
    cc: z.union([z.string(), z.array(z.string())]).optional(),
  })
  .strict()
  .refine((v) => v.html !== undefined || v.text !== undefined, {
    message: "At least one of html or text is required",
    path: ["html"],
  });
export type SendEmailRequest = z.infer<typeof SendEmailRequestSchema>;
