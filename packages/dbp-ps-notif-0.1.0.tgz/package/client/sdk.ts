import { request } from "./http";
import type { Notification, NotificationsResponse, SendEmailRequest, SendNotificationRequest } from "./types";

export type SendInput = Omit<SendNotificationRequest, never>;
export type SendEmailInput = SendEmailRequest;

export async function send(input: SendInput): Promise<void> {
  await request<Notification>("POST", "/send", { body: input, tenant: true });
}

export async function getNotifications(sessionHeader?: string): Promise<NotificationsResponse> {
  return request<NotificationsResponse>("GET", "/notifications", {
    ...(sessionHeader !== undefined && { sessionHeader }),
  });
}

export async function markRead(id: string, sessionHeader?: string): Promise<void> {
  await request<void>("POST", `/notifications/${id}/read`, {
    ...(sessionHeader !== undefined && { sessionHeader }),
  });
}

export async function markAllRead(sessionHeader?: string): Promise<void> {
  await request<void>("POST", "/notifications/read-all", {
    ...(sessionHeader !== undefined && { sessionHeader }),
  });
}

export async function sendEmail(input: SendEmailInput): Promise<void> {
  await request<{ sent: boolean }>("POST", "/email", { body: input });
}
