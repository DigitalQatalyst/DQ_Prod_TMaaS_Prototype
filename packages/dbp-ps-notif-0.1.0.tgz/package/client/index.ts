export {
  configureNotifClient,
  getNotifClientConfig,
  resetNotifClient,
  type FetchLike,
  type NotifClientConfig,
} from "./config";
export { NotifServiceError } from "./http";
export {
  getNotifications,
  markAllRead,
  markRead,
  send,
  sendEmail,
  type SendEmailInput,
  type SendInput,
} from "./sdk";
export {
  useNotifications,
  useSend,
  useSendEmail,
  type NotificationsResult,
  type SendEmailResult,
  type SendResult,
} from "./hooks";
export * from "./types";
