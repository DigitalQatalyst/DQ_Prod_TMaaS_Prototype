import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  OpenAPIRegistry,
  OpenApiGeneratorV3,
  extendZodWithOpenApi,
} from "@asteasolutions/zod-to-openapi";
import YAML from "yaml";
import { z } from "zod";
import {
  ErrorResponseSchema,
  NotificationSchema,
  NotificationsResponseSchema,
  SendEmailRequestSchema,
  SendNotificationRequestSchema,
} from "../client/types";
import { BASE_PATH } from "../server/handlers";

extendZodWithOpenApi(z);

const packageDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const contractPath = path.join(packageDir, "contract.yaml");
const manifest = JSON.parse(
  fs.readFileSync(path.join(packageDir, "package.json"), "utf8"),
) as { version: string };

const registry = new OpenAPIRegistry();

const Notification = registry.register("Notification", NotificationSchema);
const SendNotificationRequest = registry.register("SendNotificationRequest", SendNotificationRequestSchema);
const SendEmailRequest = registry.register("SendEmailRequest", SendEmailRequestSchema);
const NotificationsResponse = registry.register("NotificationsResponse", NotificationsResponseSchema);
const ErrorResponse = registry.register("ErrorResponse", ErrorResponseSchema);

const tenantHeader = z.object({
  "x-tenant-id": z.string().min(1).openapi({
    description: "Tenant scope for the request.",
  }),
});

const sessionHeader = z.object({
  "x-dbp-session": z.string().min(1).openapi({
    description:
      "Base64-encoded JSON session (PS.AUTH Session shape). Provides userId + tenantId for recipient scoping.",
  }),
});

const notifIdParam = z.object({ id: z.string().uuid() });

const jsonBody = (schema: z.ZodTypeAny) => ({ content: { "application/json": { schema } } });
const jsonResponse = (description: string, schema: z.ZodTypeAny) => ({
  description,
  content: { "application/json": { schema } },
});
const errorOf = (description: string) => jsonResponse(description, ErrorResponse);

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/send`,
  summary: "Send a notification to a recipient",
  description:
    "Validates the request, dispatches to the appropriate channel adapter " +
    "(in-app: persists + broadcasts via SSE; email: nodemailer; sms: deferred per ADR-0014), " +
    "and returns the created notification envelope.",
  request: { headers: tenantHeader, body: jsonBody(SendNotificationRequest) },
  responses: {
    201: jsonResponse("Notification created and dispatched", Notification),
    400: errorOf("Missing tenant header or invalid request body"),
  },
});

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/email`,
  summary: "Send a transactional email",
  description:
    "Sends a transactional email directly via the configured email transport " +
    "(NOTIF_EMAIL_TRANSPORT=smtp|msgraph). At least one of html or text is required. " +
    "Rate-limited to 5 requests per IP per 10 minutes.",
  request: { body: jsonBody(SendEmailRequest) },
  responses: {
    202: {
      description: "Email accepted for delivery",
      content: {
        "application/json": {
          schema: z.object({ sent: z.boolean() }),
        },
      },
    },
    400: errorOf("Invalid request body (missing required fields or html/text)"),
    429: errorOf("Rate limit exceeded — too many requests from this IP"),
  },
});

registry.registerPath({
  method: "get",
  path: `${BASE_PATH}/notifications`,
  summary: "List notifications for the session user",
  description:
    "Returns all in-app notifications for the authenticated user (from x-dbp-session), " +
    "newest-first, plus an unread count.",
  request: { headers: sessionHeader },
  responses: {
    200: jsonResponse("Notifications list with unread count", NotificationsResponse),
    401: errorOf("Missing or invalid session header"),
  },
});

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/notifications/{id}/read`,
  summary: "Mark a notification as read",
  request: { params: notifIdParam, headers: sessionHeader },
  responses: {
    200: jsonResponse("Updated notification", Notification),
    401: errorOf("Missing or invalid session header"),
    404: errorOf("No such notification for this user"),
  },
});

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/notifications/read-all`,
  summary: "Mark all notifications for the session user as read",
  request: { headers: sessionHeader },
  responses: {
    200: {
      description: "Number of notifications marked read",
      content: {
        "application/json": {
          schema: z.object({ updated: z.number().int().nonnegative() }),
        },
      },
    },
    401: errorOf("Missing or invalid session header"),
  },
});

registry.registerPath({
  method: "get",
  path: `${BASE_PATH}/stream`,
  summary: "SSE stream for live in-app notifications",
  description:
    "Opens a Server-Sent Events stream for the session user. " +
    "Events are `data: <Notification JSON>\\n\\n`; heartbeat comments are sent every 15 s. " +
    "On reconnect the client should re-fetch GET /notifications to re-hydrate state — " +
    "the stream does NOT replay history.",
  request: { headers: sessionHeader },
  responses: {
    200: {
      description: "SSE stream (text/event-stream). Each event carries a Notification JSON payload.",
      content: {
        "text/event-stream": {
          schema: z.string().openapi({ description: "SSE text stream" }),
        },
      },
    },
    401: errorOf("Missing or invalid session header"),
  },
});

const generator = new OpenApiGeneratorV3(registry.definitions);
const document = generator.generateDocument({
  openapi: "3.0.3",
  info: {
    title: "PS.NOTIF — Notifications Service",
    version: manifest.version,
    description:
      "Deliver and manage notifications across channels (in-app, email, sms). " +
      "Generated from the Zod schemas in @dbp/ps-notif (ADR-0013). Do not edit by hand.",
  },
  servers: [{ url: "/" }],
});

const header =
  "# GENERATED FILE — do not edit.\n" +
  "# Source of truth: Zod schemas in @dbp/ps-notif (client/types.ts).\n" +
  "# Regenerate with: pnpm --filter @dbp/ps-notif contracts:gen\n";
const yamlText = header + YAML.stringify(document);

const normalize = (text: string) => text.replace(/\r\n/g, "\n");

if (process.argv.includes("--check")) {
  if (!fs.existsSync(contractPath)) {
    console.error("contracts:check FAILED — contract.yaml is missing. Run contracts:gen.");
    process.exit(1);
  }
  const committed = normalize(fs.readFileSync(contractPath, "utf8"));
  if (committed !== normalize(yamlText)) {
    console.error(
      "contracts:check FAILED — contract.yaml is stale (drift from the Zod schemas). Run contracts:gen and commit.",
    );
    process.exit(1);
  }
  console.log("contracts:check passed — contract.yaml matches the Zod schemas.");
} else {
  fs.writeFileSync(contractPath, yamlText, "utf8");
  console.log(`contract.yaml written (${yamlText.split("\n").length} lines).`);
}
