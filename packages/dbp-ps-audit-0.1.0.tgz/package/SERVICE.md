# PS.AUDIT — Audit & Activity Log Service

| | |
|---|---|
| **Registry ID** | `PS.AUDIT` |
| **Package** | `@dbp/ps-audit` (independent semver, currently `0.1.0`) |
| **Atomic class** | Control |
| **Contract** | `contract.yaml` (OpenAPI 3.0.3, GENERATED — see below) |
| **Base path** | `/api/platform/audit` |

## Purpose

Records who did what to which entity, immutably; serves activity feeds. Solutions
call `logEvent` after any state-changing operation; the Phase-4 ActivityFeed UI
component binds to `useActivityFeed` — it is not a per-solution build.

## Client SDK (spec-contractual signatures)

```ts
logEvent({ actor, action, target, delta? }): Promise<void>
useActivityFeed(entityId, options?): { events, loadMore, hasMore, isLoading, isFetchingNextPage, error }
configureAuditClient({ baseUrl?, fetch?, tenantId? })  // default baseUrl /api/platform/audit
```

Plain async functions also exported: `getEvent`, `getActivityFeed`.

`useActivityFeed` uses TanStack Query `useInfiniteQuery`. `loadMore()` fetches the
next cursor page and appends events to the list. Events are ordered newest-first,
matching the append-only store's reversed iteration.

## Immutability contract

The audit store is **append-only by design**:

- The `AuditStorageAdapter` interface exposes only `append`, `get`, and `list` —
  no `update` or `delete` methods exist. Immutability is enforced at the type
  boundary, not by convention.
- `InMemoryAuditStorageAdapter.append` freezes each stored object with
  `Object.freeze({ ...event })` so aliased references cannot mutate the store.
- Every `get` and `list` call returns a shallow copy, so callers cannot mutate the
  returned objects back into the store.
- There are no HTTP endpoints for updating or deleting events. The OpenAPI contract
  has no PATCH or DELETE paths under `/api/platform/audit/events`.

## Tenancy

Every event is scoped by the `x-tenant-id` request header (400 if missing). The
client SDK sends it from `configureAuditClient({ tenantId })` (default `"default"`).

## Storage

Per ADR-0008: all persistence goes through the `AuditStorageAdapter` interface.
Phase 2 ships exactly one implementation, `InMemoryAuditStorageAdapter` (Map-based,
insertion-ordered, frozen entries), plus deterministic seed fixtures
(`seedAuditService`, tenant `tenant-demo`). Swapping in a real database later must
not change the OpenAPI contract or SDK signatures.

Cursor pagination: the cursor is the id of the last event on the previous page.
On the next call the adapter skips forward to the event after that id and returns
the next `limit` events. Cursors are opaque to callers.

## SLO

**Append p95 < 25 ms** for `POST /events` against the in-memory adapter, measured
handler-inclusive (dispatch → storage → serialised response).
Measurement: `tests/slo.test.ts` samples 200 sequential appends per run and asserts
the p95; once a real storage adapter lands, the same probe becomes the regression
gate for the production SLO.

## Contract generation (ADR-0013)

`contract.yaml` is GENERATED from the Zod schemas — never edit it by hand.

- `pnpm --filter @dbp/ps-audit contracts:gen` regenerates it (commit the result).
- `pnpm --filter @dbp/ps-audit contracts:check` regenerates in memory and fails on
  drift; the pipeline `contract-drift` stage runs this repo-wide via
  `pnpm test:contracts`.

## Contract tests (ADR-0007)

`tests/pact.test.ts`: the consumer suite drives this package's own client SDK
against a Pact mock (pact file written to `tests/pacts/`, gitignored); the provider
suite hosts the real handlers on `node:http` and verifies that pact, with state
handlers seeding the in-memory store. pact-core has no `win32-arm64` binary, so the
suite self-skips on that platform with a loud warning (it is proven green under x64
emulation; CI on linux-x64 always runs it).

## Design trade-offs

- **Cursor by id, not by offset or timestamp.** Timestamps from `new Date()` can
  collide in fast appends; UUIDs are strictly unique. The tradeoff is that the
  cursor is opaque (you cannot seek to a timestamp without a full scan). Acceptable
  for Phase 2; a real database would use a composite index on `(tenantId, ts, id)`.
- **Newest-first via full reversal.** The in-memory adapter reverses the Map's
  insertion-ordered values on every list call. This is O(n) and correct for Phase 2
  volumes. A real implementation would maintain a descending timestamp index.

## Versioning

Independent semver. Breaking changes to any endpoint or SDK signature bump the
major; `contract.yaml`'s `info.version` tracks `package.json` automatically.
