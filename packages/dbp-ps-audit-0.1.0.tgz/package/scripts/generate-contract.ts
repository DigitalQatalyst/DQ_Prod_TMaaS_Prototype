import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  OpenAPIRegistry,
  OpenApiGeneratorV3,
  extendZodWithOpenApi,
} from "@asteasolutions/zod-to-openapi";
import YAML from "yaml";
import { z } from "zod";
import {
  ActivityFeedQuerySchema,
  ActivityFeedResponseSchema,
  AuditEventSchema,
  ErrorResponseSchema,
  LogEventRequestSchema,
} from "../client/types";
import { BASE_PATH } from "../server/handlers";

extendZodWithOpenApi(z);

const packageDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const contractPath = path.join(packageDir, "contract.yaml");
const manifest = JSON.parse(
  fs.readFileSync(path.join(packageDir, "package.json"), "utf8"),
) as { version: string };

const registry = new OpenAPIRegistry();

const AuditEvent = registry.register("AuditEvent", AuditEventSchema);
const LogEventRequest = registry.register("LogEventRequest", LogEventRequestSchema);
const ActivityFeedResponse = registry.register("ActivityFeedResponse", ActivityFeedResponseSchema);
const ErrorResponse = registry.register("ErrorResponse", ErrorResponseSchema);

const tenantHeader = z.object({
  "x-tenant-id": z.string().min(1).openapi({
    description: "Tenant scope for the request. Every audit event belongs to exactly one tenant.",
  }),
});

const eventIdParam = z.object({ id: z.string().uuid() });

const jsonBody = (schema: z.ZodTypeAny) => ({ content: { "application/json": { schema } } });
const jsonResponse = (description: string, schema: z.ZodTypeAny) => ({
  description,
  content: { "application/json": { schema } },
});
const errorOf = (description: string) => jsonResponse(description, ErrorResponse);

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/events`,
  summary: "Log an audit event (append-only)",
  description:
    "Appends an immutable audit event to the log. The store is append-only: there are " +
    "no update or delete endpoints. Returns the persisted event including the generated id and ts.",
  request: { headers: tenantHeader, body: jsonBody(LogEventRequest) },
  responses: {
    201: jsonResponse("Audit event recorded", AuditEvent),
    400: errorOf("Missing tenant header or invalid event body"),
  },
});

registry.registerPath({
  method: "get",
  path: `${BASE_PATH}/events`,
  summary: "Activity feed (cursor-paginated, newest-first)",
  description:
    "Returns audit events newest-first, optionally filtered by entityId. " +
    "Pagination uses opaque cursors: pass the nextCursor value as cursor to fetch the next page.",
  request: { headers: tenantHeader, query: ActivityFeedQuerySchema },
  responses: {
    200: jsonResponse("Page of audit events with optional next-page cursor", ActivityFeedResponse),
    400: errorOf("Missing tenant header or invalid query parameters"),
  },
});

registry.registerPath({
  method: "get",
  path: `${BASE_PATH}/events/{id}`,
  summary: "Get a single audit event by id",
  request: { params: eventIdParam, headers: tenantHeader },
  responses: {
    200: jsonResponse("The audit event", AuditEvent),
    400: errorOf("Missing tenant header"),
    404: errorOf("No such audit event in this tenant"),
  },
});

const generator = new OpenApiGeneratorV3(registry.definitions);
const document = generator.generateDocument({
  openapi: "3.0.3",
  info: {
    title: "PS.AUDIT — Audit & Activity Log Service",
    version: manifest.version,
    description:
      "Append-only audit log — records who did what to which entity. " +
      "Generated from the Zod schemas in @dbp/ps-audit (ADR-0013). Do not edit by hand.",
  },
  servers: [{ url: "/" }],
});

const header =
  "# GENERATED FILE — do not edit.\n" +
  "# Source of truth: Zod schemas in @dbp/ps-audit (client/types.ts).\n" +
  "# Regenerate with: pnpm --filter @dbp/ps-audit contracts:gen\n";
const yamlText = header + YAML.stringify(document);

const normalize = (text: string) => text.replace(/\r\n/g, "\n");

if (process.argv.includes("--check")) {
  if (!fs.existsSync(contractPath)) {
    console.error("contracts:check FAILED — contract.yaml is missing. Run contracts:gen.");
    process.exit(1);
  }
  const committed = normalize(fs.readFileSync(contractPath, "utf8"));
  if (committed !== normalize(yamlText)) {
    console.error(
      "contracts:check FAILED — contract.yaml is stale (drift from the Zod schemas). Run contracts:gen and commit.",
    );
    process.exit(1);
  }
  console.log("contracts:check passed — contract.yaml matches the Zod schemas.");
} else {
  fs.writeFileSync(contractPath, yamlText, "utf8");
  console.log(`contract.yaml written (${yamlText.split("\n").length} lines).`);
}
