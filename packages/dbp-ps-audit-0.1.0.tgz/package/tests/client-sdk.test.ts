// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import {
  AuditServiceError,
  getActivityFeed,
  getEvent,
  logEvent,
  resetAuditClient,
} from "../client/index";
import { resetAuditService } from "../server/index";
import { TEST_TENANT, bindClientToHandlers } from "./helpers/bind";

const actor = { userId: "u-1", email: "sdk@example.com", displayName: "SDK User" };
const target = { entityType: "order", entityId: "o-001" };

beforeEach(() => {
  resetAuditService();
  resetAuditClient();
  bindClientToHandlers();
});

describe("logEvent", () => {
  it("appends an event without throwing", async () => {
    await expect(logEvent({ actor, action: "order.created", target })).resolves.toBeUndefined();
  });

  it("appends an event with a delta", async () => {
    await expect(
      logEvent({ actor, action: "order.updated", target, delta: { qty: 5 } }),
    ).resolves.toBeUndefined();
  });

  it("throws AuditServiceError on validation failure", async () => {
    await expect(
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      logEvent({ actor: {} as any, action: "bad" } as any),
    ).rejects.toBeInstanceOf(AuditServiceError);
  });
});

describe("getActivityFeed", () => {
  it("returns events newest-first for an entityId", async () => {
    await logEvent({ actor, action: "a1", target });
    await logEvent({ actor, action: "a2", target });
    const feed = await getActivityFeed({ entityId: target.entityId });
    expect(feed.events).toHaveLength(2);
    expect(feed.events[0]?.action).toBe("a2");
  });

  it("returns nextCursor when more pages exist", async () => {
    for (let i = 0; i < 3; i += 1) {
      await logEvent({ actor, action: `a${i}`, target });
    }
    const feed = await getActivityFeed({ limit: 2 });
    expect(feed.events).toHaveLength(2);
    expect(feed.nextCursor).not.toBeNull();
  });
});

describe("getEvent", () => {
  it("retrieves an event by id", async () => {
    await logEvent({ actor, action: "fetch.me", target });
    const feed = await getActivityFeed({ entityId: target.entityId });
    const id = feed.events[0]?.id;
    if (!id) throw new Error("no event id");
    const event = await getEvent(id);
    expect(event.action).toBe("fetch.me");
    expect(event.tenantId).toBe(TEST_TENANT);
  });

  it("throws AuditServiceError for a missing id", async () => {
    const err = await getEvent("00000000-0000-4000-8000-000000000000").catch((e) => e);
    expect(err).toBeInstanceOf(AuditServiceError);
    expect((err as AuditServiceError).status).toBe(404);
  });
});
