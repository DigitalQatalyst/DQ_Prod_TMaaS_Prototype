import { configureAuditClient } from "../../client/index";
import { dispatch } from "../../server/index";

export const TEST_TENANT = "tenant-a";
export const OTHER_TENANT = "tenant-b";

export function bindClientToHandlers(tenantId = TEST_TENANT): void {
  configureAuditClient({
    baseUrl: "http://ps-audit.test/api/platform/audit",
    fetch: (input, init) => dispatch(new Request(input, init)),
    tenantId,
  });
}

export function rawRequest(
  method: string,
  path: string,
  options: { body?: unknown; tenantId?: string | null } = {},
): Promise<Response> {
  const headers: Record<string, string> = {};
  if (options.tenantId !== null) headers["x-tenant-id"] = options.tenantId ?? TEST_TENANT;
  if (options.body !== undefined) headers["content-type"] = "application/json";
  return dispatch(
    new Request(`http://ps-audit.test/api/platform/audit${path}`, {
      method,
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : null,
    }),
  );
}
