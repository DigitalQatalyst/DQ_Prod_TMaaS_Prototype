// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import { resetAuditService } from "../server/index";
import { rawRequest } from "./helpers/bind";

/*
 * SLO from SERVICE.md: append p95 < 25ms against the in-memory adapter,
 * measured handler-inclusive (dispatch → storage → serialised response).
 */
describe("SLO — append latency", () => {
  const actor = { userId: "u-slo", email: "slo@example.com", displayName: "SLO User" };
  const target = { entityType: "order", entityId: "slo-001" };
  const body = { actor, action: "slo.probe", target };

  beforeEach(() => {
    resetAuditService();
  });

  it("keeps POST /events p95 under 25ms in-memory", async () => {
    const samples: number[] = [];
    for (let i = 0; i < 200; i += 1) {
      const start = performance.now();
      const response = await rawRequest("POST", "/events", { body });
      await response.json();
      samples.push(performance.now() - start);
      expect(response.status).toBe(201);
    }
    samples.sort((a, b) => a - b);
    const p95 = samples[Math.floor(samples.length * 0.95)] ?? Number.POSITIVE_INFINITY;
    expect(p95).toBeLessThan(25);
  });
});
