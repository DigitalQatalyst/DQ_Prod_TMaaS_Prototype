// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import type { AuditEvent } from "../client/types";
import {
  SEED_TENANT_ID,
  getAuditService,
  resetAuditService,
  seedAuditService,
} from "../server/index";
import { OTHER_TENANT, TEST_TENANT, rawRequest } from "./helpers/bind";

type FeedBody = { events: AuditEvent[]; nextCursor: string | null };

const actor = { userId: "u-1", email: "user@example.com", displayName: "User" };
const target = { entityType: "invoice", entityId: "e-001" };
const validEvent = { actor, action: "invoice.created", target, delta: { amount: 100 } };

async function appendEvent(
  data: Record<string, unknown> = validEvent,
  tenantId: string = TEST_TENANT,
): Promise<AuditEvent> {
  const response = await rawRequest("POST", "/events", { body: data, tenantId });
  expect(response.status).toBe(201);
  return (await response.json()) as AuditEvent;
}

beforeEach(() => {
  resetAuditService();
});

describe("POST /events (logEvent)", () => {
  it("creates an event and returns it with envelope fields", async () => {
    const event = await appendEvent();
    expect(event.id).toMatch(/^[0-9a-f-]{36}$/);
    expect(event.ts).toBeTruthy();
    expect(event.actor).toEqual(actor);
    expect(event.action).toBe("invoice.created");
    expect(event.target).toEqual(target);
    expect(event.delta).toEqual({ amount: 100 });
    expect(event.tenantId).toBe(TEST_TENANT);
  });

  it("accepts null delta", async () => {
    const event = await appendEvent({ ...validEvent, delta: null });
    expect(event.delta).toBeNull();
  });

  it("accepts missing delta (defaults to null)", async () => {
    const event = await appendEvent({ actor, action: "invoice.created", target });
    expect(event.delta).toBeNull();
  });

  it("requires the tenant header", async () => {
    const response = await rawRequest("POST", "/events", { body: validEvent, tenantId: null });
    expect(response.status).toBe(400);
  });

  it("rejects malformed body", async () => {
    const response = await rawRequest("POST", "/events", {
      body: { action: "missing-actor" },
    });
    expect(response.status).toBe(400);
    const body = (await response.json()) as { issues?: unknown[] };
    expect(body.issues?.length).toBeGreaterThan(0);
  });
});

describe("GET /events (activity feed)", () => {
  it("returns events newest-first", async () => {
    await appendEvent({ ...validEvent, action: "first" });
    await appendEvent({ ...validEvent, action: "second" });
    await appendEvent({ ...validEvent, action: "third" });

    const response = await rawRequest("GET", "/events");
    expect(response.status).toBe(200);
    const body = (await response.json()) as FeedBody;
    expect(body.events).toHaveLength(3);
    expect(body.events[0]?.action).toBe("third");
    expect(body.events[2]?.action).toBe("first");
  });

  it("filters by entityId", async () => {
    await appendEvent({ ...validEvent, target: { entityType: "invoice", entityId: "e-001" } });
    await appendEvent({ ...validEvent, target: { entityType: "invoice", entityId: "e-002" } });
    await appendEvent({ ...validEvent, target: { entityType: "invoice", entityId: "e-001" } });

    const response = await rawRequest("GET", "/events?entityId=e-001");
    const body = (await response.json()) as FeedBody;
    expect(body.events).toHaveLength(2);
    expect(body.events.every((e) => e.target.entityId === "e-001")).toBe(true);
  });

  it("cursor-paginates newest-first", async () => {
    for (let i = 0; i < 5; i += 1) {
      await appendEvent({ ...validEvent, action: `action-${i}` });
    }

    const page1Response = await rawRequest("GET", "/events?limit=2");
    const page1 = (await page1Response.json()) as FeedBody;
    expect(page1.events).toHaveLength(2);
    expect(page1.events[0]?.action).toBe("action-4");
    expect(page1.events[1]?.action).toBe("action-3");
    expect(page1.nextCursor).not.toBeNull();

    const page2Response = await rawRequest("GET", `/events?limit=2&cursor=${page1.nextCursor!}`);
    const page2 = (await page2Response.json()) as FeedBody;
    expect(page2.events).toHaveLength(2);
    expect(page2.events[0]?.action).toBe("action-2");
    expect(page2.events[1]?.action).toBe("action-1");
    expect(page2.nextCursor).not.toBeNull();

    const page3Response = await rawRequest("GET", `/events?limit=2&cursor=${page2.nextCursor!}`);
    const page3 = (await page3Response.json()) as FeedBody;
    expect(page3.events).toHaveLength(1);
    expect(page3.events[0]?.action).toBe("action-0");
    expect(page3.nextCursor).toBeNull();
  });

  it("isolates tenants", async () => {
    await appendEvent(validEvent, TEST_TENANT);
    await appendEvent(validEvent, OTHER_TENANT);

    const mine = (await (await rawRequest("GET", "/events", { tenantId: TEST_TENANT })).json()) as FeedBody;
    const theirs = (await (await rawRequest("GET", "/events", { tenantId: OTHER_TENANT })).json()) as FeedBody;

    expect(mine.events).toHaveLength(1);
    expect(theirs.events).toHaveLength(1);
    expect(mine.events[0]?.tenantId).toBe(TEST_TENANT);
    expect(theirs.events[0]?.tenantId).toBe(OTHER_TENANT);
  });

  it("requires the tenant header", async () => {
    const response = await rawRequest("GET", "/events", { tenantId: null });
    expect(response.status).toBe(400);
  });

  it("rejects invalid limit", async () => {
    const response = await rawRequest("GET", "/events?limit=0");
    expect(response.status).toBe(400);
  });
});

describe("GET /events/:id (getEvent)", () => {
  it("returns the event by id", async () => {
    const created = await appendEvent();
    const response = await rawRequest("GET", `/events/${created.id}`);
    expect(response.status).toBe(200);
    const body = (await response.json()) as AuditEvent;
    expect(body.id).toBe(created.id);
    expect(body.action).toBe("invoice.created");
  });

  it("404s for a missing event", async () => {
    const response = await rawRequest("GET", "/events/00000000-0000-4000-8000-000000000000");
    expect(response.status).toBe(404);
  });

  it("requires the tenant header", async () => {
    const response = await rawRequest("GET", "/events/any-id", { tenantId: null });
    expect(response.status).toBe(400);
  });

  it("cross-tenant read returns 404", async () => {
    const created = await appendEvent(validEvent, TEST_TENANT);
    const response = await rawRequest("GET", `/events/${created.id}`, { tenantId: OTHER_TENANT });
    expect(response.status).toBe(404);
  });
});

describe("immutability", () => {
  it("a second append of the same id does not overwrite — each id is unique (UUID)", async () => {
    const e1 = await appendEvent({ ...validEvent, action: "first" });
    const e2 = await appendEvent({ ...validEvent, action: "second" });
    expect(e1.id).not.toBe(e2.id);
  });

  it("returned events are independent copies — mutating the returned object does not alter the store", async () => {
    const created = await appendEvent();
    const stored = await getAuditService().storage.get(TEST_TENANT, created.id);
    if (!stored) throw new Error("event not found");
    (stored as Record<string, unknown>).action = "mutated";
    const fresh = await getAuditService().storage.get(TEST_TENANT, created.id);
    expect(fresh?.action).toBe("invoice.created");
  });

  it("stored event object is frozen — direct mutation attempt fails silently in non-strict mode", async () => {
    await appendEvent();
    const service = getAuditService();
    const events = (await service.storage.list(TEST_TENANT, { limit: 10 })).events;
    const event = events[0];
    expect(event).toBeDefined();
    const originalAction = event!.action;
    try {
      (event as Record<string, unknown>).action = "mutated";
    } catch {
      /* strict mode throws — that is also acceptable */
    }
    const fresh = await service.storage.get(TEST_TENANT, event!.id);
    expect(fresh?.action).toBe(originalAction);
  });

  it("delta round-trip preserves the full object", async () => {
    const delta = { before: { amount: 100 }, after: { amount: 200 }, note: "approved" };
    const created = await appendEvent({ ...validEvent, delta });
    const fetched = await rawRequest("GET", `/events/${created.id}`);
    const body = (await fetched.json()) as AuditEvent;
    expect(body.delta).toEqual(delta);
  });
});

describe("seed fixtures", () => {
  it("seeds deterministic demo data", async () => {
    await seedAuditService();
    const response = await rawRequest("GET", "/events", { tenantId: SEED_TENANT_ID });
    const body = (await response.json()) as FeedBody;
    expect(body.events).toHaveLength(3);
    expect(body.events[0]?.action).toBe("contract.created");
  });
});

describe("dispatch", () => {
  it("404s unknown routes", async () => {
    const response = await rawRequest("GET", "/nope");
    expect(response.status).toBe(404);
  });
});
