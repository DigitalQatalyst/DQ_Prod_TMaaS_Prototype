// @vitest-environment node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { beforeAll, describe, expect, it } from "vitest";
import {
  configureAuditClient,
  getActivityFeed,
  getEvent,
  logEvent,
} from "../client/index";
import { resetAuditService, getAuditService } from "../server/index";
import { seedAuditEvents } from "../server/fixtures";
import { startHandlerServer } from "./helpers/node-server";

/*
 * pact-core ships native binaries for these platforms only. Importing
 * @pact-foundation/pact on any other platform throws at module load, so the
 * import is dynamic and the suite self-skips (CI on linux-x64 always runs it).
 */
const PACT_PLATFORMS = ["darwin-arm64", "darwin-x64", "linux-arm64", "linux-x64", "win32-x64"];
const hostPlatform = `${process.platform}-${process.arch}`;
const pactSupported = PACT_PLATFORMS.includes(hostPlatform);
if (!pactSupported) {
  console.warn(
    `PACT TESTS SKIPPED: pact-core has no native binary for ${hostPlatform}. ` +
      `Run the suite on one of: ${PACT_PLATFORMS.join(", ")}.`,
  );
}

type PactModule = typeof import("@pact-foundation/pact");
let pact: PactModule;

const pactDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "pacts");
const CONSUMER = "dbp-ps-audit-client";
const PROVIDER = "dbp-ps-audit";

const TEST_TENANT = "tenant-pact";
const EXISTING_ID = seedAuditEvents[0]!.id;

const actorData = { userId: "u-pact", email: "pact@example.com", displayName: "Pact User" };
const targetData = { entityType: "invoice", entityId: "inv-pact-001" };
const tenantHeaders = { "x-tenant-id": TEST_TENANT };
const jsonHeaders = { ...tenantHeaders, "content-type": "application/json" };

function newPact(): InstanceType<PactModule["PactV3"]> {
  return new pact.PactV3({ consumer: CONSUMER, provider: PROVIDER, dir: pactDir });
}

function bindClientTo(mockServerUrl: string): void {
  configureAuditClient({
    baseUrl: `${mockServerUrl}/api/platform/audit`,
    fetch: (input, init) => globalThis.fetch(input, init),
    tenantId: TEST_TENANT,
  });
}

function eventMatcher() {
  const { like, uuid, datetime } = pact.MatchersV3;
  return {
    id: uuid(EXISTING_ID),
    ts: datetime("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "2026-01-01T09:00:00.000Z"),
    actor: like(actorData),
    action: like("invoice.created"),
    target: like(targetData),
    delta: like({ amount: 100 }),
    tenantId: like(TEST_TENANT),
  };
}

describe.skipIf(!pactSupported)("Pact — consumer (client SDK against the mock provider)", () => {
  beforeAll(async () => {
    pact = await import("@pact-foundation/pact");
  });

  it("logs an event (POST /events)", async () => {
    const provider = newPact();
    provider
      .given("the tenant has no events")
      .uponReceiving("a request to log an audit event")
      .withRequest({
        method: "POST",
        path: "/api/platform/audit/events",
        headers: jsonHeaders,
        body: { actor: actorData, action: "invoice.created", target: targetData, delta: { amount: 100 } },
      })
      .willRespondWith({
        status: 201,
        headers: { "content-type": "application/json" },
        body: eventMatcher(),
      });

    await provider.executeTest(async (mockServer) => {
      bindClientTo(mockServer.url);
      await expect(
        logEvent({ actor: actorData, action: "invoice.created", target: targetData, delta: { amount: 100 } }),
      ).resolves.toBeUndefined();
    });
  });

  it("fetches the activity feed (GET /events)", async () => {
    const { eachLike, nullValue } = pact.MatchersV3;
    const provider = newPact();
    provider
      .given("the tenant has seeded events")
      .uponReceiving("a request to get the activity feed")
      .withRequest({
        method: "GET",
        path: "/api/platform/audit/events",
        headers: tenantHeaders,
      })
      .willRespondWith({
        status: 200,
        headers: { "content-type": "application/json" },
        body: {
          events: eachLike(eventMatcher()),
          nextCursor: nullValue(),
        },
      });

    await provider.executeTest(async (mockServer) => {
      bindClientTo(mockServer.url);
      const result = await getActivityFeed();
      expect(result.events.length).toBeGreaterThan(0);
    });
  });

  it("reads a single event (GET /events/:id)", async () => {
    const provider = newPact();
    provider
      .given("the tenant has seeded events")
      .uponReceiving("a request to read a specific audit event")
      .withRequest({
        method: "GET",
        path: `/api/platform/audit/events/${EXISTING_ID}`,
        headers: tenantHeaders,
      })
      .willRespondWith({
        status: 200,
        headers: { "content-type": "application/json" },
        body: eventMatcher(),
      });

    await provider.executeTest(async (mockServer) => {
      bindClientTo(mockServer.url);
      const event = await getEvent(EXISTING_ID);
      expect(event.id).toBe(EXISTING_ID);
    });
  });
});

describe.skipIf(!pactSupported)("Pact — provider (handlers on node:http verify the pact)", () => {
  beforeAll(async () => {
    pact = await import("@pact-foundation/pact");
  });

  it("verifies every interaction in the generated pact file", async () => {
    const pactFile = path.join(pactDir, `${CONSUMER}-${PROVIDER}.json`);
    expect(fs.existsSync(pactFile)).toBe(true);

    const server = await startHandlerServer();
    try {
      const output = await new pact.Verifier({
        provider: PROVIDER,
        providerBaseUrl: server.url,
        pactUrls: [pactFile],
        logLevel: "error",
        stateHandlers: {
          "the tenant has no events": async () => {
            resetAuditService();
            return "reset";
          },
          "the tenant has seeded events": async () => {
            resetAuditService();
            for (const event of seedAuditEvents) {
              await getAuditService().storage.append(TEST_TENANT, { ...event, tenantId: TEST_TENANT });
            }
            return "seeded";
          },
        },
      }).verifyProvider();
      expect(output).toContain("finished");
    } finally {
      await server.close();
    }
  });
});
