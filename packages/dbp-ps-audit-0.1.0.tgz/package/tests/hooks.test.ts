import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { renderHook, waitFor } from "@testing-library/react";
import { createElement, type ReactNode } from "react";
import { beforeEach, describe, expect, it } from "vitest";
import { resetAuditClient, useActivityFeed } from "../client/index";
import { resetAuditService } from "../server/index";
import { bindClientToHandlers, rawRequest, TEST_TENANT } from "./helpers/bind";

function makeWrapper() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  return ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, children);
}

const actor = { userId: "u-hook", email: "hook@example.com", displayName: "Hook User" };

async function appendEvent(action: string, entityId = "item-001"): Promise<void> {
  await rawRequest("POST", "/events", {
    body: { actor, action, target: { entityType: "item", entityId } },
    tenantId: TEST_TENANT,
  });
}

beforeEach(() => {
  resetAuditService();
  resetAuditClient();
  bindClientToHandlers();
});

describe("useActivityFeed", () => {
  it("returns events newest-first for the given entityId", async () => {
    await appendEvent("step.one");
    await appendEvent("step.two");

    const { result } = renderHook(() => useActivityFeed("item-001"), {
      wrapper: makeWrapper(),
    });

    await waitFor(() => expect(result.current.events).toHaveLength(2));
    expect(result.current.events[0]?.action).toBe("step.two");
    expect(result.current.events[1]?.action).toBe("step.one");
    expect(result.current.isLoading).toBe(false);
    expect(result.current.error).toBeNull();
  });

  it("exposes loadMore and hasMore for cursor pagination", async () => {
    for (let i = 0; i < 3; i += 1) {
      await appendEvent(`ev-${i}`);
    }

    const { result } = renderHook(() => useActivityFeed("item-001", { limit: 2 }), {
      wrapper: makeWrapper(),
    });

    await waitFor(() => expect(result.current.events).toHaveLength(2));
    expect(result.current.hasMore).toBe(true);

    result.current.loadMore();
    await waitFor(() => expect(result.current.events).toHaveLength(3));
    expect(result.current.hasMore).toBe(false);
  });

  it("returns empty events for an entity with no audit trail", async () => {
    const { result } = renderHook(() => useActivityFeed("ghost-entity"), {
      wrapper: makeWrapper(),
    });
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.events).toHaveLength(0);
    expect(result.current.hasMore).toBe(false);
  });
});
