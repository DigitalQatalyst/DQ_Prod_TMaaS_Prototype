import type { AuditEvent } from "../client/types";
import { getAuditService, type AuditService } from "./service";

export const SEED_TENANT_ID = "tenant-demo";

export const seedAuditEvents: AuditEvent[] = [
  {
    id: "a0000000-0000-4000-8000-000000000001",
    ts: "2026-01-01T09:00:00.000Z",
    actor: { userId: "u-001", email: "alice@example.com", displayName: "Alice" },
    action: "invoice.created",
    target: { entityType: "invoice", entityId: "e-001" },
    delta: { number: "INV-001", amount: 500 },
    tenantId: SEED_TENANT_ID,
  },
  {
    id: "a0000000-0000-4000-8000-000000000002",
    ts: "2026-01-02T10:00:00.000Z",
    actor: { userId: "u-002", email: "bob@example.com", displayName: "Bob" },
    action: "invoice.approved",
    target: { entityType: "invoice", entityId: "e-001" },
    delta: { status: "approved" },
    tenantId: SEED_TENANT_ID,
  },
  {
    id: "a0000000-0000-4000-8000-000000000003",
    ts: "2026-01-03T11:00:00.000Z",
    actor: { userId: "u-001", email: "alice@example.com", displayName: "Alice" },
    action: "contract.created",
    target: { entityType: "contract", entityId: "e-002" },
    delta: null,
    tenantId: SEED_TENANT_ID,
  },
];

export async function seedAuditService(target: AuditService = getAuditService()): Promise<void> {
  for (const event of seedAuditEvents) {
    await target.storage.append(SEED_TENANT_ID, event);
  }
}
