import { InMemoryAuditStorageAdapter, type AuditStorageAdapter } from "./storage";

export type AuditService = {
  storage: AuditStorageAdapter;
};

let service: AuditService = {
  storage: new InMemoryAuditStorageAdapter(),
};

export function getAuditService(): AuditService {
  return service;
}

export function configureAuditService(overrides: Partial<AuditService>): AuditService {
  service = { ...service, ...overrides };
  return service;
}

export function resetAuditService(): AuditService {
  service = { storage: new InMemoryAuditStorageAdapter() };
  return service;
}
