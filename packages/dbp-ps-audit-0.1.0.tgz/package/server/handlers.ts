import {
  ActivityFeedQuerySchema,
  AuditEventSchema,
  LogEventRequestSchema,
  type ValidationIssue,
} from "../client/types";
import { getAuditService } from "./service";

export const BASE_PATH = "/api/platform/audit";

export type RouteHandler = (req: Request) => Promise<Response>;

export type RouteDefinition = {
  method: "GET" | "POST" | "PATCH" | "DELETE";
  path: string;
  handler: RouteHandler;
};

const json = (status: number, body: unknown): Response =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });

const errorResponse = (status: number, message: string, issues?: ValidationIssue[]): Response =>
  json(status, issues && issues.length > 0 ? { error: message, issues } : { error: message });

function pathSegments(req: Request): string[] {
  const { pathname } = new URL(req.url);
  if (!pathname.startsWith(BASE_PATH)) return [];
  return pathname
    .slice(BASE_PATH.length)
    .split("/")
    .filter(Boolean)
    .map(decodeURIComponent);
}

function tenantOf(req: Request): string | null {
  const tenantId = req.headers.get("x-tenant-id")?.trim();
  return tenantId ? tenantId : null;
}

async function readJsonBody(req: Request): Promise<{ ok: true; value: unknown } | { ok: false }> {
  try {
    return { ok: true, value: await req.json() };
  } catch {
    return { ok: false };
  }
}

const zodIssues = (issues: { path: (string | number)[]; message: string }[]): ValidationIssue[] =>
  issues.map((issue) => ({ path: issue.path.join(".") || "(root)", message: issue.message }));

export const logEventHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");
  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");
  const parsed = LogEventRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid log event request", zodIssues(parsed.error.issues));
  }
  const event = AuditEventSchema.parse({
    id: crypto.randomUUID(),
    ts: new Date().toISOString(),
    actor: parsed.data.actor,
    action: parsed.data.action,
    target: parsed.data.target,
    delta: parsed.data.delta ?? null,
    tenantId,
  });
  await getAuditService().storage.append(tenantId, event);
  return json(201, event);
};

export const getActivityFeedHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");
  const params = new URL(req.url).searchParams;
  const queryParsed = ActivityFeedQuerySchema.safeParse({
    entityId: params.get("entityId") ?? undefined,
    cursor: params.get("cursor") ?? undefined,
    limit: params.get("limit") ?? undefined,
  });
  if (!queryParsed.success) {
    return errorResponse(400, "invalid query parameters", zodIssues(queryParsed.error.issues));
  }
  const result = await getAuditService().storage.list(tenantId, {
    ...(queryParsed.data.entityId !== undefined && { entityId: queryParsed.data.entityId }),
    ...(queryParsed.data.cursor !== undefined && { cursor: queryParsed.data.cursor }),
    limit: queryParsed.data.limit,
  });
  return json(200, result);
};

export const getEventHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");
  const [, id] = pathSegments(req);
  if (!id) return errorResponse(404, "event not found");
  const event = await getAuditService().storage.get(tenantId, id);
  if (!event) return errorResponse(404, `no audit event with id ${id}`);
  return json(200, event);
};

export const routes: RouteDefinition[] = [
  { method: "POST", path: `${BASE_PATH}/events`, handler: logEventHandler },
  { method: "GET", path: `${BASE_PATH}/events`, handler: getActivityFeedHandler },
  { method: "GET", path: `${BASE_PATH}/events/:id`, handler: getEventHandler },
];

function matchesPattern(pattern: string, pathname: string): boolean {
  const expected = pattern.split("/").filter(Boolean);
  const actual = pathname.split("/").filter(Boolean);
  if (expected.length !== actual.length) return false;
  return expected.every((segment, index) => segment.startsWith(":") || segment === actual[index]);
}

export const dispatch: RouteHandler = async (req) => {
  const { pathname } = new URL(req.url);
  for (const route of routes) {
    if (route.method === req.method && matchesPattern(route.path, pathname)) {
      return route.handler(req);
    }
  }
  return errorResponse(404, `no PS.AUDIT route for ${req.method} ${pathname}`);
};
