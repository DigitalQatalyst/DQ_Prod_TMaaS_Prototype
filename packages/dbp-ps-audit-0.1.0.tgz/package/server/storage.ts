import type { AuditEvent } from "../client/types";

export type AuditStorageListOptions = {
  entityId?: string;
  cursor?: string;
  limit: number;
};

export type AuditStorageListResult = {
  events: AuditEvent[];
  nextCursor: string | null;
};

/**
 * Append-only audit log storage. The interface deliberately omits update and
 * delete so no implementation can mutate written records — immutability is
 * enforced at the type boundary, not just by convention.
 */
export interface AuditStorageAdapter {
  append(tenantId: string, event: AuditEvent): Promise<void>;
  get(tenantId: string, id: string): Promise<AuditEvent | undefined>;
  list(tenantId: string, options: AuditStorageListOptions): Promise<AuditStorageListResult>;
}

export class InMemoryAuditStorageAdapter implements AuditStorageAdapter {
  /**
   * Insertion-ordered Map per tenant. Map preserves insertion order, so
   * iterating values() yields events in append (oldest-first) order; the
   * list method reverses for newest-first feed ordering.
   */
  private readonly buckets = new Map<string, Map<string, AuditEvent>>();

  private bucket(tenantId: string): Map<string, AuditEvent> {
    let b = this.buckets.get(tenantId);
    if (!b) {
      b = new Map();
      this.buckets.set(tenantId, b);
    }
    return b;
  }

  async append(tenantId: string, event: AuditEvent): Promise<void> {
    this.bucket(tenantId).set(event.id, Object.freeze({ ...event }));
  }

  async get(tenantId: string, id: string): Promise<AuditEvent | undefined> {
    const stored = this.bucket(tenantId).get(id);
    if (!stored) return undefined;
    return { ...stored };
  }

  async list(tenantId: string, options: AuditStorageListOptions): Promise<AuditStorageListResult> {
    const { entityId, cursor, limit } = options;
    const all = [...this.bucket(tenantId).values()].reverse();

    const filtered = entityId
      ? all.filter((e) => e.target.entityId === entityId)
      : all;

    let startIndex = 0;
    if (cursor !== undefined) {
      const idx = filtered.findIndex((e) => e.id === cursor);
      startIndex = idx === -1 ? filtered.length : idx + 1;
    }

    const page = filtered.slice(startIndex, startIndex + limit);
    const nextCursor = startIndex + limit < filtered.length ? (page[page.length - 1]?.id ?? null) : null;

    return {
      events: page.map((e) => ({ ...e })),
      nextCursor,
    };
  }

  clear(): void {
    this.buckets.clear();
  }
}
