import { useInfiniteQuery } from "@tanstack/react-query";
import { getActivityFeed, type FeedOptions } from "./sdk";
import type { ActivityFeedResponse, AuditEvent } from "./types";

const feedKey = (entityId: string | undefined) =>
  ["ps-audit", "activity-feed", entityId ?? "__all__"] as const;

export type ActivityFeedResult = {
  events: AuditEvent[];
  loadMore: () => void;
  hasMore: boolean;
  isLoading: boolean;
  isFetchingNextPage: boolean;
  error: Error | null;
};

export function useActivityFeed(
  entityId: string,
  options?: Pick<FeedOptions, "limit">,
): ActivityFeedResult {
  const query = useInfiniteQuery<ActivityFeedResponse, Error>({
    queryKey: feedKey(entityId),
    queryFn: ({ pageParam }) => {
      const cursor = typeof pageParam === "string" ? pageParam : undefined;
      const limit = options?.limit;
      return getActivityFeed({
        entityId,
        ...(cursor !== undefined && { cursor }),
        ...(limit !== undefined && { limit }),
      });
    },
    initialPageParam: undefined as string | undefined,
    getNextPageParam: (lastPage) => lastPage.nextCursor ?? undefined,
  });

  const events: AuditEvent[] = query.data?.pages.flatMap((p) => p.events) ?? [];

  return {
    events,
    loadMore: () => void query.fetchNextPage(),
    hasMore: query.hasNextPage,
    isLoading: query.isLoading,
    isFetchingNextPage: query.isFetchingNextPage,
    error: query.error,
  };
}
