import { request } from "./http";
import type {
  ActivityFeedResponse,
  AuditActor,
  AuditEvent,
  AuditTarget,
} from "./types";

export type LogEventInput = {
  actor: AuditActor;
  action: string;
  target: AuditTarget;
  delta?: Record<string, unknown> | null;
};

export async function logEvent(input: LogEventInput): Promise<void> {
  await request<AuditEvent>("POST", "/events", { body: input });
}

export async function getEvent(id: string): Promise<AuditEvent> {
  return request<AuditEvent>("GET", `/events/${id}`);
}

export type FeedOptions = {
  entityId?: string;
  cursor?: string;
  limit?: number;
};

export async function getActivityFeed(options: FeedOptions = {}): Promise<ActivityFeedResponse> {
  const query: Record<string, string> = {};
  if (options.entityId !== undefined) query.entityId = options.entityId;
  if (options.cursor !== undefined) query.cursor = options.cursor;
  if (options.limit !== undefined) query.limit = String(options.limit);
  return request<ActivityFeedResponse>("GET", "/events", { query });
}
