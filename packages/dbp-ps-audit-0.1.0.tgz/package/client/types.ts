import { z } from "zod";

export const AuditActorSchema = z
  .object({
    userId: z.string().min(1),
    email: z.string().email(),
    displayName: z.string().min(1),
  })
  .strict();
export type AuditActor = z.infer<typeof AuditActorSchema>;

export const AuditTargetSchema = z
  .object({
    entityType: z.string().min(1),
    entityId: z.string().min(1),
  })
  .strict();
export type AuditTarget = z.infer<typeof AuditTargetSchema>;

export const AuditEventSchema = z
  .object({
    id: z.string().uuid(),
    ts: z.string().datetime(),
    actor: AuditActorSchema,
    action: z.string().min(1),
    target: AuditTargetSchema,
    delta: z.record(z.string(), z.unknown()).nullable(),
    tenantId: z.string().min(1),
  })
  .strict();
export type AuditEvent = z.infer<typeof AuditEventSchema>;

export const LogEventRequestSchema = z
  .object({
    actor: AuditActorSchema,
    action: z.string().min(1),
    target: AuditTargetSchema,
    delta: z.record(z.string(), z.unknown()).nullable().optional(),
  })
  .strict();
export type LogEventRequest = z.infer<typeof LogEventRequestSchema>;

export const ActivityFeedQuerySchema = z
  .object({
    entityId: z.string().min(1).optional(),
    cursor: z.string().optional(),
    limit: z.coerce.number().int().min(1).max(100).default(20),
  })
  .strict();
export type ActivityFeedQuery = z.infer<typeof ActivityFeedQuerySchema>;

export const ActivityFeedResponseSchema = z
  .object({
    events: z.array(AuditEventSchema),
    nextCursor: z.string().nullable(),
  })
  .strict();
export type ActivityFeedResponse = z.infer<typeof ActivityFeedResponseSchema>;

export const ValidationIssueSchema = z
  .object({ path: z.string(), message: z.string() })
  .strict();
export type ValidationIssue = z.infer<typeof ValidationIssueSchema>;

export const ErrorResponseSchema = z
  .object({
    error: z.string(),
    issues: z.array(ValidationIssueSchema).optional(),
  })
  .strict();
export type ErrorResponse = z.infer<typeof ErrorResponseSchema>;
