export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

export type AuditClientConfig = {
  baseUrl: string;
  fetch: FetchLike;
  tenantId: string;
};

const defaults: AuditClientConfig = {
  baseUrl: "/api/platform/audit",
  fetch: (input, init) => globalThis.fetch(input, init),
  tenantId: "default",
};

let current: AuditClientConfig = { ...defaults };

export function configureAuditClient(overrides: Partial<AuditClientConfig>): void {
  current = { ...current, ...overrides };
}

export function getAuditClientConfig(): AuditClientConfig {
  return current;
}

export function resetAuditClient(): void {
  current = { ...defaults };
}
