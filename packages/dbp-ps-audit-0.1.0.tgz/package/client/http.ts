import { getAuditClientConfig } from "./config";
import { ErrorResponseSchema, type ErrorResponse } from "./types";

export class AuditServiceError extends Error {
  readonly status: number;
  readonly issues: ErrorResponse["issues"];

  constructor(status: number, body: ErrorResponse) {
    super(body.error);
    this.name = "AuditServiceError";
    this.status = status;
    this.issues = body.issues;
  }
}

type RequestOptions = {
  body?: unknown;
  query?: Record<string, string>;
};

export async function request<T>(
  method: string,
  path: string,
  options: RequestOptions = {},
): Promise<T> {
  const { baseUrl, fetch, tenantId } = getAuditClientConfig();
  const query =
    options.query && Object.keys(options.query).length > 0
      ? `?${new URLSearchParams(options.query).toString()}`
      : "";
  const headers: Record<string, string> = { "x-tenant-id": tenantId };
  if (options.body !== undefined) headers["content-type"] = "application/json";
  const response = await fetch(`${baseUrl}${path}${query}`, {
    method,
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : null,
  });
  if (response.status === 204) return undefined as T;
  const payload = (await response.json()) as unknown;
  if (!response.ok) {
    const parsed = ErrorResponseSchema.safeParse(payload);
    throw new AuditServiceError(
      response.status,
      parsed.success
        ? parsed.data
        : { error: `PS.AUDIT request failed with status ${response.status}` },
    );
  }
  return payload as T;
}
