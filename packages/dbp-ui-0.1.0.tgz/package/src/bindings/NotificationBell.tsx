import * as React from "react";
import { Bell } from "lucide-react";
import { useNotifications } from "@dbp/ps-notif/client";
import { Badge } from "../components/badge.js";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "../components/dropdown-menu.js";
import { cn } from "../lib/cn.js";

export interface NotificationBellProps {
  sessionHeader?: string;
}

function relativeTime(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

const RECENT_LIMIT = 8;

export function NotificationBell({ sessionHeader }: NotificationBellProps) {
  const { items, unread, markRead, markAllRead, isLoading } =
    useNotifications(sessionHeader);

  const recent = items.slice(0, RECENT_LIMIT);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          aria-label={`Notifications${unread > 0 ? `, ${unread} unread` : ""}`}
          className={cn(
            "relative inline-flex items-center justify-center h-10 w-10 rounded",
            "text-[var(--color-text)] hover:bg-[color-mix(in_srgb,var(--color-border)_50%,transparent)]",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)]",
          )}
        >
          <Bell className="h-5 w-5" aria-hidden="true" />
          {unread > 0 && (
            <Badge
              tone="danger"
              aria-hidden="true"
              className="absolute -top-1 -right-1 h-4 min-w-[1rem] px-1 text-[10px] leading-none flex items-center justify-center"
            >
              {unread > 99 ? "99+" : unread}
            </Badge>
          )}
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-80 max-h-96 overflow-y-auto">
        <div className="flex items-center justify-between px-2 py-1.5">
          <DropdownMenuLabel className="p-0 text-sm font-semibold">
            Notifications
          </DropdownMenuLabel>
          {unread > 0 && (
            <button
              onClick={markAllRead}
              className="text-xs text-[var(--color-primary)] hover:underline focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--color-primary)]"
              aria-label="Mark all notifications as read"
            >
              Mark all read
            </button>
          )}
        </div>
        <DropdownMenuSeparator />

        {isLoading && (
          <div className="px-3 py-4 text-sm text-[var(--color-text)] opacity-60 text-center">
            Loading…
          </div>
        )}

        {!isLoading && recent.length === 0 && (
          <div className="px-3 py-4 text-sm text-[var(--color-text)] opacity-60 text-center">
            No notifications.
          </div>
        )}

        {recent.map((n) => (
          <DropdownMenuItem
            key={n.id}
            className={cn(
              "flex flex-col items-start gap-0.5 px-3 py-2 cursor-pointer",
              n.status === "unread" && "bg-[color-mix(in_srgb,var(--color-primary)_6%,transparent)]",
            )}
            onClick={() => markRead(n.id)}
            aria-label={`${n.status === "unread" ? "Unread: " : ""}${n.message}`}
          >
            <span
              className={cn(
                "text-sm leading-snug",
                n.status === "unread"
                  ? "font-medium text-[var(--color-text)]"
                  : "text-[var(--color-text)] opacity-70",
              )}
            >
              {n.message}
            </span>
            <span className="text-xs text-[var(--color-text)] opacity-50">
              {relativeTime(n.ts)}
            </span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
