import * as React from "react";
import { useActivityFeed } from "@dbp/ps-audit/client";
import { ScrollArea } from "../components/scroll-area.js";
import { Skeleton } from "../components/skeleton.js";
import { Button } from "../components/button.js";
import { cn } from "../lib/cn.js";

export interface ActivityFeedProps {
  entityId: string;
  tenantId?: string;
  limit?: number;
  title?: string;
}

function relativeTime(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export function ActivityFeed({ entityId, limit, title }: ActivityFeedProps) {
  const { events, loadMore, hasMore, isLoading, isFetchingNextPage, error } =
    useActivityFeed(entityId, limit !== undefined ? { limit } : undefined);

  return (
    <div className="flex flex-col gap-2 w-full" role="region" aria-label={title ?? "Activity feed"}>
      {title && (
        <h2 className="text-sm font-semibold text-[var(--color-text)] px-1">{title}</h2>
      )}

      {error && (
        <p className="text-sm text-red-600 px-1" role="alert">
          Failed to load activity.
        </p>
      )}

      <ScrollArea className="h-full max-h-[480px]">
        <ul className="flex flex-col gap-1 pr-3" aria-label="Activity events">
          {isLoading &&
            Array.from({ length: 4 }).map((_, i) => (
              <li key={i} className="flex flex-col gap-1 p-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </li>
            ))}

          {!isLoading && events.length === 0 && !error && (
            <li className="p-2 text-sm text-[var(--color-text)] opacity-60">
              No activity yet.
            </li>
          )}

          {events.map((event) => (
            <li
              key={event.id}
              className={cn(
                "rounded-md p-2 text-sm border border-[var(--color-border)]",
                "bg-[var(--color-surface)]",
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium text-[var(--color-text)] truncate">
                  {event.actor.displayName}
                </span>
                <time
                  dateTime={event.ts}
                  className="text-xs text-[var(--color-text)] opacity-60 shrink-0"
                >
                  {relativeTime(event.ts)}
                </time>
              </div>
              <p className="text-[var(--color-text)] opacity-80 mt-0.5">
                <span className="font-mono text-xs bg-[var(--color-border)] rounded px-1 mr-1">
                  {event.action}
                </span>
                {event.target.entityType}/{event.target.entityId}
              </p>
              {event.delta && (
                <details className="mt-1">
                  <summary className="text-xs text-[var(--color-text)] opacity-60 cursor-pointer select-none">
                    Changes
                  </summary>
                  <pre className="mt-1 text-xs bg-[var(--color-border)] rounded p-1 overflow-x-auto">
                    {JSON.stringify(event.delta, null, 2)}
                  </pre>
                </details>
              )}
            </li>
          ))}

          {isFetchingNextPage &&
            Array.from({ length: 2 }).map((_, i) => (
              <li key={`next-${i}`} className="flex flex-col gap-1 p-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </li>
            ))}
        </ul>
      </ScrollArea>

      {hasMore && !isFetchingNextPage && (
        <Button
          variant="ghost"
          size="sm"
          onClick={loadMore}
          className="self-start mt-1"
          aria-label="Load more activity"
        >
          Load more
        </Button>
      )}
    </div>
  );
}
