import * as React from "react";
import { cn } from "../lib/cn.js";

export interface SlotFrameProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The named slot this frame represents — shown as the label when empty */
  slotName: string;
  /** When true the frame renders the empty-state placeholder; when false renders children normally */
  isEmpty?: boolean;
}

/**
 * SlotFrame — labeled empty-state container for named shell slots.
 *
 * Shells use this to visibly surface every slot during development and in stories.
 * When isEmpty=true (default when no children provided) it renders a dashed-border
 * placeholder with the slot name. When isEmpty=false (or when children are provided)
 * it renders as a transparent passthrough wrapper so layout is preserved.
 *
 * The dashed border and label come from the muted border/text tokens so the frame
 * recedes in the layout without disappearing entirely.
 */
const SlotFrame = React.forwardRef<HTMLDivElement, SlotFrameProps>(
  ({ slotName, isEmpty, className, children, ...props }, ref) => {
    const showEmpty = isEmpty ?? !children;
    return (
      <div
        ref={ref}
        data-slot-name={slotName}
        className={cn(
          "relative h-full w-full",
          showEmpty && [
            "flex items-center justify-center",
            "rounded border-2 border-dashed border-[color-mix(in_srgb,var(--color-border)_80%,transparent)]",
            "bg-[color-mix(in_srgb,var(--color-surface)_95%,var(--color-border))]",
            "min-h-16",
          ],
          className,
        )}
        {...props}
      >
        {showEmpty ? (
          <span
            aria-label={`Empty slot: ${slotName}`}
            className="select-none font-mono text-xs text-[color-mix(in_srgb,var(--color-text)_35%,transparent)]"
          >
            slot:{slotName}
          </span>
        ) : (
          children
        )}
      </div>
    );
  },
);
SlotFrame.displayName = "SlotFrame";

export { SlotFrame };
