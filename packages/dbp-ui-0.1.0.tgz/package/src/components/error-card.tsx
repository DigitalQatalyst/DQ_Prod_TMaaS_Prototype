import * as React from 'react'
import { AlertCircle } from 'lucide-react'

export interface ErrorCardProps {
  message: string
  onRetry?: () => void
}

export function ErrorCard({ message, onRetry }: ErrorCardProps) {
  return (
    <div className="flex items-start gap-3 rounded-[var(--radius)] border border-[var(--color-destructive,#ef4444)]/20 bg-[var(--color-destructive,#ef4444)]/5 px-4 py-3">
      <AlertCircle
        size={16}
        strokeWidth={1.5}
        className="mt-0.5 shrink-0 text-[var(--color-destructive,#ef4444)]"
        aria-hidden
      />
      <div className="flex-1 min-w-0">
        <p className="text-[length:var(--text-sm,0.875rem)] text-[var(--color-text)]">{message}</p>
      </div>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="shrink-0 text-[length:var(--text-sm,0.875rem)] font-medium text-[var(--color-primary)] hover:underline focus-visible:outline-none"
        >
          Retry
        </button>
      )}
    </div>
  )
}
