import * as React from "react"
import { cn } from "../lib/cn.js"

export interface LandingFooterLinkItem {
  label: string
  href: string
}

export interface LandingFooterColumn {
  heading: string
  links: LandingFooterLinkItem[]
}

export interface LandingFooterProps {
  /** Solution code shown bold-white in the dark lockup (e.g. "DWS.01"). */
  productCode: string
  /** Product name shown muted after the code (e.g. "Work.Space4.0"). */
  productName?: string
  /** Short tagline rendered below the lockup in the first column. */
  tagline?: string
  /** Link columns (up to 2 used; remaining cols 1-2 are product lockup). */
  columns?: LandingFooterColumn[]
  /** Legal/copyright text in the bottom row (required per spec). */
  legal?: string
  className?: string
}

/**
 * LandingFooter — dark navy footer.
 *
 * Layout: md:grid-cols-4 — col 1-2 = product lockup (dark) + tagline;
 * col 3-4 = link columns (prop `columns`).
 *
 * Bottom legal row: border-t border-white/10 pt-6 text-[11px]
 * (this row is NEW — not present in the prototype Footer.tsx).
 */
export function LandingFooter({
  productCode,
  productName,
  tagline = "A governed execution workspace for digital business teams.",
  columns = [],
  legal,
  className,
}: LandingFooterProps) {
  const currentYear = new Date().getFullYear()
  const legalText = legal ?? `© ${currentYear} DigitalQatalyst. All rights reserved.`

  return (
    <footer
      className={cn(
        "bg-primary text-white",
        className
      )}
      aria-label="Site footer"
    >
      <div className="mx-auto max-w-[1200px] px-5 py-12 md:px-8 lg:px-10">

        {/* Main grid — brand column + up to 3 link columns (true 4-column footer) */}
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-[1.6fr_1fr_1fr_1fr]">

          {/* Col 1: product lockup + tagline */}
          <div className="space-y-4">
            {/* Dark variant lockup */}
            <a
              href="/"
              className={cn(
                "inline-flex items-baseline gap-1.5",
                "hover:opacity-80 motion-safe:transition-opacity",
                "focus-visible:outline-none focus-visible:[box-shadow:0_0_0_3px_rgba(255,255,255,0.3)] rounded-sm"
              )}
              aria-label={`${productCode}${productName ? ` — ${productName}` : ""} home`}
            >
              <span className="text-[18px] font-bold leading-none text-white">
                {productCode}
              </span>
              {productName && (
                <span className="text-[15px] font-medium leading-none text-[var(--color-navy-200)]">
                  / {productName}
                </span>
              )}
            </a>

            {tagline && (
              <p className="max-w-md text-sm leading-relaxed text-[var(--color-navy-200)]">
                {tagline}
              </p>
            )}
          </div>

          {/* Cols 2–4: link columns (mono-caps headings) */}
          {columns.length > 0
            ? columns.slice(0, 3).map((col, i) => (
                <nav
                  key={i}
                  aria-label={col.heading}
                  className="space-y-4"
                >
                  <h3
                    className={cn(
                      "font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-white"
                    )}
                  >
                    {col.heading}
                  </h3>
                  <ul className="space-y-2">
                    {col.links.map((link) => (
                      <li key={link.href}>
                        <a
                          href={link.href}
                          className={cn(
                            "text-sm text-[var(--color-navy-200)]",
                            "hover:text-white motion-safe:transition-colors",
                            "focus-visible:outline-none focus-visible:[box-shadow:0_0_0_3px_rgba(255,255,255,0.3)] rounded-sm"
                          )}
                        >
                          {link.label}
                        </a>
                      </li>
                    ))}
                  </ul>
                </nav>
              ))
            : (
              // Default placeholder columns when none provided (Explore · Marketplaces · Company)
              <>
                {[
                  { heading: "Explore", links: ["Orientation", "Operating Guide", "Marketplace", "Dashboard"] },
                  { heading: "Marketplaces", links: ["Services", "Task Templates", "Knowledge", "Work Directory"] },
                  { heading: "Company", links: ["About", "Security", "Support", "Contact"] },
                ].map((col) => (
                  <nav key={col.heading} aria-label={col.heading} className="space-y-4">
                    <h3 className="font-mono text-[10px] font-bold uppercase tracking-[0.14em] text-white">
                      {col.heading}
                    </h3>
                    <ul className="space-y-2">
                      {col.links.map((label) => (
                        <li key={label}>
                          <a
                            href="#"
                            className="text-sm text-[var(--color-navy-200)] hover:text-white motion-safe:transition-colors focus-visible:outline-none focus-visible:[box-shadow:0_0_0_3px_rgba(255,255,255,0.3)] rounded-sm"
                          >
                            {label}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </nav>
                ))}
              </>
            )}
        </div>

        {/* Legal row — NEW: not in prototype Footer.tsx */}
        <div
          className={cn(
            "mt-10 border-t border-white/10 pt-6",
            "text-[11px] text-[var(--color-navy-200)]"
          )}
        >
          {legalText}
        </div>
      </div>
    </footer>
  )
}
