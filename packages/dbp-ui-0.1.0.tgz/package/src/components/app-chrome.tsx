import * as React from "react";
import { AppTopBar } from "./app-top-bar.js";
import { AvatarLockup } from "./avatar.js";
import { SegmentedControl } from "./segmented-control.js";
import { SearchBar } from "../bindings/SearchBar.js";
import { NotificationBell } from "../bindings/NotificationBell.js";
import type { SearchHit } from "@dbp/ps-search/client";
import type { TopBarConfig } from "@dbp/contracts";

/**
 * AppChromeSession — the authenticated identity the top bar renders from.
 *
 * Structurally identical to PS.AUTH's `SessionIdentity` (see
 * @dbp/ps-auth/client). It is re-declared here, rather than imported, so that
 * @dbp/ui never takes a hard dependency on @dbp/ps-auth: the session is *passed
 * in* by the app page (which already calls `useSessionIdentity()`), keeping the
 * layer split clean. The avatar/role/tenant on the bar are ALWAYS derived from
 * this object — never hardcoded.
 */
export interface AppChromeSession {
  userId: string;
  email: string;
  /** Display name for the avatar lockup. */
  displayName: string;
  /** Humanised primary role for the avatar sub-label. */
  primaryRole: string;
  /** All roles in the active tenant — feeds the optional role switcher. */
  roles: ReadonlyArray<string>;
  /** Active tenant id (config-driven via IAM). */
  tenantId: string;
}

/**
 * AppChromeCapabilities — which optional top-bar affordances are wired.
 *
 * These are a pure function of the solution's `consumes_platform_services`
 * (emitted by the scaffold generator): global SEARCH appears only when
 * PS.SEARCH is wired; the NOTIFICATIONS bell only when PS.NOTIF is wired. The
 * user/avatar block (PS.AUTH, always present) and Settings are not gated here.
 * A future solution that wires PS.SEARCH gets search with zero extra config.
 */
export interface AppChromeCapabilities {
  /** PS.SEARCH ∈ consumedServices → render the global SearchBar. */
  search?: boolean;
  /** PS.NOTIF ∈ consumedServices → render the NotificationBell. */
  notifications?: boolean;
}

export interface AppChromeProps {
  /** Solution code shown bold in the lockup (e.g. "DIA.02"). From the manifest. */
  productCode: string;
  /** Product name shown muted after the code (e.g. "AnalyticsOps"). From the manifest. */
  productName?: string;
  /** The active authenticated identity, or null while loading / unauthenticated. */
  session: AppChromeSession | null;
  /** Capability flags derived from the solution's wired platform services. */
  capabilities?: AppChromeCapabilities;
  /** Placeholder for the global search input. Defaults to "Search…". */
  searchPlaceholder?: string;
  /** Optional search scope passed to the SearchBar binding. */
  searchScope?: string;
  /** Called when a search hit is chosen (e.g. router push). */
  onSearchSelect?: (hit: SearchHit) => void;
  /** Called when the active role changes (only used when the session has 2+ roles). */
  onRoleChange?: (role: string) => void;
  /** Called when the settings affordance is activated. Omit ⇒ inert default. */
  onSettings?: () => void;
  /** Lockup variant. Defaults to light. */
  variant?: "light" | "dark";
  className?: string;
}

/**
 * AppChrome — the ONE connected top-bar composition inherited by every app.
 *
 * Renders the DQ-prototype-standard {@link AppTopBar}, fully config + session
 * driven:
 *   • product lockup  ← manifest `productCode` / `productName`
 *   • global search   ← {@link SearchBar} binding, gated by `capabilities.search`
 *                       (PS.SEARCH). Uses the bar's built-in ⌘K pill when absent.
 *   • notifications   ← {@link NotificationBell} binding, gated by
 *                       `capabilities.notifications` (PS.NOTIF).
 *   • settings        ← always present (icon button).
 *   • role switcher   ← only when the session carries 2+ roles; otherwise nothing.
 *   • avatar block    ← {@link AvatarLockup} from `session` (display name +
 *                       primary role, initials fallback). Nothing while the
 *                       session is loading / unauthenticated.
 *
 * Nothing is hardcoded: the same component drives all four apps and any future
 * clone. Tokens / dq-classes only, lucide stroke 1.5 inside the bindings, the
 * banned decorative glyph is never used, a11y from the underlying bar + bindings.
 */
export function AppChrome({
  productCode,
  productName,
  session,
  capabilities = {},
  searchPlaceholder = "Search…",
  searchScope,
  onSearchSelect,
  onRoleChange,
  onSettings,
  variant = "light",
  className,
}: AppChromeProps) {
  const showSearch = capabilities.search === true;
  const showNotifications = capabilities.notifications === true;
  const showUser = session !== null;

  const config: TopBarConfig = {
    appName: productName ? `${productCode} / ${productName}` : productCode,
    logoAlt: productCode,
    actions: [],
    showSearch,
    showNotifications,
    showUser,
  };

  // ── Search slot (PS.SEARCH) ──────────────────────────────────────────────
  const searchSlot = showSearch ? (
    <div className="hidden w-52 md:block xl:w-72">
      <SearchBar
        placeholder={searchPlaceholder}
        {...(searchScope !== undefined && { scope: searchScope })}
        {...(onSearchSelect !== undefined && { onSelect: onSearchSelect })}
      />
    </div>
  ) : undefined;

  // ── Notification slot (PS.NOTIF) ─────────────────────────────────────────
  const notificationSlot = showNotifications ? <NotificationBell /> : undefined;

  // ── Role switcher (optional — only with 2+ roles) ────────────────────────
  const roles = session?.roles ?? [];
  const [activeRole, setActiveRole] = React.useState<string | undefined>(
    roles.length > 0 ? roles[0] : undefined,
  );
  React.useEffect(() => {
    if (roles.length > 0 && (activeRole === undefined || !roles.includes(activeRole))) {
      setActiveRole(roles[0]);
    }
  }, [roles, activeRole]);

  const handleRoleChange = React.useCallback(
    (role: string) => {
      setActiveRole(role);
      onRoleChange?.(role);
    },
    [onRoleChange],
  );

  const roleSlot =
    roles.length > 1 && activeRole !== undefined ? (
      <SegmentedControl
        name="Active role"
        value={activeRole}
        onChange={handleRoleChange}
        options={roles.map((r) => ({ value: r, label: humanise(r), ariaLabel: humanise(r) }))}
        className="hidden xl:inline-flex"
      />
    ) : undefined;

  // ── Settings affordance ──────────────────────────────────────────────────
  // The default AppTopBar settings button is inert; when an onSettings handler
  // is supplied we render a wired button in its place (same visual treatment).
  const dark = variant === "dark";
  const settingsSlot = onSettings ? (
    <button
      type="button"
      onClick={onSettings}
      aria-label="Settings"
      className={[
        "flex h-9 w-9 items-center justify-center rounded-button transition-colors",
        "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
        dark ? "text-white hover:bg-white/10" : "text-primary hover:bg-surface",
      ].join(" ")}
    >
      <SettingsGlyph />
    </button>
  ) : undefined;

  // ── User slot (PS.AUTH — avatar lockup from session) ─────────────────────
  const userSlot = session ? (
    <div
      className={[
        "flex items-center border-l pl-3",
        dark ? "border-white/15" : "border-[var(--color-border-subtle)]",
      ].join(" ")}
    >
      <AvatarLockup
        name={session.displayName || session.email}
        {...(session.primaryRole ? { role: session.primaryRole } : {})}
      />
    </div>
  ) : undefined;

  return (
    <AppTopBar
      config={config}
      productCode={productCode}
      {...(productName !== undefined && { productName })}
      variant={variant}
      {...(className !== undefined && { className })}
      searchSlot={searchSlot}
      roleSlot={roleSlot}
      notificationSlot={notificationSlot}
      settingsSlot={settingsSlot}
      userSlot={userSlot}
    />
  );
}

/** Local humaniser (mirror of PS.AUTH's humaniseRole) so @dbp/ui stays auth-free. */
function humanise(role: string): string {
  return role
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

/** Inline settings glyph (lucide Settings at stroke 1.5). */
function SettingsGlyph() {
  return (
    <svg
      width={19}
      height={19}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}
