"use client";

import * as React from "react";
import { Search } from "lucide-react";
import { cn } from "../lib/cn";

export interface AISearchBarProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onSubmit"> {
  /** Placeholder text shown in the input when empty. */
  placeholder?: string;
  /** Called when the user submits (Enter key or submit button click). */
  onSubmit?: (value: string) => void;
  /**
   * When true (default), a ⌘K / Ctrl+K hint badge is shown at the
   * right end of the input. Pass false to hide it.
   */
  kbdHint?: boolean;
}

/**
 * AISearchBar — prominent search entry for the app-home hero.
 *
 * Matches the DWS.01 prototype AIDiscoverySearch anatomy:
 * - Icon tile bg-orange-50 using the Search lucide icon (NOT Sparkles).
 * - Input rounded-input, focus ring ring-secondary/20 via tokens.
 * - Optional ⌘K kbd hint.
 * - Submit on Enter or button click.
 *
 * "use client" — this component uses browser state and event handlers.
 */
export function AISearchBar({
  placeholder = "Search or ask anything…",
  onSubmit,
  kbdHint = true,
  className,
  ...props
}: AISearchBarProps) {
  const [value, setValue] = React.useState("");
  const [focused, setFocused] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement>(null);

  function handleSubmit() {
    const trimmed = value.trim();
    if (trimmed) {
      onSubmit?.(trimmed);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSubmit();
    }
  }

  // ⌘K / Ctrl+K global shortcut — focus the input
  React.useEffect(() => {
    function onGlobalKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        inputRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onGlobalKeyDown);
    return () => window.removeEventListener("keydown", onGlobalKeyDown);
  }, []);

  return (
    <div
      role="search"
      aria-label="AI search"
      className={cn(
        "flex h-11 items-center gap-3 rounded-[var(--radius-input)] border bg-white",
        "px-3 shadow-md transition-shadow sm:px-4",
        focused
          ? "border-[var(--color-secondary)] ring-2 ring-[var(--color-secondary)]/20"
          : "border-[var(--color-border-default)]",
        className,
      )}
      {...props}
    >
      {/* Icon tile — bg-orange-50, Search lucide icon */}
      <span
        aria-hidden="true"
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--radius-button)] bg-orange-50 text-[var(--color-secondary)]"
      >
        <Search size={17} strokeWidth={1.7} />
      </span>

      {/* Text input */}
      <input
        ref={inputRef}
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        aria-label={placeholder}
        className="min-w-0 flex-1 bg-transparent text-sm font-medium text-[var(--color-text-primary)] placeholder:text-[var(--color-text-disabled)] focus:outline-none"
        data-testid="ai-search-input"
      />

      {/* ⌘K hint */}
      {kbdHint && (
        <kbd
          aria-hidden="true"
          className="hidden sm:inline-flex h-5 items-center gap-1 rounded border border-[var(--color-border-strong)] bg-white px-1.5 font-mono text-[10px] font-medium text-[var(--color-text-muted)]"
        >
          <span className="text-xs">⌘</span>K
        </kbd>
      )}

      {/* Submit button */}
      <button
        type="button"
        aria-label="Submit search"
        onClick={handleSubmit}
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-[var(--radius-button)] text-[var(--color-text-muted)] hover:bg-[var(--color-navy-50)] hover:text-[var(--color-primary)] focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]"
        data-testid="ai-search-submit"
      >
        <Search size={18} strokeWidth={1.5} aria-hidden="true" />
      </button>
    </div>
  );
}
