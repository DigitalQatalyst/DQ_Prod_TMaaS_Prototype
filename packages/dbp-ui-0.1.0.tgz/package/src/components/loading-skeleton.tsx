import * as React from 'react'
import { cn } from '../lib/cn.js'

const shimmer = 'animate-pulse bg-[var(--color-surface-raised,#e5e7eb)] rounded-[var(--radius)]'

type SkeletonVariant = 'list' | 'card' | 'form' | 'chart'

export interface LoadingSkeletonProps {
  variant?: SkeletonVariant
  rows?: number
  className?: string
}

export function LoadingSkeleton({ variant = 'list', rows = 5, className }: LoadingSkeletonProps) {
  if (variant === 'card') {
    return (
      <div
        data-skeleton-card
        className={cn(
          'rounded-[var(--radius)] border border-[var(--color-border)] p-4 space-y-3',
          shimmer,
          className
        )}
      >
        <div className="h-4 w-3/4 rounded" />
        <div className="h-3 w-full rounded" />
        <div className="h-3 w-2/3 rounded" />
      </div>
    )
  }

  if (variant === 'form') {
    return (
      <div className={cn('space-y-4', className)}>
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="space-y-1">
            <div className={cn('h-3 w-24 rounded', shimmer)} />
            <div className={cn('h-9 w-full rounded', shimmer)} />
          </div>
        ))}
      </div>
    )
  }

  if (variant === 'chart') {
    return (
      <div className={cn('space-y-2', className)}>
        <div className={cn('h-[200px] w-full rounded', shimmer)} />
        <div className={cn('h-3 w-1/3 mx-auto rounded', shimmer)} />
      </div>
    )
  }

  // Default: list
  return (
    <div className={cn('space-y-2', className)}>
      {Array.from({ length: rows }).map((_, i) => (
        <div
          key={i}
          data-skeleton-row
          className={cn('flex items-center gap-3 px-3 py-2 rounded', shimmer)}
        >
          <div className="h-4 w-4 rounded-full shrink-0" />
          <div className="flex-1 space-y-1">
            <div className="h-3 w-1/2 rounded" />
            <div className="h-2 w-3/4 rounded" />
          </div>
        </div>
      ))}
    </div>
  )
}
