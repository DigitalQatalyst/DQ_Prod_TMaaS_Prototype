import * as React from "react"
import { cn } from "../lib/cn.js"

export interface SegmentOption {
  value: string
  label: React.ReactNode
  /** Accessible label if the visual label is not plain text */
  ariaLabel?: string
}

export interface SegmentedControlProps {
  options: SegmentOption[]
  value: string
  onChange: (value: string) => void
  className?: string
  /** Name for the underlying radiogroup (for a11y) */
  name?: string
}

export function SegmentedControl({
  options,
  value,
  onChange,
  className,
  name,
}: SegmentedControlProps) {
  const groupId = React.useId()
  const groupName = name ?? groupId

  return (
    <div
      role="radiogroup"
      aria-label={groupName}
      className={cn(
        "inline-flex h-10 items-center gap-0.5",
        "rounded-[var(--radius-pill)]",
        "border border-[var(--color-border-subtle)]",
        "bg-[var(--color-surface)]",
        "p-0.5",
        className
      )}
    >
      {options.map((opt) => {
        const isActive = opt.value === value
        return (
          <button
            key={opt.value}
            role="radio"
            aria-checked={isActive}
            aria-label={opt.ariaLabel}
            onClick={() => onChange(opt.value)}
            className={cn(
              "flex h-full items-center gap-1.5 rounded-[var(--radius-pill)] px-3",
              "text-xs font-semibold",
              "transition-all duration-150 motion-safe:transition-all",
              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
              isActive
                ? "bg-white shadow-sm text-primary"
                : "text-[var(--color-text-muted)] hover:text-primary"
            )}
          >
            {opt.label}
          </button>
        )
      })}
    </div>
  )
}
