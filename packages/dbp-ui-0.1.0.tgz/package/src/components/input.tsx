import * as React from "react"
import { cn } from "../lib/cn"

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  error?: boolean
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, error, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-10 w-full rounded-input px-3 text-sm bg-white text-[var(--color-text-primary)]",
          "placeholder:text-[var(--color-text-disabled)]",
          "transition-colors motion-safe:transition-all",
          "disabled:cursor-not-allowed disabled:opacity-50",
          "focus-visible:outline-none",
          error
            ? "border-[1.5px] border-danger focus-visible:[box-shadow:var(--focus-ring-error)]"
            : "border-[1.5px] border-border-default focus-visible:border-primary focus-visible:[box-shadow:var(--focus-ring-primary)]",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

function FieldLabel({ className, children, ...props }: React.LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label
      className={cn(
        "block text-xs font-bold uppercase tracking-wide text-primary mb-1.5",
        className
      )}
      {...props}
    >
      {children}
    </label>
  )
}

export { Input, FieldLabel }
