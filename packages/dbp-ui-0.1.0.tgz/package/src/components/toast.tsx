"use client"
import * as React from "react"
import * as ToastPrimitive from "@radix-ui/react-toast"
import { X, CheckCircle, AlertTriangle, XCircle, Info } from "lucide-react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn.js"

/* ─── Provider ──────────────────────────────────────────────────────────── */

export const ToastProvider = ToastPrimitive.Provider

export const ToastViewport = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Viewport>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Viewport>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Viewport
    ref={ref}
    className={cn(
      "fixed bottom-4 right-4 z-[var(--z-toast)]",
      "flex flex-col gap-2",
      "w-full max-w-sm",
      "outline-none",
      className
    )}
    {...props}
  />
))
ToastViewport.displayName = ToastPrimitive.Viewport.displayName

/* ─── Toast item ────────────────────────────────────────────────────────── */

const toastVariants = cva(
  [
    "group relative flex items-start gap-3",
    "w-full rounded-[var(--radius-card)]",
    "border shadow-[var(--shadow-lg)]",
    "px-4 py-3.5",
    "transition-all duration-300 motion-safe:transition-all",
    "data-[state=open]:animate-in data-[state=closed]:animate-out",
    "data-[state=closed]:fade-out-80 data-[state=open]:fade-in-0",
    "data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)]",
    "data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)]",
    "data-[swipe=move]:transition-none",
    "data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-right-full",
    "bg-white",
  ].join(" "),
  {
    variants: {
      tone: {
        default: "border-[var(--color-border-default)]",
        success: "border-[var(--color-success-border)] bg-[var(--color-success-surface)]",
        warning: "border-[var(--color-warning-border)] bg-[var(--color-warning-surface)]",
        danger:  "border-[var(--color-danger-border)]  bg-[var(--color-danger-surface)]",
        info:    "border-[var(--color-info-border)]    bg-[var(--color-info-surface)]",
      },
    },
    defaultVariants: {
      tone: "default",
    },
  }
)

const toneIconMap = {
  default: null,
  success: CheckCircle,
  warning: AlertTriangle,
  danger:  XCircle,
  info:    Info,
} as const

const toneIconColor: Record<string, string> = {
  default: "text-[var(--color-text-muted)]",
  success: "text-[var(--color-success-text)]",
  warning: "text-[var(--color-warning-text)]",
  danger:  "text-[var(--color-danger-text)]",
  info:    "text-[var(--color-info-text)]",
}

type ToastTone = keyof typeof toneIconMap

export interface ToastProps
  extends React.ComponentPropsWithoutRef<typeof ToastPrimitive.Root>,
    VariantProps<typeof toastVariants> {
  tone?: ToastTone
}

export const Toast = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Root>,
  ToastProps
>(({ tone = "default", className, children, ...props }, ref) => {
  const Icon = toneIconMap[tone]
  return (
    <ToastPrimitive.Root
      ref={ref}
      className={cn(toastVariants({ tone }), className)}
      {...props}
    >
      {Icon && (
        <span className={cn("mt-0.5 shrink-0", toneIconColor[tone])} aria-hidden="true">
          <Icon size={16} strokeWidth={1.5} />
        </span>
      )}
      <div className="min-w-0 flex-1">{children}</div>
      <ToastPrimitive.Close
        className={cn(
          "shrink-0 rounded-[var(--radius-button)]",
          "flex h-6 w-6 items-center justify-center",
          "text-[var(--color-text-muted)]",
          "opacity-60 transition-opacity hover:opacity-100",
          "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
        )}
        aria-label="Dismiss"
      >
        <X size={14} strokeWidth={1.5} />
      </ToastPrimitive.Close>
    </ToastPrimitive.Root>
  )
})
Toast.displayName = ToastPrimitive.Root.displayName

export const ToastTitle = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Title>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Title
    ref={ref}
    className={cn("text-sm font-semibold text-primary leading-snug", className)}
    {...props}
  />
))
ToastTitle.displayName = ToastPrimitive.Title.displayName

export const ToastDescription = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Description>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Description
    ref={ref}
    className={cn("text-xs text-[var(--color-text-muted)] mt-0.5", className)}
    {...props}
  />
))
ToastDescription.displayName = ToastPrimitive.Description.displayName

export const ToastAction = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Action>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Action>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Action
    ref={ref}
    className={cn(
      "mt-2 inline-flex h-7 items-center rounded-[var(--radius-button)] px-3",
      "text-xs font-medium",
      "border border-[var(--color-border-default)]",
      "bg-transparent text-primary",
      "transition-colors hover:bg-[var(--color-navy-50)]",
      "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
      className
    )}
    {...props}
  />
))
ToastAction.displayName = ToastPrimitive.Action.displayName

/* ─── useToast hook ─────────────────────────────────────────────────────── */

export type ToastOptions = {
  title?: string
  description?: string
  tone?: ToastTone
  duration?: number
  action?: { label: string; onClick: () => void }
}

type ToastEntry = ToastOptions & { id: string; open: boolean }

let listeners: Array<(toasts: ToastEntry[]) => void> = []
let toastState: ToastEntry[] = []

function emit(toasts: ToastEntry[]) {
  toastState = toasts
  listeners.forEach((l) => l(toasts))
}

export function toast(options: ToastOptions) {
  const id = String(Date.now()) + Math.random().toString(36).slice(2)
  emit([...toastState, { ...options, id, open: true }])
  return id
}

export function useToast() {
  const [toasts, setToasts] = React.useState<ToastEntry[]>(toastState)

  React.useEffect(() => {
    listeners.push(setToasts)
    return () => {
      listeners = listeners.filter((l) => l !== setToasts)
    }
  }, [])

  const dismiss = React.useCallback((id: string) => {
    emit(toastState.map((t) => (t.id === id ? { ...t, open: false } : t)))
  }, [])

  const remove = React.useCallback((id: string) => {
    emit(toastState.filter((t) => t.id !== id))
  }, [])

  return { toasts, dismiss, remove }
}

/* ─── Toaster (drop-in provider + viewport) ────────────────────────────── */

export function Toaster() {
  const { toasts, dismiss, remove } = useToast()

  return (
    <ToastProvider swipeDirection="right" duration={5000}>
      {toasts.map(({ id, open, title, description, tone, duration, action }) => (
        <Toast
          key={id}
          {...(tone !== undefined && { tone })}
          open={open}
          {...(duration !== undefined && { duration })}
          onOpenChange={(o) => { if (!o) dismiss(id) }}
          onSwipeEnd={() => remove(id)}
        >
          <div>
            {title && <ToastTitle>{title}</ToastTitle>}
            {description && <ToastDescription>{description}</ToastDescription>}
            {action && (
              <ToastAction altText={action.label} onClick={action.onClick} className="mt-1.5">
                {action.label}
              </ToastAction>
            )}
          </div>
        </Toast>
      ))}
      <ToastViewport />
    </ToastProvider>
  )
}
