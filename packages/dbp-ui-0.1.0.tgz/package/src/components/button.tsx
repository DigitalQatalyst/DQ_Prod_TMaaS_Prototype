import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { Loader2 } from "lucide-react"
import { cn } from "../lib/cn"

const buttonVariants = cva(
  [
    "inline-flex items-center justify-center gap-2",
    "font-semibold text-sm whitespace-nowrap select-none",
    "transition-colors motion-safe:transition-all",
    "disabled:pointer-events-none disabled:opacity-50",
    "focus-visible:outline-none",
    "active:translate-y-px",
  ].join(" "),
  {
    variants: {
      variant: {
        orange:
          "bg-secondary text-white hover:bg-[color-mix(in_srgb,var(--color-secondary)_85%,black)] focus-visible:[box-shadow:var(--focus-ring-secondary)] rounded-button",
        navy:
          "bg-primary text-white hover:bg-[color-mix(in_srgb,var(--color-primary)_85%,black)] focus-visible:[box-shadow:var(--focus-ring-primary)] rounded-button",
        outline:
          "border border-primary bg-transparent text-primary hover:bg-[var(--color-navy-50)] focus-visible:[box-shadow:var(--focus-ring-primary)] rounded-button",
        ghost:
          "bg-transparent text-[var(--color-text-secondary)] hover:bg-[var(--color-navy-50)] hover:text-primary focus-visible:[box-shadow:var(--focus-ring-primary)] rounded-button",
        destructive:
          "bg-[var(--color-danger)] text-white hover:bg-[color-mix(in_srgb,var(--color-danger)_85%,black)] focus-visible:[box-shadow:var(--focus-ring-error)] rounded-button",
        link:
          "text-primary underline-offset-4 hover:underline p-0 h-auto",
      },
      size: {
        default: "h-10 px-4",
        sm:      "h-8 px-3 text-xs",
        lg:      "h-12 px-6",
        icon:    "h-10 w-10 p-0 rounded-button",
      },
    },
    defaultVariants: {
      variant: "orange",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
  /** Shows a spinner, disables the button, and sets aria-busy while loading */
  loading?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, loading = false, children, disabled, style, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"

    /* Width-lock: capture inline minWidth so the button doesn't shrink while spinner shows */
    const btnRef = React.useRef<HTMLButtonElement | null>(null)
    const [minWidth, setMinWidth] = React.useState<number | undefined>(undefined)

    React.useLayoutEffect(() => {
      if (loading && btnRef.current) {
        setMinWidth(btnRef.current.offsetWidth)
      } else if (!loading) {
        setMinWidth(undefined)
      }
    }, [loading])

    const mergedRef = (node: HTMLButtonElement | null) => {
      btnRef.current = node
      if (typeof ref === "function") ref(node)
      else if (ref) (ref as React.MutableRefObject<HTMLButtonElement | null>).current = node
    }

    return (
      <Comp
        ref={mergedRef}
        className={cn(buttonVariants({ variant, size, className }))}
        disabled={loading || disabled}
        aria-busy={loading ? "true" : undefined}
        style={minWidth !== undefined ? { minWidth, ...style } : style}
        {...props}
      >
        {loading ? (
          <>
            <Loader2
              size={14}
              strokeWidth={2}
              className="motion-safe:animate-spin shrink-0"
              aria-hidden="true"
            />
            {children}
          </>
        ) : children}
      </Comp>
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
