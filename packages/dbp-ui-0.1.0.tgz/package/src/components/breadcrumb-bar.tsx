import * as React from 'react'
import { ChevronRight } from 'lucide-react'

interface Crumb { label: string; href: string }

export interface BreadcrumbBarProps {
  crumbs: Crumb[]
  onNavigate?: (href: string) => void
}

export function BreadcrumbBar({ crumbs, onNavigate }: BreadcrumbBarProps) {
  return (
    <nav aria-label="Breadcrumb">
      <ol className="flex items-center gap-1 text-[length:var(--text-sm)]">
        {crumbs.map((crumb, i) => {
          const isLast = i === crumbs.length - 1
          return (
            <li key={crumb.href} className="flex items-center gap-1">
              {i > 0 && (
                <ChevronRight size={12} strokeWidth={1.5} className="text-[var(--color-text-muted)] shrink-0" aria-hidden />
              )}
              {isLast ? (
                <span
                  aria-current="page"
                  className="text-[var(--color-text)] font-medium truncate max-w-[200px]"
                >
                  {crumb.label}
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => onNavigate?.(crumb.href)}
                  className="text-[var(--color-text-muted)] hover:text-[var(--color-text)] truncate max-w-[160px] focus-visible:outline-none"
                >
                  {crumb.label}
                </button>
              )}
            </li>
          )
        })}
      </ol>
    </nav>
  )
}
