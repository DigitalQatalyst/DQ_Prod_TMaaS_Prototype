import * as React from "react";
import { cn } from "../lib/cn.js";

function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "animate-pulse rounded bg-[color-mix(in_srgb,var(--color-border)_60%,var(--color-surface))]",
        className,
      )}
      {...props}
    />
  );
}

export { Skeleton };
