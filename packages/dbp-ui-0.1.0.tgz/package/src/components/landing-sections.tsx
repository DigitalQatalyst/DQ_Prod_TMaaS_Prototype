import * as React from "react"
import { ArrowRight, CheckCircle, BarChart2 } from "lucide-react"
import { cn } from "../lib/cn.js"

/* ─────────────────────────────────────────────────────────────────────────────
   LandingFeatures
   bg-white, lg:grid-cols-2, feature cards with icon tile + title + description
   ──────────────────────────────────────────────────────────────────────────── */

export interface LandingFeatureItem {
  /** Lucide icon element rendered in an h-11 w-11 navy-50 tile. */
  icon?: React.ReactNode
  title: string
  description?: string
}

export interface LandingFeaturesProps {
  /** Section overline (mono). */
  overline?: string
  /** Section headline. */
  headline?: string
  /** Section headline orange accent span. */
  headlineAccent?: string
  /** Section body copy. */
  body?: string
  /** Feature items displayed in a responsive grid. */
  items?: LandingFeatureItem[]
  /** Optional "see more" link text. */
  linkLabel?: string
  /** Optional "see more" link href. */
  linkHref?: string
  className?: string
}

/**
 * LandingFeatures — two-column white section with data-driven feature cards.
 * Left: overline + headline + body + feature list + optional link.
 * Right: 2-column card grid that floats with shadow/hover.
 */
export function LandingFeatures({
  overline = "Platform capabilities",
  headline = "Everything your team needs",
  headlineAccent = "in one place.",
  body = "From task management to governed knowledge and workflow automation — all built on a single, secure platform.",
  items = [],
  linkLabel,
  linkHref = "#",
  className,
}: LandingFeaturesProps) {
  return (
    <section
      className={cn("bg-white py-20 lg:py-24", className)}
      aria-labelledby="features-heading"
    >
      <div className="mx-auto max-w-[1200px] px-5 md:px-8 lg:px-10">
        <div className="grid grid-cols-1 items-center gap-14 lg:grid-cols-2 lg:gap-16">

          {/* Left: copy block */}
          <div>
            <p className="dq-overline">{overline}</p>
            <h2
              id="features-heading"
              className={cn(
                "mt-4 text-[32px] font-semibold leading-tight tracking-tight text-primary",
                "sm:text-[36px]"
              )}
            >
              {headline}{" "}
              <span className="text-secondary">{headlineAccent}</span>
            </h2>
            {body && (
              <p className="mt-4 text-base leading-7 text-[var(--color-text-muted)]">
                {body}
              </p>
            )}

            {/* Feature list */}
            {items.length > 0 && (
              <ul className="mt-8 space-y-5">
                {items.slice(0, 3).map((item, i) => (
                  <li key={i} className="flex gap-4">
                    <div
                      className={cn(
                        "flex h-10 w-10 shrink-0 items-center justify-center",
                        "rounded-xl bg-[var(--color-navy-50)] text-primary"
                      )}
                      aria-hidden="true"
                    >
                      {item.icon ?? <CheckCircle size={20} strokeWidth={1.5} />}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-primary">{item.title}</h3>
                      {item.description && (
                        <p className="mt-1 text-sm leading-6 text-[var(--color-text-muted)]">
                          {item.description}
                        </p>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}

            {linkLabel && (
              <a
                href={linkHref}
                className={cn(
                  "mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-[var(--color-info-text)]",
                  "hover:underline focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)] rounded-sm"
                )}
              >
                {linkLabel}
                <ArrowRight size={14} strokeWidth={1.5} aria-hidden="true" />
              </a>
            )}
          </div>

          {/* Right: card grid */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {items.map((item, i) => (
              <FeatureCard key={i} item={item} index={i} />
            ))}
            {/* Placeholder cards when no items given */}
            {items.length === 0 && (
              <>
                <FeatureCard item={{ title: "Governed workflows", description: "Automate approvals and escalations with audit trails." }} index={0} />
                <FeatureCard item={{ title: "Unified knowledge", description: "Governed playbooks and standards surfaced in context." }} index={1} />
                <FeatureCard item={{ title: "Real-time visibility", description: "KPI dashboards and SLA tracking across your team." }} index={2} />
                <FeatureCard item={{ title: "Secure by design", description: "Role-based entitlements enforced on every action." }} index={3} />
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

function FeatureCard({ item, index }: { item: LandingFeatureItem; index: number }) {
  const accentClasses = [
    "bg-[var(--color-navy-50)] text-primary",
    "bg-[var(--color-orange-50)] text-secondary",
    "bg-[var(--color-navy-100)] text-primary",
    "bg-[var(--color-orange-100)] text-secondary",
  ]
  const accent = accentClasses[index % accentClasses.length]!

  return (
    <div
      className={cn(
        "rounded-[12px] border border-[var(--color-border-subtle)] bg-white p-5",
        "shadow-[0_2px_8px_rgba(3,15,53,0.05)]",
        "motion-safe:transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(3,15,53,0.10)]",
        "hover:border-[var(--color-border-default)]"
      )}
    >
      <div
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-xl",
          accent
        )}
        aria-hidden="true"
      >
        {item.icon ?? <BarChart2 size={20} strokeWidth={1.5} />}
      </div>
      <h3 className="mt-3 text-sm font-bold text-primary">{item.title}</h3>
      {item.description && (
        <p className="mt-1.5 text-sm leading-6 text-[var(--color-text-muted)]">
          {item.description}
        </p>
      )}
    </div>
  )
}


/* ─────────────────────────────────────────────────────────────────────────────
   LandingHowItWorks
   bg-surface, steps with ArrowRight connectors in a lg:flex-row flow
   ──────────────────────────────────────────────────────────────────────────── */

export interface LandingHowItWorksStep {
  /** Step number label (e.g. "01"). Auto-generated from index if absent. */
  step?: string
  title: string
  description?: string
  /** Lucide icon rendered in the step icon tile. */
  icon?: React.ReactNode
}

export interface LandingHowItWorksProps {
  overline?: string
  headline?: string
  body?: string
  steps?: LandingHowItWorksStep[]
  /**
   * Section band treatment for full-bleed alternation:
   * - "muted" (default): bg-surface gray band.
   * - "dark": deep navy mesh band (white text) — the third beat in the
   *   white→gray→dark→orange landing rhythm.
   */
  tone?: "muted" | "dark"
  className?: string
}

/**
 * LandingHowItWorks — full-bleed section with a horizontal step flow.
 * Steps are connected by ArrowRight dividers on lg screens.
 * `tone="dark"` renders the deep-navy mesh band for the landing alternation.
 */
export function LandingHowItWorks({
  overline = "How it works",
  headline = "Up and running in minutes",
  body = "Follow a simple setup path — no heavy IT project required.",
  steps = [],
  tone = "muted",
  className,
}: LandingHowItWorksProps) {
  const isDark = tone === "dark"
  const displaySteps: LandingHowItWorksStep[] =
    steps.length > 0
      ? steps
      : [
          { title: "Request access", description: "Your admin provisions your role-based profile in minutes." },
          { title: "Explore your workspace", description: "Land on your personalised home with priorities and actions ready." },
          { title: "Start work", description: "Pick up tasks, consult knowledge assets, or trigger a service." },
          { title: "Track outcomes", description: "Monitor SLAs and governance status from your performance dashboard." },
          { title: "Improve continuously", description: "Analyse patterns and refine your team's operating model over time." },
        ]

  const stepAccents = [
    "bg-[var(--color-navy-50)] text-primary",
    "bg-[var(--color-orange-50)] text-secondary",
    "bg-[var(--color-navy-100)] text-primary",
    "bg-[var(--color-orange-100)] text-secondary",
    "bg-[var(--color-navy-50)] text-primary",
  ]

  return (
    <section
      className={cn(
        "py-20 lg:py-24",
        isDark ? "text-white" : "bg-[var(--color-surface)]",
        className
      )}
      style={isDark ? { background: "var(--mesh-hero-dark)" } : undefined}
      aria-labelledby="how-it-works-heading"
    >
      <div className="mx-auto max-w-[1200px] px-5 md:px-8 lg:px-10">

        {/* Centered header block */}
        <div className="mx-auto max-w-2xl text-center">
          <p className={cn("dq-overline", isDark && "text-secondary")}>{overline}</p>
          <h2
            id="how-it-works-heading"
            className={cn(
              "mt-4 text-[32px] font-semibold leading-tight tracking-tight",
              "sm:text-[36px]",
              isDark ? "text-white" : "text-primary"
            )}
          >
            {headline}
          </h2>
          {body && (
            <p className={cn(
              "mt-4 text-base leading-7",
              isDark ? "text-white/70" : "text-[var(--color-text-muted)]"
            )}>
              {body}
            </p>
          )}
        </div>

        {/* Steps flow */}
        <div
          className={cn(
            "mt-12 flex flex-col items-stretch gap-4",
            "lg:flex-row lg:items-start lg:justify-center lg:gap-2"
          )}
          role="list"
        >
          {displaySteps.map((step, i) => {
            const accent = stepAccents[i % stepAccents.length]!
            const stepNum = step.step ?? String(i + 1).padStart(2, "0")

            return (
              <React.Fragment key={i}>
                <div
                  className={cn(
                    "flex flex-1 flex-col items-center rounded-[14px]",
                    "border border-[var(--color-border-subtle)] bg-white p-6 text-center shadow-sm",
                    "motion-safe:transition-all hover:border-secondary hover:shadow-[0_8px_24px_rgba(3,15,53,0.08)]",
                    "lg:max-w-[220px]"
                  )}
                  role="listitem"
                >
                  <div
                    className={cn(
                      "flex h-12 w-12 items-center justify-center rounded-xl",
                      accent
                    )}
                    aria-hidden="true"
                  >
                    {step.icon ?? (
                      <span className="font-mono text-xs font-bold">{stepNum}</span>
                    )}
                  </div>
                  <p className="mt-3 text-[11px] font-bold uppercase tracking-wider text-[var(--color-text-muted)]">
                    Step {stepNum}
                  </p>
                  <h3 className="mt-1 text-base font-bold text-primary">{step.title}</h3>
                  {step.description && (
                    <p className="mt-2 text-sm leading-6 text-[var(--color-text-muted)]">
                      {step.description}
                    </p>
                  )}
                </div>

                {/* ArrowRight connector — visible only on lg, hidden after last step */}
                {i < displaySteps.length - 1 && (
                  <div
                    aria-hidden
                    className="hidden shrink-0 self-center text-[var(--color-border-strong)] lg:flex"
                  >
                    <ArrowRight size={18} strokeWidth={1.5} />
                  </div>
                )}
              </React.Fragment>
            )
          })}
        </div>
      </div>
    </section>
  )
}


/* ─────────────────────────────────────────────────────────────────────────────
   LandingCta
   Full-width card with --mesh-cta-orange background, white headline + accent
   ──────────────────────────────────────────────────────────────────────────── */

export interface LandingCtaFeatureTile {
  /** Lucide icon rendered in a navy-50 tile. */
  icon?: React.ReactNode
  title: string
  description?: string
}

export interface LandingCtaProps {
  /** White headline (left part). */
  headline?: string
  /** Orange accent span appended to the headline. */
  headlineAccent?: string
  /** White body paragraph. */
  body?: string
  /** Primary CTA button. */
  primaryCta?: { label: string; href: string }
  /** Secondary CTA button (ghost). */
  secondaryCta?: { label: string; href: string }
  /** Optional feature tiles row shown below the CTA buttons. */
  featureTiles?: LandingCtaFeatureTile[]
  className?: string
}

/**
 * LandingCta — full-width gradient CTA card with optional feature tiles.
 * Background: var(--mesh-cta-orange) (deep navy with orange glow).
 */
export function LandingCta({
  headline = "Ready to transform how your team works?",
  headlineAccent = "Start today.",
  body = "Join thousands of teams already using the platform for governed, high-performance daily work.",
  primaryCta = { label: "Get Started Free", href: "#" },
  secondaryCta,
  featureTiles = [],
  className,
}: LandingCtaProps) {
  const displayTiles: LandingCtaFeatureTile[] =
    featureTiles.length > 0
      ? featureTiles
      : [
          { title: "Enterprise-grade security", description: "SOC 2 Type II compliant" },
          { title: "Role-based access", description: "Granular entitlements" },
          { title: "Audit-ready governance", description: "Full action trail" },
          { title: "Rapid onboarding", description: "Live in under a week" },
        ]

  return (
    <section
      className={cn("bg-white py-20 lg:py-24", className)}
      aria-labelledby="cta-heading"
    >
      <div className="mx-auto max-w-[1200px] px-5 md:px-8 lg:px-10">
        <div
          className="rounded-[20px] border border-[rgba(255,255,255,0.08)] px-8 py-14 text-center"
          style={{ background: "var(--mesh-cta-orange)" }}
        >
          {/* Headline */}
          <h2
            id="cta-heading"
            className={cn(
              "text-[32px] font-semibold tracking-tight text-white sm:text-[36px]"
            )}
          >
            {headline}{" "}
            <span className="text-secondary">{headlineAccent}</span>
          </h2>

          {/* Body */}
          {body && (
            <p className="mx-auto mt-4 max-w-xl text-base leading-7 text-white/70">
              {body}
            </p>
          )}

          {/* CTA row */}
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a
              href={primaryCta.href}
              className={cn(
                "inline-flex h-12 items-center justify-center gap-2 rounded-pill",
                "bg-secondary px-8 text-sm font-semibold text-white",
                "hover:bg-[var(--color-orange-600)]",
                "motion-safe:transition-colors",
                "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-orange)]"
              )}
              style={{ boxShadow: "var(--glow-orange-md)" }}
            >
              {primaryCta.label}
              <ArrowRight size={16} strokeWidth={1.5} aria-hidden="true" />
            </a>

            {secondaryCta && (
              <a
                href={secondaryCta.href}
                className={cn(
                  "inline-flex h-12 items-center justify-center gap-2 rounded-pill",
                  "border border-white/20 bg-white/10 px-8 text-sm font-semibold text-white",
                  "backdrop-blur-sm hover:bg-white/20",
                  "motion-safe:transition-colors",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
                )}
              >
                {secondaryCta.label}
              </a>
            )}
          </div>

          {/* Feature tiles */}
          {displayTiles.length > 0 && (
            <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {displayTiles.map((tile, i) => (
                <div key={i} className="flex flex-col items-center gap-2 text-center">
                  <div
                    className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-xl",
                      "bg-[var(--color-navy-50)] text-primary"
                    )}
                    aria-hidden="true"
                  >
                    {tile.icon ?? <CheckCircle size={20} strokeWidth={1.5} />}
                  </div>
                  <h3 className="text-sm font-bold text-white">{tile.title}</h3>
                  {tile.description && (
                    <p className="text-xs text-white/60">{tile.description}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
