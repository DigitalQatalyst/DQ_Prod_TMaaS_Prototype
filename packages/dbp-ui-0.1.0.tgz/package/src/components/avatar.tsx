import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn.js"

/* ─── Deterministic background palette from DQ tokens ──────────────────── */
const PALETTE: string[] = [
  "bg-primary text-white",
  "bg-secondary text-white",
  "bg-[var(--color-info)] text-white",
  "bg-[var(--color-success)] text-white",
  "bg-[var(--color-navy-200)] text-primary",
  "bg-[var(--color-orange-100)] text-secondary",
]

function pickColor(name: string): string {
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = ((hash << 5) - hash + name.charCodeAt(i)) | 0
  }
  return PALETTE[Math.abs(hash) % PALETTE.length] ?? PALETTE[0]!
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/)
  if (parts.length === 0) return "?"
  const first = parts[0]
  if (!first) return "?"
  if (parts.length === 1) return first.slice(0, 2).toUpperCase()
  const last = parts[parts.length - 1]
  return ((first[0] ?? "") + (last ? (last[0] ?? "") : "")).toUpperCase()
}

/* ─── Size variants ─────────────────────────────────────────────────────── */
const avatarVariants = cva(
  "relative flex shrink-0 items-center justify-center overflow-hidden rounded-full select-none",
  {
    variants: {
      size: {
        sm: "h-7 w-7 text-[10px] font-bold",
        md: "h-9 w-9 text-xs font-bold",
        lg: "h-12 w-12 text-sm font-bold",
      },
    },
    defaultVariants: {
      size: "md",
    },
  }
)

export interface AvatarProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof avatarVariants> {
  /** Full display name — used to derive initials and deterministic bg color */
  name: string
  /** Optional image src; falls back to initials if not provided or fails to load */
  src?: string
  /** Alt text for the image */
  alt?: string
}

export function Avatar({ name, src, alt, size, className, ...props }: AvatarProps) {
  const [imgError, setImgError] = React.useState(false)
  const colorClass = pickColor(name)
  const initials = getInitials(name)

  return (
    <div
      className={cn(avatarVariants({ size }), colorClass, className)}
      aria-label={alt ?? name}
      role="img"
      {...props}
    >
      {src && !imgError ? (
        <img
          src={src}
          alt={alt ?? name}
          className="h-full w-full object-cover"
          onError={() => setImgError(true)}
        />
      ) : (
        <span aria-hidden="true">{initials}</span>
      )}
    </div>
  )
}

/* ─── Name + role lockup variant (matches top-bar UserIdentity) ─────────── */
export interface AvatarLockupProps extends AvatarProps {
  /** Secondary text (role/email) shown below the name */
  role?: string
}

export function AvatarLockup({ name, role, size = "md", src, alt, className, ...props }: AvatarLockupProps) {
  return (
    <div className={cn("flex items-center gap-2.5", className)} {...props}>
      <Avatar name={name} size={size} {...(src !== undefined && { src })} {...(alt !== undefined && { alt })} />
      <div className="min-w-0">
        <p className="max-w-[9rem] truncate text-xs font-bold text-primary leading-snug">
          {name}
        </p>
        {role && (
          <p className="max-w-[9rem] truncate text-[11px] text-[var(--color-text-muted)] leading-snug">
            {role}
          </p>
        )}
      </div>
    </div>
  )
}
