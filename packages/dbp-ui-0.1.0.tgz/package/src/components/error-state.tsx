import * as React from "react"
import { AlertTriangle } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface ErrorStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Optional custom icon (defaults to AlertTriangle in danger tone) */
  icon?: React.ReactNode
  title?: string
  description?: string
  error?: Error | string
  /** Optional CTA slot (e.g. a retry button) */
  action?: React.ReactNode
}

export function ErrorState({
  icon,
  title = "Something went wrong",
  description,
  error,
  action,
  className,
  ...props
}: ErrorStateProps) {
  const message =
    description ??
    (error instanceof Error ? error.message : typeof error === "string" ? error : undefined)

  return (
    <div
      role="alert"
      className={cn(
        "flex flex-col items-center justify-center gap-3 py-16 px-6 text-center",
        className
      )}
      {...props}
    >
      <span
        className="flex h-12 w-12 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-danger-surface)] text-[var(--color-danger-text)]"
        aria-hidden="true"
      >
        {icon ?? <AlertTriangle size={22} strokeWidth={1.5} />}
      </span>

      <div className="max-w-[280px]">
        <p className="text-sm font-semibold text-[var(--color-danger-text)]">{title}</p>
        {message && (
          <p className="mt-1 text-xs text-[var(--color-text-muted)] leading-relaxed">
            {message}
          </p>
        )}
      </div>

      {action && <div className="mt-1">{action}</div>}
    </div>
  )
}
