import * as React from "react"
import { cn } from "../lib/cn"

export interface BreadcrumbItem {
  label: string
  href?: string
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[]
  className?: string
}

/**
 * Breadcrumb — a real wayfinding breadcrumb (not an accented eyebrow).
 *
 * Typical product/admin practice: a quiet, neutral, sentence-case trail of the
 * ancestor path ending in the current page. It is a navigation utility, so it
 * stays MUTED and is never brand-accented — the page H1 is the focal point, the
 * breadcrumb just says "you are here". Ancestors with an href are links; the
 * final crumb is the current page (muted, aria-current, non-link). It is fine for
 * the final crumb to repeat the H1 because it is de-emphasised.
 */
export function Breadcrumb({ items, className }: BreadcrumbProps) {
  return (
    <nav aria-label="Breadcrumb" className={cn("flex", className)}>
      <ol className="flex flex-wrap items-center gap-0.5 text-[12px] font-medium">
        {items.map((item, index) => {
          const isLast = index === items.length - 1
          return (
            <li key={index} className="flex items-center">
              {index > 0 && (
                <span
                  aria-hidden
                  className="mx-1.5 select-none text-[var(--color-text-disabled)]"
                >
                  /
                </span>
              )}
              {isLast ? (
                <span className="text-[var(--color-text-secondary)]" aria-current="page">
                  {item.label}
                </span>
              ) : item.href ? (
                <a
                  href={item.href}
                  className={cn(
                    "rounded-sm text-[var(--color-text-muted)] transition-colors hover:text-[var(--color-text-primary)]",
                    "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
                  )}
                >
                  {item.label}
                </a>
              ) : (
                <span className="text-[var(--color-text-muted)]">{item.label}</span>
              )}
            </li>
          )
        })}
      </ol>
    </nav>
  )
}
