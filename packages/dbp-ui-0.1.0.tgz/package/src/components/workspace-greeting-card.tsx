"use client";
import * as React from "react";

export interface WorkspaceGreetingQuickLink {
  label: string;
  href: string;
}

export interface WorkspaceGreetingUpdate {
  title: string;
  date: string;
}

export interface WorkspaceGreetingCardProps {
  /** First name for the greeting line. Absent ⇒ greeting without a name. */
  firstName?: string;
  /** Navigation callback for quick-link buttons. */
  onNavigate: (href: string) => void;
  /** Lead line under the greeting. */
  lead?: string;
  /** Quick-nav buttons across the card header. */
  quickLinks?: WorkspaceGreetingQuickLink[];
  /** Heading for the updates list. */
  updatesTitle?: string;
  /** Updates / activity feed entries. */
  updates?: WorkspaceGreetingUpdate[];
}

const DEFAULT_LEAD = "Here's what's happening in your workspace today.";

/** Time-of-day greeting. Runs client-side, so live local time is fine here. */
function timeGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

/** Render an ISO date as "MMM D"; pass non-ISO strings through unchanged. */
function formatUpdateDate(value: string): string {
  const ms = Date.parse(value);
  if (Number.isNaN(ms)) return value;
  return new Date(ms).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/**
 * WorkspaceGreetingCard — the authenticated-home hero preview card.
 *
 * A "Welcome back" panel: time-of-day greeting, a quick-nav row, and a compact
 * updates feed. Designed to sit in the `preview` slot of `LandingHero` on an
 * in-app home page inside the workspace (transaction) shell.
 */
export function WorkspaceGreetingCard({
  firstName,
  onNavigate,
  lead = DEFAULT_LEAD,
  quickLinks = [],
  updatesTitle = "Platform Updates",
  updates = [],
}: WorkspaceGreetingCardProps) {
  const greeting = timeGreeting();

  return (
    <div
      className="w-full max-w-[520px] mx-auto lg:mx-0 rounded-2xl overflow-hidden shadow-[0_24px_48px_rgba(3,15,53,0.12)]"
      style={{ background: "#fff", border: "1px solid var(--color-border-subtle)" }}
    >
      {/* Header */}
      <div className="px-6 pt-5 pb-4" style={{ background: "var(--color-primary)" }}>
        <p
          className="text-xs font-semibold uppercase tracking-widest mb-1"
          style={{ color: "rgba(255,255,255,0.55)" }}
        >
          Welcome back
        </p>
        <h2 className="text-xl font-bold" style={{ color: "#fff" }}>
          {greeting}
          {firstName ? `, ${firstName}` : ""} 👋
        </h2>
        <p className="text-sm mt-1" style={{ color: "rgba(255,255,255,0.7)" }}>
          {lead}
        </p>
      </div>

      {/* Quick nav */}
      {quickLinks.length > 0 && (
        <div
          className="grid border-b"
          style={{
            gridTemplateColumns: `repeat(${Math.min(quickLinks.length, 4)}, minmax(0, 1fr))`,
            borderColor: "var(--color-border-subtle)",
          }}
        >
          {quickLinks.slice(0, 4).map((link) => (
            <button
              key={link.href}
              type="button"
              onClick={() => onNavigate(link.href)}
              className="flex flex-col items-center gap-1 py-3 px-2 text-center hover:bg-[var(--color-surface-raised)] transition-colors"
            >
              <span
                className="text-[10px] font-medium leading-tight"
                style={{ color: "var(--color-text-muted)" }}
              >
                {link.label}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Updates */}
      {updates.length > 0 && (
        <div className="px-6 py-4 space-y-3">
          <p
            className="text-xs font-semibold uppercase tracking-wider"
            style={{ color: "var(--color-text-muted)" }}
          >
            {updatesTitle}
          </p>
          {updates.map((item) => (
            <div key={item.title} className="flex items-start gap-3 py-1">
              <div
                className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full"
                style={{ background: "var(--color-nav-accent)" }}
              />
              <p className="text-sm flex-1" style={{ color: "var(--color-text)" }}>
                {item.title}
              </p>
              <p className="text-xs shrink-0" style={{ color: "var(--color-text-muted)" }}>
                {formatUpdateDate(item.date)}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
