import * as React from 'react'
import { Inbox } from 'lucide-react'
import { cn } from '../lib/cn.js'

interface EmptyStateActionObj {
  label: string
  onClick: () => void
}

function isActionObj(v: unknown): v is EmptyStateActionObj {
  return typeof v === 'object' && v !== null && 'label' in v && 'onClick' in v
}

export interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Primary display text — takes precedence over `title` */
  headline?: string
  /** Legacy display text — kept for backward compatibility */
  title?: string
  description?: string
  /**
   * CTA slot. Accepts either:
   *  - An object `{ label, onClick }` which renders a styled button
   *  - Any ReactNode (backward-compatible slot)
   */
  action?: EmptyStateActionObj | React.ReactNode
  /** Icon node from lucide-react or any SVG */
  icon?: React.ReactNode
}

export function EmptyState({
  headline,
  title,
  description,
  action,
  icon,
  className,
  ...props
}: EmptyStateProps) {
  const displayText = headline ?? title ?? 'Nothing here yet'

  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-3 py-16 px-6 text-center',
        className
      )}
      {...props}
    >
      {icon ? (
        <span
          className="flex h-12 w-12 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-navy-50)] text-[var(--color-text-muted)]"
          aria-hidden="true"
        >
          {icon}
        </span>
      ) : (
        <span
          className="flex h-12 w-12 items-center justify-center rounded-[var(--radius-card)] bg-[var(--color-navy-50,#f3f4f6)] text-[var(--color-text-muted)]"
          aria-hidden="true"
        >
          <Inbox size={22} strokeWidth={1.5} />
        </span>
      )}

      <div className="max-w-[260px]">
        <p className="text-sm font-semibold text-primary">{displayText}</p>
        {description && (
          <p className="mt-1 text-xs text-[var(--color-text-muted)] leading-relaxed">
            {description}
          </p>
        )}
      </div>

      {action && isActionObj(action) ? (
        <button
          type="button"
          onClick={action.onClick}
          className="mt-1 px-4 py-2 rounded-[var(--radius)] bg-[var(--color-primary)] text-white text-xs font-medium hover:opacity-90 focus-visible:outline-none"
        >
          {action.label}
        </button>
      ) : action ? (
        <div className="mt-1">{action as React.ReactNode}</div>
      ) : null}
    </div>
  )
}
