import * as React from "react"
import { cn } from "../lib/cn"

/** Column span on the canonical 12-column grid. */
export type ColSpan = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12

// Static maps per breakpoint so Tailwind's JIT generates every class (no dynamic
// class names). Everything is full-width on mobile; spans apply from the given
// breakpoint up. `span` is the md+ step; sm/lg/xl are optional finer steps.
const MD: Record<ColSpan, string> = {
  1: "md:col-span-1", 2: "md:col-span-2", 3: "md:col-span-3", 4: "md:col-span-4",
  5: "md:col-span-5", 6: "md:col-span-6", 7: "md:col-span-7", 8: "md:col-span-8",
  9: "md:col-span-9", 10: "md:col-span-10", 11: "md:col-span-11", 12: "md:col-span-12",
}
const SM: Record<ColSpan, string> = {
  1: "sm:col-span-1", 2: "sm:col-span-2", 3: "sm:col-span-3", 4: "sm:col-span-4",
  5: "sm:col-span-5", 6: "sm:col-span-6", 7: "sm:col-span-7", 8: "sm:col-span-8",
  9: "sm:col-span-9", 10: "sm:col-span-10", 11: "sm:col-span-11", 12: "sm:col-span-12",
}
const LG: Record<ColSpan, string> = {
  1: "lg:col-span-1", 2: "lg:col-span-2", 3: "lg:col-span-3", 4: "lg:col-span-4",
  5: "lg:col-span-5", 6: "lg:col-span-6", 7: "lg:col-span-7", 8: "lg:col-span-8",
  9: "lg:col-span-9", 10: "lg:col-span-10", 11: "lg:col-span-11", 12: "lg:col-span-12",
}
const XL: Record<ColSpan, string> = {
  1: "xl:col-span-1", 2: "xl:col-span-2", 3: "xl:col-span-3", 4: "xl:col-span-4",
  5: "xl:col-span-5", 6: "xl:col-span-6", 7: "xl:col-span-7", 8: "xl:col-span-8",
  9: "xl:col-span-9", 10: "xl:col-span-10", 11: "xl:col-span-11", 12: "xl:col-span-12",
}

export interface GridProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Render as a different element (e.g. "ul", "section"). Default "div". */
  as?: React.ElementType
}

/**
 * Grid — the ONE canonical content grid (12 columns, `--grid-gutter` gap).
 *
 * Every multi-column surface composes from this + `Col` so they align to the same
 * columns and gutter platform-wide. See docs/03-Features/specs/ARCHETYPE-REFERENCE-SPEC.md §2.
 */
export function Grid({ as: Comp = "div", className, ...props }: GridProps) {
  return (
    <Comp
      className={cn("grid grid-cols-12 gap-[var(--grid-gutter)]", className)}
      {...props}
    />
  )
}

export interface ColProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Columns to span at md+ (1–12). Full-width below md. Default 12. */
  span?: ColSpan
  /** Optional finer responsive steps (override at that breakpoint). */
  sm?: ColSpan
  lg?: ColSpan
  xl?: ColSpan
  as?: React.ElementType
}

/**
 * Col — a child of `Grid`. Full-width on mobile; spans `span`/12 at md+, with
 * optional `sm`/`lg`/`xl` steps. e.g. `<Col span={6} xl={4}>` → 1-up mobile,
 * 2-up md, 3-up xl (the canonical card-grid pattern).
 */
export function Col({ span = 12, sm, lg, xl, as: Comp = "div", className, ...props }: ColProps) {
  return (
    <Comp
      className={cn(
        "col-span-12",
        sm && SM[sm],
        MD[span],
        lg && LG[lg],
        xl && XL[xl],
        className,
      )}
      {...props}
    />
  )
}
