"use client"
import * as React from "react"
import * as TabsPrimitive from "@radix-ui/react-tabs"
import { cn } from "../lib/cn.js"

const Tabs = TabsPrimitive.Root

const TabsList = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.List>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.List
    ref={ref}
    className={cn(
      "flex border-b border-[var(--color-border-subtle)] bg-white",
      className
    )}
    {...props}
  />
))
TabsList.displayName = TabsPrimitive.List.displayName

const TabsTrigger = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Trigger>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Trigger
    ref={ref}
    className={cn(
      /* layout */
      "relative inline-flex items-center justify-center min-h-12 px-4",
      /* typography */
      "text-sm font-semibold whitespace-nowrap select-none",
      /* motion */
      "transition-colors motion-safe:transition-all",
      /* idle color */
      "text-[var(--color-text-muted)]",
      "hover:text-primary",
      /* active color */
      "data-[state=active]:text-primary",
      /* active underline — inset left-3 right-3, orange, h-0.5 */
      "data-[state=active]:after:absolute",
      "data-[state=active]:after:bottom-0",
      "data-[state=active]:after:left-3",
      "data-[state=active]:after:right-3",
      "data-[state=active]:after:h-0.5",
      "data-[state=active]:after:rounded-full",
      "data-[state=active]:after:bg-secondary",
      /* focus */
      "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
      /* disabled */
      "disabled:pointer-events-none disabled:opacity-50",
      className
    )}
    {...props}
  />
))
TabsTrigger.displayName = TabsPrimitive.Trigger.displayName

const TabsContent = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Content>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Content
    ref={ref}
    className={cn(
      "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
      className
    )}
    {...props}
  />
))
TabsContent.displayName = TabsPrimitive.Content.displayName

export { Tabs, TabsList, TabsTrigger, TabsContent }
