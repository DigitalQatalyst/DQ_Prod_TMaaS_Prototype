import * as React from "react";
import { Bell, Settings } from "lucide-react";
import { TopBarConfig } from "@dbp/contracts";
import { cn } from "../lib/cn";

export interface AppTopBarProps {
  config: TopBarConfig;
  /**
   * Solution code shown bold in the logo lockup (e.g. "DWS.01").
   * When omitted the lockup falls back to parsing `config.appName` for a
   * leading "CODE / Name" pattern, else renders `config.appName` plain.
   */
  productCode?: string;
  /**
   * Product name shown muted after the code in the logo lockup
   * (e.g. "Work.Space4.0"). Falls back to the parsed `config.appName`.
   */
  productName?: string;
  /** Dark lockup variant (e.g. on a navy header). Defaults to light. */
  variant?: "light" | "dark";
  /** Slot for global search (e.g. <SearchBar />). Replaces the default search pill. */
  searchSlot?: React.ReactNode;
  /** Slot for a role / context selector rendered before the divider. */
  roleSlot?: React.ReactNode;
  /** Slot for the notification bell (e.g. <NotificationBell />). Replaces the default bell. */
  notificationSlot?: React.ReactNode;
  /** Slot for a settings affordance. Replaces the default settings icon button. */
  settingsSlot?: React.ReactNode;
  /** Slot for the user menu (e.g. avatar + name dropdown). Replaces the default avatar block. */
  userSlot?: React.ReactNode;
  /** User display name for the default avatar block (when no userSlot). */
  userName?: string;
  /** User role/sub-label for the default avatar block (when no userSlot). */
  userRole?: string;
  className?: string;
}

/** Splits "DWS.01 / Work.Space" → { code, name }. Falls back gracefully. */
function splitLockup(appName: string): { code: string; name?: string } {
  const slash = appName.indexOf("/");
  if (slash !== -1) {
    const name = appName.slice(slash + 1).trim() || undefined;
    return {
      code: appName.slice(0, slash).trim(),
      ...(name !== undefined && { name }),
    };
  }
  return { code: appName };
}

/** Derives up-to-two-letter initials from a display name. */
function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return (parts[0]![0]! + parts[parts.length - 1]![0]!).toUpperCase();
}

/**
 * AppTopBar — DQ prototype top bar (64px / var(--shell-header-h)).
 *
 * Anatomy: logo lockup ("CODE / Product Name") on the left; on the right a
 * search pill (with ⌘K hint), optional role selector, a vertical divider,
 * bell + settings icon buttons, and a two-line avatar block.
 *
 * Slot-driven and backward compatible: pass `searchSlot` / `notificationSlot` /
 * `userSlot` to override the corresponding default; `config.showSearch` /
 * `showNotifications` / `showUser` gate each region as before.
 */
export function AppTopBar({
  config,
  productCode,
  productName,
  variant = "light",
  searchSlot,
  roleSlot,
  notificationSlot,
  settingsSlot,
  userSlot,
  userName,
  userRole,
  className,
}: AppTopBarProps) {
  const parsed = splitLockup(config.appName);
  const code = productCode ?? parsed.code;
  const name = productName ?? parsed.name;
  const dark = variant === "dark";

  const iconBtn = cn(
    "flex h-9 w-9 items-center justify-center rounded-button transition-colors",
    "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
    dark
      ? "text-white hover:bg-white/10"
      : "text-primary hover:bg-surface"
  );

  return (
    <header
      style={{ height: "var(--shell-header-h)" }}
      className={cn(
        "flex w-full items-center justify-between px-4 md:px-6",
        dark
          ? "bg-transparent"
          : "bg-white border-b border-[var(--color-border-subtle)]",
        className
      )}
    >
      {/* LEFT: logo lockup */}
      <div className="flex min-w-0 shrink-0 items-center gap-3">
        {config.logoSrc && (
          <img
            src={config.logoSrc}
            alt={config.logoAlt}
            className="h-8 w-auto shrink-0"
          />
        )}
        <span className="flex items-baseline gap-1.5 truncate">
          <span
            className={cn(
              "text-[18px] font-bold leading-none",
              dark ? "text-white" : "text-primary"
            )}
          >
            {code}
          </span>
          {name && (
            <span
              className={cn(
                "truncate text-[15px] font-medium leading-none",
                dark ? "text-[var(--color-navy-200)]" : "text-[var(--color-text-secondary)]"
              )}
            >
              / {name}
            </span>
          )}
        </span>
      </div>

      {/* RIGHT: controls */}
      <div className="flex min-w-0 items-center gap-2">
        {config.showSearch &&
          (searchSlot ?? (
            <button
              type="button"
              className={cn(
                "hidden h-10 w-52 items-center gap-2 rounded-button border-[1.5px] px-4 text-sm transition-colors md:flex xl:w-64",
                "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                dark
                  ? "border-white/15 bg-white/5 text-white/70 hover:bg-white/10"
                  : "border-[var(--color-border-default)] bg-white text-[var(--color-text-muted)] hover:bg-[var(--color-navy-50)]"
              )}
              aria-label="Open global search"
            >
              <SearchGlyph className="h-4 w-4 shrink-0" />
              <span className="flex-1 text-left">Global search…</span>
              <kbd className="hidden h-5 items-center gap-0.5 rounded border border-[var(--color-border-strong)] bg-white px-1.5 font-mono text-[10px] font-medium text-[var(--color-text-muted)] sm:inline-flex">
                <span className="text-xs">⌘</span>K
              </kbd>
            </button>
          ))}

        {roleSlot}

        {(config.showNotifications || config.showUser || settingsSlot) && (
          <div
            aria-hidden
            className={cn(
              "mx-1 h-8 w-px",
              dark ? "bg-white/15" : "bg-[var(--color-border-subtle)]"
            )}
          />
        )}

        {config.showNotifications &&
          (notificationSlot ?? (
            <button type="button" className={iconBtn} aria-label="Notifications">
              <Bell size={19} strokeWidth={1.5} />
            </button>
          ))}

        {settingsSlot ?? (
          <button type="button" className={iconBtn} aria-label="Settings">
            <Settings size={19} strokeWidth={1.5} />
          </button>
        )}

        {config.showUser &&
          (userSlot ?? (
            <div
              className={cn(
                "flex items-center gap-3 border-l pl-3",
                dark ? "border-white/15" : "border-[var(--color-border-subtle)]"
              )}
            >
              <div
                className={cn(
                  "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-bold",
                  dark ? "bg-white text-primary" : "bg-primary text-white"
                )}
                aria-hidden
              >
                {initials(userName ?? config.appName)}
              </div>
              {(userName || userRole) && (
                <div className="hidden min-w-0 lg:block">
                  {userName && (
                    <div
                      className={cn(
                        "max-w-36 truncate text-xs font-bold",
                        dark ? "text-white" : "text-primary"
                      )}
                    >
                      {userName}
                    </div>
                  )}
                  {userRole && (
                    <div
                      className={cn(
                        "max-w-36 truncate text-[11px]",
                        dark ? "text-[var(--color-navy-200)]" : "text-[var(--color-text-muted)]"
                      )}
                    >
                      {userRole}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
      </div>
    </header>
  );
}

/** Inline magnifier glyph (lucide Search at stroke 1.5). */
function SearchGlyph({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}
