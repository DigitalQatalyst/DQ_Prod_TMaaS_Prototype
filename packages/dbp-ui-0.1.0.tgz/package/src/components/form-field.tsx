import * as React from "react"
import { FieldLabel } from "./input.js"
import { cn } from "../lib/cn.js"

/* ─── FormField ────────────────────────────────────────────────────────────
 * Composes FieldLabel + control slot + HelperText + ErrorMessage.
 * Automatically threads htmlFor/id/aria-describedby using React.useId.
 * ─────────────────────────────────────────────────────────────────────── */

export interface FormFieldProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Label text shown above the control */
  label?: string
  /** Override the generated id (also sets htmlFor on the label) */
  id?: string
  /** Helper text shown below the control when no error is present */
  helperText?: string
  /** Error message — shows instead of helperText, marks the control as invalid */
  error?: string
  /** Whether the field is required (adds * to label) */
  required?: boolean
}

export function FormField({
  label,
  id: externalId,
  helperText,
  error,
  required,
  className,
  children,
  ...rest
}: FormFieldProps) {
  const autoId = React.useId()
  const fieldId = externalId ?? autoId
  const descId = `${fieldId}-desc`
  const hasDesc = Boolean(error ?? helperText)

  /* Clone the first React element child to inject id + aria-describedby */
  const control = React.Children.map(children, (child, i) => {
    if (i === 0 && React.isValidElement(child)) {
      return React.cloneElement(child as React.ReactElement<Record<string, unknown>>, {
        id: fieldId,
        "aria-describedby": hasDesc ? descId : undefined,
        "aria-invalid": error ? "true" : undefined,
      })
    }
    return child
  })

  return (
    <div className={cn("flex flex-col gap-1.5", className)} {...rest}>
      {label && (
        <FieldLabel htmlFor={fieldId}>
          {label}
          {required && (
            <span className="ml-0.5 text-[var(--color-danger)]" aria-hidden="true">
              *
            </span>
          )}
        </FieldLabel>
      )}

      {control}

      {(error || helperText) && (
        <p
          id={descId}
          role={error ? "alert" : undefined}
          className={cn(
            "text-xs leading-snug",
            error
              ? "text-[var(--color-danger-text)]"
              : "text-[var(--color-text-muted)]"
          )}
        >
          {error ?? helperText}
        </p>
      )}
    </div>
  )
}
