import * as React from "react"
import { cn } from "../lib/cn"
import { Breadcrumb, BreadcrumbItem } from "./breadcrumb"
import { Grid, Col, type ColSpan } from "./grid"

export interface PageHeaderAction {
  label: string
  onClick: () => void
}

/** Title-block column span within the 3-column header grid. Chosen by layout type. */
export type PageHeaderSpan = 1 | 2 | 3

export interface PageHeaderProps {
  /** Always rendered. */
  title: string
  /** Optional sub-heading under the title. */
  subtitle?: string
  /** Always rendered (auto-generated trail). */
  breadcrumb?: BreadcrumbItem[]
  /**
   * Column span (of 3) the title block occupies — set by the LAYOUT type:
   *   3 → full-width title (e.g. settings)         [aside, if any, wraps to its own row]
   *   2 → title + a 1-col aside (e.g. working/catalogue: CTA/search)
   *   1 → compact title + a 2-col aside (e.g. analytics: date-range/filters)
   * Default 3.
   */
  titleSpan?: PageHeaderSpan
  /** Content for the remaining column(s): actions, search, date-range, etc. Right-aligned. */
  aside?: React.ReactNode
  /** Convenience: a primary button rendered in the aside region (when `aside` is not given). */
  action?: PageHeaderAction
  /** @deprecated alias for `aside`. */
  actions?: React.ReactNode
  className?: string
}

// Title span (thirds) mapped onto the canonical 12-column grid: 1→4, 2→8, 3→12.
const TITLE_COLS: Record<PageHeaderSpan, ColSpan> = { 1: 4, 2: 8, 3: 12 }
// The aside fills the remaining columns; for a full-width title it drops to its own
// full-width row beneath, right-aligned.
const ASIDE_COLS: Record<PageHeaderSpan, ColSpan> = { 1: 8, 2: 4, 3: 12 }

/**
 * PageHeader — the ONE factory page header (ARCHETYPE-REFERENCE-SPEC §6).
 *
 * Layout: a mono breadcrumb trail (always) above a 3-column grid. The title block
 * (bold title — always — + optional muted subtitle) spans 1/2/3 columns per the
 * `titleSpan` the layout passes; the `aside` (actions/search/date-range) fills the
 * remaining columns. Features never render this — the layout owns it and chooses
 * placement + span. Title uses the `dq-page-title` token class.
 */
export function PageHeader({
  title,
  subtitle,
  breadcrumb,
  titleSpan = 3,
  aside,
  action,
  actions,
  className,
}: PageHeaderProps) {
  const asideContent = aside ?? actions ?? (action ? (
    <button
      type="button"
      onClick={action.onClick}
      className="shrink-0 px-4 py-2 rounded-[var(--radius)] bg-[var(--color-primary)] text-white text-sm font-medium hover:opacity-90 focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
    >
      {action.label}
    </button>
  ) : null)

  return (
    <div data-page-title className={cn("py-3", className)}>
      {breadcrumb && breadcrumb.length > 0 && (
        <Breadcrumb items={breadcrumb} className="mb-2" />
      )}
      <Grid className="md:items-center">
        <Col span={TITLE_COLS[titleSpan]} className="min-w-0">
          {/* Compact workspace title — users come to transact, not read. The large
              hero scale (dq-page-title) is reserved for public/landing pages. */}
          <h1 className="text-balance text-[1.625rem] font-semibold leading-tight text-[var(--color-text)]">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-0.5 max-w-2xl text-[11px] leading-snug text-[var(--color-text-muted)]">
              {subtitle}
            </p>
          )}
        </Col>
        {asideContent && (
          <Col span={ASIDE_COLS[titleSpan]} className="flex items-start gap-2 md:justify-end">
            {asideContent}
          </Col>
        )}
      </Grid>
    </div>
  )
}
