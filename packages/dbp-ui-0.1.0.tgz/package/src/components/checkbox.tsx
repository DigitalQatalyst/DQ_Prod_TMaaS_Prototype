"use client"
import * as React from "react"
import * as CheckboxPrimitive from "@radix-ui/react-checkbox"
import { Check, Minus } from "lucide-react"
import { cn } from "../lib/cn.js"

export interface CheckboxProps
  extends React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root> {
  /** Shows a minus indicator for indeterminate state */
  indeterminate?: boolean
}

const Checkbox = React.forwardRef<
  React.ElementRef<typeof CheckboxPrimitive.Root>,
  CheckboxProps
>(({ className, indeterminate, ...props }, ref) => (
  <CheckboxPrimitive.Root
    ref={ref}
    className={cn(
      "flex h-4 w-4 shrink-0 items-center justify-center",
      "rounded-[4px] border-[1.5px]",
      "transition-colors motion-safe:transition-all",
      /* Unchecked */
      "border-[var(--color-border-default)] bg-white",
      "hover:border-primary",
      /* Checked */
      "data-[state=checked]:border-primary data-[state=checked]:bg-primary",
      "data-[state=indeterminate]:border-primary data-[state=indeterminate]:bg-primary",
      /* Focus */
      "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
      /* Disabled */
      "disabled:cursor-not-allowed disabled:opacity-50",
      className
    )}
    {...(indeterminate ? { checked: "indeterminate" as const } : props.checked !== undefined ? { checked: props.checked } : {})}
    {...props}
  >
    <CheckboxPrimitive.Indicator className="text-white">
      {indeterminate
        ? <Minus size={10} strokeWidth={3} aria-hidden="true" />
        : <Check size={10} strokeWidth={3} aria-hidden="true" />
      }
    </CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
))
Checkbox.displayName = CheckboxPrimitive.Root.displayName

export { Checkbox }
