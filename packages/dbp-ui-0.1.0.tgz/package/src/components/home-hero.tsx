import * as React from "react";
import { cn } from "../lib/cn";

export interface HomeHeroProps extends React.HTMLAttributes<HTMLElement> {
  /**
   * Pre-composed greeting string, e.g. "Good evening, Alex".
   * The caller resolves the time-of-day and first name from the session.
   */
  greeting: string;
  /** Secondary sentence shown below the greeting. */
  subtext?: string;
  /**
   * Slot for the AISearchBar (or any search widget).
   * When provided, rendered below the copy block inside a relative z-20 wrapper.
   */
  searchSlot?: React.ReactNode;
  /**
   * Slot for quick-action links or buttons shown below the search slot
   * (or below the copy block when searchSlot is absent).
   */
  quickActions?: React.ReactNode;
}

/**
 * HomeHero — authenticated in-app landing hero card.
 *
 * Matches the DWS.01 prototype src/components/stage0-home/HomeHero.tsx anatomy:
 * - rounded-2xl border bg-gradient-to-br from-white via-white to-[var(--color-navy-50)]
 * - Radial-dot decoration top-right
 * - Heading text-[28px] sm:text-[36px] lg:text-[40px] font-bold
 * - Optional searchSlot + quickActions
 *
 * Server-safe (no "use client" directive; no browser-only APIs).
 */
export function HomeHero({
  greeting,
  subtext,
  searchSlot,
  quickActions,
  className,
  ...props
}: HomeHeroProps) {
  return (
    <section
      aria-label="Welcome"
      className={cn(
        "relative rounded-2xl border border-[var(--color-border-subtle)]",
        "bg-gradient-to-br from-white via-white to-[var(--color-navy-50)]",
        "px-6 py-10 shadow-sm sm:px-10 lg:px-14 lg:py-12",
        className,
      )}
      {...props}
    >
      {/* Radial-dot decoration — top-right corner, purely decorative */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 overflow-hidden rounded-2xl"
      >
        <div
          className="absolute -right-20 -top-16 h-[320px] w-[520px] rounded-[50%] opacity-70"
          style={{
            background:
              "repeating-radial-gradient(ellipse at center, rgba(181,197,247,0.28) 0, rgba(181,197,247,0.28) 1px, transparent 1px, transparent 18px)",
          }}
        />
      </div>

      {/* Copy block */}
      <div className="relative max-w-[860px]">
        <h1
          className={cn(
            "max-w-[760px] font-bold leading-[1.12] text-[var(--color-text)]",
            "text-[28px] sm:text-[36px] lg:text-[40px]",
          )}
          data-testid="home-hero-greeting"
        >
          {greeting}
        </h1>
        {subtext && (
          <p
            className="mt-4 max-w-[620px] text-sm leading-7 text-[var(--color-text-muted)] sm:text-base"
            data-testid="home-hero-subtext"
          >
            {subtext}
          </p>
        )}
      </div>

      {/* Search slot */}
      {searchSlot && (
        <div className="relative z-20 mt-7 max-w-[820px]" data-testid="home-hero-search-slot">
          {searchSlot}
        </div>
      )}

      {/* Quick actions slot */}
      {quickActions && (
        <div className="relative z-10 mt-6" data-testid="home-hero-quick-actions">
          {quickActions}
        </div>
      )}
    </section>
  );
}
