import * as React from "react"
import { Search } from "lucide-react"
import { cn } from "../lib/cn"
import { Input } from "./input"

export interface FilterChip {
  key: string
  label: string
  count?: number
}

export interface FilterBarProps {
  searchValue?: string
  onSearchChange?: (value: string) => void
  searchPlaceholder?: string
  chips?: FilterChip[]
  activeChip?: string
  onChipChange?: (key: string) => void
  sortOptions?: Array<{ value: string; label: string }>
  sortValue?: string
  onSortChange?: (value: string) => void
  className?: string
}

export function FilterBar({
  searchValue,
  onSearchChange,
  searchPlaceholder = "Search…",
  chips,
  activeChip,
  onChipChange,
  sortOptions,
  sortValue,
  onSortChange,
  className,
}: FilterBarProps) {
  return (
    <div
      className={cn(
        "flex flex-col sm:flex-row sm:items-center gap-3",
        className
      )}
    >
      {/* Search */}
      {onSearchChange !== undefined && (
        <div className="relative shrink-0">
          <Search
            size={15}
            strokeWidth={1.5}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)] pointer-events-none"
          />
          <Input
            type="text"
            value={searchValue ?? ""}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={searchPlaceholder}
            className="pl-9 h-9 w-full sm:w-56 text-sm"
          />
        </div>
      )}

      {/* Chips */}
      {chips && chips.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto hide-scrollbar flex-1 min-w-0">
          {chips.map((chip) => {
            const isActive = activeChip === chip.key
            return (
              <button
                key={chip.key}
                type="button"
                onClick={() => onChipChange?.(chip.key)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-pill px-3 h-8 text-xs font-semibold whitespace-nowrap transition-colors select-none",
                  "border focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-primary)]",
                  isActive
                    ? "bg-primary text-white border-primary"
                    : "bg-[var(--color-surface)] text-[var(--color-text-secondary)] border-[var(--color-border-default)] hover:border-primary hover:text-primary"
                )}
                aria-pressed={isActive}
              >
                {chip.label}
                {chip.count !== undefined && (
                  <span
                    className={cn(
                      "inline-flex items-center justify-center rounded-full min-w-[18px] h-[18px] px-1 text-[10px] font-bold leading-none",
                      isActive
                        ? "bg-white/20 text-white"
                        : "bg-[var(--color-surface-raised)] text-[var(--color-text-muted)]"
                    )}
                  >
                    {chip.count}
                  </span>
                )}
              </button>
            )
          })}
        </div>
      )}

      {/* Sort */}
      {sortOptions && sortOptions.length > 0 && onSortChange && (
        <div className="shrink-0 sm:ml-auto">
          <select
            value={sortValue ?? ""}
            onChange={(e) => onSortChange(e.target.value)}
            className={cn(
              "h-9 rounded-input px-3 pr-8 text-sm",
              "bg-[var(--color-surface)] text-[var(--color-text-primary)]",
              "border-[1.5px] border-[var(--color-border-default)]",
              "focus:outline-none focus:border-primary focus:[box-shadow:var(--focus-ring-primary)]",
              "cursor-pointer appearance-none",
              "bg-[image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E\")] bg-no-repeat bg-[right_10px_center]"
            )}
          >
            {sortOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
      )}
    </div>
  )
}
