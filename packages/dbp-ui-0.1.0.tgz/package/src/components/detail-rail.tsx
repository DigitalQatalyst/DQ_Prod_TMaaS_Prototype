import * as React from "react"
import * as LucideIcons from "lucide-react"
import { cn } from "../lib/cn.js"

/**
 * detail-rail.tsx — shared primitives for the marketplace detail right rail.
 *
 * Exports:
 *   - RailSection      — titled rail card (heading + children, border-gray-200 bg-white)
 *   - RailActionButton — full-width action row (outline / navy / ghost tone, optional lucide icon)
 *   - SectionCard      — content section card used in the 8-col content column
 *
 * All tokens use CSS variables. Lucide icons: strokeWidth 1.5.
 * No ✨/Sparkles used anywhere in this file.
 */

/* ─────────────────────────────── RailSection ──────────────────────────────── */

export interface RailSectionProps {
  /** Heading shown above the rail card children. */
  title: string
  children: React.ReactNode
  className?: string
}

/**
 * RailSection — titled card in the right rail. Uses border-gray-200 (matching
 * prototype anatomy, NOT border-border-default) and no box shadow.
 */
function RailSection({ title, children, className }: RailSectionProps) {
  return (
    <section
      className={cn(
        "rounded-lg border border-gray-200 bg-white px-5 py-5",
        className,
      )}
    >
      <h3 className="mb-4 text-sm font-semibold leading-snug text-[var(--color-primary)]">
        {title}
      </h3>
      {children}
    </section>
  )
}

RailSection.displayName = "RailSection"

/* ────────────────────────────── RailActionButton ───────────────────────────── */

export type RailActionTone = "outline" | "navy" | "ghost"

export interface RailActionButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Optional lucide icon name, e.g. "CheckSquare", "Link2", "Play". */
  icon?: string
  /** Visual tone — outline (default), navy (filled), ghost (text-only). */
  tone?: RailActionTone
  children: React.ReactNode
}

/** Resolve a lucide icon name → component. Falls back to ChevronRight. */
function resolveIcon(
  name?: string,
): React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }> {
  if (!name) return LucideIcons.ChevronRight
  const candidate = (LucideIcons as unknown as Record<string, unknown>)[name]
  return (
    (candidate as React.ComponentType<{
      size?: number
      strokeWidth?: number
      className?: string
    }>) ?? LucideIcons.ChevronRight
  )
}

const toneClasses: Record<RailActionTone, string> = {
  outline:
    "border border-gray-200 bg-gray-50 text-[var(--color-primary)] hover:border-gray-300 hover:bg-white",
  navy:
    "bg-[var(--color-primary)] text-white hover:bg-[color-mix(in_srgb,var(--color-primary)_85%,black)]",
  ghost:
    "text-gray-700 hover:bg-gray-50",
}

/**
 * RailActionButton — full-width stacked action button used in rail sections.
 *
 * - `tone="outline"` — Use in Work buttons (border outline, gray-50 bg)
 * - `tone="navy"` — Acknowledgement button (dark navy fill, white text)
 * - `tone="ghost"` — Governance action rows (no border, text-gray-700)
 */
const RailActionButton = React.forwardRef<
  HTMLButtonElement,
  RailActionButtonProps
>(({ icon, tone = "outline", className, children, ...props }, ref) => {
  const Icon = resolveIcon(icon)

  return (
    <button
      ref={ref}
      type="button"
      className={cn(
        "flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-xs font-medium transition",
        "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-orange)]",
        toneClasses[tone],
        className,
      )}
      {...props}
    >
      <Icon
        size={tone === "ghost" ? 13 : 14}
        strokeWidth={1.5}
        className="shrink-0 text-gray-400"
        aria-hidden="true"
      />
      {children}
    </button>
  )
})

RailActionButton.displayName = "RailActionButton"

/* ───────────────────────────────── SectionCard ──────────────────────────────── */

export interface SectionCardProps {
  /** Optional section heading. */
  title?: string
  children: React.ReactNode
  className?: string
}

/**
 * SectionCard — content-column section card.
 * Uses `rounded-lg border border-gray-200 bg-white` matching the prototype
 * (NOT border-border-default, NOT shadow-sm — the detail page anatomy is border-gray-200 only).
 */
function SectionCard({ title, children, className }: SectionCardProps) {
  return (
    <section
      className={cn(
        "rounded-lg border border-gray-200 bg-white px-5 pt-5 pb-5",
        className,
      )}
    >
      {title ? (
        <h2 className="mb-4 text-sm font-semibold leading-snug text-[var(--color-primary)]">
          {title}
        </h2>
      ) : null}
      {children}
    </section>
  )
}

SectionCard.displayName = "SectionCard"

/* ────────────────────────────────── exports ─────────────────────────────────── */

export { RailSection, RailActionButton, SectionCard }
