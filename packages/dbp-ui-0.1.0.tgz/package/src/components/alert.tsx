import * as React from "react"
import { Info, CheckCircle, AlertTriangle, XCircle, X } from "lucide-react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn.js"

const alertVariants = cva(
  [
    "relative flex items-start gap-3",
    "rounded-[var(--radius-card)]",
    "border px-4 py-3.5",
    "text-sm",
  ].join(" "),
  {
    variants: {
      tone: {
        info:    "border-[var(--color-info-border)]    bg-[var(--color-info-surface)]    text-[var(--color-info-text)]",
        success: "border-[var(--color-success-border)] bg-[var(--color-success-surface)] text-[var(--color-success-text)]",
        warning: "border-[var(--color-warning-border)] bg-[var(--color-warning-surface)] text-[var(--color-warning-text)]",
        danger:  "border-[var(--color-danger-border)]  bg-[var(--color-danger-surface)]  text-[var(--color-danger-text)]",
      },
    },
    defaultVariants: {
      tone: "info",
    },
  }
)

const toneIconMap = {
  info:    Info,
  success: CheckCircle,
  warning: AlertTriangle,
  danger:  XCircle,
} as const

export interface AlertProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertVariants> {
  title?: string
  dismissible?: boolean
  onDismiss?: () => void
  /** Override the automatic icon, or pass false to suppress it */
  icon?: React.ReactNode | false
}

export function Alert({
  tone = "info",
  title,
  dismissible = false,
  onDismiss,
  icon,
  className,
  children,
  ...props
}: AlertProps) {
  const [dismissed, setDismissed] = React.useState(false)

  if (dismissed) return null

  const resolvedTone = tone ?? "info"
  const DefaultIcon = toneIconMap[resolvedTone]
  const showIcon = icon !== false
  const iconNode =
    icon !== undefined && icon !== false
      ? icon
      : <DefaultIcon size={16} strokeWidth={1.5} aria-hidden="true" className="mt-0.5 shrink-0" />

  function handleDismiss() {
    setDismissed(true)
    onDismiss?.()
  }

  return (
    <div
      role="alert"
      className={cn(alertVariants({ tone }), className)}
      {...props}
    >
      {showIcon && iconNode}

      <div className="min-w-0 flex-1">
        {title && (
          <p className="font-semibold leading-snug mb-1">{title}</p>
        )}
        {children && (
          <div className={cn("leading-relaxed", title ? "text-xs opacity-90" : "")}>
            {children}
          </div>
        )}
      </div>

      {dismissible && (
        <button
          onClick={handleDismiss}
          aria-label="Dismiss alert"
          className={cn(
            "shrink-0 ml-auto -mr-1 -mt-0.5",
            "flex h-6 w-6 items-center justify-center rounded-[var(--radius-button)]",
            "opacity-60 transition-opacity hover:opacity-100",
            "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
          )}
        >
          <X size={14} strokeWidth={1.5} />
        </button>
      )}
    </div>
  )
}
