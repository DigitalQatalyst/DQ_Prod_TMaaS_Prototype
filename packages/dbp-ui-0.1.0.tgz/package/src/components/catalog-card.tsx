import * as React from "react";
import { ArrowUpRight } from "lucide-react";
import { cn } from "../lib/cn";
import { Badge } from "./badge";

// ---------------------------------------------------------------------------
// Shared keyboard handler
// ---------------------------------------------------------------------------
function makeKeyHandler(handler: (() => void) | undefined) {
  if (!handler) return undefined;
  return (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handler();
    }
  };
}

// ---------------------------------------------------------------------------
// Catalog-variant inline status chip (not a dq-badge — matches prototype spec)
// ---------------------------------------------------------------------------
const STATUS_CHIP_CLASSES: Record<string, string> = {
  success: "bg-[var(--color-success-surface)] text-[var(--color-success-text)]",
  warning: "bg-[var(--color-warning-surface)] text-[var(--color-warning-text)]",
  danger:  "bg-[var(--color-danger-surface)]  text-[var(--color-danger-text)]",
  info:    "bg-[var(--color-info-surface)]    text-[var(--color-info-text)]",
  gray:    "bg-[var(--color-surface)] text-[var(--color-text-muted)]",
  orange:  "bg-[var(--color-orange-50)] text-secondary",
  navy:    "bg-[var(--color-navy-50)] text-primary",
};

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface CatalogCardProps
  extends React.HTMLAttributes<HTMLDivElement> {
  // ---- variant selector (default = "media", preserves existing behaviour) ----
  variant?: "media" | "catalog";

  // ---- shared props (both variants) ----
  title: string;
  description?: string;
  onClick?: () => void;

  // ---- media-variant props (unchanged) ----
  tags?: string[];
  /** Image src or ReactNode icon to display in the card header */
  media?: string | React.ReactNode;
  mediaAlt?: string;
  /** Status badge shown over the media area */
  statusBadge?: {
    label: string;
    tone?: "success" | "warning" | "danger" | "info" | "orange" | "navy" | "gray";
  };

  // ---- catalog-variant props (new, all optional) ----
  /**
   * Mono type chip label, e.g. "G · KNOWLEDGE".
   * Rendered in JetBrains Mono, ~9.5 px, uppercase.
   */
  typeLabel?: string;
  /**
   * Status chip label, e.g. "EFFECTIVE" or "REVIEW".
   * Displayed inline next to the type chip using the catalog-card inline style
   * (not the dq-badge pill shape).
   */
  statusLabel?: string;
  /**
   * Tone for the status chip.
   * Maps to the same tone tokens as Badge.
   * @default "gray"
   */
  statusTone?: "success" | "warning" | "danger" | "info" | "orange" | "navy" | "gray";
  /**
   * Mono meta line, e.g. "5 MIN · EFFECTIVE".
   * Rendered below the header row in font-mono uppercase.
   */
  metaLine?: string;
  /**
   * Mono asset ID shown in the footer, e.g. "KNO-001".
   */
  footerId?: string;
  /**
   * Callback for the top-right open/arrow-icon button.
   * If provided, renders an ArrowUpRight icon in the header row.
   * If omitted, falls back to `onClick`.
   */
  onOpen?: () => void;
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function CatalogCard({
  // variant
  variant = "media",

  // shared
  title,
  description,
  onClick,
  className,

  // media-variant
  tags,
  media,
  mediaAlt,
  statusBadge,

  // catalog-variant
  typeLabel,
  statusLabel,
  statusTone = "gray",
  metaLine,
  footerId,
  onOpen,

  ...props
}: CatalogCardProps) {

  // ── CATALOG VARIANT ──────────────────────────────────────────────────────
  if (variant === "catalog") {
    const handleClick = onClick;
    const handleOpen = onOpen ?? onClick;
    const isClickable = !!handleClick;
    const ariaLabel = title;

    return (
      <div
        role={isClickable ? "button" : undefined}
        tabIndex={isClickable ? 0 : undefined}
        aria-label={isClickable ? ariaLabel : undefined}
        onClick={handleClick}
        onKeyDown={makeKeyHandler(handleClick)}
        className={cn(
          // dq-card shell
          "group relative flex flex-col rounded-card border border-border-default bg-white p-6 shadow-sm",
          // text-left so inherited button contexts don't center-align
          "text-left",
          // clickable states
          isClickable && [
            "cursor-pointer",
            // catalog card hover pattern from spec: no lift on primary, but the
            // task description says "hover lift" for marketplace listing variant
            "motion-safe:transition-all hover:-translate-y-0.5 hover:shadow-lg",
            "hover:border-secondary/30 hover:bg-surface",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
          ],
          className
        )}
        {...props}
      >
        {/* HEADER ROW: type chip + status chip + open icon */}
        <div className="mb-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 min-w-0">
            {typeLabel && (
              <span className="rounded bg-[var(--color-surface)] px-2 py-1 font-mono text-[9.5px] font-medium uppercase tracking-wider text-[var(--color-text-secondary)] shrink-0">
                {typeLabel}
              </span>
            )}
            {statusLabel && (
              <span
                className={cn(
                  "rounded px-1.5 py-0.5 font-mono text-[9.5px] font-semibold uppercase tracking-[0.16em] shrink-0",
                  STATUS_CHIP_CLASSES[statusTone] ?? STATUS_CHIP_CLASSES.gray
                )}
              >
                {statusLabel}
              </span>
            )}
          </div>

          {/* Open / arrow icon — top-right */}
          {(handleOpen) && (
            <button
              type="button"
              aria-label={`Open ${title}`}
              onClick={(e) => {
                e.stopPropagation();
                handleOpen();
              }}
              className="shrink-0 flex h-6 w-6 items-center justify-center rounded text-primary/30 transition-colors hover:text-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary group-hover:text-secondary"
            >
              <ArrowUpRight size={14} strokeWidth={1.5} />
            </button>
          )}
        </div>

        {/* META LINE (mono) */}
        {metaLine && (
          <div className="font-mono text-[10.5px] uppercase tracking-wider text-[var(--color-text-disabled)]">
            {metaLine}
          </div>
        )}

        {/* TITLE */}
        <h3 className="mt-1.5 text-[15.5px] font-bold leading-snug text-primary line-clamp-2">
          {title}
        </h3>

        {/* DESCRIPTION */}
        {description && (
          <p className="mt-2.5 line-clamp-3 flex-1 text-[12.5px] leading-relaxed text-[var(--color-text-muted)]">
            {description}
          </p>
        )}

        {/* FOOTER: asset ID + VIEW affordance */}
        {footerId && (
          <div className="mt-4 flex items-center justify-between border-t border-border-subtle pt-3 font-mono text-[10px] uppercase tracking-[0.16em] text-[var(--color-text-disabled)]">
            <span className="truncate pr-3">{footerId}</span>
            {isClickable && (
              <span className="shrink-0 text-secondary opacity-0 transition-opacity group-hover:opacity-100">
                View
              </span>
            )}
          </div>
        )}
      </div>
    );
  }

  // ── MEDIA VARIANT (original) ─────────────────────────────────────────────
  return (
    <div
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={makeKeyHandler(onClick)}
      className={cn(
        "rounded-card border border-border-default bg-surface shadow-sm overflow-hidden",
        "flex flex-col",
        onClick &&
          "cursor-pointer motion-safe:transition-all hover:-translate-y-0.5 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
        className
      )}
      {...props}
    >
      {/* Media area */}
      {(media || statusBadge) && (
        <div className="relative aspect-video bg-surface-nav overflow-hidden">
          {media &&
            (typeof media === "string" ? (
              <img
                src={media}
                alt={mediaAlt ?? title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                {media}
              </div>
            ))}
          {statusBadge && (
            <div className="absolute top-2 right-2">
              <Badge tone={statusBadge.tone ?? "gray"} size="sm">
                {statusBadge.label}
              </Badge>
            </div>
          )}
        </div>
      )}

      {/* Content */}
      <div className="p-4 flex flex-col gap-1 flex-1">
        <h3 className="text-base font-semibold text-primary">{title}</h3>
        {description && (
          <p className="text-sm text-[var(--color-text-muted)] line-clamp-2">{description}</p>
        )}
        {tags && tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {tags.map((tag) => (
              <Badge key={tag} tone="gray" size="sm">
                {tag}
              </Badge>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
