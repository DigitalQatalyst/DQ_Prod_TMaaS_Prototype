import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn"

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-pill border font-semibold transition-colors select-none whitespace-nowrap",
  {
    variants: {
      tone: {
        /* Default neutral */
        default: "bg-[var(--color-surface)] text-[var(--color-text-primary)] border-[var(--color-border-default)]",
        /* Status triads — bg = -surface, text = -text, border = -border token */
        success: "bg-[var(--color-success-surface)] text-[var(--color-success-text)] border-[var(--color-success-border)]",
        warning: "bg-[var(--color-warning-surface)] text-[var(--color-warning-text)] border-[var(--color-warning-border)]",
        danger:  "bg-[var(--color-danger-surface)]  text-[var(--color-danger-text)]  border-[var(--color-danger-border)]",
        info:    "bg-[var(--color-info-surface)]    text-[var(--color-info-text)]    border-[var(--color-info-border)]",
        /* Neutral / brand tones */
        gray:    "bg-[var(--color-surface)] text-[var(--color-text-muted)] border-[var(--color-border-default)]",
        orange:  "bg-[var(--color-orange-50)] text-secondary border-[color-mix(in_srgb,var(--color-secondary)_30%,transparent)]",
        navy:    "bg-[var(--color-navy-50)] text-primary border-[color-mix(in_srgb,var(--color-primary)_20%,transparent)]",
      },
      size: {
        default: "px-2.5 py-1 text-xs leading-none",
        sm:      "px-2 py-0.5 text-[10px] leading-none",
      },
    },
    defaultVariants: {
      tone: "default",
      size: "default",
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {
  dot?: boolean
}

function Badge({ className, tone, size, dot = false, children, ...props }: BadgeProps) {
  return (
    <span className={cn(badgeVariants({ tone, size }), className)} {...props}>
      {dot && (
        <span
          aria-hidden
          className={cn(
            "rounded-full bg-current shrink-0",
            size === "sm" ? "w-1 h-1" : "w-1.5 h-1.5"
          )}
        />
      )}
      {children}
    </span>
  )
}

export { Badge, badgeVariants }
