import * as React from "react";
import { ArrowUpRight, ArrowDownRight, Minus } from "lucide-react";
import { cn } from "../lib/cn";

export type StatTileTone = "primary" | "success" | "warning" | "danger" | "info";

export interface StatTileTrend {
  /** Percentage change — positive = up, negative = down */
  value: number;
  /** Optional label e.g. "vs last month" */
  label?: string;
}

export type StatTileAttainmentColorMode = "higher-is-better" | "lower-is-better";

export interface StatTileProps extends React.HTMLAttributes<HTMLDivElement> {
  label: string;
  value: string | number;
  tone?: StatTileTone;
  trend?: StatTileTrend;
  /** Optional sub-label below the value */
  subLabel?: string;
  /**
   * @deprecated No longer rendered. Clean STCB-style KPI tiles carry no decorative
   * corner icon (the icon read as generic/Bootstrap-era). Accepted for API
   * back-compat but ignored. Tone is conveyed by the value colour instead.
   */
  icon?: React.ReactNode;
  /** Optional sparkline or chart slot rendered below the delta badge */
  sparkline?: React.ReactNode;
  /**
   * Attainment percentage (0–100). When provided, a thin progress bar is
   * rendered below the value area.
   */
  attainment?: number;
  /** Label shown next to the attainment percentage, e.g. "of target" */
  attainmentLabel?: string;
  /**
   * Controls bar colour thresholds and delta arrow colour semantics.
   * @default "higher-is-better"
   */
  attainmentColorMode?: StatTileAttainmentColorMode;
  /**
   * data-testid forwarded to the value element — for feature-level test selectors.
   * @internal
   */
  valueTestId?: string;
  /**
   * data-testid forwarded to the delta badge element.
   * @internal
   */
  deltaTestId?: string;
  /**
   * data-testid forwarded to the attainment label element.
   * @internal
   */
  attainmentTestId?: string;
  /**
   * Whether the delta direction is "good" — forwarded as data-good on the badge.
   * When undefined, it is inferred from trend.value and attainmentColorMode.
   * @internal
   */
  deltaIsGood?: boolean;
}

// Tone is carried by the value colour (STCB-style clean tile) rather than the
// dated "panel with a coloured top border" treatment.
const toneValueColor: Record<StatTileTone, string> = {
  primary: "text-primary",
  success: "text-[var(--color-success)]",
  warning: "text-[var(--color-warning)]",
  danger: "text-[var(--color-danger)]",
  info: "text-[var(--color-info,theme(colors.sky.500))]",
};

/** Derive attainment bar fill colour from percentage and colour mode. */
function attainmentFillColor(
  pct: number,
  mode: StatTileAttainmentColorMode,
): string {
  // higher-is-better: green ≥75, amber 40-74, red <40
  // lower-is-better: reverse (green ≤40, amber 41-74, red ≥75... but invert by flipping pct)
  const effectivePct = mode === "lower-is-better" ? 100 - pct : pct;
  if (effectivePct >= 75) return "var(--color-success)";
  if (effectivePct >= 40) return "var(--color-warning)";
  return "var(--color-danger)";
}

export function StatTile({
  label,
  value,
  tone = "primary",
  trend,
  subLabel,
  icon: _icon, // deprecated — consumed so it never leaks to the DOM, never rendered
  sparkline,
  attainment,
  attainmentLabel,
  attainmentColorMode = "higher-is-better",
  valueTestId,
  deltaTestId,
  attainmentTestId,
  deltaIsGood: deltaIsGoodProp,
  className,
  ...props
}: StatTileProps) {
  const trendUp = trend && trend.value > 0;
  const trendFlat = trend && trend.value === 0;

  const TrendIcon = trendFlat ? Minus : trendUp ? ArrowUpRight : ArrowDownRight;

  // In lower-is-better mode, positive delta is bad (red) and negative is good (green).
  const invertDelta = attainmentColorMode === "lower-is-better";
  // Allow explicit override via deltaIsGood prop (used by feature-level wrappers)
  const isGood =
    deltaIsGoodProp !== undefined
      ? deltaIsGoodProp
      : trend
        ? trendUp
          ? !invertDelta
          : invertDelta
        : undefined;

  const trendColor = trendFlat
    ? "text-[var(--color-text-muted)]"
    : isGood === true
      ? "text-[var(--color-success)]"
      : isGood === false
        ? "text-[var(--color-danger)]"
        : trendUp
          ? "text-[var(--color-success)]"
          : "text-[var(--color-danger)]";

  return (
    <div
      className={cn(
        "rounded-card border border-border-default bg-white shadow-sm",
        "px-5 py-4 flex flex-col gap-1 min-h-[124px]",
        className
      )}
      {...props}
    >
      {/* Overline label (clean tile — no decorative corner icon) */}
      <div className="flex items-start justify-between gap-2">
        <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.16em] text-[var(--color-text-muted)]">
          {label}
        </p>
      </div>

      {/* Value — mono-spaced, large, bold; tone carried here */}
      <p
        className={cn("font-mono text-3xl font-bold tabular-nums leading-none mt-1", toneValueColor[tone])}
        data-testid={valueTestId}
        aria-live={valueTestId ? "polite" : undefined}
      >
        {value}
      </p>

      {/* Optional sub-label */}
      {subLabel && (
        <p className="text-xs text-[var(--color-text-muted)]">{subLabel}</p>
      )}

      {/* Delta badge with Lucide arrow icon */}
      {trend && (
        <div
          className={cn("mt-2 flex items-center gap-1 text-xs font-semibold", trendColor)}
          data-testid={deltaTestId}
          data-good={deltaTestId !== undefined ? String(isGood ?? (trendUp ? !invertDelta : invertDelta)) : undefined}
        >
          <TrendIcon size={14} strokeWidth={1.5} aria-hidden="true" />
          <span>
            {trend.value > 0 ? "+" : ""}
            {trend.value}%
          </span>
          {trend.label && (
            <span className="text-[var(--color-text-muted)] font-normal ml-0.5">
              {trend.label}
            </span>
          )}
        </div>
      )}

      {/* Optional sparkline slot */}
      {sparkline && <div className="mt-2">{sparkline}</div>}

      {/* Attainment progress bar */}
      {attainment !== undefined && (
        <div className="mt-2 flex flex-col gap-1">
          {/* Track + fill */}
          <div
            className="h-[6px] w-full overflow-hidden rounded-full bg-gray-100"
            role="progressbar"
            aria-valuenow={Math.min(attainment, 100)}
            aria-valuemin={0}
            aria-valuemax={100}
          >
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${Math.min(attainment, 100)}%`,
                backgroundColor: attainmentFillColor(attainment, attainmentColorMode),
              }}
            />
          </div>
          {/* Optional percentage + label */}
          <p
            className="text-xs text-[var(--color-text-muted)]"
            data-testid={attainmentTestId}
          >
            {attainment}%{attainmentLabel ? ` ${attainmentLabel}` : ""}
          </p>
        </div>
      )}
    </div>
  );
}
