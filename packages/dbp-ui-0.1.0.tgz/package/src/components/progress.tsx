"use client"
import * as React from "react"
import * as ProgressPrimitive from "@radix-ui/react-progress"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "../lib/cn.js"

const progressTrackVariants = cva(
  "relative w-full overflow-hidden rounded-full bg-[var(--color-border-subtle)]",
  {
    variants: {
      size: {
        sm:      "h-1",
        default: "h-1.5",
        lg:      "h-2.5",
      },
    },
    defaultVariants: {
      size: "default",
    },
  }
)

const progressFillColor: Record<string, string> = {
  primary: "bg-primary",
  success: "bg-[var(--color-success)]",
  warning: "bg-[var(--color-warning)]",
  danger:  "bg-[var(--color-danger)]",
  info:    "bg-[var(--color-info)]",
  orange:  "bg-secondary",
}

export interface ProgressProps
  extends React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>,
    VariantProps<typeof progressTrackVariants> {
  /** 0–100 */
  value?: number
  tone?: keyof typeof progressFillColor
  label?: string
  showLabel?: boolean
}

export const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  ProgressProps
>(({ value = 0, tone = "primary", size, label, showLabel = false, className, ...props }, ref) => {
  const clampedValue = Math.min(100, Math.max(0, value))
  const fillClass = progressFillColor[tone] ?? progressFillColor.primary

  return (
    <div className={cn("w-full", className)}>
      {(label || showLabel) && (
        <div className="mb-1.5 flex items-center justify-between gap-2">
          {label && (
            <span className="text-xs text-[var(--color-text-muted)]">{label}</span>
          )}
          {showLabel && (
            <span className="font-mono text-[10px] text-[var(--color-text-muted)] tabular-nums">
              {clampedValue}%
            </span>
          )}
        </div>
      )}
      <ProgressPrimitive.Root
        ref={ref}
        value={clampedValue}
        className={cn(progressTrackVariants({ size }))}
        {...props}
      >
        <ProgressPrimitive.Indicator
          className={cn(
            "h-full w-full flex-1 rounded-full",
            "transition-all duration-500 ease-in-out motion-safe:transition-all",
            fillClass
          )}
          style={{ transform: `translateX(-${100 - clampedValue}%)` }}
        />
      </ProgressPrimitive.Root>
    </div>
  )
})
Progress.displayName = "Progress"
