"use client"
import * as React from "react"
import * as SwitchPrimitive from "@radix-ui/react-switch"
import { cn } from "../lib/cn.js"

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitive.Root>
>(({ className, ...props }, ref) => (
  <SwitchPrimitive.Root
    ref={ref}
    className={cn(
      "group relative inline-flex h-5 w-9 shrink-0 cursor-pointer",
      "rounded-[var(--radius-pill)]",
      "border-2 border-transparent",
      "transition-colors motion-safe:transition-all duration-200",
      /* Off state */
      "bg-[var(--color-border-strong)]",
      /* On state */
      "data-[state=checked]:bg-primary",
      /* Focus */
      "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
      /* Disabled */
      "disabled:cursor-not-allowed disabled:opacity-50",
      className
    )}
    {...props}
  >
    <SwitchPrimitive.Thumb
      className={cn(
        "pointer-events-none block h-4 w-4 rounded-full bg-white",
        "shadow-[0_1px_3px_rgba(0,0,0,0.2)]",
        "ring-0 transition-transform duration-200 motion-safe:transition-transform",
        "translate-x-0 data-[state=checked]:translate-x-4"
      )}
    />
  </SwitchPrimitive.Root>
))
Switch.displayName = SwitchPrimitive.Root.displayName

export { Switch }
