"use client"

import * as React from "react"
import { Menu } from "lucide-react"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "./sheet.js"
import { cn } from "../lib/cn.js"

export interface PublicHeaderNavLink {
  label: string
  href: string
}

export interface PublicHeaderSignIn {
  label: string
  href: string
}

export interface PublicHeaderProps {
  /** Solution code rendered bold-navy (e.g. "DWS.01"). */
  productCode: string
  /** Product name rendered muted after the code (e.g. "Work.Space4.0"). */
  productName?: string
  /** Horizontal nav links shown in the center/right area. */
  links?: PublicHeaderNavLink[]
  /** Sign-in CTA pill rendered in the top-right. */
  signIn?: PublicHeaderSignIn
  className?: string
}

/**
 * PublicHeader — sticky marketing web header (h-16).
 *
 * Desktop: product lockup (code + muted name) | nav links | sign-in pill CTA.
 * Mobile: lockup | hamburger → Sheet drawer with vertical nav + sign-in.
 *
 * This is the only "use client" landing component (needs drawer state).
 */
export function PublicHeader({
  productCode,
  productName,
  links = [],
  signIn,
  className,
}: PublicHeaderProps) {
  const [drawerOpen, setDrawerOpen] = React.useState(false)

  return (
    <header
      className={cn(
        "sticky top-0 z-[var(--z-sticky)] h-16 w-full",
        "border-b border-[var(--color-border-subtle)] bg-white",
        "flex items-center justify-between px-4 md:px-6 lg:px-8",
        className
      )}
    >
      {/* LEFT: product lockup */}
      <a
        href="/"
        className="flex items-baseline gap-1.5 hover:opacity-80 motion-safe:transition-opacity focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)] rounded-button"
        aria-label={`${productCode}${productName ? ` — ${productName}` : ""} home`}
      >
        <span className="text-[18px] font-bold leading-none text-primary">
          {productCode}
        </span>
        {productName && (
          <span className="text-[15px] font-medium leading-none text-[var(--color-text-secondary)]">
            / {productName}
          </span>
        )}
      </a>

      {/* CENTER-RIGHT: desktop nav + sign-in */}
      <nav
        aria-label="Main navigation"
        className="hidden items-center gap-6 md:flex"
      >
        {links.map((link) => (
          <a
            key={link.href}
            href={link.href}
            className={cn(
              "text-sm font-medium text-[var(--color-text-secondary)]",
              "hover:text-primary motion-safe:transition-colors",
              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)] rounded-sm"
            )}
          >
            {link.label}
          </a>
        ))}

        {signIn && (
          <a
            href={signIn.href}
            className={cn(
              "inline-flex h-9 items-center gap-2 rounded-pill px-5",
              "text-sm font-semibold text-white bg-primary",
              "hover:bg-[color-mix(in_srgb,var(--color-primary)_85%,black)]",
              "motion-safe:transition-colors",
              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
            )}
          >
            {signIn.label}
          </a>
        )}
      </nav>

      {/* MOBILE: hamburger button */}
      <button
        type="button"
        aria-label="Open navigation menu"
        aria-expanded={drawerOpen}
        aria-controls="public-header-drawer"
        className={cn(
          "flex h-9 w-9 items-center justify-center rounded-button",
          "text-primary hover:bg-[var(--color-navy-50)] motion-safe:transition-colors",
          "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
          "md:hidden"
        )}
        onClick={() => setDrawerOpen(true)}
      >
        <Menu size={20} strokeWidth={1.5} aria-hidden="true" />
      </button>

      {/* MOBILE: Sheet drawer */}
      <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
        <SheetContent
          id="public-header-drawer"
          side="right"
          className="w-72 bg-white"
          aria-label="Navigation menu"
        >
          <SheetHeader>
            <SheetTitle className="flex items-baseline gap-1.5">
              <span className="text-[18px] font-bold text-primary">{productCode}</span>
              {productName && (
                <span className="text-[15px] font-medium text-[var(--color-text-secondary)]">
                  / {productName}
                </span>
              )}
            </SheetTitle>
          </SheetHeader>

          <nav
            aria-label="Mobile navigation"
            className="flex flex-col gap-1 pt-2"
          >
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={cn(
                  "flex h-10 items-center rounded-button px-3",
                  "text-sm font-medium text-[var(--color-text-secondary)]",
                  "hover:bg-[var(--color-navy-50)] hover:text-primary",
                  "motion-safe:transition-colors",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
                )}
                onClick={() => setDrawerOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {signIn && (
            <div className="mt-4 border-t border-[var(--color-border-subtle)] pt-4">
              <a
                href={signIn.href}
                className={cn(
                  "flex h-10 w-full items-center justify-center rounded-pill",
                  "text-sm font-semibold text-white bg-primary",
                  "hover:bg-[color-mix(in_srgb,var(--color-primary)_85%,black)]",
                  "motion-safe:transition-colors",
                  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]"
                )}
                onClick={() => setDrawerOpen(false)}
              >
                {signIn.label}
              </a>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </header>
  )
}
