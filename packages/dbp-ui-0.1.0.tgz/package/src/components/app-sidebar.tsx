import * as React from "react";
import { ChevronDown, icons as lucideIcons } from "lucide-react";
import * as LucideIcons from "lucide-react";
import { SidebarConfig, NavItem } from "@dbp/contracts";
import { cn } from "../lib/cn.js";

type LucideGlyph = React.ComponentType<{
  size?: number;
  strokeWidth?: number;
  className?: string;
}>;

/**
 * Resolves a lucide icon by PascalCase name. Prefers the named module export
 * (covers deprecated aliases like "Home") and falls back to the `icons` map.
 * Returns null for unknown names so the sidebar degrades gracefully.
 */
function resolveIcon(name: string): LucideGlyph | null {
  const named = (LucideIcons as Record<string, unknown>)[name];
  if (typeof named === "object" && named !== null && "$$typeof" in named) {
    return named as LucideGlyph;
  }
  const mapped = (lucideIcons as Record<string, LucideGlyph | undefined>)[name];
  return mapped ?? null;
}

export interface AppSidebarProps {
  config: SidebarConfig;
  /** Current pathname for active state detection */
  activePath: string;
  /** Called when a nav item is clicked */
  onNavigate?: (href: string) => void;
  className?: string;
  /** Persist nav open/close state to localStorage under this key */
  storageKey?: string;
  /** Render icon-only mode (no labels, no children) */
  iconOnly?: boolean;
}

const INITIAL_NAV_STATE = { collapsedSections: {} as Record<string, boolean>, collapsedItems: {} as Record<string, boolean> }

function loadNavState(storageKey?: string): typeof INITIAL_NAV_STATE {
  if (!storageKey || typeof window === 'undefined') return INITIAL_NAV_STATE
  try {
    return JSON.parse(localStorage.getItem(storageKey) ?? 'null') ?? INITIAL_NAV_STATE
  } catch { return INITIAL_NAV_STATE }
}

function saveNavState(storageKey: string | undefined, state: typeof INITIAL_NAV_STATE): void {
  if (!storageKey || typeof window === 'undefined') return
  localStorage.setItem(storageKey, JSON.stringify(state))
}

function defaultNavState(config: SidebarConfig, activePath?: string): typeof INITIAL_NAV_STATE {
  const collapsedItems: Record<string, boolean> = {}
  config.sections.forEach(section => {
    section.items.forEach((item, idx) => {
      if (item.children && item.children.length > 0) {
        const descendantActive = activePath ? groupIsActive(item, activePath) : false
        collapsedItems[item.id] = !descendantActive && idx !== 0
      }
    })
  })
  return { collapsedSections: {}, collapsedItems }
}

const focusRing =
  "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]";

/** Resolves a lucide icon name (PascalCase) to a rendered glyph at stroke 1.5. */
function NavIcon({ name }: { name?: string }) {
  if (!name) return null;
  const Icon = resolveIcon(name);
  if (!Icon) return null;
  return <Icon size={17} strokeWidth={1.5} className="shrink-0" />;
}

function isActive(item: NavItem, activePath: string): boolean {
  return activePath === item.href || activePath.startsWith(item.href + "/");
}

function groupIsActive(item: NavItem, activePath: string): boolean {
  if (isActive(item, activePath)) return true;
  return Boolean(item.children?.some((c) => groupIsActive(c, activePath)));
}

/** Nested child row (level 3) — sits inside the .sidebar-child-line rail. */
function ChildRow({
  item,
  activePath,
  onNavigate,
}: {
  item: NavItem;
  activePath: string;
  onNavigate?: (href: string) => void;
}) {
  const active = isActive(item, activePath);
  return (
    <button
      type="button"
      onClick={() => { if (item.href) onNavigate?.(item.href); }}
      aria-current={active ? "page" : undefined}
      className={cn(
        "sidebar-feature-item w-full",
        active && "sidebar-feature-item-active",
        focusRing
      )}
    >
      {active && (
        <span
          aria-hidden
          className="absolute bottom-1.5 left-[-13px] top-1.5 w-0.5 rounded-r bg-[var(--color-nav-accent)]"
        />
      )}
      <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
      {item.badge && (
        <span className="ml-2 shrink-0 rounded-pill bg-primary px-1.5 py-0.5 text-[10px] font-bold text-white">
          {item.badge}
        </span>
      )}
    </button>
  );
}

/** Top-level group row (level 2) with optional expandable children. */
function GroupRow({
  item,
  activePath,
  onNavigate,
  iconOnly,
  isItemCollapsed,
  onToggleItem,
}: {
  item: NavItem;
  activePath: string;
  onNavigate?: (href: string) => void;
  iconOnly?: boolean;
  isItemCollapsed?: boolean;
  onToggleItem?: (id: string) => void;
}) {
  const hasChildren = Boolean(item.children && item.children.length > 0);
  const active = groupIsActive(item, activePath);
  const selfActive = isActive(item, activePath);

  const open = hasChildren ? !isItemCollapsed : false;

  const handleClick = () => {
    if (hasChildren && onToggleItem) {
      onToggleItem(item.id);
    }
    if (!hasChildren && item.href) {
      onNavigate?.(item.href);
    }
  };

  if (iconOnly) {
    return (
      <div>
        <a
          href={item.href}
          aria-current={selfActive ? "page" : undefined}
          className={cn(
            "relative sidebar-feature-group whitespace-nowrap",
            (selfActive || active) && "sidebar-feature-group-active",
            focusRing
          )}
          title={item.label}
        >
          {(selfActive || active) && (
            <span
              aria-hidden
              className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-[var(--color-nav-accent)]"
            />
          )}
          <NavIcon {...(item.icon !== undefined && { name: item.icon })} />
        </a>
      </div>
    );
  }

  return (
    <div>
      <button
        type="button"
        onClick={handleClick}
        aria-current={selfActive ? "page" : undefined}
        aria-expanded={hasChildren ? open : undefined}
        className={cn(
          "relative sidebar-feature-group",
          (selfActive || active) && "sidebar-feature-group-active",
          focusRing
        )}
      >
        {(selfActive || active) && (
          <span
            aria-hidden
            className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-[var(--color-nav-accent)]"
          />
        )}
        <NavIcon {...(item.icon !== undefined && { name: item.icon })} />
        <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
        {item.badge && (
          <span className="shrink-0 rounded-pill bg-primary px-1.5 py-0.5 text-[10px] font-bold text-white">
            {item.badge}
          </span>
        )}
        {hasChildren && (
          <ChevronDown
            size={14}
            strokeWidth={1.5}
            aria-hidden
            className={cn(
              "shrink-0 motion-safe:transition-transform",
              open && "rotate-180"
            )}
          />
        )}
      </button>

      {hasChildren && open && (
        <div className="sidebar-child-line">
          {item.children!.map((child) => (
            <ChildRow
              key={child.id}
              item={child}
              activePath={activePath}
              {...(onNavigate !== undefined && { onNavigate })}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * AppSidebar — DQ prototype three-level navigation (280px white surface).
 *
 * Hierarchy: section eyebrow (mono/bold uppercase orange) → group rows
 * (icon + label + chevron, navy-50 active with orange w-0.5 accent) → nested
 * children inside a left border-line rail (.sidebar-child-line), each with its
 * own orange active accent. Icons resolve from lucide names; aria-current marks
 * the active route; hover/focus-visible states follow the token system.
 */
export function AppSidebar({ config, activePath, onNavigate, className, storageKey, iconOnly }: AppSidebarProps) {
  const [navState, setNavState] = React.useState(() => {
    if (!storageKey || typeof window === 'undefined') return defaultNavState(config, activePath)
    const stored = loadNavState(storageKey)
    const hasStoredSections = Object.keys(stored.collapsedSections).length > 0 || Object.keys(stored.collapsedItems).length > 0
    return hasStoredSections ? stored : defaultNavState(config, activePath)
  })

  const _toggleSection = (id: string) =>
    setNavState(prev => {
      const next = { ...prev, collapsedSections: { ...prev.collapsedSections, [id]: !prev.collapsedSections[id] } }
      saveNavState(storageKey, next)
      return next
    })

  const toggleItem = (id: string) =>
    setNavState(prev => {
      const next = { ...prev, collapsedItems: { ...prev.collapsedItems, [id]: !prev.collapsedItems[id] } }
      saveNavState(storageKey, next)
      return next
    })

  return (
    <nav
      className={cn(
        "flex flex-1 min-h-0 flex-col overflow-y-auto bg-white px-3 py-4",
        className
      )}
      aria-label="Sidebar navigation"
    >
      <div className="space-y-5">
        {config.sections.map((section) => (
          <section key={section.id} className="space-y-1">
            {section.label && (
              <div className="sidebar-feature-area">{section.label}</div>
            )}
            <div className="mt-1 space-y-1">
              {section.items.map((item) => (
                <GroupRow
                  key={item.id}
                  item={item}
                  activePath={activePath}
                  {...(onNavigate !== undefined && { onNavigate })}
                  iconOnly={iconOnly ?? false}
                  isItemCollapsed={Boolean(navState.collapsedItems[item.id])}
                  onToggleItem={toggleItem}
                />
              ))}
            </div>
          </section>
        ))}
      </div>
    </nav>
  );
}
