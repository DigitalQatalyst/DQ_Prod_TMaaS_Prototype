'use client'
import * as React from 'react'

interface BreadcrumbCtx {
  dynamicLabel: string | null
  setDynamicLabel: (label: string | null) => void
}

const BreadcrumbContext = React.createContext<BreadcrumbCtx>({
  dynamicLabel: null,
  setDynamicLabel: () => {},
})

export function BreadcrumbProvider({ children }: { children: React.ReactNode }) {
  const [dynamicLabel, setDynamicLabel] = React.useState<string | null>(null)
  return (
    <BreadcrumbContext.Provider value={{ dynamicLabel, setDynamicLabel }}>
      {children}
    </BreadcrumbContext.Provider>
  )
}

export function useBreadcrumb() {
  return React.useContext(BreadcrumbContext)
}
