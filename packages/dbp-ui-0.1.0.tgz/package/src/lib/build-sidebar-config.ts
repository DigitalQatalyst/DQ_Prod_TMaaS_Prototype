import type { SidebarConfig, NavItem, NavSection } from "@dbp/contracts";
import type { ModuleNav } from "@dbp/contracts";

/**
 * Converts a manifest ModuleNav into a SidebarConfig for AppSidebar.
 *
 * Two input shapes are supported:
 *
 * **Flat `items` (current shape / back-compat):**
 * Items are grouped by their `section` string into SidebarConfig sections.
 * Items sharing the same section label are collapsed into one section.
 * Items with no section go into an implicit unnamed section.
 * Each item becomes a top-level NavItem (no children) with `href` + `label`.
 *
 * **Nested `sections` (future shape, optional extension):**
 * Sections are mapped directly to SidebarConfig sections.
 * Each group inside a section may carry `children` (passed through as-is).
 * `icon` name strings are passed through — AppSidebar resolves them via lucide.
 */
export function buildSidebarConfig(nav: ModuleNav): SidebarConfig {
  // Future nested-sections path — guard with optional chaining since the
  // ModuleNavSchema does not yet declare `sections`.
  const nestedSections = (nav as { sections?: NavSection[] }).sections;
  if (nestedSections && nestedSections.length > 0) {
    return { sections: nestedSections, collapsible: false };
  }

  // Flat items path (current ModuleNav shape).
  // Group consecutive items that share the same `section` label.
  // A change in section label (including undefined → labelled or vice-versa)
  // opens a new SidebarConfig section — matching the behaviour of the
  // per-shell buildSidebarConfig functions this helper replaces.
  const sections: SidebarConfig["sections"] = [];
  let current: SidebarConfig["sections"][number] | null = null;

  for (const item of nav.items) {
    const sectionLabel = (item as { section?: string }).section;
    if (!current || current.label !== sectionLabel) {
      current = {
        id: sectionLabel ?? "__default__",
        label: sectionLabel,
        items: [],
      };
      sections.push(current);
    }
    const navItem: NavItem = {
      id: item.id,
      label: item.label,
      href: item.href,
    };
    // Carry through optional fields that ModuleNavItemSchema may gain over time.
    const extended = item as { icon?: string; badge?: string };
    if (extended.icon) navItem.icon = extended.icon;
    if (extended.badge) navItem.badge = extended.badge;
    current.items.push(navItem);
  }

  return { sections, collapsible: false };
}

/**
 * Returns the `href` of the first item marked `active: true`.
 *
 * For flat `items`: scans the top-level array.
 * For nested `sections`: scans group items, then their children.
 *
 * Used as AppSidebar's `activePath` prop.
 */
export function deriveActivePath(nav: ModuleNav): string {
  // Nested-sections path.
  const nestedSections = (nav as { sections?: NavSection[] }).sections;
  if (nestedSections && nestedSections.length > 0) {
    for (const section of nestedSections) {
      for (const group of section.items) {
        if ((group as { active?: boolean }).active) return group.href ?? "";
        for (const child of group.children ?? []) {
          if ((child as { active?: boolean }).active) return child.href ?? "";
        }
      }
    }
    return "";
  }

  // Flat items path.
  const activeItem = nav.items.find(
    (i) => (i as { active?: boolean }).active === true,
  );
  return activeItem?.href ?? "";
}
