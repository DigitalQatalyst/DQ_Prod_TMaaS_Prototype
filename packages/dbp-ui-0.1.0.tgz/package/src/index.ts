export { Button, buttonVariants } from "./components/button.js";
export type { ButtonProps } from "./components/button.js";

export { Input, FieldLabel } from "./components/input.js";
export type { InputProps } from "./components/input.js";

export { Tabs, TabsList, TabsTrigger, TabsContent } from "./components/tabs.js";

export {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "./components/sheet.js";

export { Skeleton } from "./components/skeleton.js";

export {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  CardClickable,
} from "./components/card.js";

export { Breadcrumb } from "./components/breadcrumb.js";
export type { BreadcrumbProps, BreadcrumbItem } from "./components/breadcrumb.js";

export { Grid, Col } from "./components/grid.js";
export type { GridProps, ColProps, ColSpan } from "./components/grid.js";

export { PageHeader } from "./components/page-header.js";
export type { PageHeaderProps, PageHeaderAction, PageHeaderSpan } from "./components/page-header.js";

export { Badge, badgeVariants } from "./components/badge.js";
export type { BadgeProps } from "./components/badge.js";

export { CatalogCard } from "./components/catalog-card.js";
export type { CatalogCardProps } from "./components/catalog-card.js";

export { Separator } from "./components/separator.js";

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuGroup,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuRadioGroup,
} from "./components/dropdown-menu.js";

export { ScrollArea, ScrollBar } from "./components/scroll-area.js";

export { SlotFrame } from "./components/slot-frame.js";
export type { SlotFrameProps } from "./components/slot-frame.js";

export { AppTopBar } from "./components/app-top-bar.js";
export type { AppTopBarProps } from "./components/app-top-bar.js";

export { AppChrome } from "./components/app-chrome.js";
export type {
  AppChromeProps,
  AppChromeSession,
  AppChromeCapabilities,
} from "./components/app-chrome.js";

export { AppSidebar } from "./components/app-sidebar.js";
export type { AppSidebarProps } from "./components/app-sidebar.js";

export { LoginPage } from "./components/login-page.js";
export type { LoginPageProps } from "./components/login-page.js";

export { StatTile } from "./components/stat-tile.js";
export type { StatTileProps, StatTileTone, StatTileTrend, StatTileAttainmentColorMode } from "./components/stat-tile.js";

/* ─── New P0 components ───────────────────────────────────────────────── */

export {
  Dialog,
  DialogTrigger,
  DialogClose,
  DialogPortal,
  DialogOverlay,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogBody,
  DialogTitle,
  DialogDescription,
} from "./components/dialog.js";

export {
  Toast,
  ToastTitle,
  ToastDescription,
  ToastAction,
  ToastProvider,
  ToastViewport,
  Toaster,
  toast,
  useToast,
} from "./components/toast.js";
export type { ToastOptions, ToastProps } from "./components/toast.js";

export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton,
} from "./components/select.js";

export { FormField } from "./components/form-field.js";
export type { FormFieldProps } from "./components/form-field.js";

export { Alert } from "./components/alert.js";
export type { AlertProps } from "./components/alert.js";

/* ─── New P1 components ───────────────────────────────────────────────── */

export { Checkbox } from "./components/checkbox.js";
export type { CheckboxProps } from "./components/checkbox.js";

export { Switch } from "./components/switch.js";

export {
  TooltipProvider,
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  SimpleTooltip,
} from "./components/tooltip.js";
export type { SimpleTooltipProps } from "./components/tooltip.js";

export { Avatar, AvatarLockup } from "./components/avatar.js";
export type { AvatarProps, AvatarLockupProps } from "./components/avatar.js";

export { EmptyState } from "./components/empty-state.js";
export type { EmptyStateProps } from "./components/empty-state.js";

export { LoadingSkeleton } from "./components/loading-skeleton.js";
export type { LoadingSkeletonProps } from "./components/loading-skeleton.js";

export { ErrorCard } from "./components/error-card.js";
export type { ErrorCardProps } from "./components/error-card.js";

export { ErrorState } from "./components/error-state.js";
export type { ErrorStateProps } from "./components/error-state.js";

export { Pagination } from "./components/pagination.js";
export type { PaginationProps } from "./components/pagination.js";

export { Progress } from "./components/progress.js";
export type { ProgressProps } from "./components/progress.js";

export { SegmentedControl } from "./components/segmented-control.js";
export type { SegmentedControlProps, SegmentOption } from "./components/segmented-control.js";

/* ─── Public Landing Page components ─────────────────────────────────── */

export { PublicHeader } from "./components/public-header.js"
export type { PublicHeaderProps, PublicHeaderNavLink, PublicHeaderSignIn } from "./components/public-header.js"

export { LandingHero } from "./components/landing-hero.js"
export type { LandingHeroProps, LandingHeroTrustBullet, LandingHeroCta } from "./components/landing-hero.js"

export { LandingFeatures, LandingHowItWorks, LandingCta } from "./components/landing-sections.js"

export { WorkspaceGreetingCard } from "./components/workspace-greeting-card.js"
export type {
  WorkspaceGreetingCardProps,
  WorkspaceGreetingQuickLink,
  WorkspaceGreetingUpdate,
} from "./components/workspace-greeting-card.js"
export type {
  LandingFeaturesProps,
  LandingFeatureItem,
  LandingHowItWorksProps,
  LandingHowItWorksStep,
  LandingCtaProps,
  LandingCtaFeatureTile,
} from "./components/landing-sections.js"

export { LandingFooter } from "./components/landing-footer.js"
export type { LandingFooterProps, LandingFooterColumn, LandingFooterLinkItem } from "./components/landing-footer.js"

/* ─── Detail page layout primitives ──────────────────────────────────── */

export { DetailPageGrid } from "./components/detail-page-grid.js"
export type { DetailPageGridProps } from "./components/detail-page-grid.js"

export { RailSection, RailActionButton, SectionCard } from "./components/detail-rail.js"
export type {
  RailSectionProps,
  RailActionButtonProps,
  RailActionTone,
  SectionCardProps,
} from "./components/detail-rail.js"

/* ─── App Home primitives ─────────────────────────────────────────────── */

export { HomeHero } from "./components/home-hero.js";
export type { HomeHeroProps } from "./components/home-hero.js";

export { AISearchBar } from "./components/ai-search-bar.js";
export type { AISearchBarProps } from "./components/ai-search-bar.js";

export { FilterBar } from "./components/filter-bar.js";
export type { FilterBarProps, FilterChip } from "./components/filter-bar.js";

/* ─── Utilities ───────────────────────────────────────────────────────── */

export { cn } from "./lib/cn.js";

export { buildSidebarConfig, deriveActivePath } from "./lib/build-sidebar-config.js";

export {
  formatNumber,
  formatCurrency,
  formatPercent,
  formatDate,
  formatRelativeTime,
  isIsoDateString,
  isYearMonthString,
  type FormatNumberOptions,
  type FormatCurrencyOptions,
  type DateStyle,
} from "./lib/format.js";

export {
  ActivityFeed,
  NotificationBell,
  SearchBar,
  PermissionGate,
  AssistantPanel,
} from "./bindings/index.js";
export type {
  ActivityFeedProps,
  NotificationBellProps,
  SearchBarProps,
  PermissionGateProps,
  AssistantPanelProps,
} from "./bindings/index.js";

export { BreadcrumbBar } from './components/breadcrumb-bar.js'
export type { BreadcrumbBarProps } from './components/breadcrumb-bar.js'
export { BreadcrumbProvider, useBreadcrumb } from './context/breadcrumb-context.js'
