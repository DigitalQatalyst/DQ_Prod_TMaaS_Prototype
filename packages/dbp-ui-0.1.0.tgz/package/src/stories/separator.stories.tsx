import type { Meta, StoryObj } from "@storybook/react";
import { Separator } from "../components/separator.js";

const meta: Meta<typeof Separator> = {
  title: "UI/Separator",
  component: Separator,
  tags: ["autodocs"],
  argTypes: {
    orientation: {
      control: "select",
      options: ["horizontal", "vertical"],
    },
    decorative: { control: "boolean" },
  },
};

export default meta;
type Story = StoryObj<typeof Separator>;

export const Horizontal: Story = {
  args: { orientation: "horizontal" },
  render: (args) => (
    <div style={{ width: "320px" }}>
      <p style={{ fontSize: "14px", marginBottom: "16px" }}>Content above the separator</p>
      <Separator {...args} />
      <p style={{ fontSize: "14px", marginTop: "16px" }}>Content below the separator</p>
    </div>
  ),
};

export const Vertical: Story = {
  args: { orientation: "vertical" },
  render: (args) => (
    <div style={{ display: "flex", alignItems: "center", height: "40px", gap: "16px" }}>
      <span style={{ fontSize: "14px" }}>Home</span>
      <Separator {...args} />
      <span style={{ fontSize: "14px" }}>Products</span>
      <Separator {...args} />
      <span style={{ fontSize: "14px" }}>About</span>
    </div>
  ),
};

export const WithLabel: Story = {
  name: "With label",
  render: () => (
    <div style={{ width: "320px" }}>
      <p style={{ fontSize: "13px", color: "var(--color-text-muted)", marginBottom: "12px" }}>
        Section one content
      </p>
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <Separator />
        <span style={{ fontSize: "11px", color: "var(--color-text-muted)", whiteSpace: "nowrap", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>
          OR
        </span>
        <Separator />
      </div>
      <p style={{ fontSize: "13px", color: "var(--color-text-muted)", marginTop: "12px" }}>
        Section two content
      </p>
    </div>
  ),
};

export const InProfileCard: Story = {
  name: "In profile card",
  render: () => (
    <div
      style={{
        width: "280px",
        border: "1px solid var(--color-border)",
        borderRadius: "8px",
        padding: "16px",
        background: "white",
      }}
    >
      <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
        <div
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            background: "var(--color-navy-50)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "16px",
            fontWeight: 600,
            color: "var(--color-primary)",
          }}
        >
          AJ
        </div>
        <div>
          <p style={{ fontSize: "14px", fontWeight: 600, margin: 0 }}>Alex Johnson</p>
          <p style={{ fontSize: "12px", color: "var(--color-text-muted)", margin: 0 }}>admin@example.com</p>
        </div>
      </div>
      <Separator className="my-4" />
      <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
        <button
          type="button"
          style={{ fontSize: "13px", textAlign: "left", background: "none", border: "none", cursor: "pointer", padding: "4px 0" }}
        >
          Edit profile
        </button>
        <button
          type="button"
          style={{ fontSize: "13px", textAlign: "left", background: "none", border: "none", cursor: "pointer", padding: "4px 0" }}
        >
          Account settings
        </button>
      </div>
      <Separator className="my-4" />
      <button
        type="button"
        style={{ fontSize: "13px", color: "red", textAlign: "left", background: "none", border: "none", cursor: "pointer", padding: "4px 0" }}
      >
        Log out
      </button>
    </div>
  ),
};
