import type { Meta, StoryObj } from '@storybook/react'
import { BreadcrumbBar } from '../components/breadcrumb-bar.js'

const meta: Meta<typeof BreadcrumbBar> = {
  title: 'Shell/BreadcrumbBar',
  component: BreadcrumbBar,
  parameters: { layout: 'padded' },
}
export default meta
type Story = StoryObj<typeof BreadcrumbBar>

export const Single: Story = {
  args: { crumbs: [{ label: 'Home', href: '/home' }] },
}
export const TwoLevel: Story = {
  args: { crumbs: [{ label: 'Marketplace', href: '/marketplace' }, { label: 'Catalogue', href: '/marketplace/catalogue' }] },
}
export const ThreeLevel: Story = {
  args: {
    crumbs: [
      { label: 'Marketplace', href: '/marketplace' },
      { label: 'Catalogue', href: '/marketplace/catalogue' },
      { label: 'Design', href: '/marketplace/catalogue/design' },
    ],
  },
}
export const WithLongLabel: Story = {
  args: {
    crumbs: [
      { label: 'Platform Administration', href: '/admin' },
      { label: 'User & Role Management', href: '/admin/users' },
      { label: 'Edit: Alice Johnson', href: '/admin/users/alice' },
    ],
  },
}
