import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureAuditClient } from "@dbp/ps-audit/client";
import { ActivityFeed } from "../../bindings/ActivityFeed.js";

// ── Fake fetch helpers ──────────────────────────────────────────────────────

const BASE = "http://storybook.test/api/platform/audit";
const ENTITY_ID = "invoice-001";

const fakeEvents = [
  {
    id: "aaaaaaaa-0001-0001-0001-000000000001",
    ts: new Date(Date.now() - 60_000).toISOString(),
    actor: { userId: "u1", email: "alice@acme.com", displayName: "Alice" },
    action: "invoice.approve",
    target: { entityType: "invoice", entityId: ENTITY_ID },
    delta: { status: { from: "pending", to: "approved" } },
    tenantId: "demo",
  },
  {
    id: "aaaaaaaa-0001-0001-0001-000000000002",
    ts: new Date(Date.now() - 3600_000).toISOString(),
    actor: { userId: "u2", email: "bob@acme.com", displayName: "Bob" },
    action: "invoice.submit",
    target: { entityType: "invoice", entityId: ENTITY_ID },
    delta: null,
    tenantId: "demo",
  },
];

type FakeFetch = (input: string, init?: RequestInit) => Promise<Response>;

function makeFetch(events: typeof fakeEvents, nextCursor: string | null = null): FakeFetch {
  return () =>
    Promise.resolve(
      new Response(JSON.stringify({ events, nextCursor }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function pendingFetch(): FakeFetch {
  return () => new Promise(() => {/* never resolves */});
}

// ── Meta ─────────────────────────────────────────────────────────────────────

const meta: Meta<typeof ActivityFeed> = {
  title: "Bindings/ActivityFeed",
  component: ActivityFeed,
  tags: ["autodocs"],
  decorators: [
    (Story) => {
      configureAuditClient({ baseUrl: BASE, fetch: makeFetch(fakeEvents), tenantId: "demo" });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 320, padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export default meta;
type Story = StoryObj<typeof ActivityFeed>;

export const Default: Story = {
  args: { entityId: ENTITY_ID, title: "Activity" },
};

export const WithLoadMore: Story = {
  decorators: [
    (Story) => {
      configureAuditClient({
        baseUrl: BASE,
        fetch: makeFetch(fakeEvents, "cursor-page-2"),
        tenantId: "demo",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 320, padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  args: { entityId: ENTITY_ID, title: "Activity (with more)" },
};

export const Loading: Story = {
  decorators: [
    (Story) => {
      configureAuditClient({ baseUrl: BASE, fetch: pendingFetch(), tenantId: "demo" });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 320, padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  args: { entityId: ENTITY_ID },
};

export const Empty: Story = {
  decorators: [
    (Story) => {
      configureAuditClient({ baseUrl: BASE, fetch: makeFetch([]), tenantId: "demo" });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 320, padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  args: { entityId: ENTITY_ID },
};

export const Error: Story = {
  decorators: [
    (Story) => {
      configureAuditClient({
        baseUrl: BASE,
        fetch: () =>
          Promise.resolve(
            new Response(JSON.stringify({ error: "Internal error" }), {
              status: 500,
              headers: { "content-type": "application/json" },
            }),
          ),
        tenantId: "demo",
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 320, padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  args: { entityId: ENTITY_ID },
};
