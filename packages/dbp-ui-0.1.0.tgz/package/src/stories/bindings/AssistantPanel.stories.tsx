import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureAiClient } from "@dbp/ps-ai/client";
import { AssistantPanel } from "../../bindings/AssistantPanel.js";

const BASE = "http://storybook.test/api/platform/ai";

function makeSseFetch(reply: string) {
  return (): Promise<Response> => {
    const chunks = reply.split(" ");
    let i = 0;
    const convId = "conv-story-001";
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        const enc = new TextEncoder();
        for (const word of chunks) {
          const delta = i === 0 ? word : ` ${word}`;
          const event = `data: ${JSON.stringify({ type: "chunk", delta, conversationId: convId })}\n\n`;
          controller.enqueue(enc.encode(event));
          i++;
          await new Promise((r) => setTimeout(r, 40));
        }
        const done = `data: ${JSON.stringify({ type: "done", conversationId: convId, message: reply, usage: { inputTokens: 10, outputTokens: 20 } })}\n\n`;
        controller.enqueue(enc.encode(done));
        controller.close();
      },
    });
    return Promise.resolve(
      new Response(stream, {
        status: 200,
        headers: { "content-type": "text/event-stream" },
      }),
    );
  };
}

const meta: Meta<typeof AssistantPanel> = {
  title: "Bindings/AssistantPanel",
  component: AssistantPanel,
  tags: ["autodocs"],
  decorators: [
    (Story) => {
      configureAiClient({
        baseUrl: BASE,
        fetch: makeSseFetch("Hello! I can help you with invoices, orders, and workflows."),
      });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 360, height: 480, border: "1px solid #e5e7eb", borderRadius: 8, overflow: "hidden" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export default meta;
type Story = StoryObj<typeof AssistantPanel>;

export const Default: Story = {
  args: { title: "Assistant" },
};

export const WithContext: Story = {
  args: {
    title: "Invoice Assistant",
    context: { entityType: "invoice", entityId: "INV-101" },
  },
};
