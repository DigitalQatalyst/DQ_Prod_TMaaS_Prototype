import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureRbacClient } from "@dbp/ps-rbac/client";
import { PermissionGate } from "../../bindings/PermissionGate.js";

const BASE = "http://storybook.test/api/platform/rbac";

function packedRulesFetch(allowed: boolean) {
  const rules = allowed
    ? [{ action: "invoice.approve", subject: "all" }]
    : [];
  return (): Promise<Response> =>
    Promise.resolve(
      new Response(
        JSON.stringify({ rules, tenantId: "demo", roles: ["admin"] }),
        { status: 200, headers: { "content-type": "application/json" } },
      ),
    );
}

const meta: Meta<typeof PermissionGate> = {
  title: "Bindings/PermissionGate",
  component: PermissionGate,
  tags: ["autodocs"],
  decorators: [
    (Story) => {
      configureRbacClient({ baseUrl: BASE, fetch: packedRulesFetch(true) });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export default meta;
type Story = StoryObj<typeof PermissionGate>;

export const Allowed: Story = {
  args: {
    action: "invoice.approve",
    children: <button style={{ padding: "8px 16px", background: "#2563eb", color: "white", borderRadius: 4 }}>Approve Invoice</button>,
    fallback: <span style={{ color: "red" }}>Access denied</span>,
  },
};

export const Denied: Story = {
  decorators: [
    (Story) => {
      configureRbacClient({ baseUrl: BASE, fetch: packedRulesFetch(false) });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  args: {
    action: "invoice.approve",
    children: <button>Approve Invoice</button>,
    fallback: <span style={{ color: "red" }}>Access denied</span>,
  },
};
