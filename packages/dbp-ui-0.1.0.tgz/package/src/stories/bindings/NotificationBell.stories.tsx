import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureNotifClient, type Notification } from "@dbp/ps-notif/client";
import { NotificationBell } from "../../bindings/NotificationBell.js";

const BASE = "http://storybook.test/api/platform/notif";

const fakeNotifs: Notification[] = [
  {
    id: "bbbbbbbb-0001-0001-0001-000000000001",
    to: "alice",
    type: "task.assigned",
    message: "You have been assigned invoice #INV-101",
    link: "https://app.example.com/invoices/101",
    channel: "in-app" as const,
    status: "unread" as const,
    ts: new Date(Date.now() - 120_000).toISOString(),
    tenantId: "demo",
  },
  {
    id: "bbbbbbbb-0001-0001-0001-000000000002",
    to: "alice",
    type: "comment.added",
    message: "Bob commented on Order #ORD-55",
    channel: "in-app" as const,
    status: "read" as const,
    ts: new Date(Date.now() - 7200_000).toISOString(),
    tenantId: "demo",
  },
];

function makeFetch(items: typeof fakeNotifs, unread: number) {
  return (): Promise<Response> =>
    Promise.resolve(
      new Response(JSON.stringify({ items, unread }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}


const meta: Meta<typeof NotificationBell> = {
  title: "Bindings/NotificationBell",
  component: NotificationBell,
  tags: ["autodocs"],
  decorators: [
    (Story) => {
      configureNotifClient({ baseUrl: BASE, fetch: makeFetch(fakeNotifs, 1) });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem", display: "flex", justifyContent: "flex-end" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export default meta;
type Story = StoryObj<typeof NotificationBell>;

export const WithUnread: Story = {};

export const NoUnread: Story = {
  decorators: [
    (Story) => {
      configureNotifClient({ baseUrl: BASE, fetch: makeFetch(fakeNotifs.map((n): Notification => ({ ...n, status: "read" as const })), 0) });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem", display: "flex", justifyContent: "flex-end" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export const Empty: Story = {
  decorators: [
    (Story) => {
      configureNotifClient({ baseUrl: BASE, fetch: makeFetch([], 0) });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ padding: "1rem", display: "flex", justifyContent: "flex-end" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};
