import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { configureSearchClient } from "@dbp/ps-search/client";
import type { SearchHit } from "@dbp/ps-search/client";
import { SearchBar } from "../../bindings/SearchBar.js";

const BASE = "http://storybook.test/api/platform/search";

const fakeHits: SearchHit[] = [
  { id: "doc-1", entityType: "invoice", title: "Invoice #INV-101", score: 0.98 },
  { id: "doc-2", entityType: "order", title: "Order #ORD-55", score: 0.87 },
  { id: "doc-3", entityType: "customer", title: "Acme Corporation", score: 0.75 },
];

function makeFetch(results: SearchHit[]) {
  return (): Promise<Response> =>
    Promise.resolve(
      new Response(JSON.stringify({ results, facets: [], total: results.length }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

const meta: Meta<typeof SearchBar> = {
  title: "Bindings/SearchBar",
  component: SearchBar,
  tags: ["autodocs"],
  decorators: [
    (Story) => {
      configureSearchClient({ baseUrl: BASE, fetch: makeFetch(fakeHits), tenantId: "demo" });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 360, padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
};

export default meta;
type Story = StoryObj<typeof SearchBar>;

export const Default: Story = {
  args: {
    placeholder: "Search invoices, orders…",
    onSelect: (hit) => console.log("selected", hit),
  },
};

export const Empty: Story = {
  decorators: [
    (Story) => {
      configureSearchClient({ baseUrl: BASE, fetch: makeFetch([]), tenantId: "demo" });
      const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
      return (
        <QueryClientProvider client={qc}>
          <div style={{ width: 360, padding: "1rem" }}>
            <Story />
          </div>
        </QueryClientProvider>
      );
    },
  ],
  args: { placeholder: "Search…" },
};
