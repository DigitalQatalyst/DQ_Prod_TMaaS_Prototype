import type { Meta, StoryObj } from "@storybook/react";
import type { SidebarConfig } from "@dbp/contracts";
import { AppSidebar } from "../components/app-sidebar.js";

/**
 * Three-level DQ hierarchy:
 *   section eyebrow (orange) → group rows (icon + chevron) → nested children.
 * Icons resolve from lucide names (PascalCase) on each group item.
 */
const sidebarConfig: SidebarConfig = {
  collapsible: false,
  sections: [
    {
      id: "workspace",
      label: "Workspace",
      items: [
        { id: "home", label: "Home", href: "/home", icon: "Home" },
        {
          id: "tasks",
          label: "Tasks",
          href: "/tasks",
          icon: "ListChecks",
          badge: "4",
          children: [
            { id: "assigned", label: "Assigned to me", href: "/tasks/assigned" },
            { id: "watching", label: "Watching", href: "/tasks/watching" },
          ],
        },
        {
          id: "knowledge",
          label: "Knowledge",
          href: "/knowledge",
          icon: "BookOpen",
          children: [
            { id: "playbooks", label: "Playbooks", href: "/knowledge/playbooks" },
            { id: "standards", label: "Standards", href: "/knowledge/standards" },
          ],
        },
      ],
    },
    {
      id: "admin",
      label: "Administration",
      items: [
        { id: "people", label: "People", href: "/people", icon: "Users" },
        { id: "settings", label: "Settings", href: "/settings", icon: "Settings" },
      ],
    },
  ],
};

const meta: Meta<typeof AppSidebar> = {
  title: "Shell/AppSidebar",
  component: AppSidebar,
  parameters: { layout: "padded" },
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <div
        style={{
          height: "560px",
          width: "280px",
          border: "1px solid var(--color-border-subtle)",
        }}
      >
        <Story />
      </div>
    ),
  ],
};
export default meta;
type Story = StoryObj<typeof AppSidebar>;

export const Default: Story = {
  args: { config: sidebarConfig, activePath: "/home" },
};

/** Active descendant — parent group is highlighted and auto-expanded. */
export const ActiveChild: Story = {
  args: { config: sidebarConfig, activePath: "/tasks/assigned" },
};

export const ActiveSettings: Story = {
  args: { config: sidebarConfig, activePath: "/settings" },
};

export const CollapsibleSections: Story = {
  args: {
    config: { ...sidebarConfig, collapsible: true },
    activePath: '/home',
  },
};

export const WithPersistedState: Story = {
  args: {
    config: { ...sidebarConfig, collapsible: true },
    activePath: '/home',
    storageKey: 'storybook-nav-state',
  },
};
