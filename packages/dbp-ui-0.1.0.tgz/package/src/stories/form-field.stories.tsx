import type { Meta, StoryObj } from "@storybook/react";
import { FormField } from "../components/form-field.js";
import { Input } from "../components/input.js";

const meta: Meta = {
  title: "UI/FormField",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <FormField label="Email address" helperText="We'll never share your email." style={{ width: "320px" }}>
      <Input placeholder="you@example.com" type="email" />
    </FormField>
  ),
};

export const WithError: Story = {
  render: () => (
    <FormField label="Password" error="Password must be at least 8 characters." style={{ width: "320px" }}>
      <Input type="password" error />
    </FormField>
  ),
};

export const Required: Story = {
  render: () => (
    <FormField label="Full name" required style={{ width: "320px" }}>
      <Input placeholder="Jane Smith" />
    </FormField>
  ),
};
