import type { Meta, StoryObj } from "@storybook/react";
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from "../components/sheet.js";
import { Button } from "../components/button.js";

const meta: Meta = {
  title: "UI/Sheet",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

export const RightSlideIn: Story = {
  name: "Right (default)",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open right sheet</Button>
      </SheetTrigger>
      <SheetContent side="right">
        <SheetHeader>
          <SheetTitle>Panel Title</SheetTitle>
          <SheetDescription>
            This panel slides in from the right. Use it for detail views, forms, or
            supplementary content.
          </SheetDescription>
        </SheetHeader>
        <div style={{ padding: "8px 0" }}>
          <p style={{ fontSize: "14px", color: "var(--color-text-muted)" }}>
            Panel body content goes here.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  ),
};

export const LeftSlideIn: Story = {
  name: "Left",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open left sheet</Button>
      </SheetTrigger>
      <SheetContent side="left">
        <SheetHeader>
          <SheetTitle>Navigation</SheetTitle>
          <SheetDescription>Side navigation panel.</SheetDescription>
        </SheetHeader>
        <nav style={{ marginTop: "8px" }}>
          <ul style={{ display: "flex", flexDirection: "column", gap: "4px", listStyle: "none", padding: 0 }}>
            {["Dashboard", "Projects", "Team", "Settings"].map((item) => (
              <li key={item}>
                <a
                  href="#"
                  style={{
                    display: "block",
                    padding: "8px 12px",
                    borderRadius: "6px",
                    fontSize: "14px",
                    textDecoration: "none",
                    color: "var(--color-text)",
                  }}
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </SheetContent>
    </Sheet>
  ),
};

export const TopSlideIn: Story = {
  name: "Top",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open top sheet</Button>
      </SheetTrigger>
      <SheetContent side="top">
        <SheetHeader>
          <SheetTitle>Notification Banner</SheetTitle>
          <SheetDescription>This sheet slides down from the top of the screen.</SheetDescription>
        </SheetHeader>
      </SheetContent>
    </Sheet>
  ),
};

export const BottomSlideIn: Story = {
  name: "Bottom",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline">Open bottom sheet</Button>
      </SheetTrigger>
      <SheetContent side="bottom">
        <SheetHeader>
          <SheetTitle>Mobile Action Sheet</SheetTitle>
          <SheetDescription>Common actions for the selected item.</SheetDescription>
        </SheetHeader>
        <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
          <Button size="sm">Edit</Button>
          <Button size="sm" variant="outline">Duplicate</Button>
          <Button size="sm" variant="destructive">Delete</Button>
        </div>
      </SheetContent>
    </Sheet>
  ),
};

export const WithFormContent: Story = {
  name: "With form content",
  render: () => (
    <Sheet>
      <SheetTrigger asChild>
        <Button>Edit profile</Button>
      </SheetTrigger>
      <SheetContent side="right">
        <SheetHeader>
          <SheetTitle>Edit Profile</SheetTitle>
          <SheetDescription>
            Update your profile information. Changes are saved automatically.
          </SheetDescription>
        </SheetHeader>
        <div style={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: "16px" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <label style={{ fontSize: "13px", fontWeight: 500 }}>Name</label>
            <input
              type="text"
              defaultValue="Alex Johnson"
              style={{
                border: "1px solid var(--color-border)",
                borderRadius: "6px",
                padding: "8px 12px",
                fontSize: "14px",
              }}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <label style={{ fontSize: "13px", fontWeight: 500 }}>Email</label>
            <input
              type="email"
              defaultValue="alex@example.com"
              style={{
                border: "1px solid var(--color-border)",
                borderRadius: "6px",
                padding: "8px 12px",
                fontSize: "14px",
              }}
            />
          </div>
          <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
            <Button size="sm">Save changes</Button>
            <SheetClose asChild>
              <Button size="sm" variant="outline">Cancel</Button>
            </SheetClose>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  ),
};
