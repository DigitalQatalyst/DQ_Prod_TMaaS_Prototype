import type { Meta, StoryObj } from "@storybook/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AppChrome } from "../components/app-chrome.js";
import type { AppChromeSession } from "../components/app-chrome.js";

const client = new QueryClient();

const meta: Meta<typeof AppChrome> = {
  title: "Shell/AppChrome",
  component: AppChrome,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <QueryClientProvider client={client}>
        <Story />
      </QueryClientProvider>
    ),
  ],
};
export default meta;
type Story = StoryObj<typeof AppChrome>;

const approver: AppChromeSession = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  displayName: "Alpha Finance Approver",
  primaryRole: "Finance Approver",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
};

const multiRole: AppChromeSession = {
  ...approver,
  displayName: "Sam Okoro",
  roles: ["finance-approver", "platform-admin"],
};

/**
 * Fully wired solution (PS.SEARCH + PS.NOTIF): global search, notification bell,
 * settings, and the avatar block — all session + capability driven.
 */
export const FullyWired: Story = {
  args: {
    productCode: "DWS.05",
    productName: "Digital WFMS",
    session: approver,
    capabilities: { search: true, notifications: true },
    searchPlaceholder: "Search shifts, people, requests…",
  },
};

/**
 * Analytics solution (PS.AUTH + PS.DATA + PS.AI only): NO search, NO bell — just
 * settings + avatar. Demonstrates capability gating from consumed services.
 */
export const NoSearchNoBell: Story = {
  args: {
    productCode: "DIA.02",
    productName: "AnalyticsOps",
    session: approver,
    capabilities: { search: false, notifications: false },
  },
};

/** Multi-role session — the optional role switcher appears (xl+). */
export const WithRoleSwitcher: Story = {
  args: {
    productCode: "DWS.04",
    productName: "Digital ERP",
    session: multiRole,
    capabilities: { search: true, notifications: true },
  },
};

/** Loading / unauthenticated — session is null, so no avatar block renders. */
export const NoSession: Story = {
  args: {
    productCode: "DXP.01A",
    productName: "Digital Channels Web",
    session: null,
    capabilities: { search: true, notifications: true },
  },
};
