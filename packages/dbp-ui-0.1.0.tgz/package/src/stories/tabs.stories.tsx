import type { Meta, StoryObj } from "@storybook/react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/tabs.js";

const meta: Meta = {
  title: "UI/Tabs",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

export const Default: Story = {
  name: "Default tabs",
  render: () => (
    <Tabs defaultValue="overview" style={{ width: "480px" }}>
      <TabsList>
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="activity">Activity</TabsTrigger>
        <TabsTrigger value="settings">Settings</TabsTrigger>
      </TabsList>
      <TabsContent value="overview">
        <p style={{ padding: "16px 0", color: "var(--color-text)" }}>
          Overview content — this is the default active tab.
        </p>
      </TabsContent>
      <TabsContent value="activity">
        <p style={{ padding: "16px 0", color: "var(--color-text)" }}>
          Activity feed would live here.
        </p>
      </TabsContent>
      <TabsContent value="settings">
        <p style={{ padding: "16px 0", color: "var(--color-text)" }}>
          Settings panel would live here.
        </p>
      </TabsContent>
    </Tabs>
  ),
};

export const WithBadge: Story = {
  name: "Tabs with badge content",
  render: () => (
    <Tabs defaultValue="pending" style={{ width: "480px" }}>
      <TabsList>
        <TabsTrigger value="all">All items</TabsTrigger>
        <TabsTrigger value="pending">Pending (3)</TabsTrigger>
        <TabsTrigger value="done">Done</TabsTrigger>
      </TabsList>
      <TabsContent value="all">
        <p style={{ padding: "16px 0", color: "var(--color-text)" }}>All items listed here.</p>
      </TabsContent>
      <TabsContent value="pending">
        <p style={{ padding: "16px 0", color: "var(--color-text)" }}>3 pending items.</p>
      </TabsContent>
      <TabsContent value="done">
        <p style={{ padding: "16px 0", color: "var(--color-text)" }}>No completed items yet.</p>
      </TabsContent>
    </Tabs>
  ),
};
