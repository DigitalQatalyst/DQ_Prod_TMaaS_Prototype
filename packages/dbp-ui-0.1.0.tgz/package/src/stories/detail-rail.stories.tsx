import type { Meta, StoryObj } from "@storybook/react";
import { RailSection, RailActionButton, SectionCard } from "../components/detail-rail.js";
import { Skeleton } from "../components/skeleton.js";

const meta: Meta = {
  title: "UI/DetailRail",
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj;

const LabelValue = ({
  label,
  value,
}: {
  label: string;
  value: string;
}) => (
  <div style={{ display: "flex", flexDirection: "column", gap: "2px", marginBottom: "12px" }}>
    <span style={{ fontSize: "11px", color: "var(--color-text-muted)", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>
      {label}
    </span>
    <span style={{ fontSize: "13px", color: "var(--color-text)", fontWeight: 500 }}>
      {value}
    </span>
  </div>
);

export const LabelValuePairs: Story = {
  name: "Label/value pairs",
  render: () => (
    <div style={{ width: "280px" }}>
      <RailSection title="Details">
        <LabelValue label="Owner" value="Alex Johnson" />
        <LabelValue label="Category" value="Analytics" />
        <LabelValue label="Version" value="2.4.1" />
        <LabelValue label="Last updated" value="Jun 14, 2026" />
      </RailSection>
    </div>
  ),
};

export const WithIcons: Story = {
  name: "With action buttons",
  render: () => (
    <div style={{ width: "280px", display: "flex", flexDirection: "column", gap: "12px" }}>
      <RailSection title="Actions">
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          <RailActionButton icon="CheckSquare" tone="outline">
            Mark as complete
          </RailActionButton>
          <RailActionButton icon="Link2" tone="outline">
            Copy link
          </RailActionButton>
          <RailActionButton icon="Play" tone="navy">
            Start workflow
          </RailActionButton>
        </div>
      </RailSection>
    </div>
  ),
};

export const GhostTone: Story = {
  name: "Ghost tone buttons",
  render: () => (
    <div style={{ width: "280px" }}>
      <RailSection title="Governance">
        <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
          <RailActionButton icon="FileText" tone="ghost">View policy</RailActionButton>
          <RailActionButton icon="Shield" tone="ghost">Compliance report</RailActionButton>
          <RailActionButton icon="AlertCircle" tone="ghost">Raise concern</RailActionButton>
        </div>
      </RailSection>
    </div>
  ),
};

export const LoadingState: Story = {
  name: "Loading state",
  render: () => (
    <div style={{ width: "280px", display: "flex", flexDirection: "column", gap: "12px" }}>
      <RailSection title="Details">
        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          {[1, 2, 3, 4].map((i) => (
            <div key={i} style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
              <Skeleton className="h-3 w-16" />
              <Skeleton className="h-4 w-32" />
            </div>
          ))}
        </div>
      </RailSection>
      <RailSection title="Actions">
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          <Skeleton className="h-8 w-full rounded-md" />
          <Skeleton className="h-8 w-full rounded-md" />
        </div>
      </RailSection>
    </div>
  ),
};

export const SectionCardExample: Story = {
  name: "SectionCard",
  render: () => (
    <div style={{ maxWidth: "600px" }}>
      <SectionCard title="Overview">
        <p style={{ fontSize: "14px", color: "var(--color-text-muted)", lineHeight: "1.6" }}>
          This section card is used in the main content column of the detail page. It provides
          a consistent bordered container for grouping related content.
        </p>
      </SectionCard>
    </div>
  ),
};
