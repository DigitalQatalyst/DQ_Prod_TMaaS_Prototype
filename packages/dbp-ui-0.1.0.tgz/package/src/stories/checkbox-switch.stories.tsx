import type { Meta, StoryObj } from "@storybook/react";
import { Checkbox } from "../components/checkbox.js";
import { Switch } from "../components/switch.js";

const meta: Meta = {
  title: "UI/CheckboxAndSwitch",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Checkboxes: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Checkbox aria-label="Unchecked" /> Unchecked
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Checkbox aria-label="Checked" defaultChecked /> Checked
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Checkbox aria-label="Disabled" disabled /> Disabled
      </label>
    </div>
  ),
};

export const Switches: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Switch aria-label="Off" /> Off
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Switch aria-label="On" defaultChecked /> On
      </label>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.875rem", color: "var(--color-text-secondary)" }}>
        <Switch aria-label="Disabled" disabled /> Disabled
      </label>
    </div>
  ),
};
