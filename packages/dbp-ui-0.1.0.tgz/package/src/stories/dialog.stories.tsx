import type { Meta, StoryObj } from "@storybook/react";
import { Button } from "../components/button.js";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogBody,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "../components/dialog.js";

const meta: Meta = {
  title: "UI/Dialog",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="navy">Open dialog</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Confirm action</DialogTitle>
          <DialogDescription>This action cannot be undone. Are you sure?</DialogDescription>
        </DialogHeader>
        <DialogBody>
          <p style={{ color: "var(--color-text-secondary)", fontSize: "0.875rem" }}>
            Body content goes here — forms, details, etc.
          </p>
        </DialogBody>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="ghost">Cancel</Button>
          </DialogClose>
          <Button variant="orange">Confirm</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  ),
};

export const Large: Story = {
  render: () => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">Open large</Button>
      </DialogTrigger>
      <DialogContent size="lg">
        <DialogHeader>
          <DialogTitle>Large dialog</DialogTitle>
        </DialogHeader>
        <DialogBody>
          <p style={{ color: "var(--color-text-muted)", fontSize: "0.875rem" }}>
            Use size=&quot;lg&quot; for wider content — e.g. wizard steps, record editors.
          </p>
        </DialogBody>
        <DialogFooter>
          <Button variant="orange">Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  ),
};
