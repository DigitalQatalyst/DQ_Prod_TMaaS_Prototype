import type { Meta, StoryObj } from "@storybook/react";
import { Progress } from "../components/progress.js";

const meta: Meta<typeof Progress> = {
  title: "UI/Progress",
  component: Progress,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Progress>;

export const Default: Story = { args: { value: 60, label: "Upload progress", showLabel: true } };

export const AllTones: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px", width: "320px" }}>
      <Progress value={80} tone="primary" label="Primary" showLabel />
      <Progress value={65} tone="success" label="Success" showLabel />
      <Progress value={45} tone="warning" label="Warning" showLabel />
      <Progress value={30} tone="danger"  label="Danger"  showLabel />
      <Progress value={55} tone="info"    label="Info"    showLabel />
      <Progress value={70} tone="orange"  label="Orange"  showLabel />
    </div>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px", width: "320px" }}>
      <Progress value={50} size="sm" tone="primary" />
      <Progress value={50} size="default" tone="primary" />
      <Progress value={50} size="lg" tone="primary" />
    </div>
  ),
};
