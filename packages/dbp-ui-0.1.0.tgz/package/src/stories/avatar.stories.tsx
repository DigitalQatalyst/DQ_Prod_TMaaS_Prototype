import type { Meta, StoryObj } from "@storybook/react";
import { Avatar, AvatarLockup } from "../components/avatar.js";

const meta: Meta = {
  title: "UI/Avatar",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Sizes: Story = {
  render: () => (
    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
      <Avatar name="Alice Brown" size="sm" />
      <Avatar name="Bob Clarke" size="md" />
      <Avatar name="Carol Davies" size="lg" />
    </div>
  ),
};

export const Palette: Story = {
  name: "Deterministic color palette",
  render: () => (
    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
      {["Alice Brown", "Bob Clarke", "Carol Davies", "Dave Evans", "Eve Foster", "Frank Green"].map((n) => (
        <Avatar key={n} name={n} size="md" title={n} />
      ))}
    </div>
  ),
};

export const WithImage: Story = {
  render: () => (
    <Avatar
      name="Test User"
      size="lg"
      src="https://i.pravatar.cc/48?img=3"
    />
  ),
};

export const Lockup: Story = {
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <AvatarLockup name="Ian Hargreaves" role="Senior Analyst" />
      <AvatarLockup name="Sarah Mitchell" role="Platform Admin" size="lg" />
    </div>
  ),
};
