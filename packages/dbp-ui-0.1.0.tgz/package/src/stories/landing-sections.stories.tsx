import type { Meta, StoryObj } from "@storybook/react"
import { ShieldCheck, Workflow, BarChart2, Users, Zap, Globe, Lock } from "lucide-react"
import { LandingFeatures, LandingHowItWorks, LandingCta } from "../components/landing-sections.js"

/* ── LandingFeatures ─────────────────────────────────────────────────────── */

const featuresMeta: Meta<typeof LandingFeatures> = {
  title: "Landing/LandingFeatures",
  component: LandingFeatures,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
}
export default featuresMeta
type FeaturesStory = StoryObj<typeof LandingFeatures>

const featureItems = [
  { icon: <ShieldCheck size={20} strokeWidth={1.5} />, title: "Governed access", description: "Role-based entitlements enforced on every action and resource." },
  { icon: <Workflow size={20} strokeWidth={1.5} />, title: "Connected workflows", description: "Tasks, requests, and approvals wired together with audit trails." },
  { icon: <BarChart2 size={20} strokeWidth={1.5} />, title: "Performance visibility", description: "Live KPI dashboards and SLA tracking across your whole team." },
  { icon: <Users size={20} strokeWidth={1.5} />, title: "Multi-tenant ready", description: "Serve multiple teams or business units from a single deployment." },
]

export const Default: FeaturesStory = {
  args: {
    overline: "Platform capabilities",
    headline: "Everything your team needs",
    headlineAccent: "in one place.",
    body: "From task management to governed knowledge and workflow automation — all built on a single, secure platform.",
    items: featureItems,
    linkLabel: "Explore all features",
    linkHref: "#features",
  },
}

export const DefaultItems: FeaturesStory = {
  name: "Default placeholder items",
  args: {},
}

/* ── LandingHowItWorks ───────────────────────────────────────────────────── */

// Storybook will pick up further exports from this file IF we export separate meta.
// Since only one default export is allowed per file, we compose a composite story.

export const HowItWorks: StoryObj = {
  render: () => (
    <LandingHowItWorks
      overline="How it works"
      headline="Up and running in minutes"
      body="Follow a simple setup path — no heavy IT project required."
      steps={[
        { icon: <Zap size={20} strokeWidth={1.5} />, title: "Request access", description: "Your admin provisions your role-based profile in minutes." },
        { icon: <Users size={20} strokeWidth={1.5} />, title: "Explore your workspace", description: "Land on your personalised home with priorities and actions ready." },
        { icon: <BarChart2 size={20} strokeWidth={1.5} />, title: "Start work", description: "Pick up tasks, consult knowledge assets, or trigger a service." },
        { icon: <ShieldCheck size={20} strokeWidth={1.5} />, title: "Track outcomes", description: "Monitor SLAs and governance from your performance dashboard." },
        { icon: <Globe size={20} strokeWidth={1.5} />, title: "Improve continuously", description: "Analyse patterns and refine your team's operating model." },
      ]}
    />
  ),
}

export const HowItWorksDark: StoryObj = {
  name: "HowItWorks — dark band",
  render: () => (
    <LandingHowItWorks
      tone="dark"
      overline="How it works"
      headline="Up and running in minutes"
      body="The deep-navy mesh band — the third beat in the white→gray→dark→orange landing rhythm."
      steps={[
        { icon: <Zap size={20} strokeWidth={1.5} />, title: "Request access", description: "Your admin provisions your role-based profile in minutes." },
        { icon: <Users size={20} strokeWidth={1.5} />, title: "Explore your workspace", description: "Land on your personalised home with priorities and actions ready." },
        { icon: <BarChart2 size={20} strokeWidth={1.5} />, title: "Start work", description: "Pick up tasks, consult knowledge assets, or trigger a service." },
        { icon: <ShieldCheck size={20} strokeWidth={1.5} />, title: "Track outcomes", description: "Monitor SLAs and governance from your performance dashboard." },
      ]}
    />
  ),
}

export const CtaSection: StoryObj = {
  render: () => (
    <LandingCta
      headline="Ready to transform how your team works?"
      headlineAccent="Start today."
      body="Join thousands of teams already using the platform for governed, high-performance daily work."
      primaryCta={{ label: "Get Started Free", href: "#" }}
      secondaryCta={{ label: "Book a demo", href: "#" }}
      featureTiles={[
        { icon: <ShieldCheck size={20} strokeWidth={1.5} />, title: "SOC 2 Type II", description: "Enterprise-grade security" },
        { icon: <Lock size={20} strokeWidth={1.5} />, title: "Role-based access", description: "Granular entitlements" },
        { icon: <BarChart2 size={20} strokeWidth={1.5} />, title: "Audit-ready", description: "Full action trail" },
        { icon: <Zap size={20} strokeWidth={1.5} />, title: "Rapid onboarding", description: "Live in under a week" },
      ]}
    />
  ),
}
