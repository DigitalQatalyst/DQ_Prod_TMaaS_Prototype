import type { Meta, StoryObj } from "@storybook/react";
import { Alert } from "../components/alert.js";

const meta: Meta<typeof Alert> = {
  title: "UI/Alert",
  component: Alert,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof Alert>;

export const Info: Story = {
  args: { tone: "info", title: "Information", children: "Your session will expire in 30 minutes." },
};

export const Success: Story = {
  args: { tone: "success", title: "Saved successfully", children: "All changes have been committed." },
};

export const Warning: Story = {
  args: { tone: "warning", title: "Review required", children: "This record has pending governance approvals." },
};

export const Danger: Story = {
  args: { tone: "danger", title: "Action failed", children: "Could not connect to the data service. Try again." },
};

export const Dismissible: Story = {
  args: { tone: "info", title: "Tip", children: "You can use keyboard shortcuts to navigate faster.", dismissible: true },
};

export const AllTones: Story = {
  name: "All tones",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px", maxWidth: "480px" }}>
      <Alert tone="info" title="Info">Informational message</Alert>
      <Alert tone="success" title="Success">Operation completed</Alert>
      <Alert tone="warning" title="Warning">Proceed with caution</Alert>
      <Alert tone="danger" title="Error">Something went wrong</Alert>
    </div>
  ),
};
