import type { Meta, StoryObj } from "@storybook/react";
import { Inbox, FolderOpen, SearchX } from "lucide-react";
import { EmptyState } from "../components/empty-state.js";
import { Button } from "../components/button.js";

const meta: Meta<typeof EmptyState> = {
  title: "UI/EmptyState",
  component: EmptyState,
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof EmptyState>;

export const Default: Story = {
  args: {
    icon: <Inbox size={24} strokeWidth={1.5} />,
    title: "Nothing here yet",
    description: "Once items are added they will appear here.",
  },
};

export const WithActionButton: Story = {
  args: {
    icon: <FolderOpen size={24} strokeWidth={1.5} />,
    title: "No projects found",
    description: "Get started by creating your first project.",
    action: <Button size="sm">Create project</Button>,
  },
};

export const NoIcon: Story = {
  args: {
    title: "No results",
    description: "Try adjusting your search or filter criteria.",
  },
};

export const SearchEmpty: Story = {
  args: {
    icon: <SearchX size={24} strokeWidth={1.5} />,
    title: "No results found",
    description: "We couldn't find anything matching your search. Try different keywords.",
    action: <Button variant="outline" size="sm">Clear search</Button>,
  },
};

export const Compact: Story = {
  args: {
    icon: <Inbox size={20} strokeWidth={1.5} />,
    title: "Empty",
    description: "Nothing to display.",
    className: "py-8",
  },
};

// ─── New headline API stories ──────────────────────────────────────────────

export const HeadlineOnly: Story = {
  args: { headline: "No tasks found" },
};

export const HeadlineWithDescription: Story = {
  args: {
    headline: "No invoices yet",
    description: "Create your first invoice to get started.",
  },
};

export const HeadlineWithActionObject: Story = {
  args: {
    headline: "No records",
    action: { label: "Create Record", onClick: () => {} },
  },
};

export const HeadlineFull: Story = {
  args: {
    headline: "Nothing here",
    description: "Add something to see it here.",
    action: { label: "Add Item", onClick: () => {} },
  },
};
