import type { Meta, StoryObj } from "@storybook/react";
import { Skeleton } from "../components/skeleton.js";

const meta: Meta<typeof Skeleton> = {
  title: "UI/Skeleton",
  component: Skeleton,
  tags: ["autodocs"],
};

export default meta;
type Story = StoryObj<typeof Skeleton>;

export const Default: Story = {
  args: { className: "h-4 w-48" },
};

export const TextLines: Story = {
  name: "Text lines",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px", width: "320px" }}>
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-4/5" />
      <Skeleton className="h-4 w-3/4" />
    </div>
  ),
};

export const CardPlaceholder: Story = {
  name: "Card placeholder",
  render: () => (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "12px",
        width: "320px",
        padding: "16px",
        border: "1px solid #e5e7eb",
        borderRadius: "8px",
      }}
    >
      <Skeleton className="h-40 w-full rounded-lg" />
      <Skeleton className="h-5 w-3/4" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-4/5" />
      <div style={{ display: "flex", gap: "8px", marginTop: "4px" }}>
        <Skeleton className="h-8 w-24 rounded-md" />
        <Skeleton className="h-8 w-16 rounded-md" />
      </div>
    </div>
  ),
};

export const TableRows: Story = {
  name: "Table rows",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px", width: "480px" }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <div key={i} style={{ display: "flex", gap: "16px", alignItems: "center" }}>
          <Skeleton className="h-8 w-8 rounded-full shrink-0" />
          <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "6px" }}>
            <Skeleton className="h-3.5 w-2/3" />
            <Skeleton className="h-3 w-1/2" />
          </div>
          <Skeleton className="h-6 w-16 rounded-full" />
        </div>
      ))}
    </div>
  ),
};

export const CustomDimensions: Story = {
  name: "Custom dimensions",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <Skeleton className="h-2 w-64" />
      <Skeleton className="h-6 w-32" />
      <Skeleton className="h-12 w-12 rounded-full" />
      <Skeleton className="h-32 w-64 rounded-xl" />
    </div>
  ),
};

export const Avatar: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
      <Skeleton className="h-10 w-10 rounded-full" />
      <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
        <Skeleton className="h-4 w-28" />
        <Skeleton className="h-3 w-20" />
      </div>
    </div>
  ),
};
