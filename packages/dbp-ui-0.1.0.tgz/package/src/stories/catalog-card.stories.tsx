import type { Meta, StoryObj } from "@storybook/react";
import { CatalogCard } from "../components/catalog-card.js";

const meta: Meta<typeof CatalogCard> = {
  title: "Data/CatalogCard",
  component: CatalogCard,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof CatalogCard>;

// ── MEDIA VARIANT (original) ────────────────────────────────────────────────

export const Default: Story = {
  args: {
    variant: "media",
    title: "Digital ERP Suite",
    description:
      "End-to-end enterprise resource planning with invoicing, procurement, and approvals.",
    tags: ["Finance", "Operations", "ERP"],
    statusBadge: { label: "Available", tone: "success" },
  },
};

export const Clickable: Story = {
  args: {
    variant: "media",
    title: "Analytics Suite",
    description:
      "Pre-built analytics dashboards and reporting for operational intelligence.",
    tags: ["Analytics", "Reporting"],
    statusBadge: { label: "Beta", tone: "warning" },
    onClick: () => alert("Clicked Analytics Suite"),
  },
};

export const NoMedia: Story = {
  args: {
    variant: "media",
    title: "WFMS Module",
    description: "Digital workflow management with scheduler and task routing.",
    tags: ["Workflow", "Automation"],
  },
};

export const Grid: Story = {
  name: "Grid layout (media)",
  render: () => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: "1rem",
        maxWidth: 900,
      }}
    >
      {[
        { name: "Analytics", tone: "success" as const },
        { name: "WFMS", tone: "warning" as const },
        { name: "Marketplace", tone: "info" as const },
        { name: "ERP", tone: "success" as const },
        { name: "CRM", tone: "gray" as const },
        { name: "HCM", tone: "navy" as const },
      ].map(({ name, tone }) => (
        <CatalogCard
          key={name}
          variant="media"
          title={`${name} Suite`}
          description={`Pre-built ${name} solution for DBP.`}
          tags={[name]}
          statusBadge={{ label: "Available", tone }}
          onClick={() => alert(`Clicked ${name}`)}
        />
      ))}
    </div>
  ),
};

// ── CATALOG VARIANT (new) ────────────────────────────────────────────────────

export const CatalogVariantDefault: Story = {
  name: "Catalog — default",
  args: {
    variant: "catalog",
    typeLabel: "G · KNOWLEDGE",
    statusLabel: "EFFECTIVE",
    statusTone: "success",
    metaLine: "5 MIN · EFFECTIVE",
    title: "Governance Playbook for Procurement Approvals",
    description:
      "Defines the governed approval chain for all procurement requests above $10k, including escalation paths and SLA commitments.",
    footerId: "KNO-001",
    onClick: () => alert("Open KNO-001"),
  },
};

export const CatalogVariantReview: Story = {
  name: "Catalog — under review",
  args: {
    variant: "catalog",
    typeLabel: "S · SERVICE",
    statusLabel: "REVIEW",
    statusTone: "warning",
    metaLine: "3 MIN · UNDER REVIEW",
    title: "Invoice Processing Service — Standard Template",
    description:
      "End-to-end invoice validation and routing service with three-way matching and exception handling.",
    footerId: "SVC-042",
    onClick: () => alert("Open SVC-042"),
  },
};

export const CatalogVariantLongText: Story = {
  name: "Catalog — long text (line-clamp check)",
  args: {
    variant: "catalog",
    typeLabel: "T · TASK TEMPLATE",
    statusLabel: "EFFECTIVE",
    statusTone: "success",
    metaLine: "12 MIN · EFFECTIVE",
    title:
      "Comprehensive Employee Onboarding Workflow including IT Provisioning, Compliance Training, and Role Orientation",
    description:
      "This template covers the full onboarding lifecycle from offer acceptance through 90-day check-in. It includes IT equipment provisioning, mandatory compliance modules, department-specific orientation sessions, buddy programme assignments, and manager sign-off gates at 30, 60, and 90 days. Suitable for permanent hires in all regulated business units.",
    footerId: "TPL-019",
    onClick: () => alert("Open TPL-019"),
  },
};

export const CatalogVariantNoFooter: Story = {
  name: "Catalog — no footer ID",
  args: {
    variant: "catalog",
    typeLabel: "GL · KNOWLEDGE",
    statusLabel: "DRAFT",
    statusTone: "gray",
    metaLine: "2 MIN · DRAFT",
    title: "Risk Assessment Framework v3",
    description:
      "Preliminary draft of the updated risk assessment criteria for 2025. Not yet in effect.",
  },
};

export const CatalogVariantGrid: Story = {
  name: "Catalog — grid layout",
  render: () => (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: "1rem",
        maxWidth: 960,
      }}
    >
      {[
        {
          id: "KNO-001",
          typeLabel: "G · KNOWLEDGE",
          statusLabel: "EFFECTIVE",
          statusTone: "success" as const,
          metaLine: "5 MIN · EFFECTIVE",
          title: "Procurement Approval Playbook",
          description: "Governed approval chain for all procurement requests.",
        },
        {
          id: "SVC-042",
          typeLabel: "S · SERVICE",
          statusLabel: "REVIEW",
          statusTone: "warning" as const,
          metaLine: "3 MIN · UNDER REVIEW",
          title: "Invoice Processing Service",
          description: "End-to-end invoice validation and three-way matching.",
        },
        {
          id: "TPL-019",
          typeLabel: "T · TEMPLATE",
          statusLabel: "EFFECTIVE",
          statusTone: "success" as const,
          metaLine: "12 MIN · EFFECTIVE",
          title: "Employee Onboarding Template",
          description: "Full onboarding lifecycle from offer to 90-day check-in.",
        },
      ].map((card) => (
        <CatalogCard
          key={card.id}
          variant="catalog"
          typeLabel={card.typeLabel}
          statusLabel={card.statusLabel}
          statusTone={card.statusTone}
          metaLine={card.metaLine}
          title={card.title}
          description={card.description}
          footerId={card.id}
          onClick={() => alert(`Open ${card.id}`)}
        />
      ))}
    </div>
  ),
};
