import type { Meta, StoryObj } from "@storybook/react";
import { SimpleTooltip, TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "../components/tooltip.js";
import { Button } from "../components/button.js";

const meta: Meta = {
  title: "UI/Tooltip",
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj;

export const Default: Story = {
  render: () => (
    <TooltipProvider>
      <div style={{ display: "flex", gap: "16px", padding: "40px" }}>
        <SimpleTooltip label="Save changes" side="top">
          <Button variant="navy">Hover me (top)</Button>
        </SimpleTooltip>
        <SimpleTooltip label="Open settings" side="bottom">
          <Button variant="outline">Hover me (bottom)</Button>
        </SimpleTooltip>
        <SimpleTooltip label="Delete record" side="right">
          <Button variant="destructive">Hover me (right)</Button>
        </SimpleTooltip>
      </div>
    </TooltipProvider>
  ),
};

export const Primitive: Story = {
  name: "Primitive composition",
  render: () => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="ghost">Composed tooltip</Button>
        </TooltipTrigger>
        <TooltipContent side="top">Custom tooltip content</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  ),
};
