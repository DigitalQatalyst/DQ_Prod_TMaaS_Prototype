import type { Meta, StoryObj } from '@storybook/react'
import { LoadingSkeleton } from '../components/loading-skeleton.js'

const meta: Meta<typeof LoadingSkeleton> = {
  title: 'States/LoadingSkeleton',
  component: LoadingSkeleton,
  parameters: { layout: 'padded' },
  tags: ['autodocs'],
}
export default meta
type Story = StoryObj<typeof LoadingSkeleton>

export const List: Story = { args: { variant: 'list', rows: 5 } }
export const Card: Story = { args: { variant: 'card' } }
export const Form: Story = { args: { variant: 'form', rows: 4 } }
export const Chart: Story = { args: { variant: 'chart' } }
