import type { Meta, StoryObj } from "@storybook/react";
import { DetailPageGrid } from "../components/detail-page-grid.js";
import { RailSection, RailActionButton, SectionCard } from "../components/detail-rail.js";
import { Skeleton } from "../components/skeleton.js";

const meta: Meta<typeof DetailPageGrid> = {
  title: "UI/DetailPageGrid",
  component: DetailPageGrid,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
  },
};

export default meta;
type Story = StoryObj<typeof DetailPageGrid>;

const SampleContent = () => (
  <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
    <SectionCard title="Overview">
      <p style={{ fontSize: "14px", color: "var(--color-text-muted)", lineHeight: "1.6" }}>
        This is the main content area spanning 8 columns on large screens. It typically
        contains tabs with section cards below. On mobile, columns stack vertically.
      </p>
    </SectionCard>
    <SectionCard title="Details">
      <p style={{ fontSize: "14px", color: "var(--color-text-muted)", lineHeight: "1.6" }}>
        Additional content section with more detailed information about the item.
      </p>
    </SectionCard>
  </div>
);

const SampleRail = () => (
  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
    <RailSection title="Quick Info">
      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        {[["Owner", "Alex Johnson"], ["Category", "Analytics"], ["Version", "2.4.1"]].map(
          ([label, value]) => (
            <div key={label} style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
              <span style={{ fontSize: "11px", color: "var(--color-text-muted)", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                {label}
              </span>
              <span style={{ fontSize: "13px", fontWeight: 500 }}>{value}</span>
            </div>
          )
        )}
      </div>
    </RailSection>
    <RailSection title="Actions">
      <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
        <RailActionButton icon="Play" tone="navy">Start workflow</RailActionButton>
        <RailActionButton icon="Link2" tone="outline">Copy link</RailActionButton>
      </div>
    </RailSection>
  </div>
);

export const Default: Story = {
  args: {
    content: <SampleContent />,
    rail: <SampleRail />,
  },
};

export const LoadingState: Story = {
  name: "Loading state",
  render: () => (
    <DetailPageGrid
      content={
        <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          <div style={{ border: "1px solid #e5e7eb", borderRadius: "8px", padding: "20px" }}>
            <Skeleton className="h-5 w-40 mb-4" />
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
          <div style={{ border: "1px solid #e5e7eb", borderRadius: "8px", padding: "20px" }}>
            <Skeleton className="h-5 w-32 mb-4" />
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
            </div>
          </div>
        </div>
      }
      rail={
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          <div style={{ border: "1px solid #e5e7eb", borderRadius: "8px", padding: "20px" }}>
            <Skeleton className="h-4 w-24 mb-4" />
            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              {[1, 2, 3].map((i) => (
                <div key={i} style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                  <Skeleton className="h-3 w-16" />
                  <Skeleton className="h-4 w-28" />
                </div>
              ))}
            </div>
          </div>
        </div>
      }
    />
  ),
};
