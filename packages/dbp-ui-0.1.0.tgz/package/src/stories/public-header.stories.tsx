import type { Meta, StoryObj } from "@storybook/react"
import { PublicHeader } from "../components/public-header.js"

const meta: Meta<typeof PublicHeader> = {
  title: "Landing/PublicHeader",
  component: PublicHeader,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
}
export default meta
type Story = StoryObj<typeof PublicHeader>

const sampleLinks = [
  { label: "Features", href: "#features" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Marketplace", href: "#marketplace" },
  { label: "Pricing", href: "#pricing" },
]

export const Default: Story = {
  args: {
    productCode: "DWS.01",
    productName: "Work.Space4.0",
    links: sampleLinks,
    signIn: { label: "Sign in", href: "/login" },
  },
}

export const CodeOnly: Story = {
  args: {
    productCode: "DIA.02",
    links: sampleLinks,
    signIn: { label: "Sign in", href: "/login" },
  },
}

export const NoSignIn: Story = {
  args: {
    productCode: "DWS.01",
    productName: "Work.Space4.0",
    links: sampleLinks,
  },
}

export const MinimalNoLinks: Story = {
  args: {
    productCode: "DWS.01",
    productName: "Work.Space4.0",
    signIn: { label: "Get started", href: "/login" },
  },
}
