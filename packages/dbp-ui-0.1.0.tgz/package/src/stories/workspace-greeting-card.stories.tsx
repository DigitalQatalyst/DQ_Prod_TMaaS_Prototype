import type { Meta, StoryObj } from '@storybook/react'
import { WorkspaceGreetingCard } from '../components/workspace-greeting-card.js'

const meta: Meta<typeof WorkspaceGreetingCard> = {
  title: 'Shell/WorkspaceGreetingCard',
  component: WorkspaceGreetingCard,
  parameters: { layout: 'padded' },
}
export default meta
type Story = StoryObj<typeof WorkspaceGreetingCard>

const sampleQuickLinks = [
  { label: 'Requests', href: '/requests' },
  { label: 'Analytics', href: '/analytics' },
  { label: 'Catalogue', href: '/catalogue' },
  { label: 'Settings', href: '/settings' },
]

const sampleUpdates = [
  { title: 'Platform v2.4 released — new dashboard widgets', date: '2026-06-15' },
  { title: 'Scheduled maintenance window this Friday', date: '2026-06-13' },
  { title: 'New RBAC roles available in Settings', date: '2026-06-10' },
]

export const Default: Story = {
  args: {
    firstName: 'Alex',
    onNavigate: () => {},
    quickLinks: sampleQuickLinks,
    updates: sampleUpdates,
  },
}

export const NoUpdates: Story = {
  args: {
    firstName: 'Alex',
    onNavigate: () => {},
    quickLinks: sampleQuickLinks,
    updates: [],
  },
}

export const NoQuickLinks: Story = {
  args: {
    firstName: 'Alex',
    onNavigate: () => {},
    quickLinks: [],
    updates: sampleUpdates,
  },
}

export const NoName: Story = {
  args: {
    onNavigate: () => {},
    quickLinks: sampleQuickLinks,
    updates: sampleUpdates,
  },
}
