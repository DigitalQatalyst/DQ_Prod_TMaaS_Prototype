import type { Meta, StoryObj } from "@storybook/react";
import { ShieldCheck, Workflow, Gauge } from "lucide-react";
import { LoginPage } from "../components/login-page.js";

const meta: Meta<typeof LoginPage> = {
  title: "Shell/LoginPage",
  component: LoginPage,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof LoginPage>;

/** Microsoft-style full-width pill SSO button (right panel form slot). */
function SsoButton() {
  return (
    <button
      type="button"
      className="flex h-12 w-full items-center justify-center gap-3 rounded-full border border-[var(--color-border-default)] bg-white px-6 text-sm font-semibold text-primary shadow-sm transition hover:border-[var(--color-border-strong)] hover:shadow-md focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-orange)]"
    >
      <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
        <rect x="1" y="1" width="7.5" height="7.5" fill="#F25022" />
        <rect x="9.5" y="1" width="7.5" height="7.5" fill="#7FBA00" />
        <rect x="1" y="9.5" width="7.5" height="7.5" fill="#00A4EF" />
        <rect x="9.5" y="9.5" width="7.5" height="7.5" fill="#FFB900" />
      </svg>
      Sign in with Microsoft
    </button>
  );
}

export const Default: Story = {
  args: {
    productCode: "DWS.01",
    productName: "Your governed workspace for daily execution.",
    tagline:
      "Sign in to access tasks, knowledge, services, and performance visibility.",
    logo: <span className="text-lg font-bold text-white">DWS.01 / Work.Space4.0</span>,
    title: "Sign in to your workspace",
    subtitle: "Use your DigitalQatalyst Microsoft account to enter DWS.01.",
    footerCaption: "Prototype · SSO simulation",
    features: [
      {
        icon: <ShieldCheck size={20} strokeWidth={1.5} />,
        title: "Governed access",
        description: "Role-based entitlements enforced on every action.",
      },
      {
        icon: <Workflow size={20} strokeWidth={1.5} />,
        title: "Connected workflows",
        description: "Tasks, requests, and approvals in one place.",
      },
      {
        icon: <Gauge size={20} strokeWidth={1.5} />,
        title: "Performance visibility",
        description: "Live snapshots of your priorities and SLAs.",
      },
    ],
    children: <SsoButton />,
  },
};

/** Minimal — no feature cards, default overlines, plain form slot. */
export const MinimalBranding: Story = {
  args: {
    productCode: "DIA.02",
    productName: "AnalyticsOps",
    title: "Sign in",
    children: <SsoButton />,
  },
};
