import type { Meta, StoryObj } from "@storybook/react";
import { StatTile } from "../components/stat-tile.js";
import type { StatTileTone } from "../components/stat-tile.js";

const meta: Meta<typeof StatTile> = {
  title: "Data/StatTile",
  component: StatTile,
  tags: ["autodocs"],
  argTypes: {
    tone: {
      control: "select",
      options: ["primary", "success", "warning", "danger", "info"] satisfies StatTileTone[],
    },
  },
};
export default meta;
type Story = StoryObj<typeof StatTile>;

/** Single tile with a positive delta badge */
export const Default: Story = {
  args: {
    label: "Active Orders",
    value: "142",
    tone: "success",
    trend: { value: 12, label: "vs last month" },
  },
};

/** Negative delta renders in danger color with a down-arrow */
export const Negative: Story = {
  args: {
    label: "Churn Rate",
    value: "3.2%",
    tone: "danger",
    trend: { value: -5, label: "vs last month" },
  },
};

/** Tile with no delta badge — just label and value */
export const NoTrend: Story = {
  name: "NoTrend",
  args: {
    label: "Total Revenue",
    value: "£48,230",
    tone: "primary",
  },
};

/** Progress bar at 78 % — green fill, "of target" label */
export const WithAttainment: Story = {
  args: {
    label: "Deals Closed",
    value: "78",
    tone: "success",
    trend: { value: 6, label: "vs last month" },
    attainment: 78,
    attainmentLabel: "of target",
    attainmentColorMode: "higher-is-better",
  },
};

/** Lower-is-better: negative delta renders green, 55 % attainment = amber */
export const LowerIsBetter: Story = {
  args: {
    label: "Avg Resolution Time",
    value: "4.2 h",
    tone: "warning",
    trend: { value: -8, label: "vs last month" },
    attainment: 55,
    attainmentLabel: "of target",
    attainmentColorMode: "lower-is-better",
  },
};

/** 42 % attainment — amber bar */
export const AttainmentWarning: Story = {
  args: {
    label: "NPS Score",
    value: "42",
    tone: "warning",
    trend: { value: -3, label: "vs last month" },
    attainment: 42,
    attainmentLabel: "of target",
  },
};

/** 28 % attainment — red bar */
export const AttainmentCritical: Story = {
  args: {
    label: "Quota Attainment",
    value: "28",
    tone: "danger",
    trend: { value: -18, label: "vs last month" },
    attainment: 28,
    attainmentLabel: "of target",
  },
};

/** Row of 4 tiles — KPI strip usage pattern (mirrors DWS01 ApprovalKpiStrip) */
export const Strip: Story = {
  name: "Strip",
  render: () => (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <StatTile
        label="Pending Review"
        value="14"
        tone="warning"
        trend={{ value: 3, label: "vs yesterday" }}
      />
      <StatTile
        label="Returned"
        value="5"
        tone="danger"
        trend={{ value: -2, label: "vs yesterday" }}
      />
      <StatTile
        label="Approved Today"
        value="23"
        tone="success"
        trend={{ value: 8, label: "vs yesterday" }}
      />
      <StatTile
        label="SLA At Risk"
        value="4"
        tone="info"
        trend={{ value: 1, label: "vs yesterday" }}
      />
    </div>
  ),
};
