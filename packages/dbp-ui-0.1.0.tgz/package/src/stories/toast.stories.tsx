import type { Meta, StoryObj } from "@storybook/react";
import { Button } from "../components/button.js";
import { Toaster, toast } from "../components/toast.js";

const meta: Meta = {
  title: "UI/Toast",
  tags: ["autodocs"],
  decorators: [
    (Story) => (
      <>
        <Story />
        <Toaster />
      </>
    ),
  ],
};
export default meta;
type Story = StoryObj;

export const AllTones: Story = {
  render: () => (
    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
      <Button variant="ghost" onClick={() => toast({ title: "Default", description: "Neutral message" })}>
        Default
      </Button>
      <Button variant="navy" onClick={() => toast({ tone: "success", title: "Saved!", description: "Your changes have been saved." })}>
        Success
      </Button>
      <Button variant="orange" onClick={() => toast({ tone: "warning", title: "Warning", description: "Please review before continuing." })}>
        Warning
      </Button>
      <Button variant="destructive" onClick={() => toast({ tone: "danger", title: "Error", description: "Something went wrong." })}>
        Danger
      </Button>
    </div>
  ),
};

export const WithAction: Story = {
  render: () => (
    <Button
      variant="navy"
      onClick={() =>
        toast({
          tone: "info",
          title: "Update available",
          description: "A new version has been deployed.",
          action: { label: "Reload", onClick: () => {} },
        })
      }
    >
      Toast with action
    </Button>
  ),
};
