import type { Meta, StoryObj } from "@storybook/react";
import { AppTopBar } from "../components/app-top-bar.js";

const meta: Meta<typeof AppTopBar> = {
  title: "Shell/AppTopBar",
  component: AppTopBar,
  parameters: { layout: "fullscreen" },
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof AppTopBar>;

/** Full DQ lockup: "DWS.01 / Work.Space4.0", search pill, bell + settings, avatar block. */
export const Default: Story = {
  args: {
    config: {
      appName: "DWS.01 / Work.Space4.0",
      logoAlt: "DWS.01",
      showSearch: true,
      showNotifications: true,
      showUser: true,
      actions: [],
    },
    userName: "Ian Brooks",
    userRole: "Operations Lead",
  },
};

/** Logo lockup driven explicitly via productCode / productName props. */
export const ExplicitLockup: Story = {
  args: {
    config: {
      appName: "ignored-when-props-set",
      logoAlt: "DIA.02",
      showSearch: true,
      showNotifications: true,
      showUser: true,
      actions: [],
    },
    productCode: "DIA.02",
    productName: "AnalyticsOps",
    userName: "Priya Nair",
    userRole: "Data Analyst",
  },
};

/** With a role/context selector slot rendered before the divider. */
export const WithRoleSelector: Story = {
  args: {
    config: {
      appName: "DWS.05 / Workforce",
      logoAlt: "DWS.05",
      showSearch: true,
      showNotifications: true,
      showUser: true,
      actions: [],
    },
    roleSlot: (
      <button
        type="button"
        className="flex h-10 items-center gap-2 rounded-button border-[1.5px] border-[var(--color-border-default)] bg-white px-3 text-xs font-bold text-primary hover:bg-[var(--color-navy-50)]"
      >
        <span className="hidden font-mono text-[10px] font-bold uppercase tracking-wider text-[var(--color-text-muted)] xl:block">
          Role
        </span>
        Approver
      </button>
    ),
    userName: "Sam Okoro",
    userRole: "Finance Approver",
  },
};

/** Dark variant — for use over a navy header / login chrome. */
export const DarkVariant: Story = {
  parameters: {
    backgrounds: { default: "navy", values: [{ name: "navy", value: "#030F35" }] },
  },
  args: {
    config: {
      appName: "DWS.01 / Work.Space4.0",
      logoAlt: "DWS.01",
      showSearch: false,
      showNotifications: false,
      showUser: false,
      actions: [],
    },
    variant: "dark",
  },
};

/** Minimal: just the lockup, no search / notifications / user. */
export const MinimalBranding: Story = {
  args: {
    config: {
      appName: "Analytics Suite",
      logoAlt: "Analytics",
      showSearch: false,
      showNotifications: false,
      showUser: false,
      actions: [],
    },
  },
};
