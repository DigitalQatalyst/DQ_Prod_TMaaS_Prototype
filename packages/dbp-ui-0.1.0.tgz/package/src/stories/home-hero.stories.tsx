import type { Meta, StoryObj } from "@storybook/react";
import { HomeHero } from "../components/home-hero.js";
import { Button } from "../components/button.js";
import { AISearchBar } from "../components/ai-search-bar.js";

const meta: Meta<typeof HomeHero> = {
  title: "UI/HomeHero",
  component: HomeHero,
  tags: ["autodocs"],
  parameters: {
    layout: "padded",
  },
  argTypes: {
    greeting: { control: "text" },
    subtext: { control: "text" },
  },
};

export default meta;
type Story = StoryObj<typeof HomeHero>;

export const Default: Story = {
  args: {
    greeting: "Good morning, Alex",
    subtext:
      "You have 3 pending approvals and 2 new knowledge items published this week.",
  },
};

export const WithSearchSlot: Story = {
  name: "With search slot",
  args: {
    greeting: "Good afternoon, Alex",
    subtext: "Explore the platform, find data products, or ask anything.",
    searchSlot: (
      <AISearchBar
        placeholder="Search data products, knowledge, or ask a question…"
        onSubmit={(v) => console.log("Search:", v)}
      />
    ),
  },
};

export const WithCTAButtons: Story = {
  name: "With CTA buttons",
  args: {
    greeting: "Welcome back, Alex",
    subtext: "Here are some quick actions to get you started.",
    quickActions: (
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
        <Button size="sm">Browse catalog</Button>
        <Button size="sm" variant="outline">View my projects</Button>
        <Button size="sm" variant="ghost">Request access</Button>
      </div>
    ),
  },
};

export const WithSearchAndActions: Story = {
  name: "With search + quick actions",
  args: {
    greeting: "Good evening, Alex",
    subtext: "Your data platform. Everything in one place.",
    searchSlot: (
      <AISearchBar placeholder="Search or ask anything…" onSubmit={() => {}} />
    ),
    quickActions: (
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
        <Button size="sm" variant="outline">Browse catalog</Button>
        <Button size="sm" variant="outline">My approvals (3)</Button>
        <Button size="sm" variant="outline">Recent activity</Button>
      </div>
    ),
  },
};

export const MinimalGreeting: Story = {
  name: "Greeting only",
  args: {
    greeting: "Hello, Alex",
  },
};
