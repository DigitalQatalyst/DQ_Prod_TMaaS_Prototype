import * as React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { PageHeader } from '../components/page-header.js'

const meta: Meta<typeof PageHeader> = {
  title: 'Shell/PageHeader',
  component: PageHeader,
  parameters: { layout: 'padded' },
}
export default meta
type Story = StoryObj<typeof PageHeader>

const crumbs = [{ label: 'DXP.01A', href: '/' }, { label: 'Invoices' }]

export const Default: Story = { args: { title: 'My Dashboard', breadcrumb: crumbs } }
export const WithSubtitle: Story = {
  args: { title: 'My Dashboard', subtitle: 'Module DXP.01A.S01 — Stage 2 · SH.02', breadcrumb: crumbs },
}
export const WithAction: Story = {
  args: { title: 'Tasks', breadcrumb: crumbs, action: { label: 'Create Task', onClick: () => {} } },
}

// titleSpan is layout-driven: 2 = title + 1-col action aside (working/catalogue);
// 1 = compact title + 2-col aside (analytics date-range); 3 = full-width (settings).
export const TitleSpan2WithAction: Story = {
  args: { title: 'Service Requests', titleSpan: 2, breadcrumb: crumbs, action: { label: 'New', onClick: () => {} } },
}
export const TitleSpan1WithAside: Story = {
  args: {
    title: 'Operational Dashboards',
    titleSpan: 1,
    breadcrumb: crumbs,
    aside: <div className="rounded border border-[var(--color-border)] px-3 py-1.5 text-sm">Last 30 days ▾</div>,
  },
}
export const TitleSpan3FullWidth: Story = {
  args: { title: 'Authentication Settings', titleSpan: 3, breadcrumb: crumbs },
}
