import React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SlotFrame } from "../components/slot-frame.js";

const meta: Meta<typeof SlotFrame> = {
  title: "UI/SlotFrame",
  component: SlotFrame,
  tags: ["autodocs"],
  argTypes: {
    slotName: { control: "text" },
    isEmpty: { control: "boolean" },
  },
};

export default meta;
type Story = StoryObj<typeof SlotFrame>;

export const EmptySlot: Story = {
  name: "Empty slot (default)",
  args: {
    slotName: "main",
    style: { height: "120px", width: "100%" },
  },
};

export const WithContent: Story = {
  name: "Slot with content (passthrough)",
  args: {
    slotName: "sidebar",
    isEmpty: false,
    style: { height: "120px", width: "240px" },
  },
  render: (args) => (
    <SlotFrame {...args}>
      <div
        style={{
          background: "var(--color-surface)",
          border: "1px solid var(--color-border)",
          padding: "16px",
          borderRadius: "var(--radius)",
          color: "var(--color-text)",
          height: "100%",
        }}
      >
        Real content mounted here
      </div>
    </SlotFrame>
  ),
};

export const ShellSlotsLayout: Story = {
  name: "Shell slots — SH.02 Transaction Workspace layout",
  render: () => (
    <div style={{ display: "grid", gridTemplateAreas: '"header header" "sidebar main"', gridTemplateColumns: "264px 1fr", gridTemplateRows: "64px 1fr", gap: "4px", height: "400px", background: "#f5f5f5", padding: "4px" }}>
      <div style={{ gridArea: "header" }}>
        <SlotFrame slotName="header" style={{ height: "100%", minHeight: "unset" }} />
      </div>
      <div style={{ gridArea: "sidebar" }}>
        <SlotFrame slotName="sidebar" style={{ height: "100%", minHeight: "unset" }} />
      </div>
      <div style={{ gridArea: "main" }}>
        <SlotFrame slotName="main" style={{ height: "100%", minHeight: "unset" }} />
      </div>
    </div>
  ),
};

export const BothThemes: Story = {
  name: "Theme-swap proof — toggle 'DBP default' / 'Alt client' in the toolbar",
  render: () => (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      <p style={{ margin: 0, fontSize: "12px", color: "var(--color-text)", fontFamily: "var(--font-body)" }}>
        Toggle the theme in the toolbar above. The border and text colours below
        come from <code>--color-border</code> and <code>--color-text</code> — no
        structural change, only the token values swap.
      </p>
      <SlotFrame slotName="hero" style={{ height: "80px" }} />
      <SlotFrame slotName="catalog" style={{ height: "80px" }} />
    </div>
  ),
};
