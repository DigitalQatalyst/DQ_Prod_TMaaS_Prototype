import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AppSidebar } from "../src/components/app-sidebar.js";
import type { SidebarConfig } from "@dbp/contracts";

afterEach(() => {
  cleanup();
});

const config: SidebarConfig = {
  collapsible: false,
  sections: [
    {
      id: "main",
      label: "Main",
      items: [
        { id: "home", label: "Home", href: "/home" },
        { id: "analytics", label: "Analytics", href: "/analytics" },
        {
          id: "reports",
          label: "Reports",
          href: "/reports",
          children: [
            { id: "monthly", label: "Monthly", href: "/reports/monthly" },
          ],
        },
      ],
    },
    {
      id: "settings",
      items: [
        { id: "config", label: "Config", href: "/config", badge: "3" },
      ],
    },
  ],
};

describe("AppSidebar", () => {
  it("renders section overline labels", () => {
    render(<AppSidebar config={config} activePath="/home" />);
    expect(screen.getByText("Main")).toBeDefined();
  });

  it("renders nav items", () => {
    render(<AppSidebar config={config} activePath="/home" />);
    expect(screen.getByRole("button", { name: "Home" })).toBeDefined();
    expect(screen.getByRole("button", { name: "Analytics" })).toBeDefined();
  });

  it("active item has aria-current=page", () => {
    render(<AppSidebar config={config} activePath="/analytics" />);
    const btn = screen.getByRole("button", { name: "Analytics" });
    expect(btn.getAttribute("aria-current")).toBe("page");
  });

  it("inactive item does NOT have aria-current", () => {
    render(<AppSidebar config={config} activePath="/analytics" />);
    const btn = screen.getByRole("button", { name: "Home" });
    expect(btn.getAttribute("aria-current")).toBeNull();
  });

  it("calls onNavigate with href when item is clicked", async () => {
    const user = userEvent.setup();
    const onNavigate = vi.fn();
    render(<AppSidebar config={config} activePath="/home" onNavigate={onNavigate} />);
    await user.click(screen.getByRole("button", { name: "Analytics" }));
    expect(onNavigate).toHaveBeenCalledWith("/analytics");
  });

  it("renders nested child items when the parent group is expanded", async () => {
    const user = userEvent.setup();
    render(<AppSidebar config={config} activePath="/home" />);
    // Groups with children collapse by default — Monthly is hidden until expand.
    expect(screen.queryByRole("button", { name: "Monthly" })).toBeNull();
    await user.click(screen.getByRole("button", { name: /Reports/ }));
    expect(screen.getByRole("button", { name: "Monthly" })).toBeDefined();
  });

  it("auto-expands the group when a descendant is the active path", () => {
    render(<AppSidebar config={config} activePath="/reports/monthly" />);
    // Active descendant route auto-opens its parent group.
    expect(screen.getByRole("button", { name: "Monthly" })).toBeDefined();
  });

  it("group with children exposes aria-expanded", () => {
    render(<AppSidebar config={config} activePath="/home" />);
    const reports = screen.getByRole("button", { name: /Reports/ });
    expect(reports.getAttribute("aria-expanded")).toBe("false");
  });

  it("renders badge text when present", () => {
    render(<AppSidebar config={config} activePath="/home" />);
    expect(screen.getByText("3")).toBeDefined();
  });

  it("section without label renders no overline", () => {
    render(<AppSidebar config={config} activePath="/home" />);
    // settings section has no label — Config button (with badge) should exist
    expect(screen.getByRole("button", { name: /Config/ })).toBeDefined();
  });

  it("renders a lucide icon when item.icon is a valid icon name", () => {
    const iconConfig: SidebarConfig = {
      collapsible: false,
      sections: [
        {
          id: "main",
          items: [{ id: "home", label: "Home", href: "/home", icon: "Home" }],
        },
      ],
    };
    render(<AppSidebar config={iconConfig} activePath="/home" />);
    const btn = screen.getByRole("button", { name: "Home" });
    expect(btn.querySelector("svg")).not.toBeNull();
  });
});

describe('AppSidebar — L2 item collapse', () => {
  const multiItemConfig: SidebarConfig = {
    collapsible: true,
    sections: [{
      id: 'orientation',
      label: 'ORIENTATION',
      items: [
        { id: 'getting-started', label: 'Get Started', href: '/home', icon: 'BookOpen', children: [{ id: 'home', label: 'Home', href: '/home' }] },
        { id: 'quick-links', label: 'Quick Links', href: '/dashboard', icon: 'Link2', children: [{ id: 'dash', label: 'Dashboard', href: '/dashboard' }] },
      ],
    }],
  }

  it('first L2 item is expanded by default, rest are collapsed', () => {
    render(<AppSidebar config={multiItemConfig} activePath="/home" />)
    expect(screen.getByText('Home')).toBeTruthy()
    expect(screen.queryByText('Dashboard')).toBeNull()
  })

  it('clicking a collapsed L2 item header expands it', async () => {
    const user = userEvent.setup()
    render(<AppSidebar config={multiItemConfig} activePath="/home" />)
    await user.click(screen.getByRole('button', { name: /Quick Links/i }))
    expect(screen.getByText('Dashboard')).toBeTruthy()
  })

  it('clicking an expanded L2 item header collapses it', async () => {
    const user = userEvent.setup()
    render(<AppSidebar config={multiItemConfig} activePath="/home" />)
    await user.click(screen.getByRole('button', { name: /Get Started/i }))
    expect(screen.queryByText('Home')).toBeNull()
  })
})

describe('AppSidebar — icon-only mode', () => {
  const iconOnlyConfig: SidebarConfig = {
    collapsible: false,
    sections: [{
      id: 'orientation',
      label: 'ORIENTATION',
      items: [
        { id: 'getting-started', label: 'Get Started', href: '/home', icon: 'BookOpen', children: [{ id: 'home', label: 'Home', href: '/home' }] },
      ],
    }],
  }

  it('does not render child labels in icon-only mode', () => {
    render(<AppSidebar config={iconOnlyConfig} activePath="/home" iconOnly />)
    expect(screen.queryByText('Home')).toBeNull()
  })

  it('renders L2 items as icon-only links in icon-only mode', () => {
    render(<AppSidebar config={iconOnlyConfig} activePath="/home" iconOnly />)
    // L2 items should still be present (as links), just without labels
    expect(screen.queryByText('Get Started')).toBeNull()
  })
})
