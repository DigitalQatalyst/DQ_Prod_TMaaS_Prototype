import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { SegmentedControl } from "../src/components/segmented-control.js";

afterEach(() => { cleanup(); });

const options = [
  { value: "new", label: "New Joiner" },
  { value: "returning", label: "Returning" },
];

describe("SegmentedControl", () => {
  it("renders both options", () => {
    render(<SegmentedControl options={options} value="new" onChange={() => {}} />);
    expect(screen.getByText("New Joiner")).toBeDefined();
    expect(screen.getByText("Returning")).toBeDefined();
  });

  it("marks active button as aria-checked=true", () => {
    render(<SegmentedControl options={options} value="returning" onChange={() => {}} />);
    const btns = screen.getAllByRole("radio");
    const second = btns[1];
    expect(second).toBeDefined();
    expect(second!.getAttribute("aria-checked")).toBe("true");
  });

  it("calls onChange with the selected value", async () => {
    const user = userEvent.setup();
    let val = "new";
    render(
      <SegmentedControl
        options={options}
        value={val}
        onChange={(v) => { val = v; }}
      />
    );
    await user.click(screen.getByText("Returning"));
    expect(val).toBe("returning");
  });
});
