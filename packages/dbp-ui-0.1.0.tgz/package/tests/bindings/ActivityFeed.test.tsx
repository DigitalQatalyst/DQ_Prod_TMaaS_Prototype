import { describe, it, expect, afterEach } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  configureAuditClient,
  resetAuditClient,
} from "@dbp/ps-audit/client";
import { ActivityFeed } from "../../src/bindings/ActivityFeed.js";

const BASE = "http://test.local/api/platform/audit";

function makeEvent(n: number) {
  return {
    id: `aaaaaaaa-0001-0001-0001-00000000000${n}`,
    ts: new Date(Date.now() - n * 60_000).toISOString(),
    actor: { userId: `u${n}`, email: `user${n}@test.com`, displayName: `User ${n}` },
    action: "entity.update",
    target: { entityType: "invoice", entityId: `inv-${n}` },
    delta: null,
    tenantId: "demo",
  };
}

function makeFetch(
  events: ReturnType<typeof makeEvent>[],
  nextCursor: string | null = null,
) {
  return (): Promise<Response> =>
    Promise.resolve(
      new Response(JSON.stringify({ events, nextCursor }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function wrapper() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client: qc }, children);
}

afterEach(() => {
  cleanup();
  resetAuditClient();
});

describe("ActivityFeed", () => {
  it("renders event rows with actor, action, and relative time", async () => {
    configureAuditClient({ baseUrl: BASE, fetch: makeFetch([makeEvent(1), makeEvent(2)]), tenantId: "demo" });

    render(<ActivityFeed entityId="inv-1" title="Activity" />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByText("User 1")).toBeDefined();
    });
    // Both events use "entity.update" — use getAllByText
    expect(screen.getAllByText(/entity\.update/).length).toBeGreaterThan(0);
    expect(screen.getByRole("region", { name: "Activity" })).toBeDefined();
  });

  it("renders loading skeletons while fetching", () => {
    configureAuditClient({
      baseUrl: BASE,
      fetch: () => new Promise(() => {/* never resolves */}),
      tenantId: "demo",
    });

    render(<ActivityFeed entityId="inv-1" />, { wrapper: wrapper() });
    // skeletons are rendered as divs with animate-pulse class
    const list = screen.getByRole("list", { name: "Activity events" });
    expect(list.children.length).toBeGreaterThan(0);
  });

  it("shows empty state when no events", async () => {
    configureAuditClient({ baseUrl: BASE, fetch: makeFetch([]), tenantId: "demo" });

    render(<ActivityFeed entityId="inv-1" />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByText(/No activity yet/)).toBeDefined();
    });
  });

  it("shows error state when fetch fails", async () => {
    configureAuditClient({
      baseUrl: BASE,
      fetch: () =>
        Promise.resolve(
          new Response(JSON.stringify({ error: "server error" }), {
            status: 500,
            headers: { "content-type": "application/json" },
          }),
        ),
      tenantId: "demo",
    });

    render(<ActivityFeed entityId="inv-1" />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByRole("alert")).toBeDefined();
    });
  });

  it("shows Load more button when hasMore is true and fires loadMore", async () => {
    const user = userEvent.setup();
    let callCount = 0;
    const fetchFn = (): Promise<Response> => {
      callCount++;
      // First call returns nextCursor; second call returns no cursor
      const cursor = callCount === 1 ? "cursor-2" : null;
      return Promise.resolve(
        new Response(JSON.stringify({ events: [makeEvent(callCount)], nextCursor: cursor }), {
          status: 200,
          headers: { "content-type": "application/json" },
        }),
      );
    };
    configureAuditClient({ baseUrl: BASE, fetch: fetchFn, tenantId: "demo" });

    render(<ActivityFeed entityId="inv-1" />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByRole("button", { name: /Load more/i })).toBeDefined();
    });

    await user.click(screen.getByRole("button", { name: /Load more/i }));
    expect(callCount).toBeGreaterThanOrEqual(2);
  });
});
