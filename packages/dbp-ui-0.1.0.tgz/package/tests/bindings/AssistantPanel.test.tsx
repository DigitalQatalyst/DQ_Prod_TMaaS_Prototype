import { describe, it, expect, afterEach } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  configureAiClient,
  resetAiClient,
} from "@dbp/ps-ai/client";
import { AssistantPanel } from "../../src/bindings/AssistantPanel.js";

const BASE = "http://test.local/api/platform/ai";

/**
 * Fake SSE fetch: returns a ReadableStream that emits one chunk then a done event.
 */
function makeSseFetch(reply: string) {
  return (): Promise<Response> => {
    const enc = new TextEncoder();
    const convId = "conv-test-001";
    const chunkEvent = `data: ${JSON.stringify({ type: "chunk", delta: reply, conversationId: convId })}\n\n`;
    const doneEvent = `data: ${JSON.stringify({ type: "done", conversationId: convId, message: reply, usage: { inputTokens: 5, outputTokens: 10 } })}\n\n`;

    let i = 0;
    const stream = new ReadableStream<Uint8Array>({
      pull(controller) {
        if (i === 0) { controller.enqueue(enc.encode(chunkEvent)); i++; }
        else if (i === 1) { controller.enqueue(enc.encode(doneEvent)); i++; }
        else { controller.close(); }
      },
    });
    return Promise.resolve(
      new Response(stream, {
        status: 200,
        headers: { "content-type": "text/event-stream" },
      }),
    );
  };
}

function wrapper() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client: qc }, children);
}

afterEach(() => {
  cleanup();
  resetAiClient();
});

describe("AssistantPanel", () => {
  it("renders message input and send button", () => {
    configureAiClient({ baseUrl: BASE, fetch: makeSseFetch("Hello!") });
    render(<AssistantPanel />, { wrapper: wrapper() });
    expect(screen.getByRole("textbox", { name: /Message input/i })).toBeDefined();
    expect(screen.getByRole("button", { name: /Send message/i })).toBeDefined();
  });

  it("shows empty-state prompt when no messages", () => {
    configureAiClient({ baseUrl: BASE, fetch: makeSseFetch("Hello!") });
    render(<AssistantPanel />, { wrapper: wrapper() });
    expect(screen.getByText(/Ask me anything/i)).toBeDefined();
  });

  it("sends user message and displays assistant reply", async () => {
    const user = userEvent.setup();
    configureAiClient({ baseUrl: BASE, fetch: makeSseFetch("Great question!") });
    render(<AssistantPanel />, { wrapper: wrapper() });

    const input = screen.getByRole("textbox", { name: /Message input/i });
    await user.type(input, "Hello");
    await user.click(screen.getByRole("button", { name: /Send message/i }));

    await waitFor(() => {
      expect(screen.getByText("Hello")).toBeDefined();
    });
    await waitFor(
      () => {
        expect(screen.getByText("Great question!")).toBeDefined();
      },
      { timeout: 5_000 },
    );
  });

  it("sends on Enter key and disables input while streaming", async () => {
    const user = userEvent.setup();
    let resolveStream!: () => void;
    const neverDonePromise = new Promise<void>((r) => { resolveStream = r; });
    const hangFetch = (): Promise<Response> => {
      const enc = new TextEncoder();
      const stream = new ReadableStream<Uint8Array>({
        start(controller) {
          // emit one chunk to trigger streaming=true, then hang
          const chunk = `data: ${JSON.stringify({ type: "chunk", delta: "Hi", conversationId: "c1" })}\n\n`;
          controller.enqueue(enc.encode(chunk));
          neverDonePromise.then(() => controller.close());
        },
      });
      return Promise.resolve(new Response(stream, { status: 200, headers: { "content-type": "text/event-stream" } }));
    };
    configureAiClient({ baseUrl: BASE, fetch: hangFetch });

    render(<AssistantPanel />, { wrapper: wrapper() });
    const input = screen.getByRole("textbox", { name: /Message input/i });
    await user.type(input, "Hello{Enter}");

    await waitFor(() => {
      expect(screen.getByText("Hello")).toBeDefined();
    });

    // Resolve the stream to avoid test leaking
    resolveStream();
  });

  it("assembles streamed chunks into a single assistant message", async () => {
    const user = userEvent.setup();
    const enc = new TextEncoder();
    const convId = "conv-chunks";
    const chunks = ["Word1", " Word2", " Word3"];
    const chunkFetch = (): Promise<Response> => {
      let i = 0;
      const stream = new ReadableStream<Uint8Array>({
        pull(controller) {
          if (i < chunks.length) {
            const ev = `data: ${JSON.stringify({ type: "chunk", delta: chunks[i], conversationId: convId })}\n\n`;
            controller.enqueue(enc.encode(ev));
            i++;
          } else if (i === chunks.length) {
            const done = `data: ${JSON.stringify({ type: "done", conversationId: convId, message: chunks.join(""), usage: { inputTokens: 3, outputTokens: 3 } })}\n\n`;
            controller.enqueue(enc.encode(done));
            i++;
          } else {
            controller.close();
          }
        },
      });
      return Promise.resolve(new Response(stream, { status: 200, headers: { "content-type": "text/event-stream" } }));
    };
    configureAiClient({ baseUrl: BASE, fetch: chunkFetch });

    render(<AssistantPanel />, { wrapper: wrapper() });
    await user.type(screen.getByRole("textbox", { name: /Message input/i }), "Hi");
    await user.click(screen.getByRole("button", { name: /Send message/i }));

    await waitFor(() => {
      expect(screen.getByText("Word1 Word2 Word3")).toBeDefined();
    }, { timeout: 5_000 });
  });
});
