import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, waitFor, cleanup, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  configureSearchClient,
  resetSearchClient,
} from "@dbp/ps-search/client";
import type { SearchHit } from "@dbp/ps-search/client";
import { SearchBar } from "../../src/bindings/SearchBar.js";

const BASE = "http://test.local/api/platform/search";

const HIT: SearchHit = { id: "doc-1", entityType: "invoice", title: "Invoice #INV-101", score: 0.98 };
const HIT2: SearchHit = { id: "doc-2", entityType: "order", title: "Order #ORD-55", score: 0.87 };

function makeFetch(results: SearchHit[]) {
  return (): Promise<Response> =>
    Promise.resolve(
      new Response(JSON.stringify({ results, facets: [], total: results.length }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
}

function wrapper() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false, staleTime: 0 } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client: qc }, children);
}

afterEach(() => {
  cleanup();
  resetSearchClient();
  vi.restoreAllMocks();
});

describe("SearchBar", () => {
  it("renders the search input", () => {
    configureSearchClient({ baseUrl: BASE, fetch: makeFetch([]), tenantId: "demo" });
    render(<SearchBar />, { wrapper: wrapper() });
    expect(screen.getByRole("searchbox")).toBeDefined();
  });

  it("shows results dropdown after typing (waits for debounce)", async () => {
    const user = userEvent.setup();
    configureSearchClient({ baseUrl: BASE, fetch: makeFetch([HIT, HIT2]), tenantId: "demo" });

    render(<SearchBar />, { wrapper: wrapper() });
    const input = screen.getByRole("searchbox");

    await user.type(input, "invoice");
    // Wait for debounce (250ms) + query to resolve
    await act(async () => {
      await new Promise((r) => setTimeout(r, 350));
    });

    await waitFor(() => {
      expect(screen.getByRole("listbox")).toBeDefined();
    }, { timeout: 5000 });

    expect(screen.getByText(HIT.title)).toBeDefined();
  });

  it("navigates results with arrow keys and selects with Enter", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    configureSearchClient({ baseUrl: BASE, fetch: makeFetch([HIT, HIT2]), tenantId: "demo" });

    render(<SearchBar onSelect={onSelect} />, { wrapper: wrapper() });
    const input = screen.getByRole("searchbox");
    await user.type(input, "inv");

    await act(async () => {
      await new Promise((r) => setTimeout(r, 350));
    });
    await waitFor(() => screen.getByRole("listbox"), { timeout: 5000 });

    await user.keyboard("{ArrowDown}");
    await user.keyboard("{Enter}");

    expect(onSelect).toHaveBeenCalledWith(HIT);
  });

  it("calls onSelect when a result is clicked", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    configureSearchClient({ baseUrl: BASE, fetch: makeFetch([HIT]), tenantId: "demo" });

    render(<SearchBar onSelect={onSelect} />, { wrapper: wrapper() });
    await user.type(screen.getByRole("searchbox"), "inv");

    await act(async () => {
      await new Promise((r) => setTimeout(r, 350));
    });
    await waitFor(() => screen.getByRole("listbox"), { timeout: 5000 });
    await user.click(screen.getByText(HIT.title));

    expect(onSelect).toHaveBeenCalledWith(HIT);
  });

  it("shows entityType badge in results", async () => {
    const user = userEvent.setup();
    configureSearchClient({ baseUrl: BASE, fetch: makeFetch([HIT]), tenantId: "demo" });

    render(<SearchBar />, { wrapper: wrapper() });
    await user.type(screen.getByRole("searchbox"), "inv");

    await act(async () => {
      await new Promise((r) => setTimeout(r, 350));
    });
    await waitFor(() => screen.getByRole("listbox"), { timeout: 5000 });
    expect(screen.getByText("invoice")).toBeDefined();
  });
});
