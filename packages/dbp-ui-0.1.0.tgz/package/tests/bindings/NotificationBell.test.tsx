import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, waitFor, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  configureNotifClient,
  resetNotifClient,
} from "@dbp/ps-notif/client";
import { NotificationBell } from "../../src/bindings/NotificationBell.js";

const BASE = "http://test.local/api/platform/notif";

const NOTIF = {
  id: "bbbbbbbb-0001-0001-0001-000000000001",
  to: "alice",
  type: "task.assigned",
  message: "You have a new invoice to review",
  channel: "in-app" as const,
  status: "unread" as const,
  ts: new Date(Date.now() - 120_000).toISOString(),
  tenantId: "demo",
};

function makeListFetch(items: typeof NOTIF[], unread: number) {
  return (url: string): Promise<Response> => {
    if (url.includes("/notifications/") && url.includes("/read")) {
      return Promise.resolve(new Response(null, { status: 204 }));
    }
    if (url.includes("/read-all")) {
      return Promise.resolve(new Response(null, { status: 204 }));
    }
    return Promise.resolve(
      new Response(JSON.stringify({ items, unread }), {
        status: 200,
        headers: { "content-type": "application/json" },
      }),
    );
  };
}

function wrapper() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client: qc }, children);
}

afterEach(() => {
  cleanup();
  resetNotifClient();
});

describe("NotificationBell", () => {
  it("renders a bell button", () => {
    configureNotifClient({ baseUrl: BASE, fetch: makeListFetch([], 0) });
    render(<NotificationBell />, { wrapper: wrapper() });
    expect(screen.getByRole("button", { name: /Notifications/i })).toBeDefined();
  });

  it("shows unread badge count when there are unread notifications", async () => {
    configureNotifClient({ baseUrl: BASE, fetch: makeListFetch([NOTIF], 1) });
    render(<NotificationBell />, { wrapper: wrapper() });

    await waitFor(() => {
      expect(screen.getByText("1")).toBeDefined();
    });
  });

  it("opens dropdown with notification message on click", async () => {
    const user = userEvent.setup();
    configureNotifClient({ baseUrl: BASE, fetch: makeListFetch([NOTIF], 1) });
    render(<NotificationBell />, { wrapper: wrapper() });

    await waitFor(() => screen.getByRole("button", { name: /Notifications/i }));
    await user.click(screen.getByRole("button", { name: /Notifications/i }));

    await waitFor(() => {
      expect(screen.getByText(NOTIF.message)).toBeDefined();
    });
  });

  it("calls markRead when a notification is clicked", async () => {
    const user = userEvent.setup();
    const fetchSpy = vi.fn(makeListFetch([NOTIF], 1));
    configureNotifClient({ baseUrl: BASE, fetch: fetchSpy });

    render(<NotificationBell />, { wrapper: wrapper() });
    await waitFor(() => screen.getByRole("button", { name: /Notifications/i }));
    await user.click(screen.getByRole("button", { name: /Notifications/i }));
    await waitFor(() => screen.getByText(NOTIF.message));

    const item = screen.getByText(NOTIF.message).closest("[role=menuitem]") as HTMLElement;
    await user.click(item);

    // fetchSpy should have been called for markRead
    await waitFor(() => {
      const calls = fetchSpy.mock.calls.map((c) => c[0] as string);
      expect(calls.some((url) => url.includes("/read"))).toBe(true);
    });
  });

  it("shows Mark all read button when there are unread items and calls markAllRead", async () => {
    const user = userEvent.setup();
    const fetchSpy = vi.fn(makeListFetch([NOTIF], 1));
    configureNotifClient({ baseUrl: BASE, fetch: fetchSpy });

    render(<NotificationBell />, { wrapper: wrapper() });
    await waitFor(() => screen.getByRole("button", { name: /Notifications/i }));
    await user.click(screen.getByRole("button", { name: /Notifications/i }));
    await waitFor(() => screen.getByRole("button", { name: /Mark all notifications as read/i }));

    await user.click(screen.getByRole("button", { name: /Mark all notifications as read/i }));

    await waitFor(() => {
      const calls = fetchSpy.mock.calls.map((c) => c[0] as string);
      expect(calls.some((url) => url.includes("/read-all"))).toBe(true);
    });
  });
});
