import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Pagination } from "../src/components/pagination.js";

afterEach(() => { cleanup(); });

describe("Pagination", () => {
  it("disables Previous on first page", () => {
    render(<Pagination page={1} pageSize={10} total={50} onPageChange={() => {}} />);
    const prev = screen.getByLabelText("Previous page") as HTMLButtonElement;
    expect(prev.disabled).toBe(true);
  });

  it("disables Next on last page", () => {
    render(<Pagination page={5} pageSize={10} total={50} onPageChange={() => {}} />);
    const next = screen.getByLabelText("Next page") as HTMLButtonElement;
    expect(next.disabled).toBe(true);
  });

  it("calls onPageChange when a page number is clicked", async () => {
    const user = userEvent.setup();
    let changed = -1;
    render(<Pagination page={1} pageSize={10} total={50} onPageChange={(p) => { changed = p; }} />);
    await user.click(screen.getByText("3"));
    expect(changed).toBe(3);
  });

  it("shows caption when showCaption=true", () => {
    render(<Pagination page={2} pageSize={10} total={50} onPageChange={() => {}} showCaption />);
    expect(screen.getByText(/PAGE 2 OF 5/i)).toBeDefined();
  });
});
