import * as React from 'react'
import { describe, it, expect, afterEach, vi } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { WorkspaceGreetingCard } from '../src/components/workspace-greeting-card.js'

afterEach(cleanup)

const quickLinks = [
  { label: 'Requests', href: '/requests' },
  { label: 'Analytics', href: '/analytics' },
]

const updates = [
  { title: 'Platform v2.4 released', date: '2026-06-15' },
  { title: 'Maintenance window Friday', date: '2026-06-13' },
]

describe('WorkspaceGreetingCard', () => {
  it('renders the greeting and default lead', () => {
    render(<WorkspaceGreetingCard onNavigate={() => {}} firstName="Alex" />)
    // greeting includes the first name
    expect(screen.getByText(/Alex/)).toBeTruthy()
    // default lead text
    expect(screen.getByText("Here's what's happening in your workspace today.")).toBeTruthy()
  })

  it('renders a custom lead when provided', () => {
    render(
      <WorkspaceGreetingCard
        onNavigate={() => {}}
        lead="Custom lead text"
      />
    )
    expect(screen.getByText('Custom lead text')).toBeTruthy()
  })

  it('renders each quickLink label', () => {
    render(<WorkspaceGreetingCard onNavigate={() => {}} quickLinks={quickLinks} />)
    expect(screen.getByText('Requests')).toBeTruthy()
    expect(screen.getByText('Analytics')).toBeTruthy()
  })

  it('calls onNavigate with the href when a quickLink is clicked', async () => {
    const onNavigate = vi.fn()
    render(<WorkspaceGreetingCard onNavigate={onNavigate} quickLinks={quickLinks} />)
    await userEvent.setup().click(screen.getByText('Requests'))
    expect(onNavigate).toHaveBeenCalledWith('/requests')
  })

  it('calls onNavigate with correct href for each quickLink', async () => {
    const onNavigate = vi.fn()
    render(<WorkspaceGreetingCard onNavigate={onNavigate} quickLinks={quickLinks} />)
    const user = userEvent.setup()
    await user.click(screen.getByText('Analytics'))
    expect(onNavigate).toHaveBeenCalledWith('/analytics')
  })

  it('renders update titles', () => {
    render(<WorkspaceGreetingCard onNavigate={() => {}} updates={updates} />)
    expect(screen.getByText('Platform v2.4 released')).toBeTruthy()
    expect(screen.getByText('Maintenance window Friday')).toBeTruthy()
  })

  it('does not render quickLink buttons when quickLinks is empty', () => {
    render(<WorkspaceGreetingCard onNavigate={() => {}} quickLinks={[]} />)
    expect(screen.queryByRole('button')).toBeNull()
  })

  it('does not render the updates section when updates is empty', () => {
    render(
      <WorkspaceGreetingCard onNavigate={() => {}} updates={[]} updatesTitle="Platform Updates" />
    )
    expect(screen.queryByText('Platform Updates')).toBeNull()
  })
})
