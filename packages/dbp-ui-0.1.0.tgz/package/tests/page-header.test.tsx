import * as React from 'react'
import { describe, it, expect, afterEach, vi } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { PageHeader } from '../src/components/page-header.js'

afterEach(cleanup)

describe('PageHeader', () => {
  it('renders the title as an h1', () => {
    render(<PageHeader title="My Dashboard" />)
    expect(screen.getByRole('heading', { level: 1, name: 'My Dashboard' })).toBeTruthy()
  })

  it('renders subtitle when provided', () => {
    render(<PageHeader title="Reports" subtitle="Last 30 days" />)
    expect(screen.getByText('Last 30 days')).toBeTruthy()
  })

  it('renders action button and fires onClick', async () => {
    const onClick = vi.fn()
    render(<PageHeader title="Tasks" action={{ label: 'Create Task', onClick }} />)
    const btn = screen.getByRole('button', { name: 'Create Task' })
    await userEvent.setup().click(btn)
    expect(onClick).toHaveBeenCalledOnce()
  })

  it('does not render a button when no action provided', () => {
    render(<PageHeader title="Home" />)
    expect(screen.queryByRole('button')).toBeNull()
  })

  it('renders actions ReactNode when no action shorthand provided', () => {
    render(<PageHeader title="Home" actions={<button>Custom</button>} />)
    expect(screen.getByRole('button', { name: 'Custom' })).toBeTruthy()
  })

  it('root element has data-page-title attribute', () => {
    const { container } = render(<PageHeader title="Test" />)
    expect(container.querySelector('[data-page-title]')).toBeTruthy()
  })
})
