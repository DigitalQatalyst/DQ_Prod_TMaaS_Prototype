import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { AppTopBar } from "../src/components/app-top-bar.js";
import type { TopBarConfig } from "@dbp/contracts";

afterEach(() => { cleanup(); });

const baseConfig: TopBarConfig = {
  appName: "DBP App",
  logoAlt: "DBP",
  actions: [],
  showSearch: false,
  showNotifications: false,
  showUser: false,
};

describe("AppTopBar", () => {
  it("renders app name", () => {
    render(<AppTopBar config={baseConfig} />);
    expect(screen.getByText("DBP App")).toBeDefined();
  });

  it("renders logo when logoSrc provided", () => {
    const config: TopBarConfig = { ...baseConfig, logoSrc: "/logo.png", logoAlt: "Logo" };
    render(<AppTopBar config={config} />);
    const img = screen.getByRole("img", { name: "Logo" });
    expect(img).toBeDefined();
    expect((img as HTMLImageElement).src).toContain("/logo.png");
  });

  it("does not render logo when logoSrc is absent", () => {
    render(<AppTopBar config={baseConfig} />);
    expect(screen.queryByRole("img")).toBeNull();
  });

  it("renders notification slot when showNotifications=true", () => {
    const config: TopBarConfig = { ...baseConfig, showNotifications: true };
    render(
      <AppTopBar config={config} notificationSlot={<button>Bell</button>} />
    );
    expect(screen.getByRole("button", { name: "Bell" })).toBeDefined();
  });

  it("does NOT render notification slot when showNotifications=false", () => {
    render(
      <AppTopBar config={baseConfig} notificationSlot={<button>Bell</button>} />
    );
    expect(screen.queryByRole("button", { name: "Bell" })).toBeNull();
  });

  it("renders search slot when showSearch=true", () => {
    const config: TopBarConfig = { ...baseConfig, showSearch: true };
    render(
      <AppTopBar config={config} searchSlot={<input placeholder="Search" />} />
    );
    expect(screen.getByPlaceholderText("Search")).toBeDefined();
  });
});
