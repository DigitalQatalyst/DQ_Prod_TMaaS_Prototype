import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from "../src/components/card.js";

afterEach(() => { cleanup(); });

describe("Card subcomponents", () => {
  it("renders nested structure", () => {
    render(
      <Card data-testid="card">
        <CardHeader>
          <CardTitle>My card</CardTitle>
          <CardDescription>A description</CardDescription>
        </CardHeader>
        <CardContent>Body content</CardContent>
        <CardFooter>Footer</CardFooter>
      </Card>
    );
    expect(screen.getByTestId("card")).toBeDefined();
    expect(screen.getByText("My card")).toBeDefined();
    expect(screen.getByText("A description")).toBeDefined();
    expect(screen.getByText("Body content")).toBeDefined();
    expect(screen.getByText("Footer")).toBeDefined();
  });
});
