import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../src/components/tabs.js";

afterEach(() => {
  cleanup();
});

function TestTabs() {
  return (
    <Tabs defaultValue="alpha">
      <TabsList>
        <TabsTrigger value="alpha">Alpha</TabsTrigger>
        <TabsTrigger value="beta">Beta</TabsTrigger>
      </TabsList>
      <TabsContent value="alpha">Content A</TabsContent>
      <TabsContent value="beta">Content B</TabsContent>
    </Tabs>
  );
}

describe("Tabs", () => {
  it("renders all tab triggers", () => {
    render(<TestTabs />);
    expect(screen.getAllByRole("tab", { name: "Alpha" }).length).toBeGreaterThan(0);
    expect(screen.getAllByRole("tab", { name: "Beta" }).length).toBeGreaterThan(0);
  });

  it("shows the default tab panel content", () => {
    render(<TestTabs />);
    const panels = screen.getAllByRole("tabpanel");
    const active = panels.find((p) => p.getAttribute("data-state") === "active");
    expect(active?.textContent).toBe("Content A");
  });

  it("switches panel on click", async () => {
    const user = userEvent.setup();
    render(<TestTabs />);
    await user.click(screen.getAllByRole("tab", { name: "Beta" })[0]!);
    const panels = screen.getAllByRole("tabpanel");
    const active = panels.find((p) => p.getAttribute("data-state") === "active");
    expect(active?.textContent).toBe("Content B");
  });

  it("navigates between tabs with arrow keys", async () => {
    const user = userEvent.setup();
    render(<TestTabs />);
    const alphaTab = screen.getAllByRole("tab", { name: "Alpha" })[0]!;
    alphaTab.focus();
    await user.keyboard("{ArrowRight}");
    const betaTab = screen.getAllByRole("tab", { name: "Beta" })[0]!;
    expect(document.activeElement).toBe(betaTab);
  });
});
