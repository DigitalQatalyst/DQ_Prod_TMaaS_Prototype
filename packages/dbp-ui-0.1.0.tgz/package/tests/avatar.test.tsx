import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Avatar, AvatarLockup } from "../src/components/avatar.js";

afterEach(() => { cleanup(); });

describe("Avatar", () => {
  it("shows initials for a two-word name", () => {
    render(<Avatar name="John Doe" />);
    expect(screen.getByText("JD")).toBeDefined();
  });

  it("shows initials for a single-word name", () => {
    render(<Avatar name="Alice" />);
    expect(screen.getByText("AL")).toBeDefined();
  });

  it("has correct aria-label", () => {
    render(<Avatar name="Jane Smith" />);
    expect(screen.getByRole("img", { name: "Jane Smith" })).toBeDefined();
  });
});

describe("AvatarLockup", () => {
  it("renders name and role", () => {
    render(<AvatarLockup name="Tom Brown" role="Manager" />);
    expect(screen.getByText("Tom Brown")).toBeDefined();
    expect(screen.getByText("Manager")).toBeDefined();
  });
});
