import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AISearchBar } from "../src/components/ai-search-bar.js";

afterEach(() => cleanup());

describe("AISearchBar", () => {
  it("renders the search input", () => {
    render(<AISearchBar />);
    expect(screen.getByTestId("ai-search-input")).toBeDefined();
  });

  it("renders custom placeholder", () => {
    render(<AISearchBar placeholder="Ask the platform…" />);
    const input = screen.getByTestId("ai-search-input") as HTMLInputElement;
    expect(input.placeholder).toBe("Ask the platform…");
  });

  it("has role=search on container", () => {
    const { container } = render(<AISearchBar />);
    const region = container.querySelector("[role='search']");
    expect(region).not.toBeNull();
  });

  it("calls onSubmit with typed value when Enter is pressed", async () => {
    const onSubmit = vi.fn();
    render(<AISearchBar onSubmit={onSubmit} />);
    const input = screen.getByTestId("ai-search-input");
    await userEvent.type(input, "find open tasks{Enter}");
    expect(onSubmit).toHaveBeenCalledWith("find open tasks");
  });

  it("calls onSubmit with typed value when submit button is clicked", async () => {
    const onSubmit = vi.fn();
    render(<AISearchBar onSubmit={onSubmit} />);
    const input = screen.getByTestId("ai-search-input");
    await userEvent.type(input, "search query");
    const submitBtn = screen.getByTestId("ai-search-submit");
    await userEvent.click(submitBtn);
    expect(onSubmit).toHaveBeenCalledWith("search query");
  });

  it("does NOT call onSubmit when input is empty and Enter is pressed", async () => {
    const onSubmit = vi.fn();
    render(<AISearchBar onSubmit={onSubmit} />);
    const input = screen.getByTestId("ai-search-input");
    fireEvent.keyDown(input, { key: "Enter" });
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("does NOT call onSubmit when input is only whitespace", async () => {
    const onSubmit = vi.fn();
    render(<AISearchBar onSubmit={onSubmit} />);
    const input = screen.getByTestId("ai-search-input");
    await userEvent.type(input, "   {Enter}");
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("renders kbd hint by default", () => {
    const { container } = render(<AISearchBar />);
    const kbd = container.querySelector("kbd");
    expect(kbd).not.toBeNull();
  });

  it("hides kbd hint when kbdHint=false", () => {
    const { container } = render(<AISearchBar kbdHint={false} />);
    const kbd = container.querySelector("kbd");
    expect(kbd).toBeNull();
  });

  it("does NOT import or render Sparkles", () => {
    const { container } = render(<AISearchBar />);
    const html = container.innerHTML.toLowerCase();
    expect(html).not.toContain("sparkles");
  });

  it("icon tile has bg-orange-50 class", () => {
    const { container } = render(<AISearchBar />);
    const iconTile = container.querySelector(".bg-orange-50");
    expect(iconTile).not.toBeNull();
  });
});
