import { describe, it, expect, afterEach } from "vitest"
import { render, screen, cleanup } from "@testing-library/react"

afterEach(() => {
  cleanup()
})

import { Breadcrumb } from "../src/components/breadcrumb.js"

describe("Breadcrumb", () => {
  it("renders all items", () => {
    const items = [
      { label: "Home" },
      { label: "Products" },
      { label: "Electronics" },
    ]
    render(<Breadcrumb items={items} />)
    expect(screen.getByText("Home")).toBeDefined()
    expect(screen.getByText("Products")).toBeDefined()
    expect(screen.getByText("Electronics")).toBeDefined()
  })

  it("last item has aria-current='page'", () => {
    const items = [
      { label: "Home" },
      { label: "Products" },
      { label: "Current Page" },
    ]
    render(<Breadcrumb items={items} />)
    const lastItem = screen.getByText("Current Page")
    expect(lastItem.getAttribute("aria-current")).toBe("page")
  })

  it("single item renders without separator", () => {
    const items = [{ label: "Home" }]
    render(<Breadcrumb items={items} />)
    const separators = screen.queryAllByText("/")
    expect(separators).toHaveLength(0)
  })

  it("items with href render as links", () => {
    const items = [
      { label: "Home", href: "/" },
      { label: "Products", href: "/products" },
      { label: "Current" },
    ]
    render(<Breadcrumb items={items} />)
    const homeLink = screen.getByRole("link", { name: "Home" })
    const productsLink = screen.getByRole("link", { name: "Products" })
    expect(homeLink.getAttribute("href")).toBe("/")
    expect(productsLink.getAttribute("href")).toBe("/products")
  })

  it("renders separator between items", () => {
    const items = [
      { label: "Home" },
      { label: "Products" },
    ]
    render(<Breadcrumb items={items} />)
    const separators = screen.getAllByText("/")
    expect(separators.length).toBeGreaterThan(0)
  })

  it("has nav element with aria-label", () => {
    const items = [{ label: "Home" }]
    render(<Breadcrumb items={items} />)
    const nav = screen.getByRole("navigation", { name: "Breadcrumb" })
    expect(nav).toBeDefined()
  })
})
