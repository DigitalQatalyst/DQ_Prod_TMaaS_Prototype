import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { HomeHero } from "../src/components/home-hero.js";

afterEach(() => cleanup());

describe("HomeHero", () => {
  it("renders greeting text", () => {
    render(<HomeHero greeting="Good morning, Alex" />);
    expect(screen.getByTestId("home-hero-greeting").textContent).toBe(
      "Good morning, Alex",
    );
  });

  it("renders subtext when provided", () => {
    render(
      <HomeHero
        greeting="Good evening"
        subtext="Keep today's priorities moving."
      />,
    );
    expect(screen.getByTestId("home-hero-subtext").textContent).toBe(
      "Keep today's priorities moving.",
    );
  });

  it("does not render subtext slot when absent", () => {
    render(<HomeHero greeting="Hello" />);
    expect(screen.queryByTestId("home-hero-subtext")).toBeNull();
  });

  it("renders searchSlot when provided", () => {
    render(
      <HomeHero
        greeting="Hello"
        searchSlot={<input data-testid="search-in-slot" />}
      />,
    );
    expect(screen.getByTestId("home-hero-search-slot")).toBeDefined();
    expect(screen.getByTestId("search-in-slot")).toBeDefined();
  });

  it("does not render search slot container when searchSlot is absent", () => {
    render(<HomeHero greeting="Hello" />);
    expect(screen.queryByTestId("home-hero-search-slot")).toBeNull();
  });

  it("renders quickActions slot when provided", () => {
    render(
      <HomeHero
        greeting="Hello"
        quickActions={<button data-testid="quick-action-btn">Go</button>}
      />,
    );
    expect(screen.getByTestId("home-hero-quick-actions")).toBeDefined();
    expect(screen.getByTestId("quick-action-btn")).toBeDefined();
  });

  it("does not render quickActions slot when absent", () => {
    render(<HomeHero greeting="Hello" />);
    expect(screen.queryByTestId("home-hero-quick-actions")).toBeNull();
  });

  it("has role=landmark via aria-label", () => {
    const { container } = render(<HomeHero greeting="Hello" />);
    const section = container.querySelector("section[aria-label='Welcome']");
    expect(section).not.toBeNull();
  });

  it("heading has correct size classes", () => {
    render(<HomeHero greeting="Hello" />);
    const h1 = screen.getByTestId("home-hero-greeting");
    expect(h1.tagName).toBe("H1");
    expect(h1.className).toContain("text-[28px]");
    expect(h1.className).toContain("sm:text-[36px]");
    expect(h1.className).toContain("lg:text-[40px]");
    expect(h1.className).toContain("font-bold");
  });

  it("does NOT import or render Sparkles", () => {
    // Structural: the component renders without any element text 'sparkles'
    const { container } = render(<HomeHero greeting="Test" />);
    const html = container.innerHTML.toLowerCase();
    expect(html).not.toContain("sparkles");
  });
});
