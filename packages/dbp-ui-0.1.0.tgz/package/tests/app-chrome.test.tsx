import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { createElement, type ReactNode } from "react";
import { AppChrome } from "../src/components/app-chrome.js";
import type { AppChromeSession } from "../src/components/app-chrome.js";

afterEach(() => {
  cleanup();
});

const session: AppChromeSession = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  displayName: "Alpha Finance Approver",
  primaryRole: "Finance Approver",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
};

const multiRoleSession: AppChromeSession = {
  ...session,
  roles: ["finance-approver", "platform-admin"],
};

/** Wrap in a QueryClientProvider — the search/notif bindings use TanStack Query. */
function withQuery(ui: ReactNode) {
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  return createElement(QueryClientProvider, { client }, ui);
}

describe("AppChrome — product lockup", () => {
  it("renders the solution code and product name from props", () => {
    render(
      withQuery(
        <AppChrome productCode="DIA.02" productName="AnalyticsOps" session={session} />,
      ),
    );
    expect(screen.getByText("DIA.02")).toBeTruthy();
    expect(screen.getByText("/ AnalyticsOps")).toBeTruthy();
  });
});

describe("AppChrome — capability gating", () => {
  it("does NOT render global search when capabilities.search is false", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DIA.02"
          productName="AnalyticsOps"
          session={session}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    // Neither the live SearchBar (role=searchbox) nor the default search pill.
    expect(screen.queryByRole("searchbox")).toBeNull();
    expect(screen.queryByRole("button", { name: /open global search/i })).toBeNull();
  });

  it("renders the global search binding when capabilities.search is true", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DWS.05"
          productName="Digital WFMS"
          session={session}
          capabilities={{ search: true, notifications: false }}
          searchPlaceholder="Search shifts…"
        />,
      ),
    );
    expect(screen.getByRole("searchbox", { name: /search shifts/i })).toBeTruthy();
  });

  it("does NOT render the notification bell when capabilities.notifications is false", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DIA.02"
          productName="AnalyticsOps"
          session={session}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    expect(screen.queryByRole("button", { name: /notifications/i })).toBeNull();
  });

  it("renders the notification bell when capabilities.notifications is true", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DWS.05"
          productName="Digital WFMS"
          session={session}
          capabilities={{ search: false, notifications: true }}
        />,
      ),
    );
    expect(screen.getByRole("button", { name: /notifications/i })).toBeTruthy();
  });
});

describe("AppChrome — settings affordance", () => {
  it("always renders a settings control", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DIA.02"
          session={session}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    expect(screen.getByRole("button", { name: /settings/i })).toBeTruthy();
  });
});

describe("AppChrome — avatar / role from session", () => {
  it("renders the avatar block from the session display name + role", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DIA.02"
          session={session}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    expect(screen.getByText("Alpha Finance Approver")).toBeTruthy();
    expect(screen.getByText("Finance Approver")).toBeTruthy();
  });

  it("renders NO avatar block when session is null (loading / unauthenticated)", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DIA.02"
          session={null}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    expect(screen.queryByText("Alpha Finance Approver")).toBeNull();
  });

  it("does NOT render a role switcher for a single-role session", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DIA.02"
          session={session}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    expect(screen.queryByRole("radiogroup", { name: /active role/i })).toBeNull();
  });

  it("renders a role switcher only when the session has 2+ roles", () => {
    render(
      withQuery(
        <AppChrome
          productCode="DWS.04"
          session={multiRoleSession}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    const group = screen.getByRole("radiogroup", { name: /active role/i });
    expect(group).toBeTruthy();
    expect(screen.getByRole("radio", { name: /finance approver/i })).toBeTruthy();
    expect(screen.getByRole("radio", { name: /platform admin/i })).toBeTruthy();
  });
});

describe("AppChrome — no Sparkles icon", () => {
  it("emits no element referencing a sparkles glyph", () => {
    const { container } = render(
      withQuery(
        <AppChrome
          productCode="DIA.02"
          session={session}
          capabilities={{ search: false, notifications: false }}
        />,
      ),
    );
    expect(container.innerHTML.toLowerCase()).not.toContain("sparkle");
  });
});
