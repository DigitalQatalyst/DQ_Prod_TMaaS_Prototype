import { describe, it, expect, afterEach } from "vitest"
import { render, screen, cleanup } from "@testing-library/react"
import { LandingFooter } from "../src/components/landing-footer.js"

afterEach(() => {
  cleanup()
})

const sampleColumns = [
  {
    heading: "Navigation",
    links: [
      { label: "Orientation", href: "#orientation" },
      { label: "Dashboard", href: "#dashboard" },
    ],
  },
  {
    heading: "Marketplaces",
    links: [
      { label: "Services", href: "#services" },
      { label: "Knowledge", href: "#knowledge" },
    ],
  },
]

describe("LandingFooter", () => {
  it("renders the footer landmark", () => {
    render(<LandingFooter productCode="DWS.01" />)
    expect(screen.getByRole("contentinfo")).toBeDefined()
  })

  it("renders product code", () => {
    render(<LandingFooter productCode="DWS.01" />)
    expect(screen.getByText("DWS.01")).toBeDefined()
  })

  it("renders product name when provided", () => {
    render(<LandingFooter productCode="DWS.01" productName="Work.Space4.0" />)
    expect(screen.getByText(/Work\.Space4\.0/)).toBeDefined()
  })

  it("renders tagline", () => {
    render(
      <LandingFooter
        productCode="DWS.01"
        tagline="A governed platform for digital teams."
      />
    )
    expect(screen.getByText("A governed platform for digital teams.")).toBeDefined()
  })

  it("renders link columns headings", () => {
    render(<LandingFooter productCode="DWS.01" columns={sampleColumns} />)
    expect(screen.getByText("Navigation")).toBeDefined()
    expect(screen.getByText("Marketplaces")).toBeDefined()
  })

  it("renders column links", () => {
    render(<LandingFooter productCode="DWS.01" columns={sampleColumns} />)
    expect(screen.getByRole("link", { name: "Orientation" })).toBeDefined()
    expect(screen.getByRole("link", { name: "Services" })).toBeDefined()
  })

  it("renders custom legal text in the bottom row", () => {
    render(
      <LandingFooter
        productCode="DWS.01"
        legal="© 2026 Acme Corp. All rights reserved."
      />
    )
    expect(screen.getByText("© 2026 Acme Corp. All rights reserved.")).toBeDefined()
  })

  it("renders default legal text (current year) when not provided", () => {
    render(<LandingFooter productCode="DWS.01" />)
    const year = new Date().getFullYear()
    const legal = screen.getByText(new RegExp(String(year)))
    expect(legal).toBeDefined()
  })

  it("renders default placeholder columns when none provided", () => {
    render(<LandingFooter productCode="DWS.01" />)
    // Default columns headings
    expect(screen.getByText("Navigation")).toBeDefined()
    expect(screen.getByText("Marketplaces")).toBeDefined()
  })

  it("nav elements have accessible labels", () => {
    render(<LandingFooter productCode="DWS.01" columns={sampleColumns} />)
    const navs = screen.getAllByRole("navigation")
    expect(navs.length).toBeGreaterThan(0)
  })

  it("home link has accessible aria-label containing the product code", () => {
    render(<LandingFooter productCode="DIA.02" />)
    const homeLink = screen.getByRole("link", { name: /DIA\.02/ })
    expect(homeLink).toBeDefined()
  })
})
