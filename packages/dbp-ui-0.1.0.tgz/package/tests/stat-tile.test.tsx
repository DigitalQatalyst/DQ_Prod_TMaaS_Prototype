import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { StatTile } from "../src/components/stat-tile.js";

describe("StatTile", () => {
  it("renders label and value", () => {
    render(<StatTile label="Revenue" value="$12,450" />);
    expect(screen.getByText("Revenue")).toBeDefined();
    expect(screen.getByText("$12,450")).toBeDefined();
  });

  it("renders trend up in green", () => {
    render(
      <StatTile
        label="Active Users"
        value="2,543"
        trend={{ value: 12, label: "vs last month" }}
        data-testid="tile"
      />
    );
    // Trend is a <div> with a Lucide up-arrow icon + "+12%" span, coloured success.
    const trendEl = screen.getByText((_, el) =>
      el?.tagName === "DIV" &&
      (el.textContent ?? "").includes("12") &&
      el.className.includes("text-[var(--color-success)]"),
    );
    expect(trendEl.className).toContain("text-[var(--color-success)]");
  });

  it("renders trend down in red/danger", () => {
    render(
      <StatTile
        label="Bounce Rate"
        value="34%"
        trend={{ value: -5, label: "vs last week" }}
        data-testid="tile"
      />
    );
    const trendEl = screen.getByText((_, el) =>
      el?.tagName === "DIV" &&
      (el.textContent ?? "").includes("5") &&
      el.className.includes("text-[var(--color-danger)]"),
    );
    expect(trendEl.className).toContain("text-[var(--color-danger)]");
  });

  it("renders icon slot", () => {
    render(
      <StatTile
        label="Orders"
        value="156"
        icon={<span data-testid="icon">📦</span>}
      />
    );
    expect(screen.getByTestId("icon")).toBeDefined();
  });

  it("does not render trend when absent", () => {
    render(<StatTile label="Conversions" value="89" />);
    expect(screen.queryByText("↑")).toBeNull();
    expect(screen.queryByText("↓")).toBeNull();
  });

  it("applies correct border-t class per tone", () => {
    const { container: primaryContainer } = render(
      <StatTile label="Test" value="100" tone="primary" className="test-primary" />
    );
    const primaryTile = primaryContainer.querySelector(".test-primary");
    expect(primaryTile?.className).toContain("border-t-[var(--color-primary)]");

    const { container: successContainer } = render(
      <StatTile label="Test" value="100" tone="success" className="test-success" />
    );
    const successTile = successContainer.querySelector(".test-success");
    expect(successTile?.className).toContain("border-t-[var(--color-success)]");

    const { container: dangerContainer } = render(
      <StatTile label="Test" value="100" tone="danger" className="test-danger" />
    );
    const dangerTile = dangerContainer.querySelector(".test-danger");
    expect(dangerTile?.className).toContain("border-t-[var(--color-danger)]");
  });

  it("renders trend label when provided", () => {
    render(
      <StatTile
        label="Growth"
        value="23%"
        trend={{ value: 8, label: "YoY" }}
      />
    );
    expect(screen.getByText("YoY")).toBeDefined();
  });

  it("uses tabular-nums for the value", () => {
    render(<StatTile label="Revenue" value="1,234,567" data-testid="value" />);
    const valueElement = screen.getByText("1,234,567");
    expect(valueElement.className).toContain("tabular-nums");
  });
});
