import { describe, it, expect, afterEach } from "vitest"
import { render, screen, cleanup } from "@testing-library/react"
import { ShieldCheck } from "lucide-react"
import { LandingHero } from "../src/components/landing-hero.js"

afterEach(() => {
  cleanup()
})

describe("LandingHero", () => {
  it("renders the section landmark", () => {
    render(<LandingHero />)
    expect(screen.getByRole("region", { name: /Hero/i })).toBeDefined()
  })

  it("renders default headline text", () => {
    render(<LandingHero />)
    expect(screen.getByText("Everything you need.")).toBeDefined()
  })

  it("renders headline accent as orange span", () => {
    render(<LandingHero headlineAccent="One workspace." />)
    expect(screen.getByText("One workspace.")).toBeDefined()
  })

  it("renders custom overline", () => {
    render(<LandingHero overline="Custom overline text" />)
    expect(screen.getByText("Custom overline text")).toBeDefined()
  })

  it("renders body paragraph", () => {
    render(<LandingHero body="This is the body text." />)
    expect(screen.getByText("This is the body text.")).toBeDefined()
  })

  it("renders primary CTA link", () => {
    render(<LandingHero primaryCta={{ label: "Get Started", href: "/signup" }} />)
    const link = screen.getByRole("link", { name: /Get Started/i })
    expect(link).toBeDefined()
    expect((link as HTMLAnchorElement).href).toContain("/signup")
  })

  it("renders secondary CTA link", () => {
    render(<LandingHero secondaryCta={{ label: "Take a Tour", href: "/tour" }} />)
    const link = screen.getByRole("link", { name: /Take a Tour/i })
    expect(link).toBeDefined()
  })

  it("renders trust bullets when provided", () => {
    render(
      <LandingHero
        trustBullets={[
          { icon: <ShieldCheck size={16} />, label: "SOC 2 Compliant" },
          { label: "GDPR Ready" },
        ]}
      />
    )
    expect(screen.getByText("SOC 2 Compliant")).toBeDefined()
    expect(screen.getByText("GDPR Ready")).toBeDefined()
  })

  it("renders placeholder when no preview is provided", () => {
    render(<LandingHero />)
    expect(screen.getByRole("img", { name: /Platform preview/i })).toBeDefined()
  })

  it("renders preview slot when provided", () => {
    render(<LandingHero preview={<div>Custom preview</div>} />)
    expect(screen.getByText("Custom preview")).toBeDefined()
    // Placeholder should NOT be present
    expect(screen.queryByRole("img", { name: /Platform preview/i })).toBeNull()
  })

  it("does not render trust bullets row when array is empty", () => {
    render(<LandingHero trustBullets={[]} />)
    // No list items for trust bullets
    expect(screen.queryByText("SOC 2 Compliant")).toBeNull()
  })

  it("heading contains both headline and accent text", () => {
    render(<LandingHero headline="Hello" headlineAccent="World." />)
    const h1 = screen.getByRole("heading", { level: 1 })
    expect(h1.textContent).toContain("Hello")
    expect(h1.textContent).toContain("World.")
  })
})
