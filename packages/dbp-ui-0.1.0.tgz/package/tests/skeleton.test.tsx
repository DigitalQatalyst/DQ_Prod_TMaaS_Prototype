import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import { Skeleton } from "../src/components/skeleton.js";

describe("Skeleton", () => {
  it("renders a div with animate-pulse", () => {
    const { container } = render(<Skeleton className="h-8 w-32" />);
    const el = container.firstElementChild;
    expect(el?.className).toContain("animate-pulse");
  });
});
