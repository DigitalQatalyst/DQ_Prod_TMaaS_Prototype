import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { SlotFrame } from "../src/components/slot-frame.js";

describe("SlotFrame", () => {
  it("shows the slot label when empty (no children)", () => {
    render(<SlotFrame slotName="main" />);
    expect(screen.getByText("slot:main")).toBeDefined();
  });

  it("shows the slot label when isEmpty is explicitly true", () => {
    render(<SlotFrame slotName="sidebar" isEmpty>ignored child</SlotFrame>);
    expect(screen.getByText("slot:sidebar")).toBeDefined();
  });

  it("renders children when isEmpty is false", () => {
    render(<SlotFrame slotName="hero" isEmpty={false}><p>Actual content</p></SlotFrame>);
    expect(screen.getByText("Actual content")).toBeDefined();
    expect(screen.queryByText("slot:hero")).toBeNull();
  });

  it("renders children transparently when children provided without isEmpty override", () => {
    render(<SlotFrame slotName="cta"><span>CTA Content</span></SlotFrame>);
    expect(screen.getByText("CTA Content")).toBeDefined();
    expect(screen.queryByText("slot:cta")).toBeNull();
  });

  it("exposes data-slot-name attribute", () => {
    const { container } = render(<SlotFrame slotName="detailTabs" />);
    const el = container.firstElementChild;
    expect(el?.getAttribute("data-slot-name")).toBe("detailTabs");
  });

  it("has accessible label on the empty-state span", () => {
    render(<SlotFrame slotName="inspector" />);
    expect(screen.getByLabelText("Empty slot: inspector")).toBeDefined();
  });
});
