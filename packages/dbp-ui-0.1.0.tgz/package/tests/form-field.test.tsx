import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { FormField } from "../src/components/form-field.js";
import { Input } from "../src/components/input.js";

afterEach(() => { cleanup(); });

describe("FormField", () => {
  it("renders label and child input", () => {
    render(
      <FormField label="Email">
        <Input placeholder="you@example.com" />
      </FormField>
    );
    expect(screen.getByText("Email")).toBeDefined();
    expect(screen.getByPlaceholderText("you@example.com")).toBeDefined();
  });

  it("shows error message with role=alert", () => {
    render(
      <FormField label="Name" error="Name is required">
        <Input />
      </FormField>
    );
    expect(screen.getByRole("alert")).toBeDefined();
    expect(screen.getByText("Name is required")).toBeDefined();
  });

  it("shows helper text when no error", () => {
    render(
      <FormField label="Password" helperText="At least 8 characters">
        <Input type="password" />
      </FormField>
    );
    expect(screen.getByText("At least 8 characters")).toBeDefined();
  });

  it("links label htmlFor to input id", () => {
    render(
      <FormField label="Username">
        <Input />
      </FormField>
    );
    const label = screen.getByText("Username") as HTMLLabelElement;
    const input = screen.getByRole("textbox") as HTMLInputElement;
    expect(label.htmlFor).toBe(input.id);
  });
});
