import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { RailSection, RailActionButton, SectionCard } from "../src/components/detail-rail.js";

afterEach(() => {
  cleanup();
});

/* ─── RailSection ─────────────────────────────────────────────────────────── */

describe("RailSection", () => {
  it("renders the title as a heading", () => {
    render(
      <RailSection title="Use in Work">
        <p>Content</p>
      </RailSection>,
    );
    expect(screen.getByText("Use in Work")).toBeDefined();
  });

  it("renders children inside the section", () => {
    render(
      <RailSection title="Governance Actions">
        <button type="button">Action 1</button>
      </RailSection>,
    );
    expect(screen.getByText("Action 1")).toBeDefined();
  });

  it("uses a section element as the root", () => {
    const { container } = render(
      <RailSection title="Test Section">
        <span>child</span>
      </RailSection>,
    );
    expect(container.querySelector("section")).toBeDefined();
  });

  it("applies custom className", () => {
    const { container } = render(
      <RailSection title="Test" className="custom-rail">
        <span>x</span>
      </RailSection>,
    );
    const section = container.querySelector("section") as HTMLElement;
    expect(section.className).toContain("custom-rail");
  });
});

/* ─── RailActionButton ────────────────────────────────────────────────────── */

describe("RailActionButton", () => {
  it("renders the button label", () => {
    render(<RailActionButton>Attach to Task</RailActionButton>);
    expect(screen.getByText("Attach to Task")).toBeDefined();
  });

  it("is a button element with type=button", () => {
    render(<RailActionButton>Attach to Task</RailActionButton>);
    const btn = screen.getByRole("button", { name: /attach to task/i });
    expect(btn.tagName.toLowerCase()).toBe("button");
    expect(btn.getAttribute("type")).toBe("button");
  });

  it("fires onClick when clicked", async () => {
    const user = userEvent.setup();
    const handler = vi.fn();
    render(<RailActionButton onClick={handler}>Action</RailActionButton>);
    await user.click(screen.getByRole("button"));
    expect(handler).toHaveBeenCalledOnce();
  });

  it("fires onClick on Enter key", async () => {
    const user = userEvent.setup();
    const handler = vi.fn();
    render(<RailActionButton onClick={handler}>Action</RailActionButton>);
    screen.getByRole("button").focus();
    await user.keyboard("{Enter}");
    expect(handler).toHaveBeenCalledOnce();
  });

  it("fires onClick on Space key", async () => {
    const user = userEvent.setup();
    const handler = vi.fn();
    render(<RailActionButton onClick={handler}>Action</RailActionButton>);
    screen.getByRole("button").focus();
    await user.keyboard(" ");
    expect(handler).toHaveBeenCalledOnce();
  });

  it("applies navy tone classes", () => {
    render(<RailActionButton tone="navy">Acknowledge</RailActionButton>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("bg-[var(--color-primary)]");
    expect(btn.className).toContain("text-white");
  });

  it("applies ghost tone classes", () => {
    render(<RailActionButton tone="ghost">Ghost Action</RailActionButton>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("text-gray-700");
  });

  it("applies outline tone classes by default", () => {
    render(<RailActionButton>Default action</RailActionButton>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("border-gray-200");
  });

  it("renders a lucide icon when icon prop is provided", () => {
    const { container } = render(
      <RailActionButton icon="CheckSquare">Attach to Task</RailActionButton>,
    );
    // The icon is an svg rendered by lucide
    const svg = container.querySelector("svg");
    expect(svg).toBeDefined();
  });

  it("is focusable by keyboard (tabIndex not -1)", () => {
    render(<RailActionButton>Focus test</RailActionButton>);
    const btn = screen.getByRole("button");
    expect(btn.tabIndex).not.toBe(-1);
  });
});

/* ─── SectionCard ─────────────────────────────────────────────────────────── */

describe("SectionCard", () => {
  it("renders children", () => {
    render(
      <SectionCard>
        <p>Section content</p>
      </SectionCard>,
    );
    expect(screen.getByText("Section content")).toBeDefined();
  });

  it("renders the title as a heading when provided", () => {
    render(
      <SectionCard title="Overview">
        <p>Body</p>
      </SectionCard>,
    );
    expect(screen.getByText("Overview")).toBeDefined();
  });

  it("does not render a heading element when title is omitted", () => {
    const { container } = render(
      <SectionCard>
        <p>Body</p>
      </SectionCard>,
    );
    expect(container.querySelector("h2")).toBeNull();
  });

  it("uses a section element as root", () => {
    const { container } = render(
      <SectionCard>
        <span>x</span>
      </SectionCard>,
    );
    expect(container.querySelector("section")).toBeDefined();
  });

  it("applies border-gray-200 class (detail page exact styling)", () => {
    const { container } = render(
      <SectionCard>
        <span>x</span>
      </SectionCard>,
    );
    const section = container.querySelector("section") as HTMLElement;
    expect(section.className).toContain("border-gray-200");
  });

  it("applies custom className", () => {
    const { container } = render(
      <SectionCard className="extra-class">
        <span>x</span>
      </SectionCard>,
    );
    const section = container.querySelector("section") as HTMLElement;
    expect(section.className).toContain("extra-class");
  });
});
