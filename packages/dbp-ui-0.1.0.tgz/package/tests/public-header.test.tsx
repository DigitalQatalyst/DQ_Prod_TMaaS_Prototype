import { describe, it, expect, afterEach } from "vitest"
import { render, screen, cleanup, fireEvent } from "@testing-library/react"
import { PublicHeader } from "../src/components/public-header.js"

afterEach(() => {
  cleanup()
})

const sampleLinks = [
  { label: "Features", href: "#features" },
  { label: "How it works", href: "#how-it-works" },
]

describe("PublicHeader", () => {
  it("renders product code", () => {
    render(<PublicHeader productCode="DWS.01" />)
    // Multiple elements may contain DWS.01 (desktop + mobile)
    const elements = screen.getAllByText("DWS.01")
    expect(elements.length).toBeGreaterThan(0)
  })

  it("renders product name when provided", () => {
    render(<PublicHeader productCode="DWS.01" productName="Work.Space4.0" />)
    const elements = screen.getAllByText(/Work\.Space4\.0/)
    expect(elements.length).toBeGreaterThan(0)
  })

  it("renders desktop nav links", () => {
    render(
      <PublicHeader
        productCode="DWS.01"
        links={sampleLinks}
      />
    )
    // The desktop nav renders both links
    expect(screen.getAllByText("Features").length).toBeGreaterThan(0)
    expect(screen.getAllByText("How it works").length).toBeGreaterThan(0)
  })

  it("renders sign-in CTA when provided", () => {
    render(
      <PublicHeader
        productCode="DWS.01"
        signIn={{ label: "Sign in", href: "/login" }}
      />
    )
    const links = screen.getAllByRole("link", { name: /Sign in/i })
    expect(links.length).toBeGreaterThan(0)
  })

  it("does not render sign-in when absent", () => {
    render(<PublicHeader productCode="DWS.01" />)
    expect(screen.queryByRole("link", { name: /Sign in/i })).toBeNull()
  })

  it("renders hamburger button for mobile", () => {
    render(<PublicHeader productCode="DWS.01" links={sampleLinks} />)
    const btn = screen.getByRole("button", { name: /Open navigation menu/i })
    expect(btn).toBeDefined()
  })

  it("hamburger button has aria-expanded=false initially", () => {
    render(<PublicHeader productCode="DWS.01" links={sampleLinks} />)
    const btn = screen.getByRole("button", { name: /Open navigation menu/i })
    expect(btn.getAttribute("aria-expanded")).toBe("false")
  })

  it("hamburger opens the drawer and aria-expanded becomes true", () => {
    render(
      <PublicHeader
        productCode="DWS.01"
        links={sampleLinks}
        signIn={{ label: "Sign in", href: "/login" }}
      />
    )
    const btn = screen.getByRole("button", { name: /Open navigation menu/i })
    fireEvent.click(btn)
    expect(btn.getAttribute("aria-expanded")).toBe("true")
  })

  it("has a nav landmark on desktop", () => {
    render(<PublicHeader productCode="DWS.01" links={sampleLinks} />)
    const navs = screen.getAllByRole("navigation")
    expect(navs.length).toBeGreaterThan(0)
  })

  it("renders no nav links when links array is empty", () => {
    render(
      <PublicHeader
        productCode="DWS.01"
        links={[]}
        signIn={{ label: "Sign in", href: "/login" }}
      />
    )
    // Only the home link and sign-in, no nav links
    expect(screen.queryByRole("link", { name: "Features" })).toBeNull()
  })
})
