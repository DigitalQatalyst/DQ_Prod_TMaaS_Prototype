import * as React from 'react'
import { describe, it, expect, afterEach } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'
import { BreadcrumbBar } from '../src/components/breadcrumb-bar.js'

afterEach(cleanup)

describe('BreadcrumbBar', () => {
  it('renders a single crumb for root paths', () => {
    render(<BreadcrumbBar crumbs={[{ label: 'Home', href: '/home' }]} />)
    expect(screen.getByText('Home')).toBeTruthy()
  })

  it('renders all crumbs in order', () => {
    render(
      <BreadcrumbBar crumbs={[
        { label: 'Marketplace', href: '/marketplace' },
        { label: 'Catalogue', href: '/marketplace/catalogue' },
        { label: 'Design', href: '/marketplace/catalogue/design' },
      ]} />
    )
    expect(screen.getByText('Marketplace')).toBeTruthy()
    expect(screen.getByText('Catalogue')).toBeTruthy()
    expect(screen.getByText('Design')).toBeTruthy()
  })

  it('last crumb has aria-current=page', () => {
    render(
      <BreadcrumbBar crumbs={[
        { label: 'Marketplace', href: '/marketplace' },
        { label: 'Design', href: '/marketplace/design' },
      ]} />
    )
    expect(screen.getByText('Design').closest('[aria-current="page"]')).toBeTruthy()
  })
})
