import * as React from 'react'
import { describe, it, expect, afterEach, vi } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

afterEach(cleanup)

describe('LoadingSkeleton', () => {
  it('renders shimmer rows for list variant', async () => {
    const { LoadingSkeleton } = await import('../src/components/loading-skeleton.js')
    const { container } = render(<LoadingSkeleton variant="list" rows={3} />)
    expect(container.querySelectorAll('[data-skeleton-row]').length).toBe(3)
  })

  it('renders a single shimmer block for card variant', async () => {
    const { LoadingSkeleton } = await import('../src/components/loading-skeleton.js')
    const { container } = render(<LoadingSkeleton variant="card" />)
    expect(container.querySelector('[data-skeleton-card]')).toBeTruthy()
  })
})

describe('EmptyState', () => {
  it('renders headline text', async () => {
    const { EmptyState } = await import('../src/components/empty-state.js')
    render(<EmptyState headline="No tasks found" />)
    expect(screen.getByText('No tasks found')).toBeTruthy()
  })

  it('renders CTA button when action provided', async () => {
    const { EmptyState } = await import('../src/components/empty-state.js')
    const onClick = vi.fn()
    render(<EmptyState headline="No invoices" action={{ label: 'Create Invoice', onClick }} />)
    const btn = screen.getByRole('button', { name: 'Create Invoice' })
    await userEvent.setup().click(btn)
    expect(onClick).toHaveBeenCalledOnce()
  })

  it('does not render a button when no action provided', async () => {
    const { EmptyState } = await import('../src/components/empty-state.js')
    render(<EmptyState headline="Nothing here" />)
    expect(screen.queryByRole('button')).toBeNull()
  })
})

describe('ErrorCard', () => {
  it('renders the error message', async () => {
    const { ErrorCard } = await import('../src/components/error-card.js')
    render(<ErrorCard message="Failed to load data" />)
    expect(screen.getByText('Failed to load data')).toBeTruthy()
  })

  it('calls onRetry when Retry button clicked', async () => {
    const { ErrorCard } = await import('../src/components/error-card.js')
    const onRetry = vi.fn()
    render(<ErrorCard message="Network error" onRetry={onRetry} />)
    await userEvent.setup().click(screen.getByRole('button', { name: /retry/i }))
    expect(onRetry).toHaveBeenCalledOnce()
  })
})
