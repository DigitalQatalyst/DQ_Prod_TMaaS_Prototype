import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { Switch } from "../src/components/switch.js";

afterEach(() => { cleanup(); });

describe("Switch", () => {
  it("renders with switch role", () => {
    render(<Switch aria-label="Enable feature" />);
    expect(screen.getByRole("switch", { name: "Enable feature" })).toBeDefined();
  });

  it("starts unchecked by default", () => {
    render(<Switch aria-label="Toggle" />);
    expect(screen.getByRole("switch").getAttribute("data-state")).toBe("unchecked");
  });

  it("starts checked when defaultChecked is set", () => {
    render(<Switch aria-label="Toggle" defaultChecked />);
    expect(screen.getByRole("switch").getAttribute("data-state")).toBe("checked");
  });
});
