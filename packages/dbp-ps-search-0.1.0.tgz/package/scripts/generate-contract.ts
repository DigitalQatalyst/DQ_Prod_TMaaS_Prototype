import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  OpenAPIRegistry,
  OpenApiGeneratorV3,
  extendZodWithOpenApi,
} from "@asteasolutions/zod-to-openapi";
import YAML from "yaml";
import { z } from "zod";
import {
  SearchDocumentSchema,
  IndexDocSchema,
  IndexRequestSchema,
  SearchHitSchema,
  FacetSchema,
  FacetValueSchema,
  SearchResponseSchema,
  ErrorResponseSchema,
  ValidationIssueSchema,
} from "../client/types";
import { BASE_PATH } from "../server/handlers";

extendZodWithOpenApi(z);

const packageDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const contractPath = path.join(packageDir, "contract.yaml");
const manifest = JSON.parse(
  fs.readFileSync(path.join(packageDir, "package.json"), "utf8"),
) as { version: string };

const registry = new OpenAPIRegistry();

registry.register("SearchDocument", SearchDocumentSchema);
registry.register("IndexDoc", IndexDocSchema);
const IndexRequest = registry.register("IndexRequest", IndexRequestSchema);
registry.register("SearchHit", SearchHitSchema);
registry.register("FacetValue", FacetValueSchema);
registry.register("Facet", FacetSchema);
const SearchResponse = registry.register("SearchResponse", SearchResponseSchema);
const ErrorResponse = registry.register("ErrorResponse", ErrorResponseSchema);
registry.register("ValidationIssue", ValidationIssueSchema);

const tenantHeader = z.object({
  "x-tenant-id": z.string().min(1).openapi({
    description: "Tenant scope for the request. Indexes and queries are isolated per tenant.",
  }),
});

const jsonBody = (schema: z.ZodTypeAny) => ({ content: { "application/json": { schema } } });
const jsonResponse = (description: string, schema: z.ZodTypeAny) => ({
  description,
  content: { "application/json": { schema } },
});
const errorOf = (description: string) => jsonResponse(description, ErrorResponse);

registry.registerPath({
  method: "get",
  path: `${BASE_PATH}/search`,
  summary: "Query the search index",
  description:
    "Full-text search with fuzzy + prefix matching. Results are tenant-scoped. " +
    "Facets are computed in service code over the full filtered result set (ADR-0010). " +
    "Empty query returns all indexed documents.",
  request: {
    headers: tenantHeader,
    query: z.object({
      q: z.string().default("").openapi({ description: "Search query string." }),
      filters: z
        .string()
        .optional()
        .openapi({
          description: "JSON-encoded field-equality filter object, e.g. {\"status\":\"open\"}.",
        }),
      page: z.coerce.number().int().min(1).default(1).openapi({ description: "Page number (1-based)." }),
      pageSize: z.coerce.number().int().min(1).max(100).default(20).openapi({ description: "Results per page (max 100)." }),
    }),
  },
  responses: {
    200: jsonResponse("Search results with facets and total count", SearchResponse),
    400: errorOf("Missing tenant header or invalid query parameters"),
  },
});

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/index`,
  summary: "Index a document (upsert)",
  description:
    "Adds or replaces a document in the tenant's search index. " +
    "Re-indexing the same id replaces the existing entry (upsert semantics).",
  request: {
    headers: tenantHeader,
    body: jsonBody(IndexRequest),
  },
  responses: {
    200: jsonResponse("Document indexed", z.object({ indexed: z.literal(true) })),
    400: errorOf("Missing tenant header or invalid request body"),
  },
});

registry.registerPath({
  method: "delete",
  path: `${BASE_PATH}/index/{entityType}/{id}`,
  summary: "Remove a document from the index",
  description: "Removes the document from the tenant's index. No-op if the document does not exist.",
  request: {
    headers: tenantHeader,
    params: z.object({
      entityType: z.string().min(1).openapi({ description: "Entity type of the document to remove." }),
      id: z.string().min(1).openapi({ description: "ID of the document to remove." }),
    }),
  },
  responses: {
    204: { description: "Document removed (or was not present)" },
    400: errorOf("Missing tenant header or missing path parameters"),
  },
});

const generator = new OpenApiGeneratorV3(registry.definitions);
const document = generator.generateDocument({
  openapi: "3.0.3",
  info: {
    title: "PS.SEARCH — Search Service",
    version: manifest.version,
    description:
      "Index and query entities across the solution. MiniSearch-backed in-memory engine behind a " +
      "SearchAdapter seam (ADR-0010). Facets computed in service code. Tenant-isolated per-index. " +
      "Generated from the Zod schemas in @dbp/ps-search (ADR-0013). Do not edit by hand.",
  },
  servers: [{ url: "/" }],
});

const header =
  "# GENERATED FILE — do not edit.\n" +
  "# Source of truth: Zod schemas in @dbp/ps-search (client/types.ts).\n" +
  "# Regenerate with: pnpm --filter @dbp/ps-search contracts:gen\n";
const yamlText = header + YAML.stringify(document);

const normalize = (text: string) => text.replace(/\r\n/g, "\n");

if (process.argv.includes("--check")) {
  if (!fs.existsSync(contractPath)) {
    console.error("contracts:check FAILED — contract.yaml is missing. Run contracts:gen.");
    process.exit(1);
  }
  const committed = normalize(fs.readFileSync(contractPath, "utf8"));
  if (committed !== normalize(yamlText)) {
    console.error(
      "contracts:check FAILED — contract.yaml is stale (drift from the Zod schemas). Run contracts:gen and commit.",
    );
    process.exit(1);
  }
  console.log("contracts:check passed — contract.yaml matches the Zod schemas.");
} else {
  fs.writeFileSync(contractPath, yamlText, "utf8");
  console.log(`contract.yaml written (${yamlText.split("\n").length} lines).`);
}
