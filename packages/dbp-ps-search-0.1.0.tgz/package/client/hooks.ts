import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { search, index, type SearchFilters, type SearchOptions } from "./sdk";
import type { IndexDoc, SearchHit, Facet } from "./types";

const searchKey = (query: string, filters: SearchFilters, options: SearchOptions) =>
  ["ps-search", "search", query, filters, options.page ?? 1, options.pageSize ?? 20] as const;

/**
 * Spec-contractual hook: useSearch(query, filters?) → { results, facets, loading }
 * Empty query is treated as a no-op (returns empty results immediately).
 */
export function useSearch(
  query: string,
  filters?: SearchFilters,
  options: SearchOptions = {},
): { results: SearchHit[]; facets: Facet[]; loading: boolean; total: number } {
  const normalizedFilters: SearchFilters = filters ?? {};
  const isEmptyQuery = query.trim() === "";

  const queryResult = useQuery({
    queryKey: searchKey(query, normalizedFilters, options),
    queryFn: () => search(query, normalizedFilters, options),
    enabled: !isEmptyQuery,
    staleTime: 5_000,
  });

  if (isEmptyQuery) {
    return { results: [], facets: [], loading: false, total: 0 };
  }

  return {
    results: queryResult.data?.results ?? [],
    facets: queryResult.data?.facets ?? [],
    total: queryResult.data?.total ?? 0,
    loading: queryResult.isLoading,
  };
}

/**
 * Spec-contractual function: index(entityType, doc) → Promise<void>
 * Also available as a mutation hook for React component use.
 */
export function useIndex() {
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: ({ entityType, doc }: { entityType: string; doc: IndexDoc }) =>
      index(entityType, doc),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["ps-search", "search"] });
    },
  });
  return mutation;
}
