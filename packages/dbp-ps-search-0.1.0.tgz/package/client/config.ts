export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

export type SearchClientConfig = {
  baseUrl: string;
  fetch: FetchLike;
  tenantId: string;
};

const defaults: SearchClientConfig = {
  baseUrl: "/api/platform/search",
  fetch: (input, init) => globalThis.fetch(input, init),
  tenantId: "default",
};

let current: SearchClientConfig = { ...defaults };

export function configureSearchClient(overrides: Partial<SearchClientConfig>): void {
  current = { ...current, ...overrides };
}

export function getSearchClientConfig(): SearchClientConfig {
  return current;
}

export function resetSearchClient(): void {
  current = { ...defaults };
}
