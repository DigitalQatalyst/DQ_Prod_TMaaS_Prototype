import { z } from "zod";

// ---------------------------------------------------------------------------
// Document model — what callers index into PS.SEARCH
// ---------------------------------------------------------------------------

export const SearchDocumentSchema = z
  .object({
    id: z.string().min(1),
    entityType: z.string().min(1),
    title: z.string().min(1),
    body: z.string().optional(),
    /** Flat key-value pairs used for field filters and facet computation. */
    fields: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).default({}),
    tenantId: z.string().min(1),
  })
  .strict();
export type SearchDocument = z.infer<typeof SearchDocumentSchema>;

// ---------------------------------------------------------------------------
// Indexing requests / responses
// ---------------------------------------------------------------------------

export const IndexDocSchema = SearchDocumentSchema.omit({ tenantId: true, entityType: true });
export type IndexDoc = z.infer<typeof IndexDocSchema>;

export const IndexRequestSchema = z
  .object({
    entityType: z.string().min(1),
    doc: IndexDocSchema,
  })
  .strict();
export type IndexRequest = z.infer<typeof IndexRequestSchema>;

// ---------------------------------------------------------------------------
// Query request (mirrors GET /search query-string params via Zod coercion)
// ---------------------------------------------------------------------------

export const SearchQuerySchema = z.object({
  q: z.string().default(""),
  filters: z
    .string()
    .optional()
    .transform((v) => {
      if (!v) return {};
      try {
        const parsed = JSON.parse(v) as unknown;
        return z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).parse(parsed);
      } catch {
        return {};
      }
    }),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});
export type SearchQuery = z.infer<typeof SearchQuerySchema>;

// ---------------------------------------------------------------------------
// Response model — contract types (MiniSearch never appears here)
// ---------------------------------------------------------------------------

export const SearchHitSchema = z
  .object({
    id: z.string(),
    entityType: z.string(),
    title: z.string(),
    score: z.number(),
    highlights: z.record(z.string(), z.string()).optional(),
  })
  .strict();
export type SearchHit = z.infer<typeof SearchHitSchema>;

export const FacetValueSchema = z.object({ value: z.string(), count: z.number().int().min(0) }).strict();
export type FacetValue = z.infer<typeof FacetValueSchema>;

export const FacetSchema = z.object({ field: z.string(), values: z.array(FacetValueSchema) }).strict();
export type Facet = z.infer<typeof FacetSchema>;

export const SearchResponseSchema = z
  .object({
    results: z.array(SearchHitSchema),
    facets: z.array(FacetSchema),
    total: z.number().int().min(0),
  })
  .strict();
export type SearchResponse = z.infer<typeof SearchResponseSchema>;

// ---------------------------------------------------------------------------
// Error response (shared shape with other PS.* services)
// ---------------------------------------------------------------------------

export const ValidationIssueSchema = z
  .object({ path: z.string(), message: z.string() })
  .strict();
export type ValidationIssue = z.infer<typeof ValidationIssueSchema>;

export const ErrorResponseSchema = z
  .object({
    error: z.string(),
    issues: z.array(ValidationIssueSchema).optional(),
  })
  .strict();
export type ErrorResponse = z.infer<typeof ErrorResponseSchema>;
