import { request } from "./http";
import type { SearchResponse, IndexDoc, SearchHit, Facet } from "./types";
export type { IndexDoc };

export type SearchFilters = Record<string, string | number | boolean>;

export type SearchResult = {
  results: SearchHit[];
  facets: Facet[];
  total: number;
};

export type SearchOptions = {
  page?: number;
  pageSize?: number;
};

export async function search(
  query: string,
  filters?: SearchFilters,
  options: SearchOptions = {},
): Promise<SearchResult> {
  const q: Record<string, string> = { q: query };
  if (filters && Object.keys(filters).length > 0) {
    q.filters = JSON.stringify(filters);
  }
  if (options.page !== undefined) q.page = String(options.page);
  if (options.pageSize !== undefined) q.pageSize = String(options.pageSize);
  return request<SearchResponse>("GET", "/search", { query: q });
}

export async function index(entityType: string, doc: IndexDoc): Promise<void> {
  await request<void>("POST", "/index", { body: { entityType, doc } });
}

export async function removeFromIndex(entityType: string, id: string): Promise<void> {
  await request<void>("DELETE", `/index/${entityType}/${id}`);
}
