export {
  configureSearchClient,
  getSearchClientConfig,
  resetSearchClient,
  type SearchClientConfig,
  type FetchLike,
} from "./config";
export { SearchServiceError } from "./http";
export {
  search,
  index,
  removeFromIndex,
  type SearchFilters,
  type SearchOptions,
  type SearchResult,
} from "./sdk";
export { useSearch, useIndex } from "./hooks";
export * from "./types";
