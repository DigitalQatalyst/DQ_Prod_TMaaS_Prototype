# PS.SEARCH — Search Service

| | |
|---|---|
| **Registry ID** | `PS.SEARCH` |
| **Package** | `@dbp/ps-search` (independent semver, currently `0.1.0`) |
| **Atomic class** | Integration |
| **Contract** | `contract.yaml` (OpenAPI 3.0.3, GENERATED — see below) |
| **Base path** | `/api/platform/search` |

## Purpose

Index and query entities across the solution. Solutions call `index(entityType, doc)` to register
searchable content and `useSearch(query, filters?)` to query it. No solution ever implements its
own search engine or inverted index.

## Client SDK (spec-contractual signatures)

```ts
useSearch(query, filters?)                          // { results, facets, loading, total }
index(entityType, doc)                              // Promise<void>
removeFromIndex(entityType, id)                     // Promise<void>
configureSearchClient({ baseUrl?, fetch?, tenantId? }) // default baseUrl /api/platform/search
```

`useSearch` treats an empty query as a no-op and returns `{ results: [], facets: [], loading: false, total: 0 }`
immediately, without issuing an HTTP request. This is intentional: a Phase-4 SearchBar binding
can safely render on every keystroke including the empty state without generating traffic.

Plus plain async functions: `search(query, filters?, options?)`, `index(entityType, doc)`,
`removeFromIndex(entityType, id)`.

## Document model

```ts
{
  id: string;           // caller-assigned, unique within tenant + entityType
  entityType: string;
  title: string;
  body?: string;        // full-text indexed; optional
  fields: Record<string, string | number | boolean>;  // for filters + facets
  tenantId: string;     // set by the server from x-tenant-id header
}
```

## Indexing

- `POST /index` — upsert: re-indexing the same `id` (same entityType + tenant) replaces the
  existing entry via MiniSearch's `replace()` API.
- `DELETE /index/{entityType}/{id}` — remove; no-op if not present (idempotent).

## Query

`GET /search?q=&filters=&page=&pageSize=`

Returns `{ results: SearchHit[], facets: Facet[], total }`.

- **Full-text:** MiniSearch with fuzzy distance 0.2 and prefix matching enabled; title boosted 2×.
- **Field filters:** `filters` query param is a JSON-encoded equality object,
  e.g. `{"status":"open","amount":100}`. Post-filtering applied after MiniSearch scoring.
- **Facets:** computed in service code over the full filtered result set, before pagination
  (ADR-0010). `entityType` is always faceted. Facet computation is ~O(n) over filtered hits.
- **Empty query:** returns all indexed documents for the tenant (full-scan over the parallel doc map).

## Adapter seam (ADR-0010)

The production engine is `MiniSearchAdapter` — a `SearchAdapter` interface implementation wrapping
`minisearch`. MiniSearch types never appear in the contract or SDK types. The adapter interface
(`index`/`remove`/`query`/`clear`) is the swap point for a future OpenSearch/Typesense adapter.
The parallel `allDocs` Map held in `MiniSearchAdapter` provides O(1) tenant-doc enumeration
without touching MiniSearch internals.

## Tenancy

Every operation is scoped by the `x-tenant-id` request header (400 if missing). The
`MiniSearchAdapter` maintains one `MiniSearch` instance per tenant — isolation is structural, not
filtered. A document with the same `id` in two tenants is stored in two completely separate
inverted indexes.

## Contract generation (ADR-0013)

`contract.yaml` is GENERATED from the Zod schemas — never edit it by hand.

- `pnpm --filter @dbp/ps-search contracts:gen` regenerates it (commit the result).
- `pnpm --filter @dbp/ps-search contracts:check` regenerates in memory and fails on drift;
  the pipeline `contract-drift` stage runs this repo-wide via `pnpm test:contracts`.

## Contract tests (ADR-0007)

`tests/pact.test.ts`: consumer suite drives this package's own client SDK against a Pact mock
(pact file written to `tests/pacts/`, gitignored); provider suite hosts the real handlers on
`node:http` and verifies the pact with state handlers seeding the in-memory adapter.
pact-core has no `win32-arm64` binary; the suite self-skips on that platform with a loud warning.

## SLO

**Query p95 < 200ms** for `GET /search` against a 500-document in-memory index,
measured handler-inclusive (dispatch → MiniSearch → facet computation → serialised response).
Measurement: `tests/slo.test.ts` samples 200 sequential queries per run and asserts the p95.
Once a real storage adapter lands, the same probe becomes the regression gate for the production SLO.

## Versioning

Independent semver. Breaking changes to any endpoint or SDK signature bump the major;
`contract.yaml`'s `info.version` tracks `package.json` automatically.
