// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import { resetSearchService, SEED_TENANT_ID, seedSearchService } from "../server/index";
import { OTHER_TENANT, rawRequest } from "./helpers/bind";

type SearchBody = { results: unknown[]; facets: unknown[]; total: number };

beforeEach(() => {
  resetSearchService();
});

describe("POST /index", () => {
  it("indexes a document and returns indexed: true", async () => {
    const res = await rawRequest("POST", "/index", {
      body: {
        entityType: "invoice",
        doc: { id: "doc-1", title: "Invoice 001", fields: { status: "open" } },
      },
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { indexed: boolean };
    expect(body.indexed).toBe(true);
  });

  it("upserts: re-indexing the same id replaces the document", async () => {
    const docPayload = (title: string) => ({
      entityType: "invoice",
      doc: { id: "doc-upsert", title, fields: { status: "open" } },
    });
    await rawRequest("POST", "/index", { body: docPayload("Original Title") });
    await rawRequest("POST", "/index", { body: docPayload("Updated Title") });

    const search = await rawRequest("GET", "/search", { query: { q: "Updated" } });
    const body = (await search.json()) as SearchBody;
    expect(body.total).toBe(1);
    expect((body.results[0] as { title: string }).title).toBe("Updated Title");
  });

  it("requires x-tenant-id header", async () => {
    const res = await rawRequest("POST", "/index", {
      body: { entityType: "invoice", doc: { id: "doc-1", title: "Test", fields: {} } },
      tenantId: null,
    });
    expect(res.status).toBe(400);
  });

  it("rejects malformed body", async () => {
    const res = await rawRequest("POST", "/index", { body: { entityType: "" } });
    expect(res.status).toBe(400);
    const body = (await res.json()) as { issues: unknown[] };
    expect(body.issues?.length).toBeGreaterThan(0);
  });
});

describe("DELETE /index/:entityType/:id", () => {
  it("removes an indexed document", async () => {
    await rawRequest("POST", "/index", {
      body: { entityType: "invoice", doc: { id: "doc-del", title: "To Delete", fields: {} } },
    });

    const before = (await (await rawRequest("GET", "/search", { query: { q: "Delete" } })).json()) as SearchBody;
    expect(before.total).toBe(1);

    const del = await rawRequest("DELETE", `/index/invoice/doc-del`);
    expect(del.status).toBe(204);

    const after = (await (await rawRequest("GET", "/search", { query: { q: "Delete" } })).json()) as SearchBody;
    expect(after.total).toBe(0);
  });

  it("is a no-op when document does not exist (idempotent)", async () => {
    const res = await rawRequest("DELETE", "/index/invoice/nonexistent-id");
    expect(res.status).toBe(204);
  });

  it("requires x-tenant-id header", async () => {
    const res = await rawRequest("DELETE", "/index/invoice/doc-1", { tenantId: null });
    expect(res.status).toBe(400);
  });
});

describe("GET /search", () => {
  beforeEach(async () => {
    // Seed 3 invoices + 1 customer for tenant TEST_TENANT
    const docs = [
      { id: "inv-1", title: "Invoice Alpha Project", body: "consulting fee", fields: { status: "open", amount: 100 } },
      { id: "inv-2", title: "Invoice Beta Services", body: "licence renewal", fields: { status: "paid", amount: 200 } },
      { id: "inv-3", title: "Invoice Gamma Goods", body: "purchase order", fields: { status: "open", amount: 300 } },
      { id: "cust-1", title: "Delta Customer", body: "enterprise account", fields: { tier: "enterprise" } },
    ];
    const entityTypes: Record<string, string> = {
      "inv-1": "invoice",
      "inv-2": "invoice",
      "inv-3": "invoice",
      "cust-1": "customer",
    };
    for (const doc of docs) {
      await rawRequest("POST", "/index", {
        body: { entityType: entityTypes[doc.id], doc },
      });
    }
  });

  it("returns results + facets + total for a text query", async () => {
    const res = await rawRequest("GET", "/search", { query: { q: "Invoice" } });
    expect(res.status).toBe(200);
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBe(3);
    expect(body.results).toHaveLength(3);
    expect(Array.isArray(body.facets)).toBe(true);
    const entityTypeFacet = (body.facets as Array<{ field: string; values: unknown[] }>).find(
      (f) => f.field === "entityType",
    );
    expect(entityTypeFacet).toBeDefined();
    expect(entityTypeFacet?.values).toHaveLength(1);
  });

  it("fuzzy matches with minor typo", async () => {
    const res = await rawRequest("GET", "/search", { query: { q: "Invoic" } });
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBeGreaterThan(0);
  });

  it("prefix matches partial word", async () => {
    const res = await rawRequest("GET", "/search", { query: { q: "Alph" } });
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBeGreaterThan(0);
  });

  it("applies field-equality filters post-search", async () => {
    const res = await rawRequest("GET", "/search", {
      query: { q: "Invoice", filters: JSON.stringify({ status: "open" }) },
    });
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBe(2);
  });

  it("facets entityType over filtered result set", async () => {
    // All 4 docs: 3 invoice + 1 customer
    const res = await rawRequest("GET", "/search", { query: { q: "Delta" } });
    const body = (await res.json()) as SearchBody;
    const facet = (body.facets as Array<{ field: string; values: Array<{ value: string; count: number }> }>).find(
      (f) => f.field === "entityType",
    );
    expect(facet?.values.find((v) => v.value === "customer")?.count).toBe(1);
  });

  it("paginates results with correct total", async () => {
    const res = await rawRequest("GET", "/search", {
      query: { q: "Invoice", page: "1", pageSize: "2" },
    });
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBe(3);
    expect(body.results).toHaveLength(2);
  });

  it("returns empty results for unmatched query, facets still present", async () => {
    const res = await rawRequest("GET", "/search", { query: { q: "zzznomatch999" } });
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBe(0);
    expect(body.results).toHaveLength(0);
    expect(Array.isArray(body.facets)).toBe(true);
  });

  it("empty query is a no-op (returns all docs)", async () => {
    const res = await rawRequest("GET", "/search", { query: { q: "" } });
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBe(4);
  });

  it("requires x-tenant-id", async () => {
    const res = await rawRequest("GET", "/search", { query: { q: "Invoice" }, tenantId: null });
    expect(res.status).toBe(400);
  });
});

describe("Tenant isolation", () => {
  it("same doc id in two tenants never crosses", async () => {
    // Use fully distinct titles so MiniSearch fuzzy cannot cross-match
    await rawRequest("POST", "/index", {
      body: { entityType: "invoice", doc: { id: "shared-id", title: "AlphaDocs Unique Record", fields: {} } },
    });
    await rawRequest("POST", "/index", {
      body: { entityType: "invoice", doc: { id: "shared-id", title: "BetaDocs Exclusive Record", fields: {} } },
      tenantId: OTHER_TENANT,
    });

    const tenantA = (await (
      await rawRequest("GET", "/search", { query: { q: "AlphaDocs" } })
    ).json()) as SearchBody;
    expect(tenantA.total).toBe(1);
    expect((tenantA.results[0] as { title: string }).title).toContain("AlphaDocs");

    const tenantB = (await (
      await rawRequest("GET", "/search", { query: { q: "BetaDocs" }, tenantId: OTHER_TENANT })
    ).json()) as SearchBody;
    expect(tenantB.total).toBe(1);
    expect((tenantB.results[0] as { title: string }).title).toContain("BetaDocs");

    // Tenant A cannot see Tenant B's doc
    const crossCheck = (await (
      await rawRequest("GET", "/search", { query: { q: "BetaDocs" } })
    ).json()) as SearchBody;
    expect(crossCheck.total).toBe(0);
  });

  it("deleting from one tenant does not affect another", async () => {
    await rawRequest("POST", "/index", {
      body: { entityType: "note", doc: { id: "note-1", title: "Shared Note", fields: {} } },
    });
    await rawRequest("POST", "/index", {
      body: { entityType: "note", doc: { id: "note-1", title: "Shared Note", fields: {} } },
      tenantId: OTHER_TENANT,
    });

    await rawRequest("DELETE", "/index/note/note-1"); // deletes from TEST_TENANT only

    const tenantA = (await (
      await rawRequest("GET", "/search", { query: { q: "Shared" } })
    ).json()) as SearchBody;
    expect(tenantA.total).toBe(0);

    const tenantB = (await (
      await rawRequest("GET", "/search", { query: { q: "Shared" }, tenantId: OTHER_TENANT })
    ).json()) as SearchBody;
    expect(tenantB.total).toBe(1);
  });
});

describe("Dispatch", () => {
  it("404s unknown routes", async () => {
    const res = await rawRequest("GET", "/nope");
    expect(res.status).toBe(404);
  });
});

describe("Seed fixtures", () => {
  it("seeds deterministic demo data", async () => {
    seedSearchService();
    const res = await rawRequest("GET", "/search", {
      query: { q: "Invoice" },
      tenantId: SEED_TENANT_ID,
    });
    const body = (await res.json()) as SearchBody;
    expect(body.total).toBeGreaterThan(0);
  });
});
