import { createElement } from "react";
import { renderHook, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { beforeEach, describe, expect, it } from "vitest";
import { resetSearchService } from "../server/index";
import { useSearch, useIndex } from "../client/index";
import { bindClientToHandlers } from "./helpers/bind";

function makeWrapper() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  const Wrapper = ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client }, children);
  return Wrapper;
}

beforeEach(() => {
  resetSearchService();
  bindClientToHandlers();
});

describe("useSearch hook", () => {
  it("returns empty state for empty query (no-op)", () => {
    const { result } = renderHook(() => useSearch(""), { wrapper: makeWrapper() });
    expect(result.current.loading).toBe(false);
    expect(result.current.results).toEqual([]);
    expect(result.current.facets).toEqual([]);
    expect(result.current.total).toBe(0);
  });

  it("returns results + facets when query is non-empty", async () => {
    // Pre-index via the adapter directly for isolation
    const { getSearchService } = await import("../server/index");
    getSearchService().adapter.index({
      id: "hook-doc-1",
      entityType: "invoice",
      tenantId: "tenant-a",
      title: "Hook Invoice Test",
      body: "",
      fields: {},
    });

    const { result } = renderHook(() => useSearch("Hook"), { wrapper: makeWrapper() });

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.total).toBe(1);
    expect(result.current.results).toHaveLength(1);
    expect(result.current.facets.length).toBeGreaterThan(0);
  });
});

describe("useIndex hook", () => {
  it("exposes a mutation that indexes a document", async () => {
    const { result } = renderHook(() => useIndex(), { wrapper: makeWrapper() });

    void result.current.mutate({
      entityType: "invoice",
      doc: { id: "hook-idx-1", title: "Hook Indexed Doc", fields: {} },
    });

    await waitFor(() => {
      expect(result.current.isSuccess).toBe(true);
    });
  });
});
