// @vitest-environment node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { beforeAll, describe, expect, it } from "vitest";
import type { SearchHit } from "../client/types";
import {
  configureSearchClient,
  search,
  index,
} from "../client/index";
import { getSearchService, resetSearchService } from "../server/index";
import { TEST_TENANT } from "./helpers/bind";
import { startHandlerServer } from "./helpers/node-server";

/*
 * pact-core ships native binaries for these platforms only. Importing
 * @pact-foundation/pact on any other platform throws at module load, so the
 * import is dynamic and the suite self-skips (CI on linux-x64 always runs it).
 */
const PACT_PLATFORMS = ["darwin-arm64", "darwin-x64", "linux-arm64", "linux-x64", "win32-x64"];
const hostPlatform = `${process.platform}-${process.arch}`;
const pactSupported = PACT_PLATFORMS.includes(hostPlatform);
if (!pactSupported) {
  console.warn(
    `PACT TESTS SKIPPED: pact-core has no native binary for ${hostPlatform}. ` +
      `Run the suite on one of: ${PACT_PLATFORMS.join(", ")}.`,
  );
}

type PactModule = typeof import("@pact-foundation/pact");
let pact: PactModule;

const pactDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "pacts");
const CONSUMER = "dbp-ps-search-client";
const PROVIDER = "dbp-ps-search";

const tenantHeaders = { "x-tenant-id": TEST_TENANT };
const jsonHeaders = { ...tenantHeaders, "content-type": "application/json" };

function newPact(): InstanceType<PactModule["PactV3"]> {
  return new pact.PactV3({ consumer: CONSUMER, provider: PROVIDER, dir: pactDir });
}

function bindClientTo(mockServerUrl: string): void {
  configureSearchClient({
    baseUrl: `${mockServerUrl}/api/platform/search`,
    fetch: (input, init) => globalThis.fetch(input, init),
    tenantId: TEST_TENANT,
  });
}

describe.skipIf(!pactSupported)("Pact — consumer (client SDK against the mock provider)", () => {
  beforeAll(async () => {
    pact = await import("@pact-foundation/pact");
  });

  it("indexes a document", async () => {
    const provider = newPact();
    provider
      .given("the search index is empty")
      .uponReceiving("a request to index a document")
      .withRequest({
        method: "POST",
        path: "/api/platform/search/index",
        headers: jsonHeaders,
        body: {
          entityType: "invoice",
          doc: { id: "pact-inv-1", title: "Pact Invoice", fields: { status: "open" } },
        },
      })
      .willRespondWith({
        status: 200,
        headers: { "content-type": "application/json" },
        body: pact.MatchersV3.like({ indexed: true }),
      });

    await provider.executeTest(async (mockServer) => {
      bindClientTo(mockServer.url);
      await expect(
        index("invoice", { id: "pact-inv-1", title: "Pact Invoice", fields: { status: "open" } }),
      ).resolves.toBeUndefined();
    });
  });

  it("searches and receives results", async () => {
    const { eachLike, like, decimal, integer } = pact.MatchersV3;
    const provider = newPact();
    provider
      .given("a document with title 'Pact Invoice' is indexed for the tenant")
      .uponReceiving("a search query for 'Pact'")
      .withRequest({
        method: "GET",
        path: "/api/platform/search/search",
        query: { q: "Pact" },
        headers: tenantHeaders,
      })
      .willRespondWith({
        status: 200,
        headers: { "content-type": "application/json" },
        body: {
          results: eachLike({
            id: like("pact-inv-1"),
            entityType: like("invoice"),
            title: like("Pact Invoice"),
            score: decimal(1.0),
          }),
          facets: eachLike({ field: like("entityType"), values: eachLike({ value: like("invoice"), count: integer(1) }) }),
          total: integer(1),
        },
      });

    await provider.executeTest(async (mockServer) => {
      bindClientTo(mockServer.url);
      const result = await search("Pact");
      expect(result.total).toBeGreaterThan(0);
      expect(result.results.length).toBeGreaterThan(0);
      const hit = result.results[0] as SearchHit;
      expect(hit.id).toBe("pact-inv-1");
    });
  });
});

describe.skipIf(!pactSupported)("Pact — provider (handlers on node:http verify the pact)", () => {
  beforeAll(async () => {
    pact = await import("@pact-foundation/pact");
  });

  it("verifies every interaction in the generated pact file", async () => {
    const pactFile = path.join(pactDir, `${CONSUMER}-${PROVIDER}.json`);
    expect(fs.existsSync(pactFile)).toBe(true);

    const server = await startHandlerServer();
    try {
      const output = await new pact.Verifier({
        provider: PROVIDER,
        providerBaseUrl: server.url,
        pactUrls: [pactFile],
        logLevel: "error",
        stateHandlers: {
          "the search index is empty": async () => {
            resetSearchService();
            return "reset";
          },
          "a document with title 'Pact Invoice' is indexed for the tenant": async () => {
            resetSearchService();
            getSearchService().adapter.index({
              id: "pact-inv-1",
              entityType: "invoice",
              tenantId: TEST_TENANT,
              title: "Pact Invoice",
              body: "",
              fields: { status: "open" },
            });
            return "seeded";
          },
        },
      }).verifyProvider();
      expect(output).toContain("finished");
    } finally {
      await server.close();
    }
  });
});
