// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import { resetSearchService } from "../server/index";
import { search, index, removeFromIndex, SearchServiceError } from "../client/index";
import { bindClientToHandlers } from "./helpers/bind";

beforeEach(() => {
  resetSearchService();
  bindClientToHandlers();
});

describe("index() SDK function", () => {
  it("indexes a document without throwing", async () => {
    await expect(
      index("invoice", { id: "sdk-1", title: "SDK Invoice", fields: { status: "open" } }),
    ).resolves.toBeUndefined();
  });
});

describe("search() SDK function", () => {
  beforeEach(async () => {
    await index("invoice", { id: "sdk-inv-1", title: "Acme Invoice Alpha", fields: { status: "open" } });
    await index("invoice", { id: "sdk-inv-2", title: "Beta Invoice Paid", fields: { status: "paid" } });
    await index("customer", { id: "sdk-cust-1", title: "Customer Gamma", fields: { region: "UAE" } });
  });

  it("returns results, facets, and total", async () => {
    const result = await search("Invoice");
    expect(result.total).toBe(2);
    expect(result.results).toHaveLength(2);
    expect(result.facets.length).toBeGreaterThan(0);
  });

  it("filters by field equality", async () => {
    const result = await search("Invoice", { status: "paid" });
    expect(result.total).toBe(1);
    expect((result.results[0] as { id: string }).id).toBe("sdk-inv-2");
  });

  it("returns empty for no-match query", async () => {
    const result = await search("zzznomatch");
    expect(result.total).toBe(0);
    expect(result.results).toHaveLength(0);
  });

  it("empty query returns all docs", async () => {
    const result = await search("");
    expect(result.total).toBe(3);
  });

  it("paginates correctly", async () => {
    const page1 = await search("Invoice", {}, { page: 1, pageSize: 1 });
    expect(page1.results).toHaveLength(1);
    expect(page1.total).toBe(2);
  });
});

describe("removeFromIndex() SDK function", () => {
  it("removes an indexed document", async () => {
    await index("invoice", { id: "to-remove", title: "Remove Me", fields: {} });
    const before = await search("Remove");
    expect(before.total).toBe(1);

    await removeFromIndex("invoice", "to-remove");
    const after = await search("Remove");
    expect(after.total).toBe(0);
  });
});

describe("SearchServiceError", () => {
  it("is thrown when tenant header is missing", async () => {
    bindClientToHandlers();
    // Override to send no tenant
    const { configureSearchClient } = await import("../client/index");
    configureSearchClient({
      baseUrl: "http://ps-search.test/api/platform/search",
      tenantId: "",
    });
    await expect(search("test")).rejects.toBeInstanceOf(SearchServiceError);
  });
});
