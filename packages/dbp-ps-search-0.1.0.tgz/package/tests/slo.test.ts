// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import { getSearchService, resetSearchService } from "../server/index";
import { rawRequest } from "./helpers/bind";

/*
 * SLO check from SERVICE.md: search query p95 < 200ms against the
 * in-memory MiniSearch adapter, measured handler-inclusive (dispatch → adapter → response).
 * Seeded with 500 documents to simulate realistic load.
 */
describe("SLO — query latency", () => {
  beforeEach(() => {
    resetSearchService();
    const adapter = getSearchService().adapter;
    for (let i = 0; i < 500; i += 1) {
      adapter.index({
        id: `slo-doc-${String(i).padStart(4, "0")}`,
        entityType: i % 2 === 0 ? "invoice" : "customer",
        tenantId: "tenant-slo",
        title: `Document title ${i} with some extra content`,
        body: `Body text for document ${i}, containing various terms for indexing.`,
        fields: { status: i % 3 === 0 ? "open" : "closed", amount: i * 10 },
      });
    }
  });

  it("keeps GET /search p95 under 200ms against a 500-document index", async () => {
    const samples: number[] = [];
    for (let i = 0; i < 200; i += 1) {
      const start = performance.now();
      const response = await rawRequest("GET", "/search", {
        query: { q: "Document title", pageSize: "20" },
        tenantId: "tenant-slo",
      });
      await response.json();
      samples.push(performance.now() - start);
      expect(response.status).toBe(200);
    }
    samples.sort((a, b) => a - b);
    const p95 = samples[Math.floor(samples.length * 0.95)] ?? Number.POSITIVE_INFINITY;
    expect(p95).toBeLessThan(200);
  });
});
