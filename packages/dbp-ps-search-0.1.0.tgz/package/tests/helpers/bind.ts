import { configureSearchClient } from "../../client/index";
import { dispatch } from "../../server/index";

export const TEST_TENANT = "tenant-a";
export const OTHER_TENANT = "tenant-b";

export function bindClientToHandlers(tenantId = TEST_TENANT): void {
  configureSearchClient({
    baseUrl: "http://ps-search.test/api/platform/search",
    fetch: (input, init) => dispatch(new Request(input, init)),
    tenantId,
  });
}

export function rawRequest(
  method: string,
  path: string,
  options: { body?: unknown; tenantId?: string | null; query?: Record<string, string> } = {},
): Promise<Response> {
  const headers: Record<string, string> = {};
  if (options.tenantId !== null) headers["x-tenant-id"] = options.tenantId ?? TEST_TENANT;
  if (options.body !== undefined) headers["content-type"] = "application/json";
  const base = `http://ps-search.test/api/platform/search${path}`;
  const url =
    options.query && Object.keys(options.query).length > 0
      ? `${base}?${new URLSearchParams(options.query).toString()}`
      : base;
  return dispatch(
    new Request(url, {
      method,
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : null,
    }),
  );
}
