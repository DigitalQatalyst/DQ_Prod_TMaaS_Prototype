import {
  IndexRequestSchema,
  SearchQuerySchema,
  type ValidationIssue,
} from "../client/types";
import { getSearchService } from "./service";

export const BASE_PATH = "/api/platform/search";

export type RouteHandler = (req: Request) => Promise<Response>;

export type RouteDefinition = {
  method: "GET" | "POST" | "DELETE";
  path: string;
  handler: RouteHandler;
};

const json = (status: number, body: unknown): Response =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });

const errorResponse = (status: number, message: string, issues?: ValidationIssue[]): Response =>
  json(status, issues && issues.length > 0 ? { error: message, issues } : { error: message });

function pathSegments(req: Request): string[] {
  const { pathname } = new URL(req.url);
  if (!pathname.startsWith(BASE_PATH)) return [];
  return pathname
    .slice(BASE_PATH.length)
    .split("/")
    .filter(Boolean)
    .map(decodeURIComponent);
}

function tenantOf(req: Request): string | null {
  const tenantId = req.headers.get("x-tenant-id")?.trim();
  return tenantId ? tenantId : null;
}

async function readJsonBody(req: Request): Promise<{ ok: true; value: unknown } | { ok: false }> {
  try {
    return { ok: true, value: await req.json() };
  } catch {
    return { ok: false };
  }
}

const zodIssues = (issues: { path: (string | number)[]; message: string }[]): ValidationIssue[] =>
  issues.map((issue) => ({ path: issue.path.join(".") || "(root)", message: issue.message }));

export const searchHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const params = new URL(req.url).searchParams;
  const rawQuery: Record<string, string> = {};
  for (const [k, v] of params.entries()) rawQuery[k] = v;

  const parsed = SearchQuerySchema.safeParse(rawQuery);
  if (!parsed.success) {
    return errorResponse(400, "invalid search query", zodIssues(parsed.error.issues));
  }

  const { q, filters, page, pageSize } = parsed.data;
  const result = getSearchService().adapter.query(tenantId, { q, filters, page, pageSize });

  return json(200, result);
};

export const indexHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");

  const parsed = IndexRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid index request", zodIssues(parsed.error.issues));
  }

  const { entityType, doc } = parsed.data;
  getSearchService().adapter.index({
    ...doc,
    entityType,
    tenantId,
  });

  return json(200, { indexed: true });
};

export const removeFromIndexHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const [, entityType, id] = pathSegments(req);
  if (!entityType || !id) return errorResponse(400, "entityType and id are required");

  getSearchService().adapter.remove(tenantId, entityType, id);
  return new Response(null, { status: 204 });
};

export const routes: RouteDefinition[] = [
  { method: "GET", path: `${BASE_PATH}/search`, handler: searchHandler },
  { method: "POST", path: `${BASE_PATH}/index`, handler: indexHandler },
  { method: "DELETE", path: `${BASE_PATH}/index/:entityType/:id`, handler: removeFromIndexHandler },
];

function matchesPattern(pattern: string, pathname: string): boolean {
  const expected = pattern.split("/").filter(Boolean);
  const actual = pathname.split("/").filter(Boolean);
  if (expected.length !== actual.length) return false;
  return expected.every((segment, index) => segment.startsWith(":") || segment === actual[index]);
}

export const dispatch: RouteHandler = async (req) => {
  const { pathname } = new URL(req.url);
  for (const route of routes) {
    if (route.method === req.method && matchesPattern(route.path, pathname)) {
      return route.handler(req);
    }
  }
  return errorResponse(404, `no PS.SEARCH route for ${req.method} ${pathname}`);
};
