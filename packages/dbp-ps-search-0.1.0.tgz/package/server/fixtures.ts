import type { SearchDocument } from "../client/types";
import { getSearchService, type SearchService } from "./service";

export const SEED_TENANT_ID = "tenant-demo";
export const OTHER_SEED_TENANT_ID = "tenant-demo-b";

export const seedDocuments: SearchDocument[] = [
  {
    id: "a1b2c3d4-0001-4000-8000-000000000001",
    entityType: "invoice",
    tenantId: SEED_TENANT_ID,
    title: "Invoice INV-2026-001",
    body: "Payment due for consulting services delivered in Q1.",
    fields: { status: "open", amount: 5000, currency: "AED" },
  },
  {
    id: "a1b2c3d4-0001-4000-8000-000000000002",
    entityType: "invoice",
    tenantId: SEED_TENANT_ID,
    title: "Invoice INV-2026-002",
    body: "Renewal of annual software licence.",
    fields: { status: "paid", amount: 12000, currency: "AED" },
  },
  {
    id: "a1b2c3d4-0001-4000-8000-000000000003",
    entityType: "customer",
    tenantId: SEED_TENANT_ID,
    title: "Acme Corp",
    body: "Enterprise customer in the UAE market.",
    fields: { region: "UAE", tier: "enterprise" },
  },
];

export function seedSearchService(target: SearchService = getSearchService()): void {
  for (const doc of seedDocuments) {
    target.adapter.index(doc);
  }
}
