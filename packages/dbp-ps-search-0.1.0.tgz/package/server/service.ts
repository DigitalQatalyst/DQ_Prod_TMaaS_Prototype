import { MiniSearchAdapter, type SearchAdapter } from "./adapter";

export type SearchService = {
  adapter: SearchAdapter;
};

let service: SearchService = {
  adapter: new MiniSearchAdapter(),
};

export function getSearchService(): SearchService {
  return service;
}

export function configureSearchService(overrides: Partial<SearchService>): SearchService {
  service = { ...service, ...overrides };
  return service;
}

export function resetSearchService(): SearchService {
  service = { adapter: new MiniSearchAdapter() };
  return service;
}
