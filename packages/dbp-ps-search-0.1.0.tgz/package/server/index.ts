export {
  BASE_PATH,
  dispatch,
  indexHandler,
  removeFromIndexHandler,
  routes,
  searchHandler,
  type RouteDefinition,
  type RouteHandler,
} from "./handlers";
export {
  MiniSearchAdapter,
  type SearchAdapter,
  type SearchAdapterQueryOptions,
  type SearchAdapterQueryResult,
  type SearchFilters,
} from "./adapter";
export {
  configureSearchService,
  getSearchService,
  resetSearchService,
  type SearchService,
} from "./service";
export {
  SEED_TENANT_ID,
  OTHER_SEED_TENANT_ID,
  seedDocuments,
  seedSearchService,
} from "./fixtures";
