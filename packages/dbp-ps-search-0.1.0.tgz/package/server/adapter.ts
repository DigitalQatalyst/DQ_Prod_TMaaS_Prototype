import MiniSearch from "minisearch";
import type { SearchDocument, SearchHit, Facet } from "../client/types";

// ---------------------------------------------------------------------------
// SearchAdapter — the seam for future production engines (ADR-0010)
// ---------------------------------------------------------------------------

export type SearchFilters = Record<string, string | number | boolean>;

export type SearchAdapterQueryOptions = {
  q: string;
  filters?: SearchFilters;
  page: number;
  pageSize: number;
};

export type SearchAdapterQueryResult = {
  results: SearchHit[];
  facets: Facet[];
  total: number;
};

export interface SearchAdapter {
  index(doc: SearchDocument): void;
  remove(tenantId: string, entityType: string, id: string): void;
  query(tenantId: string, options: SearchAdapterQueryOptions): SearchAdapterQueryResult;
  clear(): void;
}

// ---------------------------------------------------------------------------
// Internal document type stored in MiniSearch — never exposed beyond this file
// ---------------------------------------------------------------------------

type IndexedDoc = {
  /** Compound key: tenantId::entityType::id */
  _key: string;
  id: string;
  entityType: string;
  tenantId: string;
  title: string;
  body: string;
  fields: Record<string, string | number | boolean>;
};

type ScoredDoc = IndexedDoc & { score: number; match: Record<string, string[]> };

// ---------------------------------------------------------------------------
// MiniSearchAdapter
// ---------------------------------------------------------------------------

export class MiniSearchAdapter implements SearchAdapter {
  /**
   * One MiniSearch instance per tenant.
   * Tenant isolation is structural: separate instances, separate inverted indexes.
   */
  private readonly indexes = new Map<string, MiniSearch<IndexedDoc>>();

  /**
   * Parallel store for O(1) all-doc enumeration (needed for empty-query path
   * and facet computation without relying on MiniSearch internals).
   * Keyed by _key.
   */
  private readonly allDocs = new Map<string, Map<string, IndexedDoc>>();

  /** entityType is always faceted per spec. Additional fields can be added here. */
  private readonly facetFields: readonly string[] = ["entityType"];

  private getOrCreateIndex(tenantId: string): MiniSearch<IndexedDoc> {
    let ms = this.indexes.get(tenantId);
    if (!ms) {
      ms = new MiniSearch<IndexedDoc>({
        idField: "_key",
        fields: ["title", "body", "entityType"],
        storeFields: ["id", "entityType", "tenantId", "title", "body", "fields"],
        searchOptions: {
          boost: { title: 2 },
          fuzzy: 0.2,
          prefix: true,
        },
      });
      this.indexes.set(tenantId, ms);
    }
    return ms;
  }

  private getOrCreateAllDocs(tenantId: string): Map<string, IndexedDoc> {
    let docs = this.allDocs.get(tenantId);
    if (!docs) {
      docs = new Map();
      this.allDocs.set(tenantId, docs);
    }
    return docs;
  }

  index(doc: SearchDocument): void {
    const ms = this.getOrCreateIndex(doc.tenantId);
    const tenantDocs = this.getOrCreateAllDocs(doc.tenantId);

    const key = `${doc.tenantId}::${doc.entityType}::${doc.id}`;
    const indexed: IndexedDoc = {
      _key: key,
      id: doc.id,
      entityType: doc.entityType,
      tenantId: doc.tenantId,
      title: doc.title,
      body: doc.body ?? "",
      fields: doc.fields,
    };

    // Upsert: replace existing doc if present
    if (ms.has(key)) {
      const existing = tenantDocs.get(key);
      if (existing) ms.replace(indexed);
      else {
        ms.remove(indexed);
        ms.add(indexed);
      }
    } else {
      ms.add(indexed);
    }

    tenantDocs.set(key, indexed);
  }

  remove(tenantId: string, entityType: string, id: string): void {
    const ms = this.indexes.get(tenantId);
    const tenantDocs = this.allDocs.get(tenantId);
    if (!ms || !tenantDocs) return;

    const key = `${tenantId}::${entityType}::${id}`;
    const existing = tenantDocs.get(key);
    if (!existing) return;

    if (ms.has(key)) ms.remove(existing);
    tenantDocs.delete(key);
  }

  query(tenantId: string, options: SearchAdapterQueryOptions): SearchAdapterQueryResult {
    const ms = this.indexes.get(tenantId);
    const tenantDocs = this.allDocs.get(tenantId);

    if (!ms || !tenantDocs || tenantDocs.size === 0) {
      return { results: [], facets: this.emptyFacets(), total: 0 };
    }

    const { q, filters, page, pageSize } = options;

    // Candidate pool: empty query returns all docs, non-empty runs MiniSearch
    let candidates: Array<IndexedDoc & { score: number }>;
    if (q.trim() === "") {
      candidates = Array.from(tenantDocs.values()).map((doc) => ({ ...doc, score: 0 }));
    } else {
      // MiniSearch stores the declared storeFields on each result at runtime,
      // but its TypeScript signature only exposes SearchResult. Cast through unknown
      // to access the stored fields we declared in the MiniSearch constructor.
      const hits = (ms.search(q) as unknown) as ScoredDoc[];
      candidates = hits.map((hit) => ({
        _key: hit._key,
        id: hit.id,
        entityType: hit.entityType,
        tenantId: hit.tenantId,
        title: hit.title,
        body: hit.body,
        fields: hit.fields,
        score: hit.score,
        match: hit.match,
      }));
    }

    // Field-equality post-filtering
    const filtered = candidates.filter((hit) => {
      if (!filters || Object.keys(filters).length === 0) return true;
      return Object.entries(filters).every(([field, expected]) => {
        if (field === "entityType") return hit.entityType === String(expected);
        return hit.fields[field] === expected;
      });
    });

    const total = filtered.length;

    // Pagination
    const start = (page - 1) * pageSize;
    const pageHits = filtered.slice(start, start + pageSize);

    const results: SearchHit[] = pageHits.map((hit) => {
      const typedHit = hit as IndexedDoc & { score: number; match?: Record<string, string[]> };
      const highlights: Record<string, string> | undefined =
        typedHit.match && Object.keys(typedHit.match).length > 0
          ? Object.fromEntries(
              Object.entries(typedHit.match).map(([field, terms]) => [field, terms.join(", ")]),
            )
          : undefined;
      return {
        id: hit.id,
        entityType: hit.entityType,
        title: hit.title,
        score: hit.score,
        ...(highlights ? { highlights } : {}),
      };
    });

    // Facets computed over the full filtered set (before pagination) — ADR-0010
    const facets = this.computeFacets(filtered);

    return { results, facets, total };
  }

  private computeFacets(docs: Array<IndexedDoc & { score: number }>): Facet[] {
    return this.facetFields.map((field) => {
      const counts = new Map<string, number>();
      for (const doc of docs) {
        const raw = field === "entityType" ? doc.entityType : doc.fields[field];
        if (raw !== undefined && raw !== null) {
          const value = String(raw);
          counts.set(value, (counts.get(value) ?? 0) + 1);
        }
      }
      const values = Array.from(counts.entries())
        .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
        .map(([value, count]) => ({ value, count }));
      return { field, values };
    });
  }

  private emptyFacets(): Facet[] {
    return this.facetFields.map((field) => ({ field, values: [] }));
  }

  clear(): void {
    this.indexes.clear();
    this.allDocs.clear();
  }
}
