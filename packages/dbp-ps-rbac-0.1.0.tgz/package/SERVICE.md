# PS.RBAC — Roles & Permissions

| | |
|---|---|
| Registry ID | `PS.RBAC` |
| Atomic class | Control |
| Package | `@dbp/ps-rbac` (semver, independently versioned — currently `0.1.0`) |
| Contract | `contract.yaml` (OpenAPI 3.0.3, GENERATED from Zod per ADR-0013 — never edit by hand) |
| Base path | `/api/platform/rbac` |

## Purpose

Authorize actions against roles and resource scopes. Built once at Layer 06; solutions consume
the client SDK and never re-implement authorization. The engine is `@casl/ability` (ADR-0012)
on both client and server — the same evaluation logic runs in-process on the client for
sub-10ms cached checks.

## Surface

- **Server** (`@dbp/ps-rbac/server`): framework-free fetch-API handlers
  (`(req: Request) => Promise<Response>`, Next 15 route-handler compatible).
  - `GET /api/platform/rbac/matrix` — role/permission catalogue + policy matrix (no auth required).
  - `GET /api/platform/rbac/rules` — packed CASL rules for the session subject (requires session header).
  - `POST /api/platform/rbac/check` — server-side permission check for the session subject.
  - `routes` manifest, `dispatch(req)` router.
  - `can(session, action, resource?)` — synchronous server-side helper; no handler call needed.
- **Client** (`@dbp/ps-rbac/client`):
  - `useCan(action, resource?)` — evaluates locally from cached packed rules; returns `false`
    while loading. No per-check network call.
  - `<Gate action="..." resource="...">` — in-house component over `useCan`; no `@casl/react` dep.
  - `fetchMatrix()`, `fetchPackedRules(headers?)`, `checkPermission(body)` — async SDK functions.
  - `configureRbacClient({ baseUrl?, fetch? })`, `getRbacClientConfig()`, `resetRbacClient()`.

## CASL containment (ADR-0012)

CASL is a runtime dependency on both sides but it is **never exposed in the contract**.
- The OpenAPI contract (`contract.yaml`) exposes service-owned types only:
  `{ roles, permissions, matrix }`, packed rules as `unknown[]`, and check `{ allowed }`.
- The MongoDB-style condition syntax is an implementation detail of the engine, documented
  in `server/policy.ts` — it never appears in the contract or client surface types.
- `<Gate>` is implemented in-house over `useCan` so `@casl/react` is never a dependency.

## Policy-as-data

The role-permission matrix ships as versioned data in `server/policy.ts`. Changes to the
policy require a code change and a semver bump. The matrix format (`MatrixEntry[]`) is
stable across versions — conditions are opaque JSON records.

## Seed matrix (aligned with PS.AUTH seed roles)

| Role | Action | Resource | Condition |
|---|---|---|---|
| `finance-approver` | `invoice.approve` | `invoice` | `submittedBy ≠ userId` (ownership: cannot approve own) |
| `finance-approver` | `invoice.read` | `invoice` | `tenantId = tenantId` (tenant-scoped) |
| `finance-clerk` | `invoice.create` | `invoice` | `tenantId = tenantId` (tenant-scoped) |
| `finance-clerk` | `invoice.read` | `invoice` | `submittedBy = userId` (own only) |
| `finance-clerk` | `invoice.update-own` | `invoice` | `submittedBy = userId` (own only) |
| `procurement-requester` | `purchase-request.create` | `purchase-request` | `tenantId = tenantId` (tenant-scoped) |
| `procurement-requester` | `purchase-request.read-own` | `purchase-request` | `submittedBy = userId` (own only) |
| `platform-admin` | `manage` | `all` | none (superuser) |

Condition placeholders `$userId` and `$tenantId` are interpolated at rule-compilation time
from the session subject (see `server/engine.ts`).

## SLO

**Check p95 < 10ms (cached).** Measured by `tests/slo.test.ts`: 200 sequential in-process
`compileAbility` + `ability.can()` calls after warm-up, p95 asserted `< 10ms` on every test
run. The SLO is achievable because `useCan` evaluates packed rules locally — the only
network call is fetching packed rules once per session (TanStack Query cache). Once a
deployment target exists, handler-level latency on `GET /rules` is the APM concern; the
client-side `useCan` path has no network component.

## Contract workflow

`pnpm --filter @dbp/ps-rbac contracts:gen` regenerates `contract.yaml` from the Zod
endpoint definitions; `contracts:check` regenerates and diffs, failing on drift. The
generated file is committed.

## Pact

Consumer test drives this package's own SDK against a Pact mock; provider verification
replays the pact against the real handlers on a `node:http` server (ADR-0007). `@pact-foundation/pact-core`
ships no native binary for `win32-arm64`, so the Pact suite self-skips on that platform
with a notice; it runs everywhere else (CI runners are x64).

## Tenancy

PS.RBAC is stateless — it does not persist roles or users itself. The role-permission matrix
is static (policy-as-code). Tenant scoping is enforced by conditions in the matrix
(`tenantId = $tenantId`) that are interpolated from the session at rule-compilation time.
No `x-tenant-id` header is needed; the session header carries the tenant context.

## Semver policy

- Patch: bug fixes to the engine or handlers; new condition types that are additive.
- Minor: new roles, permissions, or matrix entries in the seed policy; new SDK exports.
- Major: breaking changes to wire types, contract shape, or SDK signatures.
