// @vitest-environment node
import { describe, expect, it } from "vitest";
import { compileAbility, packAbilityRules, can } from "../server/engine";
import { unpackRules } from "@casl/ability/extra";
import { createMongoAbility, AbilityBuilder, subject } from "@casl/ability";
import type { Session } from "@dbp/contracts/session";

const BASE_SESSION: Session = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

const CLERK_SESSION: Session = {
  userId: "usr-alpha-finance-clerk",
  email: "finance-clerk@alpha.dev.local",
  roles: ["finance-clerk"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

const ADMIN_SESSION: Session = {
  userId: "usr-alpha-platform-admin",
  email: "platform-admin@alpha.dev.local",
  roles: ["platform-admin"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

const REQUESTER_SESSION: Session = {
  userId: "usr-alpha-procurement-requester",
  email: "procurement-requester@alpha.dev.local",
  roles: ["procurement-requester"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

describe("compileAbility — basic allow/deny", () => {
  it("finance-approver can invoice.read in their tenant", () => {
    const ability = compileAbility(BASE_SESSION);
    expect(ability.can("invoice.read", "invoice")).toBe(true);
  });

  it("finance-approver cannot invoice.create (not in their matrix)", () => {
    const ability = compileAbility(BASE_SESSION);
    expect(ability.can("invoice.create", "invoice")).toBe(false);
  });

  it("finance-clerk can invoice.create", () => {
    const ability = compileAbility(CLERK_SESSION);
    expect(ability.can("invoice.create", "invoice")).toBe(true);
  });

  it("finance-clerk cannot invoice.approve", () => {
    const ability = compileAbility(CLERK_SESSION);
    expect(ability.can("invoice.approve", "invoice")).toBe(false);
  });

  it("platform-admin can manage all", () => {
    const ability = compileAbility(ADMIN_SESSION);
    expect(ability.can("manage", "all")).toBe(true);
  });

  it("procurement-requester can create purchase requests", () => {
    const ability = compileAbility(REQUESTER_SESSION);
    expect(ability.can("purchase-request.create", "purchase-request")).toBe(true);
  });

  it("procurement-requester cannot create invoices", () => {
    const ability = compileAbility(REQUESTER_SESSION);
    expect(ability.can("invoice.create", "invoice")).toBe(false);
  });
});

describe("compileAbility — ownership condition (finance-approver cannot approve own submission)", () => {
  it("approver can approve an invoice they did NOT submit", () => {
    const ability = compileAbility(BASE_SESSION);
    // Use subject() so CASL can evaluate the condition against the object's fields
    const invoice = subject("invoice", { submittedBy: "usr-alpha-finance-clerk", tenantId: "tenant-alpha" });
    expect(ability.can("invoice.approve", invoice)).toBe(true);
  });

  it("approver CANNOT approve an invoice they submitted themselves", () => {
    const ability = compileAbility(BASE_SESSION);
    const ownInvoice = subject("invoice", { submittedBy: BASE_SESSION.userId, tenantId: "tenant-alpha" });
    expect(ability.can("invoice.approve", ownInvoice)).toBe(false);
  });
});

describe("compileAbility — tenant-scoping condition", () => {
  it("clerk can read their own invoice in the same tenant", () => {
    const ability = compileAbility(CLERK_SESSION);
    // Use subject() so CASL can evaluate the condition against the object's fields
    const invoice = subject("invoice", { submittedBy: CLERK_SESSION.userId, tenantId: CLERK_SESSION.tenantId });
    expect(ability.can("invoice.read", invoice)).toBe(true);
  });

  it("clerk cannot read an invoice from a different tenant (cross-tenant)", () => {
    const ability = compileAbility(CLERK_SESSION);
    // A cross-tenant resource that is ALSO not owned by this clerk should be denied
    const foreignOtherUserInvoice = subject("invoice", { submittedBy: "someone-else", tenantId: "tenant-beta" });
    expect(ability.can("invoice.read", foreignOtherUserInvoice)).toBe(false);
  });

  it("approver cannot read an invoice from a different tenant", () => {
    const ability = compileAbility(BASE_SESSION);
    // Approver read condition: tenantId === "tenant-alpha"; a beta invoice is denied
    const foreignInvoice = subject("invoice", { tenantId: "tenant-beta", submittedBy: "other-user" });
    expect(ability.can("invoice.read", foreignInvoice)).toBe(false);
  });
});

describe("packAbilityRules — serialisation round-trip", () => {
  it("packed rules can be unpacked and produce the same allow/deny", () => {
    const packed = packAbilityRules(BASE_SESSION);
    expect(Array.isArray(packed)).toBe(true);
    expect(packed.length).toBeGreaterThan(0);

    // Reconstruct ability from packed rules
    const { can: addCan, build } = new AbilityBuilder(createMongoAbility);
    const unpacked = unpackRules(packed as Parameters<typeof unpackRules>[0]);
    for (const rule of unpacked) {
      addCan(rule.action as string, rule.subject as string, rule.conditions);
    }
    const rebuilt = build();
    expect(rebuilt.can("invoice.read", "invoice")).toBe(true);
    expect(rebuilt.can("invoice.create", "invoice")).toBe(false);
  });
});

describe("can() — server-side helper", () => {
  it("returns true for an allowed action", () => {
    expect(can(ADMIN_SESSION, "manage", "all")).toBe(true);
  });

  it("returns false for a denied action", () => {
    expect(can(CLERK_SESSION, "invoice.approve", "invoice")).toBe(false);
  });
});
