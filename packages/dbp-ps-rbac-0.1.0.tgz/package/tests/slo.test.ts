// @vitest-environment node
import { describe, expect, it } from "vitest";
import { compileAbility } from "../server/engine";
import type { Session } from "@dbp/contracts/session";

const SESSION: Session = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

describe("SLO: cached check p95 < 10ms", () => {
  it("evaluates 200 sequential in-process permission checks with p95 under 10ms", () => {
    // Warm up — compile the ability once so JIT settles
    const warmAbility = compileAbility(SESSION);
    warmAbility.can("invoice.read", "invoice");

    const samples: number[] = [];
    for (let i = 0; i < 200; i += 1) {
      const start = performance.now();
      // Each iteration re-evaluates using a pre-compiled ability (the cached path)
      const ability = compileAbility(SESSION);
      const result = ability.can("invoice.read", "invoice");
      samples.push(performance.now() - start);
      expect(result).toBe(true);
    }

    samples.sort((a, b) => a - b);
    const p95Index = Math.floor(samples.length * 0.95);
    const p95 = samples[p95Index];
    expect(p95).toBeDefined();
    expect(p95 as number).toBeLessThan(10);
  });
});
