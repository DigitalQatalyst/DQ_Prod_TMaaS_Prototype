import { afterEach, describe, expect, it } from "vitest";
import { createElement, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { cleanup, renderHook, waitFor, render, screen } from "@testing-library/react";
import { configureRbacClient, useCan, Gate } from "../client";
import { packAbilityRules } from "../server/engine";
import type { Session } from "@dbp/contracts/session";

const SESSION: Session = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

const CLERK_SESSION: Session = {
  userId: "usr-alpha-finance-clerk",
  email: "finance-clerk@alpha.dev.local",
  roles: ["finance-clerk"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

// Build a fetch mock that returns pre-computed packed rules for the given session
function makeRulesFetch(session: Session): typeof globalThis.fetch {
  return async () => {
    const rules = packAbilityRules(session);
    const body = JSON.stringify({
      rules,
      tenantId: session.tenantId,
      roles: session.roles,
    });
    return new Response(body, { status: 200, headers: { "content-type": "application/json" } });
  };
}

function wrapper(client: QueryClient) {
  return ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client }, children);
}

afterEach(cleanup);

describe("useCan", () => {
  it("returns false while rules are loading", () => {
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    // fetch that never resolves
    configureRbacClient({ fetch: () => new Promise(() => {}) });
    const { result } = renderHook(() => useCan("invoice.read"), { wrapper: wrapper(qc) });
    expect(result.current).toBe(false);
  });

  it("returns true when the fetched rules allow the action (finance-approver / invoice.read)", async () => {
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    configureRbacClient({ fetch: makeRulesFetch(SESSION) });
    const { result } = renderHook(() => useCan("invoice.read", "invoice"), {
      wrapper: wrapper(qc),
    });
    await waitFor(() => expect(result.current).toBe(true));
  });

  it("returns false for an action not permitted (finance-approver / invoice.create)", async () => {
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    configureRbacClient({ fetch: makeRulesFetch(SESSION) });
    const { result } = renderHook(() => useCan("invoice.create", "invoice"), {
      wrapper: wrapper(qc),
    });
    await waitFor(() => expect(result.current).toBe(false));
  });

  it("returns true for finance-clerk / invoice.create", async () => {
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    configureRbacClient({ fetch: makeRulesFetch(CLERK_SESSION) });
    const { result } = renderHook(() => useCan("invoice.create", "invoice"), {
      wrapper: wrapper(qc),
    });
    await waitFor(() => expect(result.current).toBe(true));
  });
});

describe("<Gate>", () => {
  it("renders children when useCan returns true", async () => {
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    configureRbacClient({ fetch: makeRulesFetch(SESSION) });

    render(
      createElement(
        QueryClientProvider,
        { client: qc },
        createElement(
          Gate,
          { action: "invoice.read", resource: "invoice", children: createElement("span", null, "allowed-content") },
        ),
      ),
    );
    await waitFor(() => expect(screen.getByText("allowed-content")).toBeTruthy());
  });

  it("renders fallback when useCan returns false", async () => {
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
    configureRbacClient({ fetch: makeRulesFetch(SESSION) });

    render(
      createElement(
        QueryClientProvider,
        { client: qc },
        createElement(
          Gate,
          {
            action: "invoice.create",
            resource: "invoice",
            fallback: createElement("span", null, "denied-fallback"),
            children: createElement("span", null, "not-shown"),
          },
        ),
      ),
    );
    await waitFor(() => expect(screen.getByText("denied-fallback")).toBeTruthy());
  });
});
