// @vitest-environment node
import { describe, expect, it } from "vitest";
import { matrixHandler, rulesHandler, checkHandler, dispatch } from "../server/handlers";
import { RBAC_BASE_PATH } from "../client/types";
import type { Session } from "@dbp/contracts/session";

const SESSION: Session = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

function sessionHeader(session: Session): string {
  return Buffer.from(JSON.stringify(session)).toString("base64");
}

function makeRequest(method: string, path: string, session?: Session, body?: unknown): Request {
  const headers: Record<string, string> = {};
  if (session) headers["x-dbp-session"] = sessionHeader(session);
  if (body) headers["content-type"] = "application/json";
  return new Request(`http://localhost${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null,
  });
}

describe("GET /matrix", () => {
  it("returns 200 with roles, permissions, and matrix", async () => {
    const res = await matrixHandler(makeRequest("GET", `${RBAC_BASE_PATH}/matrix`));
    expect(res.status).toBe(200);
    const body = (await res.json()) as { roles: unknown[]; permissions: unknown[]; matrix: unknown[] };
    expect(Array.isArray(body.roles)).toBe(true);
    expect(body.roles.length).toBeGreaterThan(0);
    expect(Array.isArray(body.permissions)).toBe(true);
    expect(Array.isArray(body.matrix)).toBe(true);
  });

  it("includes finance-approver role", async () => {
    const res = await matrixHandler(makeRequest("GET", `${RBAC_BASE_PATH}/matrix`));
    const body = (await res.json()) as { roles: Array<{ id: string }> };
    expect(body.roles.some((r) => r.id === "finance-approver")).toBe(true);
  });
});

describe("GET /rules", () => {
  it("returns 200 with packed rules when session header is valid", async () => {
    const res = await rulesHandler(makeRequest("GET", `${RBAC_BASE_PATH}/rules`, SESSION));
    expect(res.status).toBe(200);
    const body = (await res.json()) as { rules: unknown[]; tenantId: string; roles: string[] };
    expect(Array.isArray(body.rules)).toBe(true);
    expect(body.tenantId).toBe(SESSION.tenantId);
    expect(body.roles).toContain("finance-approver");
  });

  it("returns 401 when no session header", async () => {
    const res = await rulesHandler(makeRequest("GET", `${RBAC_BASE_PATH}/rules`));
    expect(res.status).toBe(401);
  });

  it("returns 401 for malformed session", async () => {
    const req = new Request(`http://localhost${RBAC_BASE_PATH}/rules`, {
      method: "GET",
      headers: { "x-dbp-session": "not-valid-base64-json" },
    });
    const res = await rulesHandler(req);
    expect(res.status).toBe(401);
  });
});

describe("POST /check", () => {
  it("returns allowed: true for a permitted action", async () => {
    const res = await checkHandler(
      makeRequest("POST", `${RBAC_BASE_PATH}/check`, SESSION, { action: "invoice.read", resource: "invoice" }),
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { allowed: boolean };
    expect(body.allowed).toBe(true);
  });

  it("returns allowed: false for a denied action", async () => {
    const res = await checkHandler(
      makeRequest("POST", `${RBAC_BASE_PATH}/check`, SESSION, { action: "invoice.create", resource: "invoice" }),
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { allowed: boolean };
    expect(body.allowed).toBe(false);
  });

  it("returns 400 for missing body", async () => {
    const req = new Request(`http://localhost${RBAC_BASE_PATH}/check`, {
      method: "POST",
      headers: { "x-dbp-session": sessionHeader(SESSION), "content-type": "application/json" },
      body: "not-json",
    });
    const res = await checkHandler(req);
    expect(res.status).toBe(400);
  });

  it("returns 401 for missing session", async () => {
    const res = await checkHandler(
      makeRequest("POST", `${RBAC_BASE_PATH}/check`, undefined, { action: "invoice.read" }),
    );
    expect(res.status).toBe(401);
  });
});

describe("dispatch", () => {
  it("routes GET /matrix correctly", async () => {
    const res = await dispatch(makeRequest("GET", `${RBAC_BASE_PATH}/matrix`));
    expect(res.status).toBe(200);
  });

  it("returns 404 for unknown paths", async () => {
    const res = await dispatch(makeRequest("GET", `${RBAC_BASE_PATH}/unknown`));
    expect(res.status).toBe(404);
  });
});
