// @vitest-environment node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { beforeAll, describe, expect, it } from "vitest";
import { RBAC_BASE_PATH } from "../client/types";
import {
  configureRbacClient,
  fetchMatrix,
  fetchPackedRules,
  checkPermission,
  RbacServiceError,
} from "../client";
import { startRbacServer } from "./helpers/node-server";
import type { Session } from "@dbp/contracts/session";

// pact-core ships native binaries for darwin-arm64/x64, linux-arm64/x64 and win32-x64 only.
// win32-arm64 has no binary — self-skip with a notice.
const pactSupported = !(process.platform === "win32" && process.arch === "arm64");
const pactModule = pactSupported ? await import("@pact-foundation/pact") : null;

const pactDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "pacts");
const CONSUMER = "dbp-ps-rbac-client";
const PROVIDER = "dbp-ps-rbac";
const pactFile = path.join(pactDir, `${CONSUMER}-${PROVIDER}.json`);

const APPROVER_SESSION: Session = {
  userId: "usr-alpha-finance-approver",
  email: "finance-approver@alpha.dev.local",
  roles: ["finance-approver"],
  tenantId: "tenant-alpha",
  exp: 9999999999,
};

function sessionHeaderValue(session: Session): string {
  return Buffer.from(JSON.stringify(session)).toString("base64");
}

if (pactModule === null) {
  describe("PS.RBAC Pact contract", () => {
    it.skip("SKIPPED on win32-arm64: @pact-foundation/pact-core has no native binary for this platform", () => {});
  });
} else {
  const { PactV4, MatchersV3, Verifier } = pactModule;
  const { boolean, eachLike, like } = MatchersV3;

  const pact = new PactV4({
    consumer: CONSUMER,
    provider: PROVIDER,
    dir: pactDir,
    logLevel: "warn",
  });

  const sessionHeader = sessionHeaderValue(APPROVER_SESSION);

  describe("PS.RBAC Pact contract", () => {
    beforeAll(() => {
      for (const file of fs.readdirSync(pactDir)) {
        if (file.endsWith(".json")) fs.rmSync(path.join(pactDir, file));
      }
    });

    it("consumer: GET /matrix returns roles, permissions, and matrix", async () => {
      await pact
        .addInteraction()
        .given("the RBAC policy matrix is loaded")
        .uponReceiving("a request for the role-permission matrix")
        .withRequest("GET", `${RBAC_BASE_PATH}/matrix`, () => {})
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({
            roles: eachLike({ id: like("finance-approver"), label: like("Finance Approver") }),
            permissions: eachLike({
              action: like("invoice.approve"),
              resource: like("invoice"),
            }),
            matrix: eachLike({
              role: like("finance-approver"),
              action: like("invoice.approve"),
              resource: like("invoice"),
              condition: like(null),
            }),
          });
        })
        .executeTest(async (mockServer) => {
          configureRbacClient({ baseUrl: `${mockServer.url}${RBAC_BASE_PATH}` });
          const result = await fetchMatrix();
          expect(result.roles.length).toBeGreaterThan(0);
          expect(result.permissions.length).toBeGreaterThan(0);
          expect(result.matrix.length).toBeGreaterThan(0);
        });
    });

    it("consumer: GET /rules returns packed rules for a valid session", async () => {
      await pact
        .addInteraction()
        .given("a valid session for finance-approver in tenant-alpha")
        .uponReceiving("a request for packed CASL rules")
        .withRequest("GET", `${RBAC_BASE_PATH}/rules`, (builder) => {
          builder.headers({ "x-dbp-session": sessionHeader });
        })
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({
            rules: eachLike(like({})),
            tenantId: like("tenant-alpha"),
            roles: eachLike(like("finance-approver")),
          });
        })
        .executeTest(async (mockServer) => {
          const sessionFetch: typeof globalThis.fetch = (input, init) =>
            globalThis.fetch(input, {
              ...init,
              headers: { ...(init?.headers ?? {}), "x-dbp-session": sessionHeader },
            });
          configureRbacClient({ baseUrl: `${mockServer.url}${RBAC_BASE_PATH}`, fetch: sessionFetch });
          const result = await fetchPackedRules({ "x-dbp-session": sessionHeader });
          expect(result.tenantId).toBe("tenant-alpha");
          expect(result.roles).toContain("finance-approver");
        });
    });

    it("consumer: GET /rules returns 401 when no session provided", async () => {
      await pact
        .addInteraction()
        .given("no session header is provided")
        .uponReceiving("a request for rules without a session header")
        .withRequest("GET", `${RBAC_BASE_PATH}/rules`, () => {})
        .willRespondWith(401, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({
            error: like("Valid session required to fetch rules."),
          });
        })
        .executeTest(async (mockServer) => {
          configureRbacClient({ baseUrl: `${mockServer.url}${RBAC_BASE_PATH}` });
          const error = await fetchPackedRules().catch((e: unknown) => e);
          expect(error).toBeInstanceOf(RbacServiceError);
          expect((error as RbacServiceError).status).toBe(401);
        });
    });

    it("consumer: POST /check returns allowed: true for a permitted action", async () => {
      await pact
        .addInteraction()
        .given("a valid session for finance-approver in tenant-alpha")
        .uponReceiving("a check request for invoice.read")
        .withRequest("POST", `${RBAC_BASE_PATH}/check`, (builder) => {
          builder
            .headers({ "content-type": "application/json", "x-dbp-session": sessionHeader })
            .jsonBody({ action: "invoice.read" });
        })
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({ allowed: boolean(true) });
        })
        .executeTest(async (mockServer) => {
          const sessionFetch: typeof globalThis.fetch = (input, init) =>
            globalThis.fetch(input, {
              ...init,
              headers: { ...(init?.headers ?? {}), "x-dbp-session": sessionHeader },
            });
          configureRbacClient({ baseUrl: `${mockServer.url}${RBAC_BASE_PATH}`, fetch: sessionFetch });
          const result = await checkPermission({ action: "invoice.read" });
          expect(result.allowed).toBe(true);
        });
    });

    it("consumer: POST /check returns allowed: false for a denied action", async () => {
      await pact
        .addInteraction()
        .given("a valid session for finance-approver in tenant-alpha")
        .uponReceiving("a check request for invoice.create (denied)")
        .withRequest("POST", `${RBAC_BASE_PATH}/check`, (builder) => {
          builder
            .headers({ "content-type": "application/json", "x-dbp-session": sessionHeader })
            .jsonBody({ action: "invoice.create" });
        })
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({ allowed: boolean(false) });
        })
        .executeTest(async (mockServer) => {
          const sessionFetch: typeof globalThis.fetch = (input, init) =>
            globalThis.fetch(input, {
              ...init,
              headers: { ...(init?.headers ?? {}), "x-dbp-session": sessionHeader },
            });
          configureRbacClient({ baseUrl: `${mockServer.url}${RBAC_BASE_PATH}`, fetch: sessionFetch });
          const result = await checkPermission({ action: "invoice.create" });
          expect(result.allowed).toBe(false);
        });
    });

    it("provider: handlers on node:http verify the generated pact", async () => {
      expect(fs.existsSync(pactFile)).toBe(true);
      const server = await startRbacServer();
      try {
        const output = await new Verifier({
          provider: PROVIDER,
          providerBaseUrl: server.baseUrl,
          pactUrls: [pactFile],
          logLevel: "warn",
          requestFilter: (req: { headers: Record<string, string> }) => {
            // Inject a valid session header for interactions that declare one,
            // so the provider can decode and verify.
            if (req.headers["x-dbp-session"] === undefined) {
              req.headers["x-dbp-session"] = sessionHeader;
            }
            return req;
          },
        }).verifyProvider();
        expect(output).toContain("finished: 0");
      } finally {
        await server.close();
      }
    });
  });
}
