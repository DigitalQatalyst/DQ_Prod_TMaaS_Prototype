import { z } from "zod";

export const RBAC_BASE_PATH = "/api/platform/rbac";

// ---------------------------------------------------------------------------
// Domain types — service-owned, CASL never leaks here
// ---------------------------------------------------------------------------

export const RoleSchema = z
  .object({
    id: z.string().min(1),
    label: z.string().min(1),
    // tenantId absent → platform-global role; present → tenant-custom role.
    // Mirrors rbac.role.tenant_id (nullable in DB).
    tenantId: z.string().min(1).optional(),
  })
  .strict();
export type Role = z.infer<typeof RoleSchema>;

export const PermissionSchema = z
  .object({
    action: z.string().min(1),
    resource: z.string().min(1),
    description: z.string().optional(),
  })
  .strict();
export type Permission = z.infer<typeof PermissionSchema>;

// A single entry in the role→permission matrix.
// condition is opaque JSON (MongoDB-style CASL condition); null = no condition.
// tenantId absent → applies to all tenants (global default); present → tenant-specific
// override/addition. Mirrors rbac.role_permission.tenant_id (nullable in DB).
export const MatrixEntrySchema = z
  .object({
    role: z.string().min(1),
    action: z.string().min(1),
    resource: z.string().min(1),
    condition: z.record(z.unknown()).nullable(),
    tenantId: z.string().min(1).optional(),
  })
  .strict();
export type MatrixEntry = z.infer<typeof MatrixEntrySchema>;

// ---------------------------------------------------------------------------
// User-role assignment — mirrors rbac.user_role(tenant_id, user_id, role_id).
// Represents a single (user, tenant) → role binding.
// ---------------------------------------------------------------------------

export const UserRoleAssignmentSchema = z
  .object({
    tenantId: z.string().min(1),
    userId: z.string().min(1),
    roleId: z.string().min(1),
  })
  .strict();
export type UserRoleAssignment = z.infer<typeof UserRoleAssignmentSchema>;

// ---------------------------------------------------------------------------
// Wire response schemas
// ---------------------------------------------------------------------------

export const MatrixResponseSchema = z
  .object({
    roles: z.array(RoleSchema),
    permissions: z.array(PermissionSchema),
    matrix: z.array(MatrixEntrySchema),
  })
  .strict();
export type MatrixResponse = z.infer<typeof MatrixResponseSchema>;

// Packed CASL rules — opaque array of serialised rule objects.
// Typed as unknown[] so CASL types are fully contained server-side.
export const PackedRulesResponseSchema = z
  .object({
    rules: z.array(z.unknown()),
    tenantId: z.string().min(1),
    roles: z.array(z.string().min(1)),
  })
  .strict();
export type PackedRulesResponse = z.infer<typeof PackedRulesResponseSchema>;

export const CheckRequestSchema = z
  .object({
    action: z.string().min(1),
    resource: z.string().optional(),
    subject: z.string().optional(),
  })
  .strict();
export type CheckRequest = z.infer<typeof CheckRequestSchema>;

export const CheckResponseSchema = z
  .object({
    allowed: z.boolean(),
  })
  .strict();
export type CheckResponse = z.infer<typeof CheckResponseSchema>;

export const RbacErrorResponseSchema = z
  .object({
    error: z.string().min(1),
  })
  .strict();
export type RbacErrorResponse = z.infer<typeof RbacErrorResponseSchema>;

// ---------------------------------------------------------------------------
// Client config
// ---------------------------------------------------------------------------

export interface RbacClientConfig {
  baseUrl?: string;
  fetch?: typeof globalThis.fetch;
}
