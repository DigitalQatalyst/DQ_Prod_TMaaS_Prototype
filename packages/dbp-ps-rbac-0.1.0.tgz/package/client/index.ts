import { type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { AbilityBuilder, createMongoAbility, type MongoAbility } from "@casl/ability";
import { unpackRules } from "@casl/ability/extra";
import {
  RBAC_BASE_PATH,
  CheckRequestSchema,
  CheckResponseSchema,
  MatrixResponseSchema,
  PackedRulesResponseSchema,
  RbacErrorResponseSchema,
} from "./types";
import type {
  CheckRequest,
  CheckResponse,
  MatrixResponse,
  PackedRulesResponse,
  RbacClientConfig,
} from "./types";

export {
  RBAC_BASE_PATH,
  CheckRequestSchema,
  CheckResponseSchema,
  MatrixResponseSchema,
  PackedRulesResponseSchema,
  RbacErrorResponseSchema,
};
export type * from "./types";

// ---------------------------------------------------------------------------
// Error class
// ---------------------------------------------------------------------------

export class RbacServiceError extends Error {
  readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = "RbacServiceError";
    this.status = status;
  }
}

// ---------------------------------------------------------------------------
// Client config
// ---------------------------------------------------------------------------

let clientConfig: RbacClientConfig = {};

export function configureRbacClient(config: RbacClientConfig): void {
  clientConfig = { ...clientConfig, ...config };
}

export function getRbacClientConfig(): RbacClientConfig {
  return clientConfig;
}

export function resetRbacClient(): void {
  clientConfig = {};
}

function resolveBaseUrl(): string {
  return clientConfig.baseUrl ?? RBAC_BASE_PATH;
}

function resolveFetch(): typeof globalThis.fetch {
  return clientConfig.fetch ?? globalThis.fetch.bind(globalThis);
}

// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------

async function requestJson(path: string, init?: RequestInit): Promise<unknown> {
  const response = await resolveFetch()(`${resolveBaseUrl()}${path}`, init);
  if (!response.ok) {
    let message = `RBAC request failed with status ${response.status}.`;
    try {
      const parsed = RbacErrorResponseSchema.safeParse(await response.json());
      if (parsed.success) message = parsed.data.error;
    } catch {
      // non-JSON body — keep generic message
    }
    throw new RbacServiceError(response.status, message);
  }
  return (await response.json()) as unknown;
}

// ---------------------------------------------------------------------------
// Plain async SDK functions
// ---------------------------------------------------------------------------

export async function fetchMatrix(): Promise<MatrixResponse> {
  return MatrixResponseSchema.parse(await requestJson("/matrix"));
}

export async function fetchPackedRules(headers?: HeadersInit): Promise<PackedRulesResponse> {
  return PackedRulesResponseSchema.parse(
    await requestJson("/rules", { headers: headers ?? {} }),
  );
}

export async function checkPermission(body: CheckRequest): Promise<CheckResponse> {
  return CheckResponseSchema.parse(
    await requestJson("/check", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(CheckRequestSchema.parse(body)),
    }),
  );
}

// ---------------------------------------------------------------------------
// Local CASL evaluation (the sub-10ms SLO depends on this being in-process)
// ---------------------------------------------------------------------------

function buildAbility(packedRules: PackedRulesResponse): MongoAbility {
  const { can, build } = new AbilityBuilder<MongoAbility>(createMongoAbility);
  // unpackRules reconstructs the serialised CASL rule array
  const rules = unpackRules(packedRules.rules as Parameters<typeof unpackRules>[0]);
  for (const rule of rules) {
    can(rule.action as string, rule.subject as string, rule.conditions);
  }
  return build();
}

// ---------------------------------------------------------------------------
// TanStack Query hooks
// ---------------------------------------------------------------------------

const RULES_KEY = ["ps-rbac", "rules"] as const;

export function usePackedRules() {
  return useQuery({
    queryKey: RULES_KEY,
    queryFn: () => fetchPackedRules(),
  });
}

/**
 * useCan evaluates the packed rules locally — no per-check network call.
 * Returns false while loading or if rules are unavailable.
 */
export function useCan(action: string, resource?: string): boolean {
  const { data } = usePackedRules();
  if (data === undefined) return false;
  const ability = buildAbility(data);
  return ability.can(action, resource ?? "all");
}

// ---------------------------------------------------------------------------
// <Gate> component — renders children only when useCan returns true
// ---------------------------------------------------------------------------

interface GateProps {
  action: string;
  resource?: string;
  children: ReactNode;
  fallback?: ReactNode;
}

export function Gate({ action, resource, children, fallback = null }: GateProps): ReactNode {
  const allowed = useCan(action, resource);
  return allowed ? children : fallback;
}
