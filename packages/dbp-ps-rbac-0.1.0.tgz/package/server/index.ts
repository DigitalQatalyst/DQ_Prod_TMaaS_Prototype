export {
  BASE_PATH,
  RBAC_BASE_PATH,
  checkHandler,
  dispatch,
  matrixHandler,
  routes,
  rulesHandler,
} from "./handlers";
export type { RbacRoute, RouteHandler } from "./handlers";
export { can, compileAbility, packAbilityRules } from "./engine";
export { MATRIX, PERMISSIONS, ROLES } from "./policy";
