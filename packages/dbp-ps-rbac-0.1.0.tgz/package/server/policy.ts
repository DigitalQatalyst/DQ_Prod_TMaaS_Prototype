import type { MatrixEntry, Permission, Role } from "../client/types";

// ---------------------------------------------------------------------------
// Seed roles — aligned with PS.AUTH seed roles
// ---------------------------------------------------------------------------

export const ROLES: ReadonlyArray<Role> = [
  { id: "finance-approver", label: "Finance Approver" },
  { id: "finance-clerk", label: "Finance Clerk" },
  { id: "procurement-requester", label: "Procurement Requester" },
  { id: "platform-admin", label: "Platform Admin" },
];

// ---------------------------------------------------------------------------
// Seed permissions
// ---------------------------------------------------------------------------

export const PERMISSIONS: ReadonlyArray<Permission> = [
  { action: "invoice.approve", resource: "invoice", description: "Approve an invoice submitted by another user." },
  { action: "invoice.read", resource: "invoice", description: "Read invoice records." },
  { action: "invoice.create", resource: "invoice", description: "Create a new invoice." },
  { action: "invoice.update-own", resource: "invoice", description: "Update invoices created by self." },
  { action: "purchase-request.create", resource: "purchase-request", description: "Create a purchase request." },
  { action: "purchase-request.read-own", resource: "purchase-request", description: "Read own purchase requests." },
  { action: "manage", resource: "all", description: "Superuser: manage all resources." },
];

// ---------------------------------------------------------------------------
// Role-permission matrix (policy-as-code, versioned in this file)
//
// condition keys:
//   submittedBy — ownership check; "$ne: $userId" means "not the requesting user"
//   tenantId    — tenant-scoping; "$eq: $tenantId" binds the rule to the session tenant
//
// Both conditions are injected at rule-compilation time in engine.ts using the
// session subject, so the matrix entries stay declarative.
// ---------------------------------------------------------------------------

export const MATRIX: ReadonlyArray<MatrixEntry> = [
  // finance-approver -------------------------------------------------------
  // May approve invoices — but NOT invoices they themselves submitted.
  // condition: submittedBy !== requesting userId  (ownership condition)
  {
    role: "finance-approver",
    action: "invoice.approve",
    resource: "invoice",
    condition: { submittedBy: { $ne: "$userId" } },
  },
  // May read all invoices in their tenant (tenant-scoping rule)
  {
    role: "finance-approver",
    action: "invoice.read",
    resource: "invoice",
    condition: { tenantId: { $eq: "$tenantId" } },
  },

  // finance-clerk ----------------------------------------------------------
  // May create invoices in their tenant
  {
    role: "finance-clerk",
    action: "invoice.create",
    resource: "invoice",
    condition: { tenantId: { $eq: "$tenantId" } },
  },
  // May read only own invoices (ownership condition)
  {
    role: "finance-clerk",
    action: "invoice.read",
    resource: "invoice",
    condition: { submittedBy: { $eq: "$userId" } },
  },
  // May update only own invoices (ownership condition)
  {
    role: "finance-clerk",
    action: "invoice.update-own",
    resource: "invoice",
    condition: { submittedBy: { $eq: "$userId" } },
  },

  // procurement-requester --------------------------------------------------
  {
    role: "procurement-requester",
    action: "purchase-request.create",
    resource: "purchase-request",
    condition: { tenantId: { $eq: "$tenantId" } },
  },
  {
    role: "procurement-requester",
    action: "purchase-request.read-own",
    resource: "purchase-request",
    condition: { submittedBy: { $eq: "$userId" } },
  },

  // platform-admin ---------------------------------------------------------
  // Manage all — no conditions, full access within tenant
  {
    role: "platform-admin",
    action: "manage",
    resource: "all",
    condition: null,
  },
];

// ---------------------------------------------------------------------------
// RbacPolicyConfig — named config surface bundling the platform-global defaults.
//
// Platform-global: ROLES and PERMISSIONS carry no tenantId (null in DB), meaning
// they apply across all tenants. MATRIX entries likewise carry no tenantId,
// making them the baseline for every tenant.
//
// Tenant-custom: a solution/tenant layer may compose this config with additional
// roles, permissions, and matrix overrides that carry a tenantId. The engine
// resolves the effective matrix per tenant via resolveMatrixForTenant().
// ---------------------------------------------------------------------------

export interface RbacPolicyConfig {
  roles: ReadonlyArray<Role>;
  permissions: ReadonlyArray<Permission>;
  matrix: ReadonlyArray<MatrixEntry>;
}

export const RBAC_POLICY_CONFIG: RbacPolicyConfig = {
  roles: ROLES,
  permissions: PERMISSIONS,
  matrix: MATRIX,
};

// ---------------------------------------------------------------------------
// resolveMatrixForTenant — computes the effective matrix for a given tenant.
//
// Returns all entries with no tenantId (platform-global defaults) PLUS any
// entries whose tenantId matches the argument (tenant-specific overrides).
// This is the seam the engine will use to compile per-tenant CASL abilities
// once tenant-custom policies are loaded from DB — engine.ts is untouched.
// ---------------------------------------------------------------------------

export function resolveMatrixForTenant(
  tenantId: string,
  matrix: ReadonlyArray<MatrixEntry> = MATRIX,
): MatrixEntry[] {
  return matrix.filter(
    (entry) => entry.tenantId === undefined || entry.tenantId === tenantId,
  );
}
