import { SessionSchema } from "@dbp/contracts/session";
import {
  RBAC_BASE_PATH,
  CheckRequestSchema,
  CheckResponseSchema,
  MatrixResponseSchema,
  PackedRulesResponseSchema,
  RbacErrorResponseSchema,
} from "../client/types";
import { ROLES, PERMISSIONS, MATRIX } from "./policy";
import { packAbilityRules, can as engineCan } from "./engine";

export { RBAC_BASE_PATH };
export const BASE_PATH = RBAC_BASE_PATH;

function json(body: unknown, init?: ResponseInit): Response {
  return new Response(JSON.stringify(body), {
    ...init,
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
  });
}

function errorResponse(status: number, message: string): Response {
  return json(RbacErrorResponseSchema.parse({ error: message }), { status });
}

// ---------------------------------------------------------------------------
// GET /matrix — static role/permission/matrix catalogue
// ---------------------------------------------------------------------------

export async function matrixHandler(req: Request): Promise<Response> {
  void req;
  return json(
    MatrixResponseSchema.parse({
      roles: ROLES,
      permissions: PERMISSIONS,
      matrix: MATRIX,
    }),
  );
}

// ---------------------------------------------------------------------------
// GET /rules — packed CASL rules for the requesting session
//
// Expects either:
//   Authorization: Bearer <session-json-base64>
//   or x-dbp-session: <session-json-base64>
//
// In production PS.AUTH verifies the JWT and injects a signed session header.
// For this service the caller passes a base64-encoded JSON Session object
// (tests use this directly; real apps pass the PS.AUTH session token which
// an upstream middleware decodes into x-dbp-session).
// ---------------------------------------------------------------------------

function extractSession(req: Request): ReturnType<typeof SessionSchema.safeParse> {
  const raw =
    req.headers.get("x-dbp-session") ??
    req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ??
    null;

  if (raw === null) {
    return { success: false, error: new Error("Missing session header") } as ReturnType<
      typeof SessionSchema.safeParse
    >;
  }

  try {
    const decoded = JSON.parse(Buffer.from(raw, "base64").toString("utf8")) as unknown;
    return SessionSchema.safeParse(decoded);
  } catch {
    return { success: false, error: new Error("Invalid session encoding") } as ReturnType<
      typeof SessionSchema.safeParse
    >;
  }
}

export async function rulesHandler(req: Request): Promise<Response> {
  const parsed = extractSession(req);
  if (!parsed.success) {
    return errorResponse(401, "Valid session required to fetch rules.");
  }
  const session = parsed.data;
  const rules = packAbilityRules(session);
  return json(
    PackedRulesResponseSchema.parse({
      rules,
      tenantId: session.tenantId,
      roles: session.roles,
    }),
  );
}

// ---------------------------------------------------------------------------
// POST /check — server-side permission check (stateless, uses session header)
// ---------------------------------------------------------------------------

async function readJsonBody(req: Request): Promise<unknown | undefined> {
  try {
    return (await req.json()) as unknown;
  } catch {
    return undefined;
  }
}

export async function checkHandler(req: Request): Promise<Response> {
  const sessionParsed = extractSession(req);
  if (!sessionParsed.success) {
    return errorResponse(401, "Valid session required to check permissions.");
  }
  const raw = await readJsonBody(req);
  if (raw === undefined) {
    return errorResponse(400, "Request body must be valid JSON.");
  }
  const bodyParsed = CheckRequestSchema.safeParse(raw);
  if (!bodyParsed.success) {
    return errorResponse(400, "Body must be { action, resource?, subject? }.");
  }
  const { action, resource } = bodyParsed.data;
  const allowed = engineCan(sessionParsed.data, action, resource);
  return json(CheckResponseSchema.parse({ allowed }));
}

// ---------------------------------------------------------------------------
// Routes manifest + dispatch
// ---------------------------------------------------------------------------

export type RouteHandler = (req: Request) => Promise<Response>;

export interface RbacRoute {
  method: "GET" | "POST";
  path: string;
  handler: RouteHandler;
}

export const routes: ReadonlyArray<RbacRoute> = [
  { method: "GET", path: `${RBAC_BASE_PATH}/matrix`, handler: matrixHandler },
  { method: "GET", path: `${RBAC_BASE_PATH}/rules`, handler: rulesHandler },
  { method: "POST", path: `${RBAC_BASE_PATH}/check`, handler: checkHandler },
];

export async function dispatch(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const pathname = url.pathname;
  const route = routes.find((r) => r.method === req.method && r.path === pathname);
  if (route === undefined) {
    return errorResponse(404, `No route ${req.method} ${pathname}`);
  }
  return route.handler(req);
}
