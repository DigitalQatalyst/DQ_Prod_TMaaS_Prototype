import { AbilityBuilder, createMongoAbility, type MongoAbility } from "@casl/ability";
import { packRules } from "@casl/ability/extra";
import type { Session } from "@dbp/contracts/session";
import type { MatrixEntry } from "../client/types";
import { MATRIX } from "./policy";

// ---------------------------------------------------------------------------
// Condition interpolation
//
// Matrix conditions reference session values via "$userId" / "$tenantId"
// placeholder strings. At compile time we substitute real values from the
// session so CASL receives concrete MongoDB-style condition objects.
// ---------------------------------------------------------------------------

function interpolateCondition(
  condition: Record<string, unknown> | null,
  session: Session,
): Record<string, unknown> | undefined {
  if (condition === null) return undefined;

  const replacePlaceholder = (value: unknown): unknown => {
    if (value === "$userId") return session.userId;
    if (value === "$tenantId") return session.tenantId;
    if (typeof value === "object" && value !== null) {
      const out: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
        out[k] = replacePlaceholder(v);
      }
      return out;
    }
    return value;
  };

  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(condition)) {
    out[k] = replacePlaceholder(v);
  }
  return out;
}

// ---------------------------------------------------------------------------
// compileAbility — builds a CASL MongoAbility for the given session
// ---------------------------------------------------------------------------

export function compileAbility(
  session: Session,
  matrix: ReadonlyArray<MatrixEntry> = MATRIX,
): MongoAbility {
  const { can, build } = new AbilityBuilder<MongoAbility>(createMongoAbility);

  for (const entry of matrix) {
    if (!session.roles.includes(entry.role)) continue;
    const interpolated = interpolateCondition(
      entry.condition as Record<string, unknown> | null,
      session,
    );
    can(entry.action, entry.resource, interpolated);
  }

  return build();
}

// ---------------------------------------------------------------------------
// packAbilityRules — serialises the compiled rules for the client
// ---------------------------------------------------------------------------

export function packAbilityRules(
  session: Session,
  matrix: ReadonlyArray<MatrixEntry> = MATRIX,
): unknown[] {
  const ability = compileAbility(session, matrix);
  return packRules(ability.rules) as unknown[];
}

// ---------------------------------------------------------------------------
// Server-side can() — evaluates a permission for the given session
//
// resource should be the resource type string (e.g. "invoice").
// Pass undefined only when the action targets "all" (e.g. platform-admin manage all).
// For condition-grade checks against a specific resource instance, use compileAbility
// directly and call ability.can(action, subject(resourceType, resourceObject)).
// ---------------------------------------------------------------------------

export function can(session: Session, action: string, resource?: string): boolean {
  const ability = compileAbility(session);
  // resource is the subject type string (e.g. "invoice", "purchase-request", or "all").
  // When undefined, default to "all" (matches platform-admin manage-all rules).
  // Note: with conditions present, CASL returns true for string subjects because it
  // cannot evaluate the condition — callers needing condition-grade checks must use
  // compileAbility + subject() directly.
  if (resource === undefined) {
    // Check "all" first; if denied, check whether the ability has any rule for this action
    // on any resource by trying to find a matching rule explicitly.
    return ability.can(action, "all");
  }
  return ability.can(action, resource);
}
