import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import { stringify } from "yaml";
import {
  OpenAPIRegistry,
  OpenApiGeneratorV3,
  extendZodWithOpenApi,
} from "@asteasolutions/zod-to-openapi";
import {
  RBAC_BASE_PATH,
  CheckRequestSchema,
  CheckResponseSchema,
  MatrixResponseSchema,
  PackedRulesResponseSchema,
  RbacErrorResponseSchema,
} from "../client/types";

// extendZodWithOpenApi must run once, at the top of this script only — never in runtime code
extendZodWithOpenApi(z);

const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const packageManifest = JSON.parse(
  fs.readFileSync(path.join(packageRoot, "package.json"), "utf8"),
) as { version: string };

function buildOpenApiDocument(): ReturnType<OpenApiGeneratorV3["generateDocument"]> {
  const registry = new OpenAPIRegistry();

  const matrixResponse = registry.register("MatrixResponse", MatrixResponseSchema);
  const packedRulesResponse = registry.register("PackedRulesResponse", PackedRulesResponseSchema);
  const checkRequest = registry.register("CheckRequest", CheckRequestSchema);
  const checkResponse = registry.register("CheckResponse", CheckResponseSchema);
  const rbacError = registry.register("RbacErrorResponse", RbacErrorResponseSchema);

  const errorContent = (description: string) => ({
    description,
    content: { "application/json": { schema: rbacError } },
  });

  const sessionHeaderSchema = z.object({
    "x-dbp-session": z
      .string()
      .optional()
      .openapi({ description: "Base64-encoded session JSON (set by upstream middleware)." }),
  });

  registry.registerPath({
    method: "get",
    path: `${RBAC_BASE_PATH}/matrix`,
    operationId: "getMatrix",
    summary: "Return the full role/permission catalogue and role-permission matrix.",
    responses: {
      200: {
        description: "Roles, permissions, and the policy matrix.",
        content: { "application/json": { schema: matrixResponse } },
      },
    },
  });

  registry.registerPath({
    method: "get",
    path: `${RBAC_BASE_PATH}/rules`,
    operationId: "getPackedRules",
    summary: "Return packed CASL rules for the requesting session (for local client evaluation).",
    request: { headers: sessionHeaderSchema },
    responses: {
      200: {
        description: "Packed CASL rules, tenant ID, and roles for the session subject.",
        content: { "application/json": { schema: packedRulesResponse } },
      },
      401: errorContent("Session header missing or invalid."),
    },
  });

  registry.registerPath({
    method: "post",
    path: `${RBAC_BASE_PATH}/check`,
    operationId: "checkPermission",
    summary: "Server-side permission check for the requesting session.",
    request: {
      headers: sessionHeaderSchema,
      body: { content: { "application/json": { schema: checkRequest } }, required: true },
    },
    responses: {
      200: {
        description: "Whether the action is allowed.",
        content: { "application/json": { schema: checkResponse } },
      },
      400: errorContent("Malformed or invalid request body."),
      401: errorContent("Session header missing or invalid."),
    },
  });

  return new OpenApiGeneratorV3(registry.definitions).generateDocument({
    openapi: "3.0.3",
    info: {
      title: "PS.RBAC — Roles & Permissions",
      version: packageManifest.version,
      description:
        "Layer 06 platform service. Compiles policy-as-code role-permission matrix to CASL rules; serves packed rules to clients for sub-10ms local evaluation.",
    },
    servers: [{ url: "/" }],
  });
}

const contractPath = path.join(packageRoot, "contract.yaml");
const header =
  "# GENERATED FILE — do not edit by hand (ADR-0013).\n" +
  "# Regenerate: pnpm --filter @dbp/ps-rbac contracts:gen\n";
const rendered = header + stringify(buildOpenApiDocument());
const normalize = (text: string): string => text.replace(/\r\n/g, "\n");
const mode = process.argv[2];

if (mode === "gen") {
  fs.writeFileSync(contractPath, rendered, "utf8");
  console.log("PASS  contract.yaml regenerated from Zod definitions.");
} else if (mode === "check") {
  const existing = fs.existsSync(contractPath)
    ? fs.readFileSync(contractPath, "utf8")
    : "";
  if (normalize(existing) !== normalize(rendered)) {
    console.error(
      "FAIL  contract.yaml is stale — regenerate with: pnpm --filter @dbp/ps-rbac contracts:gen",
    );
    process.exit(1);
  }
  console.log("PASS  contract.yaml matches the Zod-defined contract.");
} else {
  console.error("Usage: tsx scripts/generate-contract.ts <gen|check>");
  process.exit(1);
}
