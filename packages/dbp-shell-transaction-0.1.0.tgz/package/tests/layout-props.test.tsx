import * as React from 'react'
import { describe, it, expect, afterEach } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'

afterEach(cleanup)

describe('WorkingLayout — new props', () => {
  it('renders pageTitle', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout pageTitle="My Dashboard"><div /></WorkingLayout>)
    expect(screen.getByText('My Dashboard')).toBeTruthy()
  })

  it('renders subtitle when provided', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout pageTitle="Tasks" subtitle="24 open"><div /></WorkingLayout>)
    expect(screen.getByText('24 open')).toBeTruthy()
  })

  it('renders breadcrumb labels when provided', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(
      <WorkingLayout
        pageTitle="Detail Page"
        breadcrumb={[{ label: 'Home', href: '/' }, { label: 'Tasks', href: '/tasks' }, { label: 'Active Crumb' }]}
      >
        <div />
      </WorkingLayout>
    )
    const nav = screen.getByRole('navigation', { name: 'Breadcrumb' })
    expect(nav.textContent).toContain('Home')
    expect(nav.textContent).toContain('Tasks')
    expect(nav.textContent).toContain('Active Crumb')
  })
})

describe('AnalyticsLayout — new props', () => {
  it('renders pageTitle', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    render(<AnalyticsLayout pageTitle="Revenue"><div /></AnalyticsLayout>)
    expect(screen.getByText('Revenue')).toBeTruthy()
  })

  it('renders subtitle when provided', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    render(<AnalyticsLayout pageTitle="Revenue" subtitle="Last 30 days"><div /></AnalyticsLayout>)
    expect(screen.getByText('Last 30 days')).toBeTruthy()
  })

  it('renders breadcrumb labels when provided', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    render(
      <AnalyticsLayout
        pageTitle="Revenue Page"
        breadcrumb={[{ label: 'Analytics Section', href: '/analytics' }, { label: 'Revenue Crumb' }]}
      >
        <div />
      </AnalyticsLayout>
    )
    const nav = screen.getByRole('navigation', { name: 'Breadcrumb' })
    expect(nav.textContent).toContain('Analytics Section')
    expect(nav.textContent).toContain('Revenue Crumb')
  })
})

// ─── Page-header suppression contract (ARCHETYPE-REFERENCE-SPEC §3/§5) ─────────
// A1 header-led layouts render EXACTLY ONE PageHeader (marked [data-page-title]).
// A2 hero (content-landing) and A3 full-bleed (lve, conversational) render ZERO.
// This locks the "header present except content-landing / conversational / bare"
// rule so a layout edit can't silently add or drop the page header.

describe('layout header-suppression contract', () => {
  it('content-landing renders NO page header', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    const { container } = render(<ContentLandingLayout><div /></ContentLandingLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(0)
  })

  it('lve renders NO page header', async () => {
    const { LveLayout } = await import('../layouts/lve.js')
    const { container } = render(<LveLayout list={<div />} detail={<div />} />)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(0)
  })

  it('conversational renders NO page header', async () => {
    const { ConversationalLayout } = await import('../layouts/conversational.js')
    const { container } = render(<ConversationalLayout thread={<div />} input={<div />} />)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(0)
  })

  it('working renders EXACTLY ONE page header', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    const { container } = render(<WorkingLayout pageTitle="X"><div /></WorkingLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })

  it('analytics renders EXACTLY ONE page header', async () => {
    const { AnalyticsLayout } = await import('../layouts/analytics.js')
    const { container } = render(<AnalyticsLayout pageTitle="X"><div /></AnalyticsLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })

  it('catalogue renders EXACTLY ONE page header', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    const { container } = render(<CatalogueLayout pageTitle="X"><div /></CatalogueLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })

  it('settings renders EXACTLY ONE page header (title only)', async () => {
    const { SettingsLayout } = await import('../layouts/settings.js')
    const { container } = render(<SettingsLayout pageTitle="X" nav={<div />}><div /></SettingsLayout>)
    expect(container.querySelectorAll('[data-page-title]')).toHaveLength(1)
  })
})

// ─── Breadcrumb presence contract (spec §3 table) ─────────────────────────────
// Breadcrumb <nav> appears for header-led layouts ONLY when a breadcrumb is
// passed; content-landing / conversational never render one; settings renders a
// title-only header (no breadcrumb even though it has a PageHeader).

describe('layout breadcrumb contract', () => {
  it('working renders NO breadcrumb nav when none provided', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout pageTitle="X"><div /></WorkingLayout>)
    expect(screen.queryByRole('navigation', { name: 'Breadcrumb' })).toBeNull()
  })

  it('working renders a breadcrumb nav when provided', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout pageTitle="X" breadcrumb={[{ label: 'Home', href: '/' }, { label: 'X' }]}><div /></WorkingLayout>)
    expect(screen.getByRole('navigation', { name: 'Breadcrumb' })).toBeTruthy()
  })

  it('content-landing renders NO breadcrumb nav', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    render(<ContentLandingLayout><div /></ContentLandingLayout>)
    expect(screen.queryByRole('navigation', { name: 'Breadcrumb' })).toBeNull()
  })

  it('settings renders NO breadcrumb nav (title-only header)', async () => {
    const { SettingsLayout } = await import('../layouts/settings.js')
    render(<SettingsLayout pageTitle="X" nav={<div />}><div /></SettingsLayout>)
    expect(screen.queryByRole('navigation', { name: 'Breadcrumb' })).toBeNull()
  })
})

describe('CatalogueLayout — new props', () => {
  it('renders pageTitle', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    render(<CatalogueLayout pageTitle="Products"><div /></CatalogueLayout>)
    expect(screen.getByText('Products')).toBeTruthy()
  })

  it('renders subtitle when provided', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    render(<CatalogueLayout pageTitle="Products" subtitle="142 items"><div /></CatalogueLayout>)
    expect(screen.getByText('142 items')).toBeTruthy()
  })

  it('renders breadcrumb labels when provided', async () => {
    const { CatalogueLayout } = await import('../layouts/catalogue.js')
    render(
      <CatalogueLayout
        pageTitle="Products Page"
        breadcrumb={[{ label: 'Catalogue Section', href: '/catalogue' }, { label: 'Products Crumb' }]}
      >
        <div />
      </CatalogueLayout>
    )
    const nav = screen.getByRole('navigation', { name: 'Breadcrumb' })
    expect(nav.textContent).toContain('Catalogue Section')
    expect(nav.textContent).toContain('Products Crumb')
  })
})
