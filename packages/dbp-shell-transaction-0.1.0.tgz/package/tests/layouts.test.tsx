import * as React from 'react'
import { describe, it, expect, afterEach } from 'vitest'
import { render, screen, cleanup } from '@testing-library/react'

afterEach(cleanup)

describe('ContentLandingLayout', () => {
  it('renders children in content area', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    render(<ContentLandingLayout><span>hero content</span></ContentLandingLayout>)
    expect(screen.getByText('hero content')).toBeTruthy()
  })
  it('does not render a page title block', async () => {
    const { ContentLandingLayout } = await import('../layouts/content-landing.js')
    const { container } = render(<ContentLandingLayout><div /></ContentLandingLayout>)
    expect(container.querySelector('[data-page-title]')).toBeNull()
  })
})

describe('WorkingLayout', () => {
  it('renders children and accepts a pageTitle prop', async () => {
    const { WorkingLayout } = await import('../layouts/working.js')
    render(<WorkingLayout pageTitle="My Dashboard"><span>widgets</span></WorkingLayout>)
    expect(screen.getByText('My Dashboard')).toBeTruthy()
    expect(screen.getByText('widgets')).toBeTruthy()
  })
})

describe('LveLayout', () => {
  it('renders list, detail and edit slots', async () => {
    const { LveLayout } = await import('../layouts/lve.js')
    render(
      <LveLayout list={<span>list</span>} detail={<span>detail</span>} edit={<span>edit</span>} />
    )
    expect(screen.getByText('list')).toBeTruthy()
    expect(screen.getByText('detail')).toBeTruthy()
    expect(screen.getByText('edit')).toBeTruthy()
  })
})

describe('ConversationalLayout', () => {
  it('renders thread and input slots without a page title', async () => {
    const { ConversationalLayout } = await import('../layouts/conversational.js')
    const { container } = render(
      <ConversationalLayout thread={<span>messages</span>} input={<span>composer</span>} />
    )
    expect(screen.getByText('messages')).toBeTruthy()
    expect(screen.getByText('composer')).toBeTruthy()
    expect(container.querySelector('[data-page-title]')).toBeNull()
  })
})
