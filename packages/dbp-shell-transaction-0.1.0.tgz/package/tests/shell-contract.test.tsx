import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import TransactionShell from "../index.js";
import { SHELL_SLOTS } from "../slots.js";

vi.mock("next/navigation", () => ({
  useRouter: () => ({ push: vi.fn() }),
  usePathname: () => "/",
}));

vi.mock("@dbp/ps-auth/client", () => ({
  useAuth: () => ({ session: null, isLoading: true }),
}));

afterEach(() => {
  cleanup();
});

// ─── Locked slot set (ARCHETYPE-REFERENCE-SPEC §1.2) ──────────────────────────
// The shell exposes EXACTLY four slots, in this order. Adding/removing/renaming a
// slot is a deliberate platform change that must update the spec — this test makes
// such a change fail loudly rather than drift silently.

describe("shell contract — locked slot set", () => {
  it("exposes exactly the four canonical slots in order", () => {
    expect([...SHELL_SLOTS]).toEqual(["sidebar", "header", "main", "context"]);
  });

  it("has no slots beyond the four canonical ones", () => {
    expect(SHELL_SLOTS).toHaveLength(4);
  });
});

// ─── Context panel render contract (spec §1.4) ───────────────────────────────

describe("shell contract — context panel", () => {
  it("does not render the context panel when the context slot is empty", () => {
    const { container } = render(<TransactionShell />);
    expect(container.querySelector('[aria-label="Context panel"]')).toBeNull();
  });

  it("renders the context panel when the context slot has content", () => {
    const { container } = render(
      <TransactionShell slots={{ context: <div>detail</div> }} />,
    );
    expect(container.querySelector('[aria-label="Context panel"]')).toBeTruthy();
  });
});

// ─── defaultCollapsed contract (spec §1.4 — Conversational treatment) ─────────

describe("shell contract — nav.defaultCollapsed", () => {
  it("starts the sidebar expanded by default", () => {
    render(<TransactionShell />);
    const btn = screen.getByRole("button", { name: /collapse sidebar/i });
    expect(btn.getAttribute("aria-expanded")).toBe("true");
  });

  it("starts the sidebar collapsed when nav.defaultCollapsed is true", () => {
    render(<TransactionShell nav={{ defaultCollapsed: true }} />);
    // When collapsed the toggle is labelled "Expand sidebar" and aria-expanded=false.
    const btn = screen.getByRole("button", { name: /expand sidebar/i });
    expect(btn.getAttribute("aria-expanded")).toBe("false");
  });
});
