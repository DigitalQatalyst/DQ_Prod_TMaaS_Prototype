import { describe, it, expect } from 'vitest'
import { mergeNavConfig } from '../nav-merge.js'
import type { NavSection } from '@dbp/contracts'

const fullSections: NavSection[] = [
  { id: 'orientation', label: 'ORIENTATION', items: [{ id: 'home', label: 'Home', href: '/home' }] },
  { id: 'marketplace', label: 'MARKETPLACE', items: [{ id: 'cat', label: 'Catalogue', href: '/marketplace' }] },
  { id: 'workspace', label: 'WORKSPACE', items: [{ id: 'tasks', label: 'Tasks', href: '/tasks' }] },
  { id: 'service-operations', label: 'SERVICE OPERATIONS', items: [{ id: 'svc', label: 'Services', href: '/services' }] },
  { id: 'operational-intelligence', label: 'OPERATIONAL INTELLIGENCE', items: [{ id: 'dash', label: 'Dashboards', href: '/analytics' }] },
  { id: 'platform-management', label: 'PLATFORM MANAGEMENT', items: [{ id: 'users', label: 'Users', href: '/admin/users' }] },
]

describe('mergeNavConfig', () => {
  it('returns all six standard sections unchanged', () => {
    const result = mergeNavConfig(fullSections)
    expect(result.map(s => s.id)).toEqual([
      'orientation',
      'marketplace',
      'workspace',
      'service-operations',
      'operational-intelligence',
      'platform-management',
    ])
  })

  it('accepts any subset of the known sections (presence is optional)', () => {
    const subset = fullSections.filter(s => s.id === 'orientation' || s.id === 'platform-management')
    const result = mergeNavConfig(subset)
    expect(result.map(s => s.id)).toEqual(['orientation', 'platform-management'])
  })

  it('accepts an empty section list', () => {
    expect(mergeNavConfig([])).toEqual([])
  })

  it('throws on an unknown section id', () => {
    const bad: NavSection[] = [
      ...fullSections,
      { id: 'tasks-section', label: 'TASKS', items: [{ id: 'my-tasks', label: 'My Tasks', href: '/tasks' }] },
    ]
    expect(() => mergeNavConfig(bad)).toThrow('tasks-section')
  })

  it('rejects the retired pre-rename ids (platform-admin / analytics)', () => {
    expect(() =>
      mergeNavConfig([{ id: 'platform-admin', label: 'X', items: [] }]),
    ).toThrow('platform-admin')
    expect(() =>
      mergeNavConfig([{ id: 'analytics', label: 'X', items: [] }]),
    ).toThrow('analytics')
  })
})
