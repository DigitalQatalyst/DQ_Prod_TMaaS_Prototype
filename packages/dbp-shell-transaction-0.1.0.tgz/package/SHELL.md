---
shell_id: SH.02
name: Transaction Workspace Shell
journey_stage: 2
journey_role: Transact
fixed_dims:
  top_bar_h: 56px                    # spec-defined literal — SH.02 is 56px, not the global --shell-header-h (64px)
  sidebar_w_expanded: 240px          # spec-defined literal — expanded sidebar width
  sidebar_w_collapsed: 64px          # matches --shell-sidebar-collapsed-w in base.css
  context_panel_w: 320px             # spec-defined literal — right context panel width
slots: [sidebar, header, main, context]
composes: [PS.AUTH, PS.WORKFLOW, PS.DATA, PS.NOTIF]
---

# SH.02 — Transaction Workspace Shell

Stage 02 (Transact) shell. Fixed three-column layout below a top bar.

## Fixed Structure

```
┌───────────────────────────────────────────────────────────────────┐
│  Top Bar  h:56      [ header slot — breadcrumb zone ]   actions  │
├──────────────┬────────────────────────────────────┬──────────────┤
│  Sidebar     │  Main Content                      │  Context     │
│  w:240 (exp) │  [ main slot ]                     │  Panel       │
│  w:64 (coll) │  flex-1, scrollable                │  w:320       │
│  [ sidebar ] │                                    │  [ context ] │
│  slot below  │                                    │  optional    │
│  primary nav │                                    │              │
└──────────────┴────────────────────────────────────┴──────────────┘
```

## Slots

| Slot | Mounts On | Typical Feature |
|------|-----------|-----------------|
| `sidebar` | Content region inside sidebar, below primary nav items | Secondary nav, workspace tree, filters |
| `header` | Top bar breadcrumb zone | Breadcrumb trail, page title, contextual actions |
| `main` | Central content area (scrollable) | APP.F01 Entity List, APP.F03 Form Builder, APP.F04 Kanban |
| `context` | Right context panel (optional, w:320) | APP.F02 Entity Detail, APP.F06 Approval Surface, ActivityFeed binding |

## Sidebar Collapse Behaviour

The left sidebar collapses from w:240 to w:64. In the collapsed state:
- Primary nav icons remain visible at the left edge.
- Slot content (`sidebar` slot) and item labels are hidden via `overflow-hidden`.
- Toggle button: `<button aria-expanded={!collapsed}>` in the top bar (or sidebar footer).
- Keyboard: `Enter` and `Space` activate the toggle.
- Transition: `motion-safe:transition-[width]` — skipped under `prefers-reduced-motion: reduce`.

## Context Panel Behaviour

- The context panel is **optional**: it renders only when the `context` slot receives content.
- When hidden (no `context` slot content), the main area grows to fill the space.
- The panel is also **closeable** when open: the shell exposes `contextOpen` / `onContextOpenChange` props so the parent (or a feature inside `main`) can close it programmatically.
- Below `lg` (< 1024px) the context panel is hidden from layout and opens as a `<Sheet side="right">`.
- Document breakpoint: `lg` = 1024px threshold.

## Top Bar — Actions Zone

The top bar reserves a trailing actions zone (right side) for solution-time bindings:

```tsx
// Phase 4 binding pattern (not implemented in Phase 3):
<TransactionShell
  nav={{
    actions: (
      <>
        <NotificationBell />   {/* PS.NOTIF binding */}
        <UserMenu />           {/* PS.AUTH binding */}
      </>
    ),
  }}
/>
```

In Phase 3 the actions zone renders a placeholder `<div data-slot-name="actions" />` so
the layout reserve is visible in stories. Solutions mount `NotificationBell` (PS.NOTIF)
and `UserMenu` (PS.AUTH) here at solution time.

## Responsive Breakpoints

| Breakpoint | Behaviour |
|------------|-----------|
| `< md` (< 768px) | Sidebar hidden from layout; opens as `<Sheet side="left">` triggered by a hamburger button in the top bar |
| `md` – `lg` (768–1023px) | Sidebar inline, expanded (w:240) or collapsed (w:64); context panel hidden |
| `>= lg` (>= 1024px) | Full three-column layout: sidebar + main + optional context panel |

## Platform Service Wiring (solution time)

No data fetching occurs in Phase 3. Wiring happens when a solution mounts features into slots:

### PS.AUTH
The host application validates the session JWT **once** at the app boundary and injects
the `x-dbp-session` header on every outgoing PS.* request. The shell itself never reads
auth state — this is enforced by the import boundary rule (no `@dbp/ps-auth/server`).

```
Host App → validates JWT (PS.AUTH middleware)
         → injects x-dbp-session header
         → mounts TransactionShell
           → features call PS.DATA/WORKFLOW/NOTIF client SDKs
             → SDKs forward x-dbp-session header automatically
```

The `UserMenu` binding (top bar actions zone) reads the session from the PS.AUTH client
SDK's `useSession()` hook at solution time.

### PS.WORKFLOW
- `main` slot → APP.F03 Form Builder, APP.F04 Kanban — trigger workflow transitions via
  the PS.WORKFLOW client SDK.
- `context` slot → APP.F06 Approval Action Surface — submits approvals to PS.WORKFLOW.

### PS.DATA
- All data-reading features (APP.F01, APP.F02, APP.F07) call PS.DATA via the client SDK.
- Entity schemas are registered in PS.DATA at solution scaffolding time (never in the shell).

### PS.NOTIF
- `NotificationBell` binding (top bar actions zone) subscribes to PS.NOTIF event stream.
- Shell does NOT own the subscription — the binding component manages it.

## Theme

The 9 tokens (`--color-*`, `--font-*`, `--radius`, `--density`) propagate via CSS cascade
from the solution root. Structural dimensions (`top_bar_h`, sidebar widths, `context_panel_w`)
are fixed and never theme-overridable.
