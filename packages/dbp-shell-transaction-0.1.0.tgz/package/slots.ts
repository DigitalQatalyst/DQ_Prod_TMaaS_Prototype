export const SHELL_SLOTS = ["sidebar", "header", "main", "context"] as const;

export type SlotName = (typeof SHELL_SLOTS)[number];

export interface SlotMeta {
  readonly name: SlotName;
  readonly region: "sidebarContent" | "topBar" | "mainContent" | "contextPanel";
  readonly description: string;
}

export const SLOT_META: Readonly<Record<SlotName, SlotMeta>> = {
  sidebar: {
    name: "sidebar",
    region: "sidebarContent",
    description:
      "Content region inside the left sidebar, below the primary nav items. Hosts secondary navigation, workspace trees, or additional filters at solution time.",
  },
  header: {
    name: "header",
    region: "topBar",
    description:
      "Breadcrumb zone in the top bar. Typically hosts a breadcrumb trail and/or page title. Sits between the sidebar toggle and the actions zone.",
  },
  main: {
    name: "main",
    region: "mainContent",
    description:
      "Central scrollable content area. Hosts APP.F01 Entity List, APP.F03 Form Builder, APP.F04 Kanban, or any other primary work surface.",
  },
  context: {
    name: "context",
    region: "contextPanel",
    description:
      "Optional right context panel (w:320). Panel renders only when this slot receives content. Below lg it opens as a Sheet. Hosts APP.F02 Entity Detail, APP.F06 Approval Action Surface, or the ActivityFeed binding.",
  },
};
