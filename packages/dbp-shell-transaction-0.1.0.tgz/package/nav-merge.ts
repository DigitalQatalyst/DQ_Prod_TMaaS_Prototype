import type { NavSection } from '@dbp/contracts'

// The six canonical Feature-Area ids (the standard navigation model). A solution
// SELECTS the relevant subset and renames labels for its context, but section ids
// must be drawn from this set so layout inference + nav merge stay stable across
// solutions. See docs/01-Architecture/Standard-Navigation-and-Layout-Map.md.
const KNOWN_SECTION_IDS = [
  'orientation',
  'marketplace',
  'workspace',
  'service-operations',
  'operational-intelligence',
  'platform-management',
] as const

const KNOWN_SECTION_ID_SET = new Set<string>(KNOWN_SECTION_IDS)

/**
 * Validate a solution's nav sections against the standard 6-id model.
 *
 * Presence is OPTIONAL — a solution may declare any subset of the six sections.
 * But every declared section id MUST be one of the known ids; an unknown id is a
 * hard error (it silently emits clean YAML yet 500s at runtime otherwise).
 */
export function mergeNavConfig(sections: NavSection[]): NavSection[] {
  for (const section of sections) {
    if (!KNOWN_SECTION_ID_SET.has(section.id)) {
      throw new Error(
        `Nav config has an unknown section id "${section.id}". ` +
        `Section ids must be one of the standard Feature-Area ids ` +
        `(${KNOWN_SECTION_IDS.join(', ')}). Check your nav-config.ts.`
      )
    }
  }
  return sections
}
