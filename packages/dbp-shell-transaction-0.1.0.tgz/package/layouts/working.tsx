import * as React from 'react'
import { PageHeader } from '@dbp/ui'
import type { BreadcrumbItem } from '@dbp/ui'

interface WorkingLayoutProps {
  pageTitle: string
  subtitle?: string
  breadcrumb?: BreadcrumbItem[]
  action?: { label: string; onClick: () => void }
  children: React.ReactNode
}

export function WorkingLayout({ pageTitle, subtitle, breadcrumb, action, children }: WorkingLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
        <div>
          <PageHeader
            titleSpan={2}
            title={pageTitle}
            {...(subtitle !== undefined && { subtitle })}
            {...(breadcrumb !== undefined && { breadcrumb })}
            {...(action !== undefined && { action })}
          />
        </div>
      </div>
      <div className="flex-1 w-full pt-4 pb-8">
        {children}
      </div>
    </div>
  )
}
