import * as React from 'react'
import { PageHeader } from '@dbp/ui'

interface SettingsLayoutProps {
  pageTitle: string
  nav: React.ReactNode
  children: React.ReactNode
}

export function SettingsLayout({ pageTitle, nav, children }: SettingsLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
        <div>
          <PageHeader titleSpan={3} title={pageTitle} />
        </div>
      </div>
      <div className="flex flex-1 w-full pt-4 pb-8 gap-8">
        <aside className="w-[var(--settings-nav-w)] shrink-0">{nav}</aside>
        <main className="flex-1 min-w-0 max-w-[var(--settings-form-max-w)]">{children}</main>
      </div>
    </div>
  )
}
