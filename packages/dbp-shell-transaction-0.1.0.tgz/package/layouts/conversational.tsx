import * as React from 'react'

interface ConversationalLayoutProps {
  thread: React.ReactNode
  input: React.ReactNode
}

export function ConversationalLayout({ thread, input }: ConversationalLayoutProps) {
  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {thread}
      </div>
      <div className="shrink-0 border-t border-[var(--color-border)] px-6 py-4 bg-[var(--color-surface)]">
        {input}
      </div>
    </div>
  )
}
