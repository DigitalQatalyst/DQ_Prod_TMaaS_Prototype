import * as React from 'react'

interface LveLayoutProps {
  list: React.ReactNode
  detail: React.ReactNode
  edit?: React.ReactNode
  editOpen?: boolean
}

export function LveLayout({ list, detail, edit, editOpen = false }: LveLayoutProps) {
  return (
    <div className="flex h-full overflow-hidden">
      <div className="w-[var(--lve-list-w)] shrink-0 border-r border-[var(--color-border)] overflow-y-auto">
        {list}
      </div>
      <div className="flex-1 overflow-y-auto">
        {detail}
      </div>
      {edit && (
        <div
          className={[
            'w-[var(--lve-edit-w)] shrink-0 border-l border-[var(--color-border)] overflow-y-auto',
            'motion-safe:transition-transform',
            editOpen ? 'translate-x-0' : 'translate-x-full',
          ].join(' ')}
          aria-hidden={!editOpen}
        >
          {edit}
        </div>
      )}
    </div>
  )
}
