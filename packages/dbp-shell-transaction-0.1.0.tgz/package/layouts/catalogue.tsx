import * as React from 'react'
import { PageHeader } from '@dbp/ui'
import type { BreadcrumbItem } from '@dbp/ui'

interface CatalogueLayoutProps {
  pageTitle: string
  subtitle?: string
  breadcrumb?: BreadcrumbItem[]
  filters?: React.ReactNode
  children: React.ReactNode
}

export function CatalogueLayout({ pageTitle, subtitle, breadcrumb, filters, children }: CatalogueLayoutProps) {
  return (
    <div className="flex flex-col min-h-full w-full overflow-y-auto">
      <div className="sticky top-0 z-10 bg-[var(--color-surface)]">
        <div>
          <PageHeader
            titleSpan={2}
            title={pageTitle}
            {...(subtitle !== undefined && { subtitle })}
            {...(breadcrumb !== undefined && { breadcrumb })}
          />
        </div>
      </div>
      <div className="flex flex-1 w-full pt-4 pb-8 gap-6">
        {filters && (
          <aside className="w-[var(--catalogue-filter-w)] shrink-0">{filters}</aside>
        )}
        <main className="flex-1 min-w-0">{children}</main>
      </div>
    </div>
  )
}
