"use client";
import * as React from "react";
import { usePathname } from "next/navigation";
import * as LucideIcons from "lucide-react";
import {
  AppSidebar,
  SlotFrame,
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  buildSidebarConfig,
  deriveActivePath,
} from "@dbp/ui";
import type { ModuleNav, NavSection } from "@dbp/contracts";
import { type SlotName } from "./slots.js";
import { type NavItem } from "./nav.js";
import { mergeNavConfig } from "./nav-merge.js";
import { SessionGuard } from "./session-guard.js";

/**
 * Render a named slot's content, or NOTHING when unfilled.
 *
 * Unfilled optional slots must not surface the dashed `slot:<name>` dev
 * placeholder at runtime (UI-audit fix; commit fe92b7c precedent). SlotFrame is
 * reserved for Storybook stories that pass `isEmpty`/placeholders explicitly.
 */
function Slot({ name, children }: { name: SlotName; children?: React.ReactNode }) {
  if (children == null) return null;
  return <SlotFrame slotName={name}>{children}</SlotFrame>;
}


type LucideGlyph = React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }>;

function resolveNavIcon(name: string): LucideGlyph | null {
  const icon = (LucideIcons as Record<string, unknown>)[name];
  if (typeof icon === "object" && icon !== null && "$$typeof" in icon) return icon as LucideGlyph;
  return null;
}

function NavGlyph({ name }: { name: string }) {
  const Icon = resolveNavIcon(name);
  if (!Icon) return null;
  return <Icon size={17} strokeWidth={1.5} />;
}

/**
 * SH.02 fixed structural dimensions (from SCAFFOLD-SPEC Part A).
 * All shell dimensions are consumed from design tokens (base.css) so they are
 * the single source of truth and cannot drift from the spec. Never hardcode px.
 */
const SIDEBAR_W_EXPANDED = "var(--shell-sidebar-w)"; // 280px
const SIDEBAR_W_COLLAPSED = "var(--shell-sidebar-collapsed-w)"; // 64px
const CONTEXT_PANEL_W = "var(--shell-panel-w)"; // 320px (context panel + mobile drawer)

export interface TransactionShellProps {
  /** Named slot content. Every slot defaults to an empty SlotFrame when omitted. */
  slots?: Partial<Record<SlotName, React.ReactNode>>;
  /** Nav chrome configuration. */
  nav?: {
    logo?: React.ReactNode;
    /** Primary sidebar nav items — Zod-typed via NavItem in nav.tsx. */
    items?: NavItem[];
    /**
     * Grouped sidebar nav — use this instead of `items` for the DWS.01-style
     * three-level hierarchy (section → group → children). When provided,
     * `items` is ignored. Each section may have an optional eyebrow label
     * (e.g. "ORIENTATION"), groups are collapsible, children are indented.
     */
    sections?: NavSection[];
    breadcrumb?: React.ReactNode;
    user?: React.ReactNode;
    /**
     * Actions zone rendered in the top-bar trailing area.
     * Phase 4 bindings (NotificationBell / UserMenu) mount here.
     * See SHELL.md for the binding contract.
     */
    actions?: React.ReactNode;
    /**
     * Enriched, full-width top bar (e.g. `<AppChrome>` from @dbp/ui). When
     * provided it OWNS the entire top-bar content to the right of the sidebar
     * toggle — `breadcrumb`, `actions`, and `user` are then ignored. This is the
     * session + capability driven chrome inherited by every app. Omit it to keep
     * the legacy breadcrumb + actions layout (backward compatible).
     */
    topBar?: React.ReactNode;
    /**
     * When true the sidebar starts collapsed (icon-only strip).
     * Default: false — sidebar starts expanded.
     * Use for Type 6 Conversational pages (/copilot) where spec §6 requires
     * the sidebar to collapse automatically.
     */
    defaultCollapsed?: boolean;
  };
  /**
   * Controls the context panel's open state when populated-but-closeable mode is
   * desired. When undefined and the `context` slot has content the panel is shown.
   * Pass false to force-close it even when content is present.
   */
  contextOpen?: boolean;
  /** Called when the panel requests a state change (close button, Sheet overlay). */
  onContextOpenChange?: (open: boolean) => void;
  /** Solution identifier used to namespace the nav collapse localStorage key. */
  solutionId?: string;
}

/**
 * SH.02 — Transaction Workspace Shell
 *
 * Fixed three-column layout: collapsible sidebar | main content | optional context panel.
 * Structure is immutable across theme swaps — only the 9 tokens affect appearance.
 *
 * Slots: sidebar · header · main · context
 *
 * @see SHELL.md for full slot/dimension/responsive/PS-wiring documentation.
 */
export default function TransactionShell({
  slots = {},
  nav = {},
  contextOpen,
  onContextOpenChange,
  solutionId,
}: TransactionShellProps) {
  const pathname = usePathname();
  const [sidebarCollapsed, setSidebarCollapsed] = React.useState(nav?.defaultCollapsed === true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = React.useState(false);
  const [mobileContextOpen, setMobileContextOpen] = React.useState(false);

  const sidebarId = React.useId();

  const validatedSections = React.useMemo(
    () => (nav?.sections ? mergeNavConfig(nav.sections) : []),
    [nav?.sections],
  );

  const hasContextContent = Boolean(slots.context);
  // Panel is visible when: there is content AND contextOpen is not explicitly false.
  const contextPanelVisible =
    hasContextContent && (contextOpen === undefined ? true : contextOpen);

  const toggleSidebar = React.useCallback(() => {
    setSidebarCollapsed((prev) => !prev);
  }, []);

  const handleToggleKeyDown = React.useCallback(
    (e: React.KeyboardEvent<HTMLButtonElement>) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggleSidebar();
      }
    },
    [toggleSidebar],
  );

  const handleContextClose = React.useCallback(() => {
    if (onContextOpenChange) {
      onContextOpenChange(false);
    }
    setMobileContextOpen(false);
  }, [onContextOpenChange]);

  return (
    <SessionGuard>
    <div className="flex h-dvh min-h-0 flex-col bg-[var(--color-surface)]">
      {/* ── Top Bar ──────────────────────────────────────────────────── */}
      <header
        style={{ height: "var(--shell-header-h)" }}
        className="flex shrink-0 items-center border-b border-[var(--color-border-subtle)] bg-white z-[var(--z-sticky)]"
      >
        {/* Sidebar toggle — visible on desktop; hamburger opens Sheet on mobile */}
        <div className="flex items-center px-2">
          {/* Desktop collapse toggle */}
          <button
            type="button"
            aria-expanded={!sidebarCollapsed}
            aria-controls={sidebarId}
            onClick={toggleSidebar}
            onKeyDown={handleToggleKeyDown}
            className="hidden md:flex items-center justify-center w-9 h-9 rounded text-[color-mix(in_srgb,var(--color-text)_65%,transparent)] hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-1"
            title={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {/* Hamburger / panel icon */}
            <svg
              aria-hidden="true"
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M2 3h12M2 8h12M2 13h12"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
            <span className="sr-only">
              {sidebarCollapsed ? "Expand" : "Collapse"} sidebar
            </span>
          </button>

          {/* Mobile hamburger — opens Sheet */}
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(true)}
            className="md:hidden flex items-center justify-center w-9 h-9 rounded text-[color-mix(in_srgb,var(--color-text)_65%,transparent)] hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-1"
            aria-label="Open navigation"
          >
            <svg
              aria-hidden="true"
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M2 3h12M2 8h12M2 13h12"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>

        {/* Enriched chrome (AppChrome) OWNS the rest of the bar when provided —
            session + capability driven. Falls back to the legacy breadcrumb +
            actions layout otherwise (backward compatible). */}
        {nav.topBar != null ? (
          <div data-slot-name="topBar" className="min-w-0 flex-1">
            {nav.topBar}
          </div>
        ) : (
          <>
            {/* Breadcrumb zone — header slot (nav.breadcrumb is the default content) */}
            {(slots.header ?? nav.breadcrumb) != null && (
              <div className="flex-1 min-w-0 px-2">
                <Slot name="header">{slots.header ?? nav.breadcrumb}</Slot>
              </div>
            )}

            {/* Actions zone — Phase 4 bindings mount here (NotificationBell, UserMenu) */}
            <div
              data-slot-name="actions"
              className="flex shrink-0 items-center gap-1 px-3"
              aria-label="Top bar actions"
            >
              {nav.actions ?? null}
              {nav.user && <div className="ml-1">{nav.user}</div>}
            </div>
          </>
        )}
      </header>

      {/* ── Body: Sidebar + Main + Context Panel ─────────────────────── */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* ── Left Sidebar (inline on ≥md) ────────────────────────────── */}
        <aside
          id={sidebarId}
          aria-label="Workspace navigation"
          style={{
            width: sidebarCollapsed ? SIDEBAR_W_COLLAPSED : SIDEBAR_W_EXPANDED,
          }}
          className={[
            "hidden md:flex flex-col shrink-0 border-r border-[var(--color-border-subtle)] bg-white overflow-hidden",
            "motion-safe:transition-[width] motion-safe:duration-200 motion-safe:ease-in-out",
          ].join(" ")}
        >
          {/* Logo area */}
          {nav.logo && (
            <div
              style={{ height: "var(--shell-header-h)" }}
              className="flex shrink-0 items-center border-b border-[var(--color-border-subtle)] px-3 overflow-hidden"
            >
              <div className="shrink-0">{nav.logo}</div>
            </div>
          )}

          {/* Primary nav items — AppSidebar when expanded; icon-only list when collapsed */}
          {(validatedSections.length || nav.items?.length) ? (
            (() => {
              // Build a unified ModuleNav for both code paths.
              const moduleNav = validatedSections.length
                ? ({ items: [], sections: validatedSections } as unknown as ModuleNav)
                : ({ items: nav.items ?? [] } as ModuleNav);
              const sidebarConfig = buildSidebarConfig(moduleNav);
              // Use the live pathname so AppSidebar auto-expands the correct
              // group and marks the correct child active on every navigation.
              const activePath = pathname ?? deriveActivePath(moduleNav);

              // Collapsed: icon-only strip — pull icons from first group in each section.
              if (sidebarCollapsed) {
                const collapsedItems = sidebarConfig.sections.flatMap((s) =>
                  s.items.map((g) => ({ id: g.id, label: g.label, icon: g.icon, href: g.href, active: activePath === g.href || activePath.startsWith(g.href + "/") }))
                );
                return (
                  <nav aria-label="Primary navigation" className="shrink-0 py-2">
                    <ul role="list" className="flex flex-col gap-1 px-3">
                      {collapsedItems.map((item) => (
                        <li key={item.id}>
                          <a
                            href={item.href ?? "#"}
                            aria-current={item.active ? "page" : undefined}
                            title={item.label}
                            className={[
                              "relative sidebar-feature-group whitespace-nowrap",
                              item.active && "sidebar-feature-group-active",
                              "focus-visible:outline-none focus-visible:[box-shadow:var(--focus-ring-navy)]",
                            ]
                              .filter(Boolean)
                              .join(" ")}
                          >
                            {item.active && (
                              <span
                                aria-hidden
                                className="absolute bottom-1.5 left-0 top-1.5 w-0.5 rounded-r bg-secondary"
                              />
                            )}
                            {item.icon && (
                              <span className="flex h-5 w-5 shrink-0 items-center justify-center" aria-hidden="true">
                                <NavGlyph name={item.icon} />
                              </span>
                            )}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </nav>
                );
              }

              return (
                <AppSidebar
                  config={sidebarConfig}
                  activePath={activePath}
                  onNavigate={(href) => { window.location.href = href; }}
                  storageKey={`dbp-nav-state-${solutionId ?? 'default'}`}
                />
              );
            })()
          ) : null}

          {/* sidebar slot — content region below primary nav; hidden when empty */}
          {slots.sidebar != null && (
            <div className="flex-1 overflow-y-auto p-2">
              <Slot name="sidebar">{slots.sidebar}</Slot>
            </div>
          )}

          {/* Footer nav — Help/Support + Logout, pinned to bottom */}
          <div className="shrink-0 border-t border-[var(--color-border-subtle)] py-2 px-1">
            <a href="/help" title="Help / Support" className="sidebar-feature-group font-normal">
              <svg aria-hidden width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>
              </svg>
              {!sidebarCollapsed && <span>Help / Support</span>}
            </a>
            <a href="/logout" title="Logout" className="sidebar-feature-group font-normal">
              <svg aria-hidden width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              {!sidebarCollapsed && <span>Logout</span>}
            </a>
          </div>
        </aside>

        {/* ── Main Content ─────────────────────────────────────────────── */}
        <main
          className="flex-1 min-w-0 overflow-y-auto p-[var(--shell-gutter)]"
          aria-label="Main content"
        >
          <Slot name="main">{slots.main}</Slot>
        </main>

        {/* ── Context Panel (inline on ≥lg) ────────────────────────────── */}
        {contextPanelVisible && (
          <aside
            style={{ width: CONTEXT_PANEL_W }}
            className="hidden lg:flex flex-col shrink-0 border-l border-[var(--color-border-subtle)] bg-white overflow-hidden"
            aria-label="Context panel"
          >
            {/* Close button for populated-but-closeable mode */}
            {onContextOpenChange && (
              <div className="flex shrink-0 items-center justify-end px-3 py-2 border-b border-[var(--color-border-subtle)]">
                <button
                  type="button"
                  onClick={handleContextClose}
                  className="flex items-center justify-center w-7 h-7 rounded text-[color-mix(in_srgb,var(--color-text)_60%,transparent)] hover:bg-[color-mix(in_srgb,var(--color-border)_40%,transparent)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-primary)] focus-visible:ring-offset-1"
                  aria-label="Close context panel"
                >
                  <svg
                    aria-hidden="true"
                    width="14"
                    height="14"
                    viewBox="0 0 14 14"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M1 1l12 12M13 1L1 13"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                  </svg>
                </button>
              </div>
            )}
            <div className="flex-1 overflow-y-auto p-[var(--shell-gutter)]">
              <Slot name="context">{slots.context}</Slot>
            </div>
          </aside>
        )}

        {/* Context panel — stacks as Sheet below lg */}
        {hasContextContent && (
          <Sheet
            open={mobileContextOpen}
            onOpenChange={(open) => {
              setMobileContextOpen(open);
              if (!open) onContextOpenChange?.(false);
            }}
          >
            <SheetContent side="right">
              <SheetHeader>
                <SheetTitle>Context</SheetTitle>
              </SheetHeader>
              <div className="flex-1 overflow-y-auto p-[var(--shell-gutter)]" data-slot-name="context">
                <Slot name="context">{slots.context}</Slot>
              </div>
            </SheetContent>
          </Sheet>
        )}
      </div>

      {/* ── Mobile Sidebar Sheet ─────────────────────────────────────── */}
      <Sheet open={mobileSidebarOpen} onOpenChange={setMobileSidebarOpen}>
        <SheetContent side="left">
          <SheetHeader>
            <SheetTitle>Navigation</SheetTitle>
          </SheetHeader>
          <div className="flex flex-col gap-2 py-2" data-slot-name="sidebar">
            {(validatedSections.length || nav.items?.length) ? (
              (() => {
                const moduleNav = validatedSections.length
                  ? ({ items: [], sections: validatedSections } as unknown as ModuleNav)
                  : ({ items: nav.items ?? [] } as ModuleNav);
                return (
                  <AppSidebar
                    config={buildSidebarConfig(moduleNav)}
                    activePath={pathname ?? deriveActivePath(moduleNav)}
                    onNavigate={() => setMobileSidebarOpen(false)}
                    storageKey={`dbp-nav-state-${solutionId ?? 'default'}`}
                  />
                );
              })()
            ) : null}
            <div className="px-2">
              <Slot name="sidebar">{slots.sidebar}</Slot>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
    </SessionGuard>
  );
}
