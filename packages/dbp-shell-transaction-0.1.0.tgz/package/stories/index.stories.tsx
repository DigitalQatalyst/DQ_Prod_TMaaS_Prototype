import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SlotFrame } from "@dbp/ui";
import TransactionShell from "../index.js";

const meta: Meta<typeof TransactionShell> = {
  title: "Shells/SH.02 Transaction Workspace",
  component: TransactionShell,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**SH.02 — Transaction Workspace Shell** (Stage 02 Transact)

Fixed structure: top bar (h:64 via --shell-header-h) → [sidebar w:280/64 collapsible | main content | context panel w:320 optional].

Slots: \`sidebar\` · \`header\` · \`main\` · \`context\`

The sidebar collapses from w:240 to w:64 — icons remain visible. The context panel
renders only when the \`context\` slot has content; below lg it opens as a Sheet.
Toggle the **Theme** toolbar button to verify zero structural change between "DBP default" and "Alt client".
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof TransactionShell>;

// ─── Mock helpers ──────────────────────────────────────────────────────────────

function MockIcon({ label }: { label: string }) {
  return (
    <svg
      aria-hidden="true"
      width="16"
      height="16"
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect
        x="1"
        y="1"
        width="14"
        height="14"
        rx="2"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      <text
        x="8"
        y="11"
        textAnchor="middle"
        fontSize="7"
        fill="currentColor"
        fontFamily="monospace"
      >
        {label[0]}
      </text>
    </svg>
  );
}

const MOCK_NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: <MockIcon label="Dashboard" />, active: true, href: "#" },
  { id: "orders", label: "Orders", icon: <MockIcon label="Orders" />, href: "#" },
  { id: "products", label: "Products", icon: <MockIcon label="Products" />, href: "#" },
  { id: "customers", label: "Customers", icon: <MockIcon label="Customers" />, href: "#" },
  { id: "reports", label: "Reports", icon: <MockIcon label="Reports" />, href: "#" },
];

function MockMainContent() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <p style={{ margin: 0, fontSize: "14px", color: "var(--color-text)", opacity: 0.7 }}>
        slot:main — APP.F01 Entity List or similar feature mounts here at solution time.
      </p>
      {Array.from({ length: 5 }, (_, i) => (
        <div
          key={i}
          style={{
            padding: "12px 16px",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius)",
            color: "var(--color-text)",
            fontSize: "14px",
          }}
        >
          Row {i + 1} — entity data from PS.DATA
        </div>
      ))}
    </div>
  );
}

function MockContextContent() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <h3 style={{ margin: "0 0 4px", fontSize: "15px", fontWeight: 600, color: "var(--color-text)" }}>
        Entity Detail
      </h3>
      <p style={{ margin: 0, fontSize: "13px", color: "color-mix(in srgb, var(--color-text) 65%, transparent)" }}>
        APP.F02 Entity Detail Panel or APP.F06 Approval Surface mounts here at solution time.
      </p>
      {["Field A", "Field B", "Field C"].map((f) => (
        <div
          key={f}
          style={{
            display: "flex",
            justifyContent: "space-between",
            fontSize: "13px",
            color: "var(--color-text)",
            padding: "6px 0",
            borderBottom: "1px solid var(--color-border)",
          }}
        >
          <span style={{ opacity: 0.6 }}>{f}</span>
          <span>value</span>
        </div>
      ))}
    </div>
  );
}

// ─── Empty Shell ──────────────────────────────────────────────────────────────

/**
 * All 4 slots render as labeled SlotFrame placeholders.
 *
 * At RUNTIME unfilled slots collapse (render nothing); this story passes
 * SlotFrame placeholders EXPLICITLY so the slot layout (incl. the context panel)
 * is visible in Storybook. Renders correctly in both toolbar themes.
 */
export const EmptyShell: Story = {
  name: "Empty shell (all 4 SlotFrames, context open)",
  render: () => (
    <div style={{ height: "600px" }}>
      <TransactionShell
        slots={{
          sidebar: <SlotFrame slotName="sidebar" isEmpty />,
          header: <SlotFrame slotName="header" isEmpty />,
          main: <SlotFrame slotName="main" isEmpty />,
          context: <SlotFrame slotName="context" isEmpty />,
        }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "All 4 slots shown as labeled SlotFrame placeholders (passed explicitly — at runtime unfilled slots collapse). Renders correctly in both toolbar themes.",
      },
    },
  },
};

// ─── Populated ────────────────────────────────────────────────────────────────

export const Populated: Story = {
  name: "Populated shell",
  render: () => (
    <div style={{ height: "600px" }}>
      <TransactionShell
        nav={{
          logo: (
            <span
              style={{
                fontWeight: 700,
                color: "var(--color-primary)",
                fontSize: "16px",
                whiteSpace: "nowrap",
              }}
            >
              DBP Tx
            </span>
          ),
          items: MOCK_NAV_ITEMS,
          breadcrumb: (
            <nav aria-label="Breadcrumb">
              <ol
                style={{
                  display: "flex",
                  gap: "4px",
                  listStyle: "none",
                  margin: 0,
                  padding: 0,
                  fontSize: "13px",
                  color: "color-mix(in srgb, var(--color-text) 60%, transparent)",
                }}
              >
                <li>Workspace</li>
                <li aria-hidden="true">/</li>
                <li style={{ color: "var(--color-text)", fontWeight: 500 }}>Orders</li>
              </ol>
            </nav>
          ),
          actions: (
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: "var(--radius)",
                background: "color-mix(in srgb, var(--color-border) 40%, transparent)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "11px",
                color: "var(--color-text)",
              }}
            >
              {/* Phase 4: NotificationBell mounts here */}
              🔔
            </div>
          ),
          user: (
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: "50%",
                background: "var(--color-primary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "11px",
                color: "#fff",
                fontWeight: 600,
              }}
            >
              U
            </div>
          ),
        }}
        slots={{
          sidebar: (
            <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
              <p
                style={{
                  margin: "0 0 8px",
                  fontSize: "11px",
                  fontWeight: 600,
                  textTransform: "uppercase",
                  letterSpacing: "0.05em",
                  color: "color-mix(in srgb, var(--color-text) 50%, transparent)",
                }}
              >
                Filters
              </p>
              {["All", "Pending", "In Progress", "Completed"].map((s) => (
                <button
                  key={s}
                  style={{
                    padding: "4px 8px",
                    background: "none",
                    border: "none",
                    borderRadius: "var(--radius)",
                    color: "var(--color-text)",
                    fontSize: "13px",
                    cursor: "pointer",
                    textAlign: "left",
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
          ),
          main: <MockMainContent />,
          context: <MockContextContent />,
        }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "Shell populated with representative content in every slot.",
      },
    },
  },
};

// ─── Sidebar Collapsed ────────────────────────────────────────────────────────

export const SidebarCollapsed: Story = {
  name: "Sidebar — collapsed state",
  render: () => (
    <div style={{ height: "500px" }}>
      <TransactionShell
        nav={{
          logo: (
            <span style={{ fontWeight: 700, color: "var(--color-primary)", fontSize: "16px" }}>
              DBP
            </span>
          ),
          items: MOCK_NAV_ITEMS,
          breadcrumb: (
            <span style={{ fontSize: "13px", color: "var(--color-text)" }}>
              Orders / New Order
            </span>
          ),
        }}
        slots={{
          main: <MockMainContent />,
        }}
      />
      <p
        style={{
          position: "absolute",
          bottom: 8,
          left: 8,
          margin: 0,
          fontSize: "12px",
          color: "var(--color-text)",
          background: "var(--color-surface)",
          padding: "4px 8px",
          borderRadius: "var(--radius)",
          border: "1px solid var(--color-border)",
        }}
      >
        Click the ≡ toggle in the top bar to collapse/expand the sidebar. Icons remain visible collapsed.
      </p>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Sidebar in collapsed state (w:64). Icons remain visible; labels are hidden. The ≡ toggle in the top bar controls the collapse with a width transition (skipped under prefers-reduced-motion).",
      },
    },
  },
};

// ─── Mobile Viewport ──────────────────────────────────────────────────────────

export const MobileViewport: Story = {
  name: "Mobile viewport (< md)",
  render: () => (
    <div style={{ width: "375px", height: "667px", overflow: "hidden" }}>
      <TransactionShell
        nav={{
          logo: (
            <span style={{ fontWeight: 700, color: "var(--color-primary)", fontSize: "15px" }}>
              DBP
            </span>
          ),
          items: MOCK_NAV_ITEMS,
          breadcrumb: (
            <span style={{ fontSize: "13px", color: "var(--color-text)" }}>Orders</span>
          ),
        }}
        slots={{
          main: <MockMainContent />,
        }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "375px viewport. The sidebar is hidden from layout and opens as a Sheet via the hamburger button. The context panel is also hidden at this breakpoint (opens as a Sheet when triggered).",
      },
    },
  },
};
