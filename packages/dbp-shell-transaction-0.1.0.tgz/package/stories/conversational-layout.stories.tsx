import type { Meta, StoryObj } from '@storybook/react'
import * as React from 'react'
import { ConversationalLayout } from '../layouts/conversational.js'

const meta: Meta<typeof ConversationalLayout> = {
  title: 'Layouts/ConversationalLayout',
  component: ConversationalLayout,
  parameters: { layout: 'fullscreen' },
}
export default meta
type Story = StoryObj<typeof ConversationalLayout>

const thread = (
  <div className="space-y-3 py-4">
    {['Hello', 'How can I help?', 'Show me recent tasks'].map((m, i) => (
      <div
        key={i}
        className={`max-w-xs rounded-lg px-3 py-2 text-sm ${i % 2 === 0 ? 'bg-gray-100' : 'bg-blue-600 text-white ml-auto'}`}
      >
        {m}
      </div>
    ))}
  </div>
)
const input = (
  <div className="flex gap-2">
    <input className="flex-1 border rounded-lg px-3 py-2 text-sm" placeholder="Ask anything..." />
    <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm">Send</button>
  </div>
)

export const Default: Story = { args: { thread, input } }
