import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import type { BreadcrumbItem } from "@dbp/ui";
import { AnalyticsLayout } from "../layouts/analytics.js";

// ─── Mock helpers ────────────────────────────────────────────────────────────────

/** A row of KPI stat cards — typical analytics page header content. */
function KpiRow() {
  const kpis: { label: string; value: string; delta: string; up: boolean }[] = [
    { label: "Active Users", value: "4,821", delta: "+12%", up: true },
    { label: "Requests Today", value: "1,340", delta: "+5%", up: true },
    { label: "Avg. Handle Time", value: "3m 42s", delta: "−8%", up: true },
    { label: "SLA Breaches", value: "7", delta: "+2", up: false },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: "12px", marginBottom: "24px" }}>
      {kpis.map((k) => (
        <div
          key={k.label}
          style={{
            padding: "16px",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius)",
          }}
        >
          <p style={{ margin: "0 0 4px", fontSize: "11px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em", color: "color-mix(in srgb, var(--color-text) 55%, transparent)" }}>
            {k.label}
          </p>
          <p style={{ margin: "0 0 4px", fontSize: "24px", fontWeight: 700, color: "var(--color-text)" }}>
            {k.value}
          </p>
          <p style={{ margin: 0, fontSize: "12px", color: k.up ? "var(--color-primary)" : "color-mix(in srgb, var(--color-text) 55%, transparent)" }}>
            {k.delta} vs last period
          </p>
        </div>
      ))}
    </div>
  );
}

/** A placeholder chart area. */
function ChartPlaceholder({ label }: { label: string }) {
  return (
    <div
      style={{
        height: "220px",
        background: "color-mix(in srgb, var(--color-border) 30%, transparent)",
        border: "1px dashed var(--color-border)",
        borderRadius: "var(--radius)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "color-mix(in srgb, var(--color-text) 40%, transparent)",
        fontSize: "13px",
        fontStyle: "italic",
      }}
    >
      {label}
    </div>
  );
}

/** A mock filter bar (date range + dimension pickers). */
function MockFilterBar() {
  return (
    <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap", paddingBottom: "8px" }}>
      {["Last 7 days", "By area", "By role"].map((f) => (
        <button
          key={f}
          type="button"
          style={{
            padding: "4px 12px",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius)",
            background: "var(--color-surface)",
            color: "var(--color-text)",
            fontSize: "12px",
            cursor: "pointer",
          }}
        >
          {f}
        </button>
      ))}
      <span style={{ marginLeft: "auto", fontSize: "12px", color: "color-mix(in srgb, var(--color-text) 50%, transparent)" }}>
        Showing 2026-06-12 → 2026-06-19
      </span>
    </div>
  );
}

const BREADCRUMB: BreadcrumbItem[] = [
  { label: "Analytics", href: "#" },
  { label: "Operational KPIs" },
];

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof AnalyticsLayout> = {
  title: "Layouts/AnalyticsLayout",
  component: AnalyticsLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**AnalyticsLayout** — a sticky-header layout designed for KPI dashboards and chart pages.

Props: \`pageTitle\` · \`subtitle?\` · \`breadcrumb?: BreadcrumbItem[]\` · \`filterBar?: ReactNode\` · \`children\`

The header (PageHeader + optional filterBar) is sticky so it remains visible while the user
scrolls through charts. Content is constrained to \`max-w-[1400px]\` with consistent \`px-6 py-6\`
padding. The filterBar zone is separated from the page title by a border so it reads as a distinct
control surface.

Use this layout for: APP.F09 Analytics Hub, APP.F18 Reporting pages, APP.F20 Audit logs.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof AnalyticsLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/**
 * Baseline — title + subtitle + KPI row + two chart placeholders. No filter bar,
 * no breadcrumb. Shows the default layout with the sticky header at its minimum.
 */
export const Default: Story = {
  name: "Default (title + KPI row + charts)",
  args: {
    pageTitle: "Operational KPIs",
    subtitle: "Platform-wide metrics for the current reporting period",
  },
  render: (args) => (
    <div style={{ height: "700px" }}>
      <AnalyticsLayout {...args}>
        <KpiRow />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
          <ChartPlaceholder label="Requests over time (line chart)" />
          <ChartPlaceholder label="Requests by area (bar chart)" />
        </div>
      </AnalyticsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "Minimal usage: title + subtitle in the sticky header, KPI cards, and chart placeholders as children.",
      },
    },
  },
};

/**
 * With filter bar — a sticky date-range + dimension picker row appears below
 * the PageHeader, separated by a hairline border. Demonstrates the `filterBar`
 * slot used by scoped analytics views.
 */
export const WithFilterBar: Story = {
  name: "With filter bar",
  args: {
    pageTitle: "Operational KPIs",
    subtitle: "Platform-wide metrics",
    filterBar: <MockFilterBar />,
  },
  render: (args) => (
    <div style={{ height: "700px" }}>
      <AnalyticsLayout {...args}>
        <KpiRow />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
          <ChartPlaceholder label="Requests over time (line chart)" />
          <ChartPlaceholder label="Requests by area (bar chart)" />
        </div>
      </AnalyticsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "filterBar renders below the PageHeader with a top border separator. Typically contains date-range pickers and dimension facets.",
      },
    },
  },
};

/**
 * With breadcrumb — the eyebrow trail appears above the page title in the
 * PageHeader, linking back to the Analytics Hub landing.
 */
export const WithBreadcrumb: Story = {
  name: "With breadcrumb",
  args: {
    pageTitle: "Operational KPIs",
    subtitle: "Platform-wide metrics",
    breadcrumb: BREADCRUMB,
  },
  render: (args) => (
    <div style={{ height: "700px" }}>
      <AnalyticsLayout {...args}>
        <KpiRow />
        <ChartPlaceholder label="Full-width trend chart" />
      </AnalyticsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "breadcrumb renders as the DQ mono-uppercase overline trail above the page title. Items are BreadcrumbItem[] — { label, href? }.",
      },
    },
  },
};
