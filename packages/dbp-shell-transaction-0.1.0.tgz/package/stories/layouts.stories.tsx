import type { Meta, StoryObj } from '@storybook/react'
import * as React from 'react'
import { LveLayout } from '../layouts/lve.js'

const meta: Meta<typeof LveLayout> = {
  title: 'Layouts/LveLayout',
  component: LveLayout,
  parameters: { layout: 'fullscreen' },
}
export default meta
type Story = StoryObj<typeof LveLayout>

const listContent = (
  <div className="p-4 space-y-2">
    {['Record A', 'Record B', 'Record C'].map(r => (
      <div key={r} className="p-3 bg-gray-50 rounded border">{r}</div>
    ))}
  </div>
)
const detailContent = (
  <div className="p-6">
    <h2 className="text-lg font-semibold">Record A</h2>
    <p className="mt-2 text-sm text-gray-500">Detail view content</p>
  </div>
)
const editContent = (
  <div className="p-6 space-y-4">
    <div className="space-y-1">
      <label className="text-sm font-medium">Title</label>
      <input className="w-full border rounded px-3 py-2 text-sm" defaultValue="Record A" />
    </div>
  </div>
)

export const Default: Story = { args: { list: listContent, detail: detailContent } }
export const WithEditPanel: Story = { args: { list: listContent, detail: detailContent, edit: editContent, editOpen: true } }
