import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { SettingsLayout } from "../layouts/settings.js";

// ─── Mock helpers ────────────────────────────────────────────────────────────────

/** A vertical settings sub-nav — sibling-route links (no Next/Link, just <a>). */
function MockSettingsNav({ active }: { active: string }) {
  const links = [
    { label: "General", href: "#general" },
    { label: "Profile", href: "#profile" },
    { label: "Notifications", href: "#notifications" },
    { label: "Security", href: "#security" },
    { label: "Integrations", href: "#integrations" },
    { label: "Billing", href: "#billing" },
  ];
  return (
    <nav aria-label="Settings navigation">
      <ul role="list" style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: "2px" }}>
        {links.map(({ label, href }) => {
          const isActive = label === active;
          return (
            <li key={label}>
              <a
                href={href}
                aria-current={isActive ? "page" : undefined}
                style={{
                  display: "block",
                  padding: "7px 10px",
                  borderRadius: "var(--radius)",
                  fontSize: "13px",
                  fontWeight: isActive ? 600 : 400,
                  color: isActive ? "var(--color-primary)" : "var(--color-text)",
                  background: isActive
                    ? "color-mix(in srgb, var(--color-primary) 8%, transparent)"
                    : "transparent",
                  textDecoration: "none",
                }}
              >
                {label}
              </a>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

/** A generic mock form for a settings page. */
function MockSettingsForm({ section }: { section: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
      <p style={{ margin: 0, fontSize: "13px", color: "color-mix(in srgb, var(--color-text) 60%, transparent)" }}>
        Configure your {section.toLowerCase()} settings. Changes are saved automatically when you
        leave each field.
      </p>

      {/* Text field group */}
      <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
        <label
          htmlFor="display-name"
          style={{ fontSize: "13px", fontWeight: 600, color: "var(--color-text)" }}
        >
          Display name
        </label>
        <input
          id="display-name"
          type="text"
          defaultValue="Alpha Finance Approver"
          style={{
            padding: "7px 10px",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius)",
            fontSize: "13px",
            color: "var(--color-text)",
            background: "var(--color-surface)",
            outline: "none",
          }}
        />
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
        <label
          htmlFor="email"
          style={{ fontSize: "13px", fontWeight: 600, color: "var(--color-text)" }}
        >
          Email address
        </label>
        <input
          id="email"
          type="email"
          defaultValue="approver@alpha.dev.local"
          style={{
            padding: "7px 10px",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius)",
            fontSize: "13px",
            color: "var(--color-text)",
            background: "var(--color-surface)",
            outline: "none",
          }}
        />
      </div>

      {/* Toggle row */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "12px",
          border: "1px solid var(--color-border)",
          borderRadius: "var(--radius)",
        }}
      >
        <div>
          <p style={{ margin: "0 0 2px", fontSize: "13px", fontWeight: 600, color: "var(--color-text)" }}>
            Email notifications
          </p>
          <p style={{ margin: 0, fontSize: "12px", color: "color-mix(in srgb, var(--color-text) 55%, transparent)" }}>
            Receive activity digests and workflow alerts
          </p>
        </div>
        <div
          style={{
            width: "36px",
            height: "20px",
            borderRadius: "10px",
            background: "var(--color-primary)",
            display: "flex",
            alignItems: "center",
            padding: "2px",
            cursor: "pointer",
          }}
        >
          <div
            style={{
              width: "16px",
              height: "16px",
              borderRadius: "50%",
              background: "#fff",
              marginLeft: "16px",
            }}
          />
        </div>
      </div>

      {/* Save button */}
      <div>
        <button
          type="button"
          style={{
            padding: "8px 20px",
            background: "var(--color-primary)",
            color: "#fff",
            border: "none",
            borderRadius: "var(--radius)",
            fontSize: "13px",
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          Save changes
        </button>
      </div>
    </div>
  );
}

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof SettingsLayout> = {
  title: "Layouts/SettingsLayout",
  component: SettingsLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**SettingsLayout** — a sticky-header + left-nav layout for settings and configuration pages.

Props: \`pageTitle: string\` · \`nav: ReactNode\` (required, 200px aside) · \`children: ReactNode\`

The \`nav\` prop is a required ReactNode — typically a vertical list of sibling-route
\`<a>\` links (no Next/Link needed at layout level). The main content is constrained
to \`max-w-[680px]\` to keep form lines readable.

Use for: APP.F15 Settings hub, APP.F16 User Preferences, APP.F17 Admin Configuration,
tenant/workspace configuration pages.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof SettingsLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/**
 * General settings — the default active page. Shows the full layout: sticky page
 * title in the header, vertical sub-nav on the left, form content on the right.
 */
export const Default: Story = {
  name: "Default (General settings active)",
  args: {
    pageTitle: "Settings",
    nav: <MockSettingsNav active="General" />,
  },
  render: (args) => (
    <div style={{ height: "640px" }}>
      <SettingsLayout {...args}>
        <MockSettingsForm section="General" />
      </SettingsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "General settings active in the left nav, with a mock form as children. The nav prop is a ReactNode — " +
          "typically a vertical list of <a> links where the active item is styled distinctly.",
      },
    },
  },
};

/**
 * Security settings active — demonstrates nav item switching by changing the
 * `active` highlight in the sub-nav.
 */
export const SecurityActive: Story = {
  name: "Security settings active",
  args: {
    pageTitle: "Settings",
    nav: <MockSettingsNav active="Security" />,
  },
  render: (args) => (
    <div style={{ height: "640px" }}>
      <SettingsLayout {...args}>
        <MockSettingsForm section="Security" />
      </SettingsLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Security item active in the left sub-nav. The same SettingsLayout is reused across all settings sub-pages — " +
          "only the nav active state and children change.",
      },
    },
  },
};
