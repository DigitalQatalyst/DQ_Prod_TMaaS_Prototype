import type { Meta, StoryObj } from '@storybook/react'
import * as React from 'react'
import { WorkingLayout } from '../layouts/working.js'

const meta: Meta<typeof WorkingLayout> = {
  title: 'Layouts/WorkingLayout',
  component: WorkingLayout,
  parameters: { layout: 'fullscreen' },
}
export default meta
type Story = StoryObj<typeof WorkingLayout>

export const Default: Story = {
  args: {
    pageTitle: 'My Dashboard',
    children: (
      <div className="grid grid-cols-3 gap-4 p-4">
        <div className="bg-gray-100 rounded h-32" />
        <div className="bg-gray-100 rounded h-32" />
        <div className="bg-gray-100 rounded h-32" />
      </div>
    ),
  },
}
export const WithSubtitle: Story = {
  args: {
    pageTitle: 'Analytics',
    subtitle: 'Last 30 days',
    children: <div className="bg-gray-100 rounded h-64 m-4" />,
  },
}
export const WithAction: Story = {
  args: {
    pageTitle: 'Tasks',
    action: { label: 'Create Task', onClick: () => {} },
    children: <div className="bg-gray-100 rounded h-48 m-4" />,
  },
}
