import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import type { BreadcrumbItem } from "@dbp/ui";
import { CatalogueLayout } from "../layouts/catalogue.js";

// ─── Mock helpers ────────────────────────────────────────────────────────────────

/** A mock product/service card for a catalogue grid. */
function CatalogueCard({ title, category, code }: { title: string; category: string; code: string }) {
  return (
    <div
      style={{
        padding: "16px",
        background: "var(--color-surface)",
        border: "1px solid var(--color-border)",
        borderRadius: "var(--radius)",
        display: "flex",
        flexDirection: "column",
        gap: "6px",
      }}
    >
      <div
        style={{
          padding: "4px 8px",
          background: "color-mix(in srgb, var(--color-primary) 10%, transparent)",
          borderRadius: "calc(var(--radius) / 2)",
          fontSize: "10px",
          fontWeight: 700,
          textTransform: "uppercase",
          letterSpacing: "0.08em",
          color: "var(--color-primary)",
          alignSelf: "flex-start",
        }}
      >
        {category}
      </div>
      <p style={{ margin: 0, fontSize: "14px", fontWeight: 600, color: "var(--color-text)" }}>{title}</p>
      <p style={{ margin: 0, fontSize: "11px", color: "color-mix(in srgb, var(--color-text) 50%, transparent)", fontFamily: "monospace" }}>
        {code}
      </p>
    </div>
  );
}

const CATALOGUE_ITEMS = [
  { title: "Digital Workflow Suite", category: "Platform", code: "DWS.05" },
  { title: "Digital Channels Web", category: "CX", code: "DXP.01A" },
  { title: "AnalyticsOps", category: "Insights", code: "DIA.02" },
  { title: "Digital Enterprise Portal", category: "Platform", code: "SDO.01" },
  { title: "Shift Management", category: "Ops", code: "DWS.03" },
  { title: "Contract Lifecycle", category: "Legal", code: "DWS.04" },
];

/** A mock grid of catalogue cards. */
function CatalogueGrid() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "12px" }}>
      {CATALOGUE_ITEMS.map((item) => (
        <CatalogueCard key={item.code} {...item} />
      ))}
    </div>
  );
}

/** A mock filter aside panel — checkboxes per category. */
function MockFilters() {
  const categories = ["Platform", "CX", "Insights", "Ops", "Legal"];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
      <p
        style={{
          margin: "0 0 8px",
          fontSize: "11px",
          fontWeight: 600,
          textTransform: "uppercase",
          letterSpacing: "0.06em",
          color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
        }}
      >
        Category
      </p>
      {categories.map((c) => (
        <label
          key={c}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            fontSize: "13px",
            color: "var(--color-text)",
            cursor: "pointer",
            padding: "4px 0",
          }}
        >
          <input type="checkbox" defaultChecked={c === "Platform"} style={{ accentColor: "var(--color-primary)" }} />
          {c}
        </label>
      ))}
      <div style={{ marginTop: "16px", borderTop: "1px solid var(--color-border)", paddingTop: "12px" }}>
        <p
          style={{
            margin: "0 0 8px",
            fontSize: "11px",
            fontWeight: 600,
            textTransform: "uppercase",
            letterSpacing: "0.06em",
            color: "color-mix(in srgb, var(--color-text) 55%, transparent)",
          }}
        >
          Status
        </p>
        {["Active", "Draft", "Archived"].map((s) => (
          <label
            key={s}
            style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "13px", color: "var(--color-text)", cursor: "pointer", padding: "4px 0" }}
          >
            <input type="checkbox" defaultChecked={s === "Active"} style={{ accentColor: "var(--color-primary)" }} />
            {s}
          </label>
        ))}
      </div>
    </div>
  );
}

const BREADCRUMB: BreadcrumbItem[] = [
  { label: "Marketplace", href: "#" },
  { label: "Solution Catalogue" },
];

// ─── Meta ────────────────────────────────────────────────────────────────────────

const meta: Meta<typeof CatalogueLayout> = {
  title: "Layouts/CatalogueLayout",
  component: CatalogueLayout,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**CatalogueLayout** — a sticky-header + optional filter-aside layout for browsable lists,
service catalogues, and resource galleries.

Props: \`pageTitle\` · \`subtitle?\` · \`breadcrumb?: BreadcrumbItem[]\` · \`filters?: ReactNode\` · \`children\`

When \`filters\` is provided a 220px aside appears to the left of the main content area.
Without it children take the full available width. The PageHeader is sticky.

Use for: APP.F01 Entity List, APP.F14 Catalogue / Marketplace browsing, solution picker pages.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof CatalogueLayout>;

// ─── Stories ─────────────────────────────────────────────────────────────────────

/**
 * No filters — grid takes the full content width. Minimal usage with title +
 * subtitle only in the sticky header.
 */
export const Default: Story = {
  name: "Default (no filters aside)",
  args: {
    pageTitle: "Solution Catalogue",
    subtitle: "Browse and activate Digital Business Platform solutions",
  },
  render: (args) => (
    <div style={{ height: "640px" }}>
      <CatalogueLayout {...args}>
        <CatalogueGrid />
      </CatalogueLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: "No filters prop — children fill the full width. Good for simple lists or when filtering is done inline.",
      },
    },
  },
};

/**
 * With filters aside — a 220px filter panel appears left of the grid. This is
 * the standard layout for browsable catalogues with faceted navigation.
 */
export const WithFilters: Story = {
  name: "With filters aside",
  args: {
    pageTitle: "Solution Catalogue",
    subtitle: "Browse and activate Digital Business Platform solutions",
    filters: <MockFilters />,
  },
  render: (args) => (
    <div style={{ height: "640px" }}>
      <CatalogueLayout {...args}>
        <CatalogueGrid />
      </CatalogueLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "filters prop — a 220px aside appears to the left of the grid. Typical use: category facets, status toggles, tag filters.",
      },
    },
  },
};

/**
 * With breadcrumb + filters — eyebrow trail + filter aside, full combination.
 */
export const WithBreadcrumbAndFilters: Story = {
  name: "With breadcrumb + filters",
  args: {
    pageTitle: "Solution Catalogue",
    subtitle: "Browse and activate solutions",
    breadcrumb: BREADCRUMB,
    filters: <MockFilters />,
  },
  render: (args) => (
    <div style={{ height: "640px" }}>
      <CatalogueLayout {...args}>
        <CatalogueGrid />
      </CatalogueLayout>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Full combination: breadcrumb eyebrow trail + filter aside + catalogue grid. BreadcrumbItem shape: { label: string; href?: string }.",
      },
    },
  },
};
