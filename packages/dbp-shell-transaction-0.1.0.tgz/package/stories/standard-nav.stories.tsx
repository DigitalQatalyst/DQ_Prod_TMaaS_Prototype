import * as React from "react";
import type { Meta, StoryObj } from "@storybook/react";
import type { NavSection } from "@dbp/contracts";
import TransactionShell from "../index.js";
// SOURCE OF TRUTH: scripts/standard-menu.json — the curated default standard menu
// every generated solution receives (docs/01-Architecture/
// Standard-Navigation-and-Layout-Map.md §2.3). Importing it here keeps this story
// in lock-step with what the generator actually emits — no hand-maintained copy.
import standardMenu from "../../../../../../scripts/standard-menu.json";

/**
 * Mirrors `buildNavSections()` in scripts/standard-menu-scaffold.mjs (which cannot
 * be imported in the browser — it reads the JSON via node:fs). Keep the two in
 * sync: areas → sections, groups → items, features → children. If the generator's
 * transform changes, update this to match.
 */
function buildNavSections(): NavSection[] {
  return (standardMenu.areas as MenuArea[]).map((a) => ({
    id: a.id,
    label: a.label.toUpperCase(),
    items: a.groups.map((g) => ({
      id: g.id,
      label: g.label,
      icon: g.icon,
      children: g.features.map((f) => ({ id: f.id, label: f.label, href: f.route })),
    })),
  }));
}

interface MenuArea {
  id: string;
  label: string;
  groups: { id: string; label: string; icon: string; features: { id: string; label: string; route: string }[] }[];
}

const STD_NAV = buildNavSections();

const meta: Meta<typeof TransactionShell> = {
  title: "Shells/Standard Navigation",
  component: TransactionShell,
  tags: ["autodocs"],
  parameters: {
    layout: "fullscreen",
    docs: {
      description: {
        component: `
**Standard Navigation** — the default 3-level sidebar (\`area → group → feature\`) every
generated solution receives.

This is NOT mock data: it is built from \`scripts/standard-menu.json\` — the same source
the generator's \`buildNavSections()\` reads. It is the curated standard menu from
*docs/01-Architecture/Standard-Navigation-and-Layout-Map.md §2.3*.

Builders refine from here — rename, hide, or wire features to real entities, and add
solution-specific groups. Use this story to explore the out-of-the-box information
architecture: 6 areas, ${STD_NAV.reduce((n, s) => n + s.items.length, 0)} groups,
${STD_NAV.reduce((n, s) => n + s.items.reduce((m, g) => m + (g.children?.length ?? 0), 0), 0)} feature pages.

Toggle the **Theme** toolbar button to confirm the nav structure is identical across
"DBP default" and "Alt client" — only tokens change. Use the ≡ top-bar toggle to collapse
the sidebar to its icon-only strip.
        `.trim(),
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof TransactionShell>;

function DemoLogo() {
  return (
    <span style={{ fontWeight: 700, color: "var(--color-primary)", fontSize: "16px", whiteSpace: "nowrap" }}>
      DBP Standard
    </span>
  );
}

function DemoMain({ title }: { title: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <h2 style={{ margin: 0, fontSize: "18px", fontWeight: 600, color: "var(--color-text)" }}>{title}</h2>
      <p style={{ margin: 0, fontSize: "14px", color: "color-mix(in srgb, var(--color-text) 65%, transparent)" }}>
        The selected feature page mounts here at solution time. This story focuses on the
        standard sidebar — expand the groups on the left to walk the full information architecture.
      </p>
    </div>
  );
}

/**
 * The complete standard menu rendered inside the Transaction Workspace shell. Every
 * area is a collapsible section; groups expand to reveal feature pages. This is the
 * exact nav a freshly-generated solution ships with.
 */
export const FullStandardMenu: Story = {
  name: "Full standard menu (real generator data)",
  render: () => (
    <div style={{ height: "640px" }}>
      <TransactionShell
        solutionId="storybook-standard"
        nav={{ logo: <DemoLogo />, sections: STD_NAV }}
        slots={{ main: <DemoMain title="Welcome / Home" /> }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "All 6 areas with their groups and feature pages, sourced live from scripts/standard-menu.json.",
      },
    },
  },
};

/**
 * Same standard menu, sidebar starting collapsed — verifies the icon-only strip
 * (one glyph per group) that the shell renders at w:64.
 */
export const Collapsed: Story = {
  name: "Standard menu — collapsed (icon strip)",
  render: () => (
    <div style={{ height: "560px" }}>
      <TransactionShell
        solutionId="storybook-standard-collapsed"
        nav={{ logo: <DemoLogo />, sections: STD_NAV, defaultCollapsed: true }}
        slots={{ main: <DemoMain title="Collapsed sidebar" /> }}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          "Sidebar collapsed to w:64. Each group reduces to its Lucide glyph; the ≡ toggle expands it back.",
      },
    },
  },
};
