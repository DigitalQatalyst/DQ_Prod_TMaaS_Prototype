import { z } from "zod";
import { TenantIdSchema } from "./entity";

// ---------------------------------------------------------------------------
// Tenant — the multi-tenant isolation boundary (the client/company).
//
// Zod is the source of truth; the DB `auth.tenant` table mirrors this shape
// (id, name, external_id, status) plus the isolation columns (ADR-0017/0018
// area) and the reserved per-tenant SSO connection (auth.tenant_idp).
// ---------------------------------------------------------------------------

export const TenantStatusSchema = z.enum(["active", "suspended", "archived"]);
export type TenantStatus = z.infer<typeof TenantStatusSchema>;

// ---------------------------------------------------------------------------
// Isolation mode — selectable PER TENANT, in one deployment (ADR-0017).
//   pooled    — shared schema + Postgres RLS on tenant_id (default, dense)
//   schema    — one Postgres schema per tenant (bridge)
//   silo      — one database per tenant (strongest in-deployment isolation)
//   dedicated — a fully separate single-tenant stack
// ---------------------------------------------------------------------------

export const IsolationModeSchema = z.enum(["pooled", "schema", "silo", "dedicated"]);
export type IsolationMode = z.infer<typeof IsolationModeSchema>;

export const TenantIsolationSchema = z
  .object({
    mode: IsolationModeSchema.default("pooled"),
    // Secret REFERENCE for silo/dedicated routing (never the DSN itself).
    dsnRef: z.string().min(1).optional(),
  })
  .strict();
export type TenantIsolation = z.infer<typeof TenantIsolationSchema>;

// ---------------------------------------------------------------------------
// Per-tenant enterprise SSO connection (reserved; ADR-0019).
// Federation is delegated to the managed IdP; this is just the routing config.
// ---------------------------------------------------------------------------

export const TenantIdpConnectionTypeSchema = z.enum(["social", "saml", "oidc"]);
export type TenantIdpConnectionType = z.infer<typeof TenantIdpConnectionTypeSchema>;

export const TenantIdpSchema = z
  .object({
    connectionType: TenantIdpConnectionTypeSchema,
    connectionRef: z.string().min(1), // managed-IdP connection id (Entra/WorkOS/…)
    emailDomain: z.string().optional(), // SSO login discovery: acme.com → this tenant
  })
  .strict();
export type TenantIdp = z.infer<typeof TenantIdpSchema>;

export const TenantSchema = z
  .object({
    id: TenantIdSchema, // slug, e.g. "tenant-alpha" (matches auth.tenant.id)
    name: z.string().min(1),
    externalId: z.string().optional(), // correlates a client across solution DBs / IdP org
    status: TenantStatusSchema.default("active"),
    isolation: TenantIsolationSchema.default({ mode: "pooled" }),
    idp: TenantIdpSchema.nullable().default(null),
  })
  .strict();
export type Tenant = z.infer<typeof TenantSchema>;
