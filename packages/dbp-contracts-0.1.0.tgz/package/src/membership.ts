import { z } from "zod";
import { TenantIdSchema } from "./entity";

// ---------------------------------------------------------------------------
// Membership — the user ↔ tenant join (ADR-0020).
//
// One global Identity (./identity) has many Memberships, one per tenant it
// belongs to. This is what makes "one login, many companies" possible. Mirrors
// the `auth.membership` table (the tenant-scoped, RLS'd join row).
//
// `roles` is a convenience projection of the authoritative `rbac.user_role`
// assignments for this (user, tenant); the DB join table remains the source of
// truth, this array is what the session/JWT carries for the active tenant.
// ---------------------------------------------------------------------------

export const MembershipStatusSchema = z.enum(["invited", "active", "revoked"]);
export type MembershipStatus = z.infer<typeof MembershipStatusSchema>;

export const MembershipSchema = z
  .object({
    userId: z.string().min(1), // → Identity.id
    tenantId: TenantIdSchema,
    roles: z.array(z.string().min(1)).default([]),
    status: MembershipStatusSchema.default("active"),
  })
  .strict();
export type Membership = z.infer<typeof MembershipSchema>;
