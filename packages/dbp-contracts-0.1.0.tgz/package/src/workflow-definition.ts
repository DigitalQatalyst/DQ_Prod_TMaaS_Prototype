import { z } from "zod";

export const WorkflowStepTypeSchema = z.enum(["task", "approval", "end"]);
export type WorkflowStepType = z.infer<typeof WorkflowStepTypeSchema>;

export const WorkflowStepSchema = z
  .object({
    id: z.string().min(1),
    name: z.string().min(1),
    type: WorkflowStepTypeSchema,
    assigneeRoles: z.array(z.string().min(1)).min(1),
    next: z.string().optional(),
    onReject: z.string().optional(),
  })
  .strict();
export type WorkflowStep = z.infer<typeof WorkflowStepSchema>;

export const WorkflowDefinitionSchema = z
  .object({
    id: z.string().min(1),
    name: z.string().min(1),
    version: z.string().min(1),
    steps: z.array(WorkflowStepSchema).min(1),
    initialStep: z.string().min(1),
  })
  .strict();
export type WorkflowDefinition = z.infer<typeof WorkflowDefinitionSchema>;
