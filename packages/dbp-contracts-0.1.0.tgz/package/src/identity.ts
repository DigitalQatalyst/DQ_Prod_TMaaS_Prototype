import { z } from "zod";

// ---------------------------------------------------------------------------
// Global identity (one human) — IAM multi-tenant model (ADR-0020).
//
// Distinct from the legacy tenant-scoped UserSchema in ./session. An Identity
// has NO tenantId: it is the global human, linked to one or more tenants via a
// Membership (./membership). Mirrors the refactored `auth.user` table.
// ---------------------------------------------------------------------------

export const IdentityStatusSchema = z.enum(["active", "suspended", "disabled"]);
export type IdentityStatus = z.infer<typeof IdentityStatusSchema>;

export const IdentitySchema = z
  .object({
    id: z.string().min(1), // internal id or IdP subject — globally unique
    email: z.string().email(), // globally unique (one human, one identity)
    displayName: z.string().min(1),
    status: IdentityStatusSchema.default("active"),
  })
  .strict();
export type Identity = z.infer<typeof IdentitySchema>;

// ---------------------------------------------------------------------------
// Federated login link — maps an IdP (provider, subject) to a global Identity.
// Mirrors the refactored `auth.identity` table. `unique(provider, subject)`
// means "one login per human" (resolved pre-tenant at login; see ADR-0023).
// ---------------------------------------------------------------------------

export const IdentityProviderKindSchema = z.enum(["password", "oidc", "entra", "saml"]);
export type IdentityProviderKind = z.infer<typeof IdentityProviderKindSchema>;

export const FederatedIdentitySchema = z
  .object({
    id: z.string().uuid(),
    userId: z.string().min(1), // → Identity.id
    provider: IdentityProviderKindSchema,
    subject: z.string().min(1), // provider `sub` / email
  })
  .strict();
export type FederatedIdentity = z.infer<typeof FederatedIdentitySchema>;
