import { z } from "zod";

export const TenantIdSchema = z.string().min(1);
export type TenantId = z.infer<typeof TenantIdSchema>;

export const EntityTypeNameSchema = z
  .string()
  .regex(/^[a-z][a-z0-9-]*$/, "entity type names are lowercase kebab-case");
export type EntityTypeName = z.infer<typeof EntityTypeNameSchema>;

export const EntityDataSchema = z.record(z.string(), z.unknown());
export type EntityData = z.infer<typeof EntityDataSchema>;

export const EntityRecordSchema = z
  .object({
    id: z.string().uuid(),
    type: EntityTypeNameSchema,
    tenantId: TenantIdSchema,
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
    data: EntityDataSchema,
  })
  .strict();

export type EntityRecord<TData extends EntityData = EntityData> = Omit<
  z.infer<typeof EntityRecordSchema>,
  "data"
> & { data: TData };
