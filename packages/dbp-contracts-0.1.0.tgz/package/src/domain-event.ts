import { z } from "zod";

export const DomainEventTypeSchema = z.string().min(1).regex(/^[a-z][a-z0-9-]*(\.[a-z][a-z0-9-]*)*$/, "event type must be dot-separated lowercase kebab segments, e.g. invoice.created");
export type DomainEventType = z.infer<typeof DomainEventTypeSchema>;

export const DomainEventSchema = z
  .object({
    type: DomainEventTypeSchema,
    payload: z.record(z.string(), z.unknown()),
    source: z.string().min(1),
    ts: z.string().datetime(),
    correlationId: z.string().uuid(),
  })
  .strict();

export type DomainEvent = z.infer<typeof DomainEventSchema>;
