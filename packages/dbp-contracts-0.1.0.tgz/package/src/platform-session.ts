import { z } from "zod";
import { SessionSchema, type Session } from "./session";

// ---------------------------------------------------------------------------
// PlatformSession — the active-tenant session for the multi-tenant IAM model
// (ADR-0020). Additive: the legacy SessionSchema in ./session is unchanged and
// still consumed by the CASL engine, auth handlers, and middleware. New code
// uses PlatformSession and maps to/from the legacy shape during rollout.
//
//   userId  → sub   (global Identity.id)
//   tenantId→ tid   (the ACTIVE tenant; switching tenants re-mints the token)
//   roles            roles in the active tenant only
//   memberships      tenant ids the user belongs to (feeds the tenant switcher)
// ---------------------------------------------------------------------------

export const PlatformSessionSchema = z
  .object({
    sub: z.string().min(1),
    email: z.string().email(),
    tid: z.string().min(1),
    roles: z.array(z.string().min(1)),
    memberships: z.array(z.string().min(1)).optional(),
    exp: z.number().int().positive(),
  })
  .strict();
export type PlatformSession = z.infer<typeof PlatformSessionSchema>;

// ---------------------------------------------------------------------------
// Compatibility mapping (the ADR-0020 field aliasing, done at the contract edge
// so the legacy-Session consumers keep working unchanged during migration).
// ---------------------------------------------------------------------------

/** Project an active-tenant PlatformSession down to the legacy Session shape. */
export function toLegacySession(session: PlatformSession): Session {
  return SessionSchema.parse({
    userId: session.sub,
    email: session.email,
    roles: session.roles,
    tenantId: session.tid,
    exp: session.exp,
  });
}

/** Lift a legacy Session into the active-tenant PlatformSession shape. */
export function toPlatformSession(session: Session, memberships?: string[]): PlatformSession {
  return PlatformSessionSchema.parse({
    sub: session.userId,
    email: session.email,
    tid: session.tenantId,
    roles: session.roles,
    ...(memberships !== undefined ? { memberships } : {}),
    exp: session.exp,
  });
}
