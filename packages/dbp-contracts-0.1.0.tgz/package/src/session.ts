import { z } from "zod";

export const SessionSchema = z
  .object({
    userId: z.string().min(1),
    email: z.string().email(),
    roles: z.array(z.string().min(1)),
    tenantId: z.string().min(1),
    exp: z.number().int().positive(),
  })
  .strict();
export type Session = z.infer<typeof SessionSchema>;

export const UserSchema = z
  .object({
    id: z.string().min(1),
    email: z.string().email(),
    displayName: z.string().min(1),
    roles: z.array(z.string().min(1)),
    tenantId: z.string().min(1),
  })
  .strict();
export type User = z.infer<typeof UserSchema>;
