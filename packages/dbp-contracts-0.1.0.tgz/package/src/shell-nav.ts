import { z } from "zod";

// exactOptionalPropertyTypes: ZodOptional infers `string | undefined` for its
// output type, but NavItem uses exact-optional `?` fields (no explicit undefined).
// The ZodLazy annotation cannot satisfy both the recursive self-reference and the
// exact-optional output in one shot. We cast via `unknown` to break the cycle.
export const NavItemSchema = z.lazy(() =>
  z.object({
    id: z.string(),
    label: z.string(),
    // Optional: group/parent items navigate by expanding `children`, not via href.
    href: z.string().optional(),
    icon: z.string().optional(),
    badge: z.string().optional(),
    badgeTone: z
      .enum(["success", "warning", "danger", "info", "orange", "navy", "gray"])
      .optional(),
    children: z
      .array(NavItemSchema as unknown as z.ZodType<NavItem, z.ZodTypeDef, unknown>)
      .optional(),
  }),
) as z.ZodType<NavItem, z.ZodTypeDef, unknown>;
export type NavItem = {
  id: string;
  label: string;
  href?: string;
  icon?: string;
  badge?: string;
  badgeTone?: "success" | "warning" | "danger" | "info" | "orange" | "navy" | "gray";
  children?: NavItem[];
};

export const NavSectionSchema = z.object({
  id: z.string(),
  label: z.string().optional(),
  items: z.array(NavItemSchema),
});
export type NavSection = z.infer<typeof NavSectionSchema>;

export const SidebarConfigSchema = z.object({
  sections: NavSectionSchema.array(),
  collapsible: z.boolean().default(false),
});
export type SidebarConfig = z.infer<typeof SidebarConfigSchema>;

export const TopBarActionSchema = z.object({
  id: z.string(),
  label: z.string(),
  icon: z.string().optional(),
  href: z.string().optional(),
  onClick: z.string().optional(),
});
export type TopBarAction = z.infer<typeof TopBarActionSchema>;

export const TopBarConfigSchema = z.object({
  logoSrc: z.string().optional(),
  logoAlt: z.string().default("DBP"),
  appName: z.string(),
  actions: TopBarActionSchema.array().default([]),
  showSearch: z.boolean().default(false),
  showNotifications: z.boolean().default(true),
  showUser: z.boolean().default(true),
});
export type TopBarConfig = z.infer<typeof TopBarConfigSchema>;
