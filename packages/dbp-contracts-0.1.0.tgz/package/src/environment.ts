import { z } from "zod";

export const EnvironmentNameSchema = z.enum(["dev", "test", "staging", "prod", "demo"]);
export type EnvironmentName = z.infer<typeof EnvironmentNameSchema>;

export const LogLevelSchema = z.enum(["debug", "info", "warn", "error"]);
export type LogLevel = z.infer<typeof LogLevelSchema>;

export const EnvironmentConfigSchema = z
  .object({
    name: EnvironmentNameSchema,
    port: z.number().int().min(1024).max(65535),
    baseUrl: z.string().url().nullable(),
    logLevel: LogLevelSchema,
    featureFlags: z.record(z.string(), z.boolean()),
  })
  .strict();
export type EnvironmentConfig = z.infer<typeof EnvironmentConfigSchema>;
