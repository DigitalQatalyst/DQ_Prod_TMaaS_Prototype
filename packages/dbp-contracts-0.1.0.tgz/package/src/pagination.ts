import { z } from "zod";

/** Maximum page size the PS.DATA server accepts. Never request more than this per page. */
export const MAX_PAGE_SIZE = 200;

export const PageQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(MAX_PAGE_SIZE).default(20),
});
export type PageQuery = z.infer<typeof PageQuerySchema>;

export const FilterValueSchema = z.union([z.string(), z.number(), z.boolean()]);
export type FilterValue = z.infer<typeof FilterValueSchema>;

export const EntityFiltersSchema = z.record(z.string(), FilterValueSchema);
export type EntityFilters = z.infer<typeof EntityFiltersSchema>;

export const paginated = <TItem extends z.ZodTypeAny>(item: TItem) =>
  z
    .object({
      rows: z.array(item),
      total: z.number().int().min(0),
      page: z.number().int().min(1),
      pageSize: z.number().int().min(1),
    })
    .strict();
