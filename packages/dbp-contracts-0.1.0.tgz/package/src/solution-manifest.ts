import { z } from "zod";
import { IsolationModeSchema } from "./tenant";
import { IdentityProviderKindSchema } from "./identity";

// ─── Primitive patterns ──────────────────────────────────────────────────────

const L02IdPattern = /^(DXP|DWS|DIA|SDO)\.\d{2}[A-X]?$/;
const L03IdPattern = /^(DXP|DWS|DIA|SDO)\.\d{2}[A-X]?\.[A-Z]\d{2}$/;
const TemplateIdPattern = /^(APP|ANL)\.F\d{2}$/;
const PsIdPattern = /^PS\.[A-Z]+$/;
const ShIdPattern = /^SH\.\d{2}$/;
const KebabCasePattern = /^[a-z][a-z0-9-]*$/;

// ─── Theme (9 overridable design-token CSS vars) ─────────────────────────────

export const ThemeOverridesSchema = z
  .object({
    "--color-primary": z.string().describe("Overrides --color-primary CSS variable (hex or CSS color)."),
    "--color-secondary": z.string().describe("Overrides --color-secondary CSS variable."),
    "--color-surface": z.string().describe("Overrides --color-surface CSS variable."),
    "--color-border": z.string().describe("Overrides --color-border CSS variable."),
    "--color-text": z.string().describe("Overrides --color-text CSS variable."),
    "--font-display": z.string().describe("Overrides --font-display CSS variable (font-family name)."),
    "--font-body": z.string().describe("Overrides --font-body CSS variable (font-family name)."),
    "--radius": z.string().describe("Overrides --radius CSS variable (e.g. '0', '8px', '16px')."),
    "--density": z
      .enum(["comfortable", "compact"])
      .describe("Overrides --density CSS variable."),
  })
  .partial()
  .describe("Optional overrides for any of the 9 design-token CSS variables from @dbp/design-tokens/theme.css.");

export type ThemeOverrides = z.infer<typeof ThemeOverridesSchema>;

// ─── Feature instance (inside a module) ─────────────────────────────────────

export const FeatureInstanceSchema = z
  .object({
    id: z
      .string()
      .regex(TemplateIdPattern, "Must be a valid feature template ID (e.g. APP.F01, ANL.F02).")
      .describe("The feature template ID from REGISTRY.yaml (e.g. APP.F01 — Entity List Table)."),
    role: z
      .string()
      .regex(KebabCasePattern, "Must be kebab-case (e.g. invoice-queue).")
      .describe(
        "Kebab-case instance name scoped to this solution module (e.g. invoice-queue). Used as the React component key.",
      ),
    slot: z
      .string()
      .optional()
      .describe(
        "Override the feature's default registry slot for placement in the shell. If omitted, the registry default is used.",
      ),
    wires: z
      .array(z.string().regex(PsIdPattern, "Each wire must be a PS.* service ID (e.g. PS.DATA)."))
      .min(1)
      .describe(
        "Platform services this feature instance wires to. Must be a subset of the solution-level consumes_platform_services.",
      ),
    config: z
      .record(z.string(), z.unknown())
      .describe(
        "Feature configuration object — must satisfy the feature package's Zod contract (types.ts). Validated at generate time via tsx.",
      ),
  })
  .describe("One instantiation of a feature blueprint wired into a shell slot.");

export type FeatureInstance = z.infer<typeof FeatureInstanceSchema>;

// ─── Per-module sidebar nav (shell `nav` prop) ───────────────────────────────
//
// Optional per-module navigation passed to the module's shell. Drives the
// `const <SOLUTION>_NAV = { … }` constant the generator emits and the shell's
// `nav={…}` prop. Three independently-optional parts:
//   logo       → rendered as a styled <span> (omit on pages that only carry a
//                breadcrumb, e.g. a transaction page below a list page).
//   items      → sidebar nav links (id / label / href, optional active flag).
//   breadcrumb → rendered as <Breadcrumb items={…} /> from @dbp/ui; the trailing
//                crumb usually omits href (it is the current page).

const ModuleNavItemSchema = z.object({
  id: z.string().min(1).describe("Stable key for the nav item (React key / id)."),
  label: z.string().min(1).describe("Visible nav label."),
  href: z.string().min(1).describe("Destination route (e.g. /m01)."),
  active: z.boolean().optional().describe("Marks the item for the current page. Emitted only when true."),
});

const ModuleNavBreadcrumbItemSchema = z.object({
  label: z.string().min(1).describe("Breadcrumb crumb label."),
  href: z.string().min(1).optional().describe("Crumb link. Omit on the trailing (current-page) crumb."),
});

// ─── Nested nav schemas (3-level: section → group → child) ──────────────────
//
// These extend ModuleNavSchema with an optional `sections` field that drives a
// 3-level collapsible sidebar structure. The flat `items` path is unchanged for
// backward compatibility. Redeclared here (rather than re-exported from
// shell-nav.ts) because:
//   • shell-nav's NavItemSchema is recursive and carries badge/badgeTone fields
//     not needed at the manifest layer.
//   • NavSectionSchema is already exported from shell-nav.ts — a separate
//     ManifestNavSectionSchema avoids a name collision in the barrel export.

/** Leaf nav item — links directly to a route, no children. */
export const NavChildSchema = z.object({
  id: z.string().describe("Stable key for the nav child (React key / id)."),
  label: z.string().describe("Visible nav label."),
  href: z.string().describe("Destination route (e.g. /m01/detail)."),
  icon: z.string().optional().describe("Lucide icon name string (e.g. \"Home\"). Resolved at emit time."),
});
export type NavChild = z.infer<typeof NavChildSchema>;

/** Collapsible nav group — may act as a direct link (no children) or expand to reveal children. */
export const NavGroupSchema = z.object({
  id: z.string().describe("Stable key for the nav group (React key / id)."),
  label: z.string().describe("Visible group label."),
  icon: z.string().optional().describe("Lucide icon name string (e.g. \"LayoutDashboard\"). Resolved at emit time."),
  href: z.string().optional().describe("If no children, acts as a direct link."),
  children: z.array(NavChildSchema).optional().describe("Child nav items rendered inside the collapsible group."),
});
export type NavGroup = z.infer<typeof NavGroupSchema>;

/** Named sidebar section — an eyebrow label grouping one or more nav groups. */
export const ManifestNavSectionSchema = z.object({
  id: z.string().describe("Stable key for the section (React key / id)."),
  label: z.string().optional().describe("Eyebrow label (e.g. \"ORIENTATION\", \"MARKETPLACE\"). Omit for unlabelled sections."),
  items: z.array(NavGroupSchema).describe("Nav groups rendered inside this section."),
});
export type ManifestNavSection = z.infer<typeof ManifestNavSectionSchema>;

export const ModuleNavSchema = z
  .object({
    logo: z
      .string()
      .min(1)
      .optional()
      .describe("Sidebar logo text — emitted as a styled <span>. Omit for pages that show only a breadcrumb."),
    items: z.array(ModuleNavItemSchema).min(1).describe("Sidebar nav items (flat path — preserved for backward compatibility)."),
    sections: z
      .array(ManifestNavSectionSchema)
      .optional()
      .describe(
        "3-level nested sidebar structure (section → group → child). Takes precedence over `items` when present. Absent ⇒ flat `items` list is used.",
      ),
    breadcrumb: z
      .array(ModuleNavBreadcrumbItemSchema)
      .min(1)
      .optional()
      .describe("Breadcrumb trail — emitted as <Breadcrumb items={…} /> from @dbp/ui."),
  })
  .describe("Per-module sidebar nav passed to the shell's nav prop. Absent ⇒ the shell renders its default nav.");

export type ModuleNav = z.infer<typeof ModuleNavSchema>;

// ─── Module (L03) ────────────────────────────────────────────────────────────

export const ModuleSchema = z
  .object({
    id: z
      .string()
      .regex(L03IdPattern, "Must be an L03 id (e.g. DWS.04.M01).")
      .describe("L03 module identifier: <L02>.<Letter><NN> (e.g. DWS.04.M01)."),
    name: z.string().min(1).describe("Human-readable module name (e.g. Finance Module)."),
    journey: z
      .number()
      .int()
      .min(0)
      .max(4)
      .describe("Journey stage this module runs at (0 = Discover … 4 = Process)."),
    scaffold: z
      .string()
      .regex(ShIdPattern, "Must be a valid shell ID (e.g. SH.02).")
      .describe("The stage shell this module mounts into (must exist in REGISTRY.yaml shells)."),
    route: z
      .string()
      .regex(/^\/[a-z0-9/-]*$/, "Must be an absolute kebab route, e.g. /marketplace/discern")
      .optional()
      .describe("Explicit route path. Absent ⇒ derived from module id (DWS.01.M01 → /m01)."),
    layout: z
      .enum(["working", "analytics", "catalogue", "content-landing", "bare"])
      .optional()
      .describe(
        "Page layout type wrapping the module's primary (main) slot. Absent ⇒ inferred from " +
          "the module's features (self-contained features → bare, ANL.* → analytics, " +
          "APP.F10 → catalogue, APP.F12 → content-landing, else working).",
      ),
    features: z
      .array(FeatureInstanceSchema)
      .min(1)
      .describe("Feature blueprint instances mounted in this module's shell slots."),
    nav: ModuleNavSchema.optional().describe(
      "Optional per-module sidebar nav passed to the shell. Absent ⇒ the shell renders its default nav.",
    ),
    section: z
      .string()
      .optional()
      .describe(
        "Optional standard-menu Feature-Area id this module belongs to (e.g. workspace, " +
          "service-operations). Used with `menuItem` to infer the page layout from the standard " +
          "navigation map. See docs/01-Architecture/Standard-Navigation-and-Layout-Map.md.",
      ),
    menuItem: z
      .string()
      .optional()
      .describe(
        "Optional standard-menu Feature label (e.g. Tasks, Service Requests). With `section`, " +
          "drives layout via the standard-menu→layout map. Absent ⇒ layout inferred from features.",
      ),
  })
  .describe("One solution module (L03) — declares its shell, journey stage, and features.");

export type Module = z.infer<typeof ModuleSchema>;

// ─── Routes (optional per-module basePath overrides) ─────────────────────────

export const RoutesSchema = z
  .object({
    basePath: z
      .string()
      .optional()
      .describe("Optional Next.js basePath for this app (e.g. /dws-04). Defaults to '/'."),
  })
  .describe("Optional route configuration for the generated Next.js app.");

export type Routes = z.infer<typeof RoutesSchema>;

// ─── Archetype blocks (all optional — absence ⇒ that route is not emitted) ────
//
// These five blocks drive the four NET-NEW page archetypes (+ upgraded landing)
// emitted by scripts/scaffold-solution.mjs:
//   nav         → public header links + sign-in (SH.00) and reused for app nav
//   landing     → SH.00 LandingShell (hero/features/how_it_works/cta/footer)
//   home        → SH.02 + @dbp/feature-app-home (APP.F12) at /home
//   marketplace → SH.01 + @dbp/feature-catalog-grid (APP.F10) at /marketplace
//                 (+ nested `detail:` → @dbp/feature-marketplace-item-detail APP.F11
//                    at /marketplace/[id])
//   copilot     → SH.04 + @dbp/feature-copilot-page (APP.F15) at /copilot
//
// The per-feature config sub-shapes mirror each feature package's types.ts
// (camelCase) so the generator passes them through unchanged. A malformed block
// fails the GENERATOR with a clear message, never the build.

const HrefLink = z.object({
  label: z.string().min(1),
  href: z.string().min(1),
});

// ── nav: (top-level) — public header + app sidebar nav ────────────────────────

export const NavConfigSchema = z
  .object({
    links: z.array(HrefLink).default([]).describe("Public header nav links (also reused for app sidebar)."),
    sign_in: HrefLink.optional().describe("Sign-in CTA pill in the public header (label + href)."),
  })
  .describe("Public header navigation + app sidebar nav. Drives SH.00 PublicHeader.");

export type NavConfig = z.infer<typeof NavConfigSchema>;

// ── landing: — SH.00 LandingShell sections ────────────────────────────────────

const IconItem = z.object({
  /** Lucide icon name (resolved at emit time; unknown names fall back). */
  icon: z.string().optional(),
  title: z.string().min(1),
  description: z.string().optional(),
});

export const LandingConfigSchema = z
  .object({
    hero: z
      .object({
        overline: z.string().optional(),
        headline: z.string().min(1),
        headline_accent: z.string().optional(),
        body: z.string().optional(),
        primary_cta: HrefLink.optional(),
        secondary_cta: HrefLink.optional(),
        trust_bullets: z
          .array(z.object({ icon: z.string().optional(), label: z.string().min(1) }))
          .default([]),
      })
      .describe("Landing hero — two-tone headline, CTAs, trust bullets."),
    features: z
      .object({
        overline: z.string().optional(),
        headline: z.string().optional(),
        headline_accent: z.string().optional(),
        body: z.string().optional(),
        items: z.array(IconItem).min(1),
      })
      .optional()
      .describe("Features section (LandingFeatures)."),
    how_it_works: z
      .object({
        overline: z.string().optional(),
        headline: z.string().optional(),
        body: z.string().optional(),
        steps: z
          .array(
            z.object({
              step: z.string().optional(),
              title: z.string().min(1),
              description: z.string().optional(),
              icon: z.string().optional(),
            }),
          )
          .min(1),
      })
      .optional()
      .describe("How-it-works step flow (LandingHowItWorks)."),
    cta: z
      .object({
        headline: z.string().optional(),
        headline_accent: z.string().optional(),
        body: z.string().optional(),
        primary_cta: HrefLink.optional(),
        secondary_cta: HrefLink.optional(),
      })
      .optional()
      .describe("Closing CTA card (LandingCta)."),
    footer: z
      .object({
        tagline: z.string().optional(),
        columns: z
          .array(
            z.object({
              heading: z.string().min(1),
              links: z.array(HrefLink).min(1),
            }),
          )
          .default([]),
        legal: z.string().optional(),
      })
      .optional()
      .describe("Dark navy multi-column footer + legal row (LandingFooter)."),
  })
  .describe("Public landing page — mounts in SH.00 at route '/'.");

export type LandingConfig = z.infer<typeof LandingConfigSchema>;

// ── home: — @dbp/feature-app-home (APP.F12) config ────────────────────────────
// Sub-shapes mirror app-home/types.ts (AppHomeConfig). YAML authors use the same
// camelCase keys the feature expects so the generator forwards them unchanged.

const HomeKpiMetric = z.object({
  field: z.string().min(1).optional(),
  aggregate: z.enum(["count", "sum", "avg"]),
});

const HomeKpi = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  entityType: z.string().min(1),
  metric: HomeKpiMetric,
  format: z.enum(["number", "currency", "percent"]).optional(),
  icon: z.string().optional(),
  filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
});

const HomeQuickLink = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  href: z.string().min(1),
  icon: z.string().optional(),
  description: z.string().optional(),
  tone: z.enum(["navy", "orange"]).optional(),
});

const HomeStaticItem = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  description: z.string().optional(),
  date: z.string().optional(),
  href: z.string().optional(),
});

const HomeHeroCta = z.object({ label: z.string().min(1), href: z.string().min(1) });

// Optional in-app hero (LandingHero composition rendered inside the workspace
// shell). Absent ⇒ the generator falls back to manifest.landing.hero.
const HomeHero = z.object({
  overline: z.string().optional(),
  headline: z.string().min(1),
  headlineAccent: z.string().optional(),
  body: z.string().optional(),
  primaryCta: HomeHeroCta.optional(),
  secondaryCta: HomeHeroCta.optional(),
  trustBullets: z.array(z.object({ label: z.string().min(1) })).optional(),
});

// Optional explicit config for the WorkspaceGreetingCard (the LandingHero
// preview on /home). When omitted, the generator falls back to the first 4
// `quickLinks` and the `updates` list.
const HomeGreetingCard = z.object({
  lead: z.string().optional(),
  quickLinks: z.array(z.object({ label: z.string().min(1), href: z.string().min(1) })).optional(),
  updatesTitle: z.string().optional(),
  updates: z
    .array(z.object({ title: z.string().min(1), date: z.string().optional() }))
    .optional(),
});

// Optional marketing-style sections rendered on the authenticated home BELOW the
// hero (LandingFeatures / LandingHowItWorks / LandingCta). camelCase — distinct from
// the public landing block. Absent ⇒ that section is not rendered (the generator
// also falls back to manifest.landing.* for DXP solutions that still have one).
const HomeFeatures = z.object({
  overline: z.string().optional(),
  headline: z.string().optional(),
  headlineAccent: z.string().optional(),
  body: z.string().optional(),
  items: z.array(z.object({ icon: z.string().optional(), title: z.string().min(1), description: z.string().optional() })).min(1),
});
const HomeHowItWorks = z.object({
  overline: z.string().optional(),
  headline: z.string().optional(),
  body: z.string().optional(),
  steps: z.array(z.object({ step: z.string().optional(), title: z.string().min(1), description: z.string().optional(), icon: z.string().optional() })).min(1),
});
const HomeCta = z.object({
  headline: z.string().optional(),
  headlineAccent: z.string().optional(),
  body: z.string().optional(),
  primaryCta: HomeHeroCta.optional(),
  secondaryCta: HomeHeroCta.optional(),
});

export const HomeConfigSchema = z
  .object({
    hero: HomeHero.optional(),
    greetingCard: HomeGreetingCard.optional(),
    greeting: z.object({ tagline: z.string().min(1) }).optional(),
    aiSearchPlaceholder: z.string().optional(),
    aiSearchHref: z.string().optional(),
    kpis: z.array(HomeKpi).min(1).max(5),
    quickLinks: z.array(HomeQuickLink).min(1),
    updatesTitle: z.string().optional(),
    supportTitle: z.string().optional(),
    updates: z.array(HomeStaticItem).optional(),
    support: z.array(HomeStaticItem).optional(),
    features: HomeFeatures.optional(),
    howItWorks: HomeHowItWorks.optional(),
    cta: HomeCta.optional(),
  })
  .describe("Authenticated home (APP.F12) — mounts in SH.02 at route '/home'.");

export type HomeConfig = z.infer<typeof HomeConfigSchema>;

// ── marketplace: — @dbp/feature-catalog-grid (APP.F10) + detail (APP.F11) ─────
// Sub-shapes mirror catalog-grid/types.ts and marketplace-item-detail/types.ts.

const CatalogCardFields = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  typeLabel: z.string().optional(),
  status: z.string().optional(),
  statusTone: z
    .enum(["success", "warning", "danger", "info", "orange", "navy", "gray"])
    .optional(),
  footerId: z.string().optional(),
  tags: z.string().optional(),
});

const CatalogFilterField = z.object({
  field: z.string().min(1),
  label: z.string().min(1),
});

const MarketplaceDetailBadge = z.object({
  field: z.string().min(1),
  style: z.enum(["pill", "mono", "lock"]),
});

const MarketplaceTab = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
});

const MarketplaceRailAction = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  icon: z.string().optional(),
  tone: z.enum(["outline", "navy", "ghost"]).optional(),
});

const MarketplaceGovernanceAction = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  icon: z.string().optional(),
  tone: z.enum(["outline", "navy", "ghost"]).optional(),
});

export const MarketplaceDetailConfigSchema = z
  .object({
    summaryField: z.string().min(1),
    badgeFields: z.array(MarketplaceDetailBadge).optional(),
    tabs: z.array(MarketplaceTab).min(1).optional(),
    railActions: z.array(MarketplaceRailAction).optional(),
    acknowledgement: z.object({ required: z.boolean(), label: z.string().min(1) }).optional(),
    governanceActions: z.array(MarketplaceGovernanceAction).optional(),
  })
  .describe("Marketplace item detail (APP.F11) — route '/marketplace/[id]'.");

export const MarketplaceConfigSchema = z
  .object({
    entityType: z.string().min(1),
    headline: z.string().min(1),
    lede: z.string().optional(),
    itemLabel: z.string().optional(),
    categories: z.array(z.object({ id: z.string().min(1), label: z.string().min(1) })).optional(),
    categoryField: z.string().optional(),
    cardFields: CatalogCardFields,
    filterFields: z.array(CatalogFilterField).optional(),
    recommendedFilter: CatalogFilterField.optional(),
    pageSize: z.number().int().min(1).max(200).optional(),
    filters: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
    detail: MarketplaceDetailConfigSchema.optional(),
  })
  .describe("Marketplace listing (APP.F10) — mounts in SH.01 at '/marketplace'.");

export type MarketplaceConfig = z.infer<typeof MarketplaceConfigSchema>;

// ── copilot: — @dbp/feature-copilot-page (APP.F15) config ─────────────────────
// Sub-shapes mirror copilot-page/types.ts (CopilotPageConfig).

const CopilotValueMetric = z.object({
  entityType: z.string().min(1),
  aggregate: z.enum(["count", "sum", "avg"]),
  field: z.string().min(1).optional(),
});

const CopilotInsightCard = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  valueMetric: CopilotValueMetric,
  icon: z.string().optional(),
});

export const CopilotConfigSchema = z
  .object({
    eyebrow: z.string().min(1),
    title: z.string().min(1),
    description: z.string().min(1),
    insightCards: z.array(CopilotInsightCard).min(1).max(3),
    composerPlaceholder: z.string().min(1),
    submitLabel: z.string().min(1),
    suggestedPrompts: z.array(z.string().min(1)).min(1).max(8),
    entityType: z.string().min(1),
    ragScope: z.string().min(1).optional(),
    assistantContext: z.record(z.string(), z.unknown()).optional(),
  })
  .describe("Copilot page (APP.F15) — mounts in SH.04 WorkbenchShell at '/copilot'.");

export type CopilotConfig = z.infer<typeof CopilotConfigSchema>;

// ─── IAM / tenancy sub-schemas ───────────────────────────────────────────────

/**
 * A custom role declared by a solution (beyond the platform-global defaults).
 * Consumed by the scaffold generator to wire per-solution RBAC seed data.
 */
export const SolutionRoleSchema = z
  .object({
    id: z.string().min(1).describe("Stable role key (e.g. 'ops-manager'). Must be unique within the solution."),
    label: z.string().min(1).describe("Human-readable role name (e.g. 'Operations Manager')."),
  })
  .strict();

export type SolutionRole = z.infer<typeof SolutionRoleSchema>;

/**
 * A custom permission declared by a solution (beyond the platform-global defaults).
 * action + resource form the canonical `action:resource` permission key at runtime.
 */
export const SolutionPermissionSchema = z
  .object({
    action: z.string().min(1).describe("Permission action verb (e.g. 'read', 'approve', 'export')."),
    resource: z.string().min(1).describe("Resource the action applies to (e.g. 'invoice', 'report')."),
    description: z.string().optional().describe("Human-readable description of what this permission grants."),
  })
  .strict();

export type SolutionPermission = z.infer<typeof SolutionPermissionSchema>;

// ─── Top-level solution manifest ─────────────────────────────────────────────

export const SolutionManifestSchema = z
  .object({
    platform: z
      .enum(["DXP", "DWS", "DIA", "SDO"])
      .describe("L01 platform this solution belongs to (DXP | DWS | DIA | SDO)."),
    solution_type: z
      .enum(["DXP", "DWS", "DIA", "SDO"])
      .optional()
      .describe(
        "Solution type that drives the public-page policy. Only DXP solutions expose public " +
          "pages (a `/` landing); every other type exposes only `/login` and redirects `/`. " +
          "Absent ⇒ falls back to `platform`.",
      ),
    solution: z
      .string()
      .regex(L02IdPattern, "Must be an L02 solution ID (e.g. DWS.04).")
      .describe("L02 solution identifier (e.g. DWS.04 — Digital ERP)."),
    name: z.string().min(1).describe("Human-readable solution name (e.g. Digital ERP)."),
    journey_stages: z
      .array(z.number().int().min(0).max(4))
      .min(1)
      .describe("MACH journey stages this solution covers (0–4). Drives which shells are wired."),
    deploy_layer: z
      .enum(["L01", "L02", "L03", "L04", "L05"])
      .describe("Federated DBP deployment layer (typically L03 for domain-platform solutions)."),
    consumes_platform_services: z
      .array(z.string().regex(PsIdPattern, "Each entry must be a PS.* ID (e.g. PS.AUTH)."))
      .min(1)
      .describe(
        "All Layer-06 platform services this solution wires to. Every feature.wires entry must be a subset of this list.",
      ),
    modules: z
      .array(ModuleSchema)
      .min(1)
      .describe("L03 module declarations — each declares a shell, journey stage, and features."),
    theme: ThemeOverridesSchema.optional().describe(
      "Optional design-token overrides from the 9 overridable tokens in @dbp/design-tokens/theme.css.",
    ),
    routes: RoutesSchema.optional().describe("Optional Next.js routing configuration."),
    nav: NavConfigSchema.optional().describe(
      "Public header navigation (SH.00) + app sidebar nav. Absent ⇒ default header only.",
    ),
    landing: LandingConfigSchema.optional().describe(
      "Public landing page config (SH.00). Absent ⇒ the legacy bespoke landing is emitted.",
    ),
    home: HomeConfigSchema.optional().describe(
      "Authenticated home config (APP.F12 in SH.02). Absent ⇒ no /home route is emitted.",
    ),
    marketplace: MarketplaceConfigSchema.optional().describe(
      "Marketplace listing (+ optional detail) config (APP.F10/F11 in SH.01). Absent ⇒ no marketplace routes.",
    ),
    copilot: CopilotConfigSchema.optional().describe(
      "Copilot page config (APP.F15 in SH.04). Absent ⇒ no /copilot route is emitted.",
    ),
    // ── entities: manifest-driven entity + seed declaration ──────────────────
    //
    // Optional top-level list of entity types this solution exposes via PS.DATA.
    // When present, the scaffold generator emits:
    //   • solution/entities/<type>.ts  — Zod schema + JSON-schema entity-type definition
    //   • solution/fixtures/seed.ts    — registerAndSeedData() shared by instrumentation.ts
    //                                    and the PS.DATA route chunk (Next.js isolation fix)
    // Both files are RE-EMITTED (overwritten) on every --force regen when this block
    // is present, so the manifest stays the single source of truth for generated entities.
    // Hand-authored entity files NOT listed here are preserved (create-if-missing rule).
    // Absence of this block leaves solution/entities/** and solution/fixtures/** untouched.
    entities: z
      .array(
        z.object({
          type: z
            .string()
            .min(1)
            .describe("Entity type identifier (e.g. 'task'). Used as the PS.DATA entity type key."),
          fields: z
            .array(
              z.object({
                name: z.string().min(1).describe("Field name (camelCase, e.g. 'title')."),
                type: z
                  .enum(["string", "number", "boolean", "enum"])
                  .describe("Field primitive type. Use 'enum' when values is set."),
                enum: z
                  .array(z.string().min(1))
                  .optional()
                  .describe("Allowed enum values. Only valid when type is 'enum'."),
                required: z
                  .boolean()
                  .optional()
                  .describe("Whether the field is required in the entity schema (default false)."),
              }),
            )
            .min(1)
            .describe("Field definitions for the entity Zod schema and JSON-schema type definition."),
          seed: z
            .array(z.record(z.string(), z.unknown()))
            .optional()
            .describe(
              "Optional demo seed rows for this entity type. Each row is the data payload " +
                "(id/type/tenantId/createdAt/updatedAt are added by the generator). Absent ⇒ no seed rows are emitted.",
            ),
        }),
      )
      .optional()
      .describe(
        "Optional entity type + seed declarations. When present the generator emits entity schema files " +
          "and a shared seed module (solution/fixtures/seed.ts) that wires both instrumentation.ts and the " +
          "PS.DATA route chunk — eliminating the 'entity type X is not registered' error on fresh scaffolds.",
      ),
    // ── iam: per-solution IAM / tenancy declaration surface ───────────────────
    //
    // Declares the default isolation tier, identity provider, and any
    // solution-specific roles/permissions beyond the platform-global defaults.
    // Consumed by the scaffold generator to emit RBAC seed data and tenancy
    // bootstrap config. All properties are optional; absent ⇒ platform defaults
    // apply. Existing manifests without this block continue to validate.
    iam: z
      .object({
        // Tenancy posture a scaffolded solution is born with (per-tenant overridable at runtime).
        defaultIsolation: IsolationModeSchema.default("pooled").describe(
          "Default data-isolation tier for this solution's tenants (pooled | schema | silo | dedicated). Per-tenant runtime override is allowed.",
        ),
        // Which identity provider this solution authenticates against.
        identity: z
          .object({
            provider: IdentityProviderKindSchema.describe(
              "IdP kind this solution authenticates against (password | oidc | entra | saml).",
            ),
          })
          .strict()
          .optional()
          .describe("Identity provider binding for this solution. Absent ⇒ platform default IdP."),
        // Solution-declared custom roles beyond the platform-global defaults.
        roles: z
          .array(SolutionRoleSchema)
          .optional()
          .describe("Custom roles declared by this solution. Merged with platform-global roles at seed time."),
        // Solution-declared custom permissions beyond the platform-global defaults.
        permissions: z
          .array(SolutionPermissionSchema)
          .optional()
          .describe("Custom permissions declared by this solution. Merged with platform-global permissions at seed time."),
      })
      .strict()
      .optional()
      .describe(
        "Per-solution IAM / tenancy declaration surface. Absent ⇒ all platform defaults apply. Existing manifests without this field continue to validate.",
      ),
  })
  .describe(
    "DBP Solution Manifest — the machine-readable YAML frontmatter block of a SOLUTION.md file. Validated by the scaffold generator before code is emitted.",
  );

export type SolutionManifest = z.infer<typeof SolutionManifestSchema>;
