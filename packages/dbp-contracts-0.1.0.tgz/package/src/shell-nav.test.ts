import { describe, expect, it } from "vitest";
import {
  SidebarConfigSchema,
  TopBarConfigSchema,
} from "./shell-nav";

describe("SidebarConfigSchema", () => {
  it("validates a minimal sidebar config", () => {
    const result = SidebarConfigSchema.safeParse({
      sections: [
        {
          id: "main",
          items: [
            { id: "home", label: "Home", href: "/" },
          ],
        },
      ],
    });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.collapsible).toBe(false);
    }
  });

  it("validates nested nav items", () => {
    const result = SidebarConfigSchema.safeParse({
      sections: [
        {
          id: "nav",
          label: "Navigation",
          items: [
            {
              id: "parent",
              label: "Parent",
              href: "/parent",
              children: [
                { id: "child", label: "Child", href: "/parent/child", badge: "3", badgeTone: "danger" },
              ],
            },
          ],
        },
      ],
      collapsible: true,
    });
    expect(result.success).toBe(true);
  });

  it("rejects invalid badgeTone", () => {
    const result = SidebarConfigSchema.safeParse({
      sections: [
        {
          id: "nav",
          items: [{ id: "x", label: "X", href: "/x", badgeTone: "purple" }],
        },
      ],
    });
    expect(result.success).toBe(false);
  });
});

describe("TopBarConfigSchema", () => {
  it("validates a minimal top bar config", () => {
    const result = TopBarConfigSchema.safeParse({ appName: "MyApp" });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.logoAlt).toBe("DBP");
      expect(result.data.showUser).toBe(true);
      expect(result.data.actions).toEqual([]);
    }
  });

  it("validates actions", () => {
    const result = TopBarConfigSchema.safeParse({
      appName: "MyApp",
      actions: [{ id: "settings", label: "Settings", icon: "Settings", href: "/settings" }],
      showSearch: true,
    });
    expect(result.success).toBe(true);
  });
});
