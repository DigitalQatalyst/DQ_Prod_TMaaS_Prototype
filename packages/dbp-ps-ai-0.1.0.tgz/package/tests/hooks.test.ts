import { createElement } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { renderHook, act, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it } from "vitest";
import {
  configureAiClient,
  resetAiClient,
  useAssistant,
  useRagSearch,
  useRecommend,
} from "../client/index";
import { dispatch, resetAiService, seedAiService, SEED_RAG_SCOPE, SEED_TENANT_ID } from "../server/index";
import { TEST_TENANT } from "./helpers/bind";

function wrapper() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return ({ children }: { children: React.ReactNode }) =>
    createElement(QueryClientProvider, { client }, children);
}

beforeEach(async () => {
  resetAiService();
  resetAiClient();
  configureAiClient({
    baseUrl: "http://ps-ai.test/api/platform/ai",
    fetch: (input, init) => dispatch(new Request(input, init)),
  });
  await seedAiService();
});

describe("useAssistant hook", () => {
  it("starts with empty messages and streaming false", () => {
    const { result } = renderHook(() => useAssistant(undefined, TEST_TENANT), {
      wrapper: wrapper(),
    });
    expect(result.current.messages).toHaveLength(0);
    expect(result.current.streaming).toBe(false);
  });

  it("appends user and assistant messages after ask", async () => {
    const { result } = renderHook(() => useAssistant(undefined, TEST_TENANT), {
      wrapper: wrapper(),
    });

    await act(async () => {
      await result.current.ask("how do invoices work?");
    });

    expect(result.current.messages.length).toBeGreaterThanOrEqual(2);
    expect(result.current.messages[0]!.role).toBe("user");
    expect(result.current.messages[0]!.content).toBe("how do invoices work?");
    const lastMsg = result.current.messages[result.current.messages.length - 1]!;
    expect(lastMsg.role).toBe("assistant");
    expect(lastMsg.content.length).toBeGreaterThan(0);
  });

  it("streaming is false after ask completes", async () => {
    const { result } = renderHook(() => useAssistant(undefined, TEST_TENANT), {
      wrapper: wrapper(),
    });
    await act(async () => {
      await result.current.ask("hello");
    });
    expect(result.current.streaming).toBe(false);
  });
});

describe("useRagSearch hook", () => {
  it("returns results for a matching query", async () => {
    const { result } = renderHook(
      () => useRagSearch("invoice workflow", SEED_RAG_SCOPE, SEED_TENANT_ID),
      { wrapper: wrapper() },
    );
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.results.length).toBeGreaterThan(0);
    expect(result.current.error).toBeNull();
  });

  it("returns empty array when no query matches", async () => {
    const { result } = renderHook(
      () => useRagSearch("xyznomatch", SEED_RAG_SCOPE, SEED_TENANT_ID),
      { wrapper: wrapper() },
    );
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.results).toHaveLength(0);
  });
});

describe("useRecommend hook", () => {
  it("returns recommendations for invoice entity", async () => {
    const { result } = renderHook(
      () => useRecommend("invoice", { status: "submitted" }, TEST_TENANT),
      { wrapper: wrapper() },
    );
    await waitFor(() => expect(result.current.isLoading).toBe(false));
    expect(result.current.recommendations.length).toBeGreaterThan(0);
    expect(result.current.error).toBeNull();
  });
});
