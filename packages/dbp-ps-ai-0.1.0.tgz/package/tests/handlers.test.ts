// @vitest-environment node
import { beforeEach, describe, expect, it } from "vitest";
import type { RagResult, Recommendation, SseDone, SseChunk } from "../client/types";
import {
  SEED_TENANT_ID,
  SEED_RAG_SCOPE,
  getAiService,
  resetAiService,
  seedAiService,
  seedRagDocuments,
} from "../server/index";
import { OTHER_TENANT, TEST_TENANT, rawRequest } from "./helpers/bind";

// ---------------------------------------------------------------------------
// Helper: consume SSE response body and collect events
// ---------------------------------------------------------------------------

async function consumeSse(
  response: Response,
): Promise<Array<SseChunk | SseDone>> {
  const text = await response.text();
  const events: Array<SseChunk | SseDone> = [];
  for (const block of text.split("\n\n")) {
    const dataLine = block.split("\n").find((l) => l.startsWith("data: "));
    if (!dataLine) continue;
    const payload = JSON.parse(dataLine.slice("data: ".length)) as SseChunk | SseDone;
    events.push(payload);
  }
  return events;
}

beforeEach(() => {
  resetAiService();
});

// ---------------------------------------------------------------------------
// POST /assistant/ask
// ---------------------------------------------------------------------------

describe("POST /assistant/ask", () => {
  it("returns SSE stream with chunk + done events", async () => {
    const response = await rawRequest("POST", "/assistant/ask", {
      body: { message: "how do invoices work?" },
    });
    expect(response.status).toBe(200);
    expect(response.headers.get("content-type")).toContain("text/event-stream");

    const events = await consumeSse(response);
    const chunks = events.filter((e) => e.type === "chunk") as SseChunk[];
    const dones = events.filter((e) => e.type === "done") as SseDone[];

    expect(chunks.length).toBeGreaterThan(0);
    expect(dones).toHaveLength(1);
    expect(dones[0]!.message.length).toBeGreaterThan(0);
  });

  it("assembled message matches concatenated deltas", async () => {
    const response = await rawRequest("POST", "/assistant/ask", {
      body: { message: "help me with a contract" },
    });
    const events = await consumeSse(response);
    const assembled = (events.filter((e) => e.type === "chunk") as SseChunk[])
      .map((c) => c.delta)
      .join("");
    const done = events.find((e) => e.type === "done") as SseDone;
    expect(done.message).toBe(assembled);
  });

  it("is deterministic — same input produces same output", async () => {
    const msg = "how do invoices work?";
    const r1 = await rawRequest("POST", "/assistant/ask", { body: { message: msg } });
    const r2 = await rawRequest("POST", "/assistant/ask", { body: { message: msg } });
    const e1 = (await consumeSse(r1)).find((e) => e.type === "done") as SseDone;
    const e2 = (await consumeSse(r2)).find((e) => e.type === "done") as SseDone;
    expect(e1.message).toBe(e2.message);
  });

  it("accumulates conversation history across turns", async () => {
    const r1 = await rawRequest("POST", "/assistant/ask", {
      body: { message: "tell me about invoices" },
    });
    const d1 = (await consumeSse(r1)).find((e) => e.type === "done") as SseDone;
    const convId = d1.conversationId;

    const r2 = await rawRequest("POST", "/assistant/ask", {
      body: { message: "what about approval?", conversationId: convId },
    });
    expect(r2.status).toBe(200);
    const d2 = (await consumeSse(r2)).find((e) => e.type === "done") as SseDone;
    expect(d2.conversationId).toBe(convId);

    // Verify history in storage (2 user + 2 assistant turns = 4 messages).
    const conv = await getAiService().conversationStorage.get(TEST_TENANT, convId);
    expect(conv?.messages).toHaveLength(4);
  });

  it("echoes context keys in the response", async () => {
    const response = await rawRequest("POST", "/assistant/ask", {
      body: { message: "tell me about invoices", context: { userId: "u-1" } },
    });
    const done = (await consumeSse(response)).find((e) => e.type === "done") as SseDone;
    expect(done.message).toContain("userId");
  });

  it("requires x-tenant-id header", async () => {
    const response = await rawRequest("POST", "/assistant/ask", {
      body: { message: "hello" },
      tenantId: null,
    });
    expect(response.status).toBe(400);
  });

  it("rejects invalid body", async () => {
    const response = await rawRequest("POST", "/assistant/ask", {
      body: { invalid: true },
    });
    expect(response.status).toBe(400);
    const body = (await response.json()) as { issues?: unknown[] };
    expect(body.issues?.length).toBeGreaterThan(0);
  });

  it("provides usage stub in done event", async () => {
    const response = await rawRequest("POST", "/assistant/ask", {
      body: { message: "help me" },
    });
    const done = (await consumeSse(response)).find((e) => e.type === "done") as SseDone;
    expect(done.usage.inputTokens).toBeGreaterThan(0);
    expect(done.usage.outputTokens).toBeGreaterThan(0);
  });

  it("stub ask first-chunk p95 < 50ms (SLO probe)", async () => {
    const N = 50;
    const times: number[] = [];
    for (let i = 0; i < N; i++) {
      const start = performance.now();
      const r = await rawRequest("POST", "/assistant/ask", { body: { message: "how do invoices work?" } });
      // Read only until the first chunk event.
      const reader = r.body!.getReader();
      const decoder = new TextDecoder();
      let firstChunk = false;
      while (!firstChunk) {
        const { done, value } = await reader.read();
        if (done) break;
        const text = decoder.decode(value, { stream: true });
        if (text.includes('"type":"chunk"')) firstChunk = true;
      }
      reader.cancel();
      times.push(performance.now() - start);
    }
    times.sort((a, b) => a - b);
    const p95 = times[Math.floor(N * 0.95)]!;
    expect(p95).toBeLessThan(50);
  });
});

// ---------------------------------------------------------------------------
// POST /rag/content
// ---------------------------------------------------------------------------

describe("POST /rag/content", () => {
  it("registers documents and returns count", async () => {
    const response = await rawRequest("POST", "/rag/content", {
      body: {
        scope: "test-scope",
        docs: [
          { id: "d1", title: "Invoice Guide", content: "Invoices are financial documents." },
          { id: "d2", title: "Contract Guide", content: "Contracts establish legal obligations." },
        ],
      },
    });
    expect(response.status).toBe(200);
    const body = (await response.json()) as { registered: number };
    expect(body.registered).toBe(2);
  });

  it("requires x-tenant-id header", async () => {
    const response = await rawRequest("POST", "/rag/content", {
      body: { scope: "s", docs: [{ id: "d1", title: "T", content: "C" }] },
      tenantId: null,
    });
    expect(response.status).toBe(400);
  });

  it("rejects empty docs array", async () => {
    const response = await rawRequest("POST", "/rag/content", {
      body: { scope: "s", docs: [] },
    });
    expect(response.status).toBe(400);
  });

  it("deduplicates by id within a scope", async () => {
    await rawRequest("POST", "/rag/content", {
      body: { scope: "s", docs: [{ id: "d1", title: "Old Title", content: "old content" }] },
    });
    await rawRequest("POST", "/rag/content", {
      body: { scope: "s", docs: [{ id: "d1", title: "New Title", content: "new content" }] },
    });
    const search = await rawRequest("POST", "/rag/search", {
      body: { query: "new content", scope: "s" },
    });
    const { results } = (await search.json()) as { results: RagResult[] };
    const d1 = results.find((r) => r.id === "d1");
    expect(d1?.title).toBe("New Title");
  });
});

// ---------------------------------------------------------------------------
// POST /rag/search
// ---------------------------------------------------------------------------

describe("POST /rag/search", () => {
  beforeEach(async () => {
    // Seed uses SEED_TENANT_ID; all rag/search tests in this describe use it.
    await seedAiService();
  });

  it("returns results for matching query", async () => {
    const response = await rawRequest("POST", "/rag/search", {
      body: { query: "invoice workflow approval" },
      tenantId: SEED_TENANT_ID,
    });
    expect(response.status).toBe(200);
    const { results } = (await response.json()) as { results: RagResult[] };
    expect(results.length).toBeGreaterThan(0);
    expect(results[0]).toMatchObject({
      id: expect.any(String),
      scope: SEED_RAG_SCOPE,
      title: expect.any(String),
      snippet: expect.any(String),
      score: expect.any(Number),
    });
  });

  it("orders by descending score", async () => {
    const response = await rawRequest("POST", "/rag/search", {
      body: { query: "invoice workflow" },
      tenantId: SEED_TENANT_ID,
    });
    const { results } = (await response.json()) as { results: RagResult[] };
    for (let i = 1; i < results.length; i++) {
      expect(results[i - 1]!.score).toBeGreaterThanOrEqual(results[i]!.score);
    }
  });

  it("filters by scope", async () => {
    // Register a doc in a different scope under the same seed tenant.
    await rawRequest("POST", "/rag/content", {
      body: {
        scope: "other-scope",
        docs: [{ id: "o1", title: "Other Invoice Doc", content: "invoice payment billing" }],
      },
      tenantId: SEED_TENANT_ID,
    });
    const response = await rawRequest("POST", "/rag/search", {
      body: { query: "invoice", scope: SEED_RAG_SCOPE },
      tenantId: SEED_TENANT_ID,
    });
    const { results } = (await response.json()) as { results: RagResult[] };
    expect(results.every((r) => r.scope === SEED_RAG_SCOPE)).toBe(true);
  });

  it("is deterministic — same query returns same ordered results", async () => {
    const r1 = await rawRequest("POST", "/rag/search", {
      body: { query: "platform services" },
      tenantId: SEED_TENANT_ID,
    });
    const r2 = await rawRequest("POST", "/rag/search", {
      body: { query: "platform services" },
      tenantId: SEED_TENANT_ID,
    });
    const { results: res1 } = (await r1.json()) as { results: RagResult[] };
    const { results: res2 } = (await r2.json()) as { results: RagResult[] };
    expect(res1.map((r) => r.id)).toEqual(res2.map((r) => r.id));
  });

  it("returns empty array when no matches", async () => {
    const response = await rawRequest("POST", "/rag/search", {
      body: { query: "xyznomatch" },
      tenantId: SEED_TENANT_ID,
    });
    const { results } = (await response.json()) as { results: RagResult[] };
    expect(results).toHaveLength(0);
  });

  it("requires x-tenant-id header", async () => {
    const response = await rawRequest("POST", "/rag/search", {
      body: { query: "invoice" },
      tenantId: null,
    });
    expect(response.status).toBe(400);
  });
});

// ---------------------------------------------------------------------------
// POST /recommend
// ---------------------------------------------------------------------------

describe("POST /recommend", () => {
  it("returns recommendations for known entity", async () => {
    const response = await rawRequest("POST", "/recommend", {
      body: { entity: "invoice" },
    });
    expect(response.status).toBe(200);
    const { recommendations } = (await response.json()) as { recommendations: Recommendation[] };
    expect(recommendations.length).toBeGreaterThan(0);
    expect(recommendations[0]).toMatchObject({
      id: expect.any(String),
      label: expect.any(String),
      reason: expect.any(String),
      score: expect.any(Number),
    });
  });

  it("orders by descending score", async () => {
    const response = await rawRequest("POST", "/recommend", {
      body: { entity: "invoice" },
    });
    const { recommendations } = (await response.json()) as { recommendations: Recommendation[] };
    for (let i = 1; i < recommendations.length; i++) {
      expect(recommendations[i - 1]!.score).toBeGreaterThanOrEqual(recommendations[i]!.score);
    }
  });

  it("is deterministic", async () => {
    const r1 = await rawRequest("POST", "/recommend", { body: { entity: "contract" } });
    const r2 = await rawRequest("POST", "/recommend", { body: { entity: "contract" } });
    const { recommendations: rec1 } = (await r1.json()) as { recommendations: Recommendation[] };
    const { recommendations: rec2 } = (await r2.json()) as { recommendations: Recommendation[] };
    expect(rec1.map((r) => r.id)).toEqual(rec2.map((r) => r.id));
  });

  it("returns default recommendations for unknown entity", async () => {
    const response = await rawRequest("POST", "/recommend", {
      body: { entity: "unknown-entity-xyz" },
    });
    const { recommendations } = (await response.json()) as { recommendations: Recommendation[] };
    expect(recommendations.length).toBeGreaterThan(0);
  });

  it("context-keyed rule fires only when context key is present", async () => {
    const withCtx = await rawRequest("POST", "/recommend", {
      body: { entity: "invoice", context: { status: "submitted" } },
    });
    const withoutCtx = await rawRequest("POST", "/recommend", {
      body: { entity: "invoice" },
    });
    const { recommendations: withRecs } = (await withCtx.json()) as {
      recommendations: Recommendation[];
    };
    const { recommendations: withoutRecs } = (await withoutCtx.json()) as {
      recommendations: Recommendation[];
    };
    const approveWithCtx = withRecs.find((r) => r.id === "inv-approve");
    const approveWithout = withoutRecs.find((r) => r.id === "inv-approve");
    expect(approveWithCtx).toBeDefined();
    expect(approveWithout).toBeUndefined();
  });

  it("requires x-tenant-id header", async () => {
    const response = await rawRequest("POST", "/recommend", {
      body: { entity: "invoice" },
      tenantId: null,
    });
    expect(response.status).toBe(400);
  });

  it("rejects invalid body", async () => {
    const response = await rawRequest("POST", "/recommend", {
      body: { invalid: true },
    });
    expect(response.status).toBe(400);
  });

  // Regression: self-service-dashboard was omitting x-tenant-id, causing a 400
  // retry loop. This test pins the exact request shape the server requires.
  it("request shape regression — entity string + optional context, no extra fields", async () => {
    // Minimal valid request: entity only
    const r1 = await rawRequest("POST", "/recommend", {
      body: { entity: "sales-record" },
    });
    expect(r1.status).toBe(200);

    // Valid with context
    const r2 = await rawRequest("POST", "/recommend", {
      body: { entity: "sales-record", context: { useCase: "analytics" } },
    });
    expect(r2.status).toBe(200);

    // Missing x-tenant-id → must return 400 (not silently fall through)
    const r3 = await rawRequest("POST", "/recommend", {
      body: { entity: "sales-record" },
      tenantId: null,
    });
    expect(r3.status).toBe(400);
    const body3 = (await r3.json()) as { error: string };
    expect(body3.error).toContain("x-tenant-id");

    // Spurious extra field (tenantId in body instead of header) → 400 (strict schema)
    const r4 = await rawRequest("POST", "/recommend", {
      body: { entity: "sales-record", tenantId: "should-be-in-header" },
    });
    expect(r4.status).toBe(400);
  });
});

// ---------------------------------------------------------------------------
// Tenant isolation
// ---------------------------------------------------------------------------

describe("tenant isolation", () => {
  it("RAG content is scoped to tenant", async () => {
    // Register in tenant A.
    await rawRequest("POST", "/rag/content", {
      body: {
        scope: "docs",
        docs: [{ id: "private", title: "Tenant A Doc", content: "private tenant a invoice" }],
      },
      tenantId: TEST_TENANT,
    });

    // Tenant B should not see tenant A docs.
    const r = await rawRequest("POST", "/rag/search", {
      body: { query: "private tenant a invoice", scope: "docs" },
      tenantId: OTHER_TENANT,
    });
    const { results } = (await r.json()) as { results: RagResult[] };
    expect(results).toHaveLength(0);
  });

  it("conversations are scoped to tenant", async () => {
    const r1 = await rawRequest("POST", "/assistant/ask", {
      body: { message: "hello from tenant A" },
      tenantId: TEST_TENANT,
    });
    const d1 = (await consumeSse(r1)).find((e) => e.type === "done") as SseDone;
    const convId = d1.conversationId;

    // Tenant B cannot load tenant A's conversation.
    const conv = await getAiService().conversationStorage.get(OTHER_TENANT, convId);
    expect(conv).toBeUndefined();
  });
});

// ---------------------------------------------------------------------------
// Seed fixtures
// ---------------------------------------------------------------------------

describe("seed fixtures", () => {
  it("seeds deterministic RAG docs accessible via search", async () => {
    await seedAiService();
    const r = await rawRequest("POST", "/rag/search", {
      body: { query: "platform services overview", scope: SEED_RAG_SCOPE },
      tenantId: SEED_TENANT_ID,
    });
    const { results } = (await r.json()) as { results: RagResult[] };
    expect(results.length).toBeGreaterThan(0);
    expect(results.some((r) => r.id === seedRagDocuments[2].id)).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// Dispatch
// ---------------------------------------------------------------------------

describe("dispatch", () => {
  it("404s unknown routes", async () => {
    const response = await rawRequest("GET", "/nope");
    expect(response.status).toBe(404);
  });
});
