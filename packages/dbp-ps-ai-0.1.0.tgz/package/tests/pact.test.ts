// @vitest-environment node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { beforeAll, describe, expect, it } from "vitest";
import {
  configureAiClient,
  ragSearch,
  recommend,
  registerContent,
} from "../client/index";
import {
  SEED_RAG_SCOPE,
  SEED_TENANT_ID,
  resetAiService,
  seedAiService,
} from "../server/index";
import { startHandlerServer } from "./helpers/node-server";

/*
 * pact-core ships native binaries for these platforms only. Importing
 * @pact-foundation/pact on any other platform throws at module load, so the
 * import is dynamic and the suite self-skips (CI on linux-x64 always runs it).
 */
const PACT_PLATFORMS = ["darwin-arm64", "darwin-x64", "linux-arm64", "linux-x64", "win32-x64"];
const hostPlatform = `${process.platform}-${process.arch}`;
const pactSupported = PACT_PLATFORMS.includes(hostPlatform);
if (!pactSupported) {
  console.warn(
    `PACT TESTS SKIPPED: pact-core has no native binary for ${hostPlatform}. ` +
      `Run the suite on one of: ${PACT_PLATFORMS.join(", ")}.`,
  );
}

type PactModule = typeof import("@pact-foundation/pact");
let pact: PactModule;

const pactDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "pacts");
const CONSUMER = "dbp-ps-ai-client";
const PROVIDER = "dbp-ps-ai";

const TEST_TENANT = SEED_TENANT_ID;
const tenantHeaders = { "x-tenant-id": TEST_TENANT };
const jsonTenantHeaders = { ...tenantHeaders, "content-type": "application/json" };

function newPact(): InstanceType<PactModule["PactV3"]> {
  return new pact.PactV3({ consumer: CONSUMER, provider: PROVIDER, dir: pactDir });
}

function bindClientTo(mockServerUrl: string): void {
  configureAiClient({
    baseUrl: `${mockServerUrl}/api/platform/ai`,
    fetch: (input, init) => globalThis.fetch(input, init),
  });
}

describe.skipIf(!pactSupported)(
  "Pact — consumer (client SDK against the mock provider)",
  () => {
    beforeAll(async () => {
      pact = await import("@pact-foundation/pact");
    });

    it("registers RAG content (POST /rag/content)", async () => {
      const provider = newPact();
      provider
        .given("tenant is ready to receive content")
        .uponReceiving("a request to register RAG content")
        .withRequest({
          method: "POST",
          path: "/api/platform/ai/rag/content",
          headers: jsonTenantHeaders,
          body: {
            scope: SEED_RAG_SCOPE,
            docs: pact.MatchersV3.eachLike({
              id: pact.MatchersV3.like("doc-0001"),
              title: pact.MatchersV3.like("Invoice Workflow Overview"),
              content: pact.MatchersV3.like("Invoices flow through a standard lifecycle."),
            }),
          },
        })
        .willRespondWith({
          status: 200,
          headers: { "content-type": "application/json" },
          body: { registered: pact.MatchersV3.like(1) },
        });

      await provider.executeTest(async (mockServer) => {
        bindClientTo(mockServer.url);
        const result = await registerContent(
          {
            scope: SEED_RAG_SCOPE,
            docs: [
              {
                id: "doc-0001",
                title: "Invoice Workflow Overview",
                content: "Invoices flow through a standard lifecycle.",
              },
            ],
          },
          TEST_TENANT,
        );
        expect(result.registered).toBe(1);
      });
    });

    it("searches RAG content (POST /rag/search)", async () => {
      const provider = newPact();
      provider
        .given("tenant has seeded RAG content")
        .uponReceiving("a request to search RAG content")
        .withRequest({
          method: "POST",
          path: "/api/platform/ai/rag/search",
          headers: jsonTenantHeaders,
          body: {
            query: pact.MatchersV3.like("invoice workflow"),
            scope: pact.MatchersV3.like(SEED_RAG_SCOPE),
          },
        })
        .willRespondWith({
          status: 200,
          headers: { "content-type": "application/json" },
          body: {
            results: pact.MatchersV3.eachLike({
              id: pact.MatchersV3.like("doc-0001"),
              scope: pact.MatchersV3.like(SEED_RAG_SCOPE),
              title: pact.MatchersV3.like("Invoice Workflow Overview"),
              snippet: pact.MatchersV3.like("Invoices flow through a standard lifecycle."),
              score: pact.MatchersV3.like(0.5),
            }),
          },
        });

      await provider.executeTest(async (mockServer) => {
        bindClientTo(mockServer.url);
        const results = await ragSearch("invoice workflow", SEED_RAG_SCOPE, TEST_TENANT);
        expect(results.length).toBeGreaterThan(0);
      });
    });

    it("gets recommendations (POST /recommend)", async () => {
      const provider = newPact();
      provider
        .given("tenant is ready for recommendations")
        .uponReceiving("a request for recommendations on invoice entity")
        .withRequest({
          method: "POST",
          path: "/api/platform/ai/recommend",
          headers: jsonTenantHeaders,
          body: { entity: pact.MatchersV3.like("invoice") },
        })
        .willRespondWith({
          status: 200,
          headers: { "content-type": "application/json" },
          body: {
            recommendations: pact.MatchersV3.eachLike({
              id: pact.MatchersV3.like("inv-request-info"),
              label: pact.MatchersV3.like("Request more information"),
              reason: pact.MatchersV3.like("Some line items lack a cost centre code."),
              score: pact.MatchersV3.like(0.75),
            }),
          },
        });

      await provider.executeTest(async (mockServer) => {
        bindClientTo(mockServer.url);
        const results = await recommend("invoice", undefined, TEST_TENANT);
        expect(results.length).toBeGreaterThan(0);
      });
    });
  },
);

describe.skipIf(!pactSupported)(
  "Pact — provider (handlers on node:http verify the pact)",
  () => {
    beforeAll(async () => {
      pact = await import("@pact-foundation/pact");
    });

    it("verifies every interaction in the generated pact file", async () => {
      const pactFile = path.join(pactDir, `${CONSUMER}-${PROVIDER}.json`);
      expect(fs.existsSync(pactFile)).toBe(true);

      const server = await startHandlerServer();
      try {
        const output = await new pact.Verifier({
          provider: PROVIDER,
          providerBaseUrl: server.url,
          pactUrls: [pactFile],
          logLevel: "error",
          stateHandlers: {
            "tenant is ready to receive content": async () => {
              resetAiService();
              return "reset";
            },
            "tenant has seeded RAG content": async () => {
              resetAiService();
              await seedAiService();
              return "seeded";
            },
            "tenant is ready for recommendations": async () => {
              resetAiService();
              return "reset";
            },
          },
        }).verifyProvider();
        expect(output).toContain("finished");
      } finally {
        await server.close();
      }
    });
  },
);
