# PS.AI — AI Service

## Purpose

Single AI surface for DBP solutions: assistant conversations (streaming SSE), RAG-backed
search over registered content, and deterministic recommendations. Solutions consume the
client SDK — they never embed model calls or roll their own AI logic.

Maps to DIA.03 (AIOps) in the architecture. All model traffic routes through the
`AiGatewayAdapter` seam, which is the PromptOps governance boundary.

## Atomic class

`AI`

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/platform/ai/assistant/ask` | Stream assistant reply (SSE) |
| POST | `/api/platform/ai/rag/content` | Register docs into scope store |
| POST | `/api/platform/ai/rag/search` | Search scope store by relevance |
| POST | `/api/platform/ai/recommend` | Deterministic recommendations |

All endpoints require `x-tenant-id` header for tenant isolation.

## SLOs

| Metric | Target | Measurement approach |
|--------|--------|---------------------|
| Stub ask first-chunk p95 | < 50 ms | `handlers.test.ts` "SLO probe": 50 cold in-process round-trips, `performance.now()` around the request, p95 extracted from sorted array |
| RAG search p95 | < 20 ms | Same pattern (token-overlap over in-memory Map is O(n·k) where k = tokens; well within target) |

**Live-gateway SLOs are a future ADR.** When `StubGatewayAdapter` is replaced by a real
provider (DIA.03 build-out), the SLOs for latency, throughput, and token budgets must be
re-assessed and documented in a new ADR tied to the gateway choice.

## Contract

- Location: `contract.yaml` (committed, generated from Zod schemas)
- Regenerate: `pnpm --filter @dbp/ps-ai contracts:gen`
- Drift check: `pnpm --filter @dbp/ps-ai contracts:check` (runs in `pnpm pipeline`)

SSE endpoint (`/assistant/ask`) is documented as `text/event-stream` with `SseChunk` and
`SseDone` schemas in OpenAPI components. Shape is contract-fixed per ADR-0011 — a live
gateway adapter changes no consumer.

## Adapter seam + PromptOps / DIA.03

`AiGatewayAdapter` (in `server/gateway.ts`) is the single swap point:

```ts
interface AiGatewayAdapter {
  complete(options: GatewayCompleteOptions): AsyncIterable<string>;
}
```

To wire a real model provider:
1. Implement `AiGatewayAdapter` in a new file (e.g. `server/anthropic-adapter.ts`).
2. Call `configureAiService({ gateway: new AnthropicAdapter(...) })` at startup.
3. Write a new ADR documenting the provider choice, cost governance, and SLOs.
4. No consumer code changes — the SSE streaming shape is already contract-fixed.

## Determinism note

Phase-2 `StubGatewayAdapter` is intentionally deterministic: canned responses are keyed
by intent patterns extracted from the last user message. Same input → same output.
Feature and e2e tests rely on this property. RAG retrieval uses Jaccard token-overlap
(bag-of-words heuristic) — also deterministic. This is a known trade-off documented in
ADR-0011.

## Storage and tenancy

- RAG scope store: in-memory `InMemoryRagStorageAdapter` — tenant-isolated, scope-isolated.
- Conversation store: in-memory `InMemoryConversationStorageAdapter` — tenant-isolated.
- No durability across process restarts. A production-storage ADR is mandatory before any
  real deployment (ADR-0008).

## Semver policy

`0.1.0` — pre-stable. Breaking changes to SDK signatures (useAssistant, ragSearch,
recommend) require a minor bump and a CHANGELOG entry. No breaking changes until the
first stable release (1.0.0) which is gated on at least one live-gateway integration test.
