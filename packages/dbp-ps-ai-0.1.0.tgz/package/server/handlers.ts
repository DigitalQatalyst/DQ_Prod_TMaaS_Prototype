import {
  AskRequestSchema,
  RagSearchRequestSchema,
  RagResultSchema,
  RecommendRequestSchema,
  RegisterContentRequestSchema,
  type ChatMessage,
  type ValidationIssue,
} from "../client/types";
import { getRecommendations } from "./recommend-rules";
import { jaccardScore, snippet } from "./rag-score";
import { getAiService } from "./service";

export const BASE_PATH = "/api/platform/ai";

export type RouteHandler = (req: Request) => Promise<Response>;

export type RouteDefinition = {
  method: "GET" | "POST" | "PATCH" | "DELETE";
  path: string;
  handler: RouteHandler;
};

const json = (status: number, body: unknown): Response =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });

const errorResponse = (status: number, message: string, issues?: ValidationIssue[]): Response =>
  json(status, issues && issues.length > 0 ? { error: message, issues } : { error: message });

function tenantOf(req: Request): string | null {
  const v = req.headers.get("x-tenant-id")?.trim();
  return v ? v : null;
}

async function readJsonBody(req: Request): Promise<{ ok: true; value: unknown } | { ok: false }> {
  try {
    return { ok: true, value: await req.json() };
  } catch {
    return { ok: false };
  }
}

const zodIssues = (issues: { path: (string | number)[]; message: string }[]): ValidationIssue[] =>
  issues.map((issue) => ({ path: issue.path.join(".") || "(root)", message: issue.message }));

// ---------------------------------------------------------------------------
// POST /assistant/ask — SSE streaming response
// ---------------------------------------------------------------------------

export const assistantAskHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");

  const parsed = AskRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid ask request", zodIssues(parsed.error.issues));
  }

  const { message, context, conversationId } = parsed.data;
  const svc = getAiService();

  // Load or create conversation.
  const convId = conversationId ?? crypto.randomUUID();
  const now = new Date().toISOString();
  const existing = conversationId
    ? await svc.conversationStorage.get(tenantId, convId)
    : undefined;

  const history: ChatMessage[] = existing ? [...existing.messages] : [];
  history.push({ role: "user", content: message });

  // Persist conversation with user message appended.
  await svc.conversationStorage.put(tenantId, {
    id: convId,
    tenantId,
    messages: history,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  });

  const encoder = new TextEncoder();

  // Stub gateway adapter is synchronous under the hood but typed as AsyncIterable.
  const chunks: string[] = [];
  for await (const chunk of svc.gateway.complete({
    messages: history,
    ...(context !== undefined && { context }),
  })) {
    chunks.push(chunk);
  }
  const fullMessage = chunks.join("");

  // Persist the assistant reply.
  const updatedHistory = [...history, { role: "assistant" as const, content: fullMessage }];
  await svc.conversationStorage.put(tenantId, {
    id: convId,
    tenantId,
    messages: updatedHistory,
    createdAt: existing?.createdAt ?? now,
    updatedAt: new Date().toISOString(),
  });

  // Stream collected chunks as SSE events.
  const byteStream = new ReadableStream<Uint8Array>({
    async start(ctrl) {
      for (const chunk of chunks) {
        const event: import("../client/types").SseChunk = {
          type: "chunk",
          delta: chunk,
          conversationId: convId,
        };
        ctrl.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`));
      }
      const done: import("../client/types").SseDone = {
        type: "done",
        conversationId: convId,
        message: fullMessage,
        // Stub usage: approximate token counts.
        usage: {
          inputTokens: Math.ceil(message.length / 4),
          outputTokens: Math.ceil(fullMessage.length / 4),
        },
      };
      ctrl.enqueue(encoder.encode(`data: ${JSON.stringify(done)}\n\n`));
      ctrl.close();
    },
  });

  return new Response(byteStream, {
    status: 200,
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache",
      connection: "keep-alive",
    },
  });
};

// ---------------------------------------------------------------------------
// POST /rag/content — register documents into scope store
// ---------------------------------------------------------------------------

export const ragContentHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");

  const parsed = RegisterContentRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid register content request", zodIssues(parsed.error.issues));
  }

  const svc = getAiService();
  for (const doc of parsed.data.docs) {
    await svc.ragStorage.put(tenantId, parsed.data.scope, doc);
  }

  return json(200, { registered: parsed.data.docs.length });
};

// ---------------------------------------------------------------------------
// POST /rag/search — retrieve documents by relevance
// ---------------------------------------------------------------------------

export const ragSearchHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");

  const parsed = RagSearchRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid rag search request", zodIssues(parsed.error.issues));
  }

  const { query, scope } = parsed.data;
  const svc = getAiService();
  const entries = await svc.ragStorage.listByScope(tenantId, scope);

  const results = entries
    .map((entry) => ({
      id: entry.doc.id,
      scope: entry.scope,
      title: entry.doc.title,
      snippet: snippet(entry.doc.content),
      score: jaccardScore(query, `${entry.doc.title} ${entry.doc.content}`),
    }))
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id))
    .map((r) => RagResultSchema.parse(r));

  return json(200, { results });
};

// ---------------------------------------------------------------------------
// POST /recommend — deterministic rule-based recommendations
// ---------------------------------------------------------------------------

export const recommendHandler: RouteHandler = async (req) => {
  const tenantId = tenantOf(req);
  if (!tenantId) return errorResponse(400, "x-tenant-id header is required");

  const body = await readJsonBody(req);
  if (!body.ok) return errorResponse(400, "request body is not valid JSON");

  const parsed = RecommendRequestSchema.safeParse(body.value);
  if (!parsed.success) {
    return errorResponse(400, "invalid recommend request", zodIssues(parsed.error.issues));
  }

  const recommendations = getRecommendations(
    parsed.data.entity,
    parsed.data.context as Record<string, unknown> | undefined,
  );
  return json(200, { recommendations });
};

// ---------------------------------------------------------------------------
// Routes manifest + dispatch
// ---------------------------------------------------------------------------

export const routes: RouteDefinition[] = [
  { method: "POST", path: `${BASE_PATH}/assistant/ask`, handler: assistantAskHandler },
  { method: "POST", path: `${BASE_PATH}/rag/content`, handler: ragContentHandler },
  { method: "POST", path: `${BASE_PATH}/rag/search`, handler: ragSearchHandler },
  { method: "POST", path: `${BASE_PATH}/recommend`, handler: recommendHandler },
];

function matchesPattern(pattern: string, pathname: string): boolean {
  const expected = pattern.split("/").filter(Boolean);
  const actual = pathname.split("/").filter(Boolean);
  if (expected.length !== actual.length) return false;
  return expected.every((segment, index) => segment.startsWith(":") || segment === actual[index]);
}

export const dispatch: RouteHandler = async (req) => {
  const { pathname } = new URL(req.url);
  for (const route of routes) {
    if (route.method === req.method && matchesPattern(route.path, pathname)) {
      return route.handler(req);
    }
  }
  return errorResponse(404, `no PS.AI route for ${req.method} ${pathname}`);
};
