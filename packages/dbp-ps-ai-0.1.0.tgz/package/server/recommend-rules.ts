import type { Recommendation } from "../client/types";

/**
 * Deterministic recommendation rules keyed by entity type.
 * Same entity + context → same ranked output; tests rely on this.
 */

type Rule = {
  id: string;
  label: string;
  reason: string;
  score: number;
  /** If provided, the rule only fires when context contains this key. */
  contextKey?: string;
};

const RULES: Record<string, Rule[]> = {
  invoice: [
    {
      id: "inv-approve",
      label: "Approve invoice",
      reason: "The invoice is in Submitted state and meets all validation criteria.",
      score: 0.95,
      contextKey: "status",
    },
    {
      id: "inv-request-info",
      label: "Request more information",
      reason: "Some line items lack a cost centre code.",
      score: 0.75,
    },
    {
      id: "inv-reject",
      label: "Reject invoice",
      reason: "Duplicate invoice number detected in this period.",
      score: 0.45,
    },
  ],
  contract: [
    {
      id: "ctr-review",
      label: "Route for legal review",
      reason: "Contract value exceeds the threshold requiring legal sign-off.",
      score: 0.9,
    },
    {
      id: "ctr-sign",
      label: "Prepare for signature",
      reason: "All review comments have been resolved.",
      score: 0.8,
    },
    {
      id: "ctr-archive",
      label: "Archive expired contract",
      reason: "Contract end date has passed.",
      score: 0.6,
    },
  ],
  workflow: [
    {
      id: "wf-advance",
      label: "Advance to next step",
      reason: "All required approvals for the current step are complete.",
      score: 0.92,
    },
    {
      id: "wf-remind",
      label: "Send reminder notification",
      reason: "The current step has been pending for more than 48 hours.",
      score: 0.7,
    },
  ],
  default: [
    {
      id: "default-view",
      label: "View entity details",
      reason: "Review all fields and related records before taking action.",
      score: 0.5,
    },
    {
      id: "default-audit",
      label: "Check audit trail",
      reason: "Verify recent changes before proceeding.",
      score: 0.4,
    },
  ],
};

export function getRecommendations(
  entity: string,
  context?: Record<string, unknown>,
): Recommendation[] {
  const rules = RULES[entity.toLowerCase()] ?? RULES["default"]!;
  return rules
    .filter((r) => r.contextKey === undefined || (context !== undefined && r.contextKey in context))
    .map(({ id, label, reason, score }) => ({ id, label, reason, score }))
    .sort((a, b) => b.score - a.score);
}
