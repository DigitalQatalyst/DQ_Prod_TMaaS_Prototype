import { getAiService, type AiService } from "./service";

export const SEED_TENANT_ID = "tenant-demo";

export const SEED_RAG_SCOPE = "platform-docs";

export const seedRagDocuments = [
  {
    id: "doc-0001",
    title: "Invoice Workflow Overview",
    content:
      "Invoices flow through a standard lifecycle: Draft → Submitted → Under Review → Approved or Rejected. " +
      "Each transition triggers a notification to relevant stakeholders. Use PS.WORKFLOW to advance state.",
  },
  {
    id: "doc-0002",
    title: "Contract Management Guide",
    content:
      "Contracts are created in Draft state and require legal review above a value threshold. " +
      "Signature workflow uses PS.WORKFLOW multi-step approvals. Archival occurs after expiry.",
  },
  {
    id: "doc-0003",
    title: "Platform Services Overview",
    content:
      "DBP provides ten platform services: PS.AUTH (identity), PS.RBAC (authorisation), PS.AUDIT (activity log), " +
      "PS.NOTIF (notifications), PS.SEARCH (entity search), PS.WORKFLOW (state machines), PS.EVENTS (event bus), " +
      "PS.AI (assistant/RAG/recommend), PS.DATA (entity store), PS.APIGW (API gateway). " +
      "Solutions consume SDK clients — never re-implement.",
  },
] as const;

export async function seedAiService(target: AiService = getAiService()): Promise<void> {
  for (const doc of seedRagDocuments) {
    await target.ragStorage.put(SEED_TENANT_ID, SEED_RAG_SCOPE, doc);
  }
}
