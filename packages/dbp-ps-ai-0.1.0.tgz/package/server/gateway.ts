import type { ChatMessage } from "../client/types";

// ---------------------------------------------------------------------------
// AiGatewayAdapter interface
//
// The seam where a live model provider would plug in (DIA.03 / PromptOps).
// In Phase 2 the only implementation is StubGatewayAdapter (ADR-0011).
// ---------------------------------------------------------------------------

export type GatewayCompleteOptions = {
  /** Arbitrary context forwarded from the caller (intent, entity, user info…). */
  context?: Record<string, unknown>;
  /** The full conversation history (user + assistant turns). */
  messages: ChatMessage[];
};

/**
 * Stream-or-full adapter interface.
 * complete() MUST return an async iterable of text chunks.
 * The final chunk carries the full message in the "done" event (SSE layer handles framing).
 */
export interface AiGatewayAdapter {
  complete(options: GatewayCompleteOptions): AsyncIterable<string>;
}

// ---------------------------------------------------------------------------
// Intent detection — maps a message to a canned key
// ---------------------------------------------------------------------------

const INTENT_PATTERNS: Array<{ pattern: RegExp; key: string }> = [
  { pattern: /\b(invoice|payment|bill|amount)\b/i, key: "invoice" },
  { pattern: /\b(contract|agreement|sign|clause)\b/i, key: "contract" },
  { pattern: /\b(workflow|approval|step|state)\b/i, key: "workflow" },
  { pattern: /\b(report|analytics|dashboard|metric)\b/i, key: "report" },
  { pattern: /\b(help|how|what|explain)\b/i, key: "help" },
];

function detectIntent(message: string): string {
  for (const { pattern, key } of INTENT_PATTERNS) {
    if (pattern.test(message)) return key;
  }
  return "default";
}

// ---------------------------------------------------------------------------
// Canned response templates (deterministic: same intent → same output)
// ---------------------------------------------------------------------------

const CANNED: Record<string, string> = {
  invoice:
    "Invoice processing follows a standard lifecycle: Draft → Submitted → Under Review → " +
    "Approved or Rejected. Use the workflow engine to advance state and notify stakeholders.",
  contract:
    "Contracts pass through a review and signature workflow. Key clauses include payment terms, " +
    "liability caps, and termination rights. Ensure all parties have signed before activation.",
  workflow:
    "Workflows are multi-step state machines defined in PS.WORKFLOW. Each step can have " +
    "guards, actions, and notifications. The current state is always queryable from the SDK.",
  report:
    "Reports aggregate entity data across the PS.DATA store. Use filters and pagination to " +
    "narrow scope. For real-time dashboards, combine with the PS.EVENTS event bus.",
  help:
    "I can help with invoices, contracts, workflows, reports, and general platform guidance. " +
    "Ask me a specific question and I will guide you through the relevant platform service.",
  default:
    "I understand you have a question about the platform. Could you provide more detail? " +
    "I can assist with invoices, contracts, workflows, analytics, and platform services.",
};

// Chunk size for streaming simulation (characters per chunk).
const CHUNK_SIZE = 20;

/**
 * StubGatewayAdapter — deterministic, context-echoing canned responses.
 *
 * Intent is detected from the most recent user message. Same input → same
 * output, so tests can assert on response content. No model SDK dependency
 * (ADR-0011). Streaming is simulated by splitting the canned response into
 * fixed-size character chunks so the SSE framing is exercised end-to-end.
 */
export class StubGatewayAdapter implements AiGatewayAdapter {
  async *complete(options: GatewayCompleteOptions): AsyncIterable<string> {
    const lastUser = [...options.messages].reverse().find((m) => m.role === "user");
    const intent = lastUser ? detectIntent(lastUser.content) : "default";

    // Optionally echo a context key so tests can verify context forwarding.
    const contextNote =
      options.context && Object.keys(options.context).length > 0
        ? ` [context: ${Object.keys(options.context).join(", ")}]`
        : "";

    const full = (CANNED[intent] ?? CANNED["default"]!) + contextNote;

    for (let i = 0; i < full.length; i += CHUNK_SIZE) {
      yield full.slice(i, i + CHUNK_SIZE);
    }
  }
}
