import type { ChatMessage, RagDocument } from "../client/types";

// ---------------------------------------------------------------------------
// RAG scope store — in-memory (ADR-0008)
// ---------------------------------------------------------------------------

export type ScopeEntry = {
  doc: RagDocument;
  scope: string;
  tenantId: string;
};

export interface RagStorageAdapter {
  put(tenantId: string, scope: string, doc: RagDocument): Promise<void>;
  listByScope(tenantId: string, scope?: string): Promise<ScopeEntry[]>;
  clear(): void;
}

export class InMemoryRagStorageAdapter implements RagStorageAdapter {
  /** tenantId → scope → doc[] (insertion order). */
  private readonly buckets = new Map<string, Map<string, RagDocument[]>>();

  private scopeBucket(tenantId: string, scope: string): RagDocument[] {
    let tenantMap = this.buckets.get(tenantId);
    if (!tenantMap) {
      tenantMap = new Map();
      this.buckets.set(tenantId, tenantMap);
    }
    let docs = tenantMap.get(scope);
    if (!docs) {
      docs = [];
      tenantMap.set(scope, docs);
    }
    return docs;
  }

  async put(tenantId: string, scope: string, doc: RagDocument): Promise<void> {
    const bucket = this.scopeBucket(tenantId, scope);
    const existing = bucket.findIndex((d) => d.id === doc.id);
    if (existing >= 0) {
      bucket[existing] = { ...doc };
    } else {
      bucket.push({ ...doc });
    }
  }

  async listByScope(tenantId: string, scope?: string): Promise<ScopeEntry[]> {
    const tenantMap = this.buckets.get(tenantId);
    if (!tenantMap) return [];
    const entries: ScopeEntry[] = [];
    for (const [s, docs] of tenantMap.entries()) {
      if (scope !== undefined && s !== scope) continue;
      for (const doc of docs) {
        entries.push({ doc: { ...doc }, scope: s, tenantId });
      }
    }
    return entries;
  }

  clear(): void {
    this.buckets.clear();
  }
}

// ---------------------------------------------------------------------------
// Conversation store — in-memory (ADR-0008)
// ---------------------------------------------------------------------------

export type ConversationEntry = {
  id: string;
  tenantId: string;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt: string;
};

export interface ConversationStorageAdapter {
  get(tenantId: string, id: string): Promise<ConversationEntry | undefined>;
  put(tenantId: string, entry: ConversationEntry): Promise<void>;
  clear(): void;
}

export class InMemoryConversationStorageAdapter implements ConversationStorageAdapter {
  private readonly buckets = new Map<string, Map<string, ConversationEntry>>();

  private bucket(tenantId: string): Map<string, ConversationEntry> {
    let b = this.buckets.get(tenantId);
    if (!b) {
      b = new Map();
      this.buckets.set(tenantId, b);
    }
    return b;
  }

  async get(tenantId: string, id: string): Promise<ConversationEntry | undefined> {
    const entry = this.bucket(tenantId).get(id);
    return entry ? { ...entry, messages: [...entry.messages] } : undefined;
  }

  async put(tenantId: string, entry: ConversationEntry): Promise<void> {
    this.bucket(tenantId).set(entry.id, { ...entry, messages: [...entry.messages] });
  }

  clear(): void {
    this.buckets.clear();
  }
}
