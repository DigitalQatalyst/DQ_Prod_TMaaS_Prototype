/**
 * Token-overlap relevance scoring for in-memory RAG retrieval.
 *
 * Implementation: normalise tokens from query and document (lower-case,
 * split on non-word chars, drop stop words), then compute Jaccard similarity
 * over the token sets. Score is in [0, 1]. Deterministic for identical inputs.
 *
 * Documented trade-off (ADR-0011): this is a bag-of-words heuristic, not
 * vector similarity. Adequate for Phase-2 deterministic testing; a production
 * adapter would use embedding-based retrieval.
 */

const STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "do",
  "for", "from", "has", "have", "he", "her", "his", "how", "i", "if", "in",
  "into", "is", "it", "its", "just", "me", "my", "of", "on", "or", "our",
  "she", "so", "than", "that", "the", "their", "them", "then", "there",
  "they", "this", "to", "up", "us", "was", "we", "were", "what", "when",
  "where", "which", "who", "will", "with", "you", "your",
]);

function tokenise(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .split(/\W+/)
      .filter((t) => t.length > 1 && !STOP_WORDS.has(t)),
  );
}

export function jaccardScore(query: string, text: string): number {
  const qTokens = tokenise(query);
  const dTokens = tokenise(text);
  if (qTokens.size === 0 || dTokens.size === 0) return 0;
  let intersection = 0;
  for (const t of qTokens) {
    if (dTokens.has(t)) intersection++;
  }
  const union = qTokens.size + dTokens.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

/** Return the first 200 characters of content as a snippet. */
export function snippet(content: string): string {
  if (content.length <= 200) return content;
  return content.slice(0, 197) + "...";
}
