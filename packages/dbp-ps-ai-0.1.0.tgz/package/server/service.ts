import { StubGatewayAdapter, type AiGatewayAdapter } from "./gateway";
import {
  InMemoryConversationStorageAdapter,
  InMemoryRagStorageAdapter,
  type ConversationStorageAdapter,
  type RagStorageAdapter,
} from "./storage";

export type AiService = {
  gateway: AiGatewayAdapter;
  ragStorage: RagStorageAdapter;
  conversationStorage: ConversationStorageAdapter;
};

function buildService(): AiService {
  return {
    gateway: new StubGatewayAdapter(),
    ragStorage: new InMemoryRagStorageAdapter(),
    conversationStorage: new InMemoryConversationStorageAdapter(),
  };
}

let service: AiService = buildService();

export function getAiService(): AiService {
  return service;
}

export function configureAiService(overrides: Partial<AiService>): AiService {
  service = { ...service, ...overrides };
  return service;
}

export function resetAiService(): AiService {
  service = buildService();
  return service;
}
