import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  OpenAPIRegistry,
  OpenApiGeneratorV3,
  extendZodWithOpenApi,
} from "@asteasolutions/zod-to-openapi";
import YAML from "yaml";
import { z } from "zod";
import {
  AskRequestSchema,
  ErrorResponseSchema,
  RagResultSchema,
  RagSearchRequestSchema,
  RecommendRequestSchema,
  RecommendationSchema,
  RecommendResponseSchema,
  RegisterContentRequestSchema,
  RegisterContentResponseSchema,
  SseChunkSchema,
  SseDoneSchema,
} from "../client/types";
import { BASE_PATH } from "../server/handlers";

extendZodWithOpenApi(z);

const packageDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const contractPath = path.join(packageDir, "contract.yaml");
const manifest = JSON.parse(
  fs.readFileSync(path.join(packageDir, "package.json"), "utf8"),
) as { version: string };

const registry = new OpenAPIRegistry();

const AskRequest = registry.register("AskRequest", AskRequestSchema);
const RagSearchRequest = registry.register("RagSearchRequest", RagSearchRequestSchema);
const RegisterContentRequest = registry.register("RegisterContentRequest", RegisterContentRequestSchema);
const RegisterContentResponse = registry.register("RegisterContentResponse", RegisterContentResponseSchema);
const RagResult = registry.register("RagResult", RagResultSchema);
const RecommendRequest = registry.register("RecommendRequest", RecommendRequestSchema);
registry.register("Recommendation", RecommendationSchema);
const RecommendResponse = registry.register("RecommendResponse", RecommendResponseSchema);
const SseChunk = registry.register("SseChunk", SseChunkSchema);
const SseDone = registry.register("SseDone", SseDoneSchema);
const ErrorResponse = registry.register("ErrorResponse", ErrorResponseSchema);

const tenantHeader = z.object({
  "x-tenant-id": z.string().min(1).openapi({
    description: "Tenant scope for the request.",
  }),
});

const jsonBody = (schema: z.ZodTypeAny) => ({ content: { "application/json": { schema } } });
const jsonResponse = (description: string, schema: z.ZodTypeAny) => ({
  description,
  content: { "application/json": { schema } },
});
const errorOf = (description: string) => jsonResponse(description, ErrorResponse);

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/assistant/ask`,
  summary: "Ask the assistant (streaming SSE)",
  description:
    "Sends a message to the AI assistant and receives a streamed Server-Sent Events response. " +
    "Each SSE event is `data: <JSON>\\n\\n`. " +
    "Events with type=chunk carry incremental text deltas; the final type=done event carries " +
    "the full assembled message and a usage stub. " +
    "Conversation state is persisted per conversationId (in-memory, ADR-0008). " +
    "Phase-2 implementation: StubGatewayAdapter (deterministic, no model SDK, ADR-0011).",
  request: {
    headers: tenantHeader,
    body: jsonBody(AskRequest),
  },
  responses: {
    200: {
      description:
        "SSE stream (text/event-stream). See SseChunk and SseDone schemas for event shapes.",
      content: {
        "text/event-stream": {
          schema: z.string().openapi({ description: "SSE text stream" }),
        },
      },
    },
    400: errorOf("Missing tenant header or invalid request body"),
  },
});

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/rag/content`,
  summary: "Register documents into the RAG scope store",
  description:
    "Adds or replaces documents in the in-memory RAG scope store for the given tenant + scope. " +
    "Documents with the same id within a scope are overwritten (upsert). ADR-0008, ADR-0011.",
  request: {
    headers: tenantHeader,
    body: jsonBody(RegisterContentRequest),
  },
  responses: {
    200: jsonResponse("Number of documents registered", RegisterContentResponse),
    400: errorOf("Missing tenant header or invalid request body"),
  },
});

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/rag/search`,
  summary: "Search the RAG scope store",
  description:
    "Retrieves documents from the in-memory RAG scope store using token-overlap (Jaccard) relevance scoring. " +
    "Results with score=0 are excluded. Ordered by descending score, then id for ties. " +
    "Deterministic for identical inputs. " +
    "Trade-off documented: this is a bag-of-words heuristic — a production adapter " +
    "would use embedding-based retrieval (ADR-0011).",
  request: {
    headers: tenantHeader,
    body: jsonBody(RagSearchRequest),
  },
  responses: {
    200: jsonResponse(
      "RAG search results ordered by descending relevance score",
      z.object({ results: z.array(RagResult) }),
    ),
    400: errorOf("Missing tenant header or invalid request body"),
  },
});

registry.registerPath({
  method: "post",
  path: `${BASE_PATH}/recommend`,
  summary: "Get deterministic recommendations for an entity",
  description:
    "Returns a ranked list of recommendations for the given entity type, derived from " +
    "deterministic rule tables. Context keys may activate additional rules. " +
    "Same entity+context always yields the same ordered output (ADR-0011).",
  request: {
    headers: tenantHeader,
    body: jsonBody(RecommendRequest),
  },
  responses: {
    200: jsonResponse("Ranked recommendations", RecommendResponse),
    400: errorOf("Missing tenant header or invalid request body"),
  },
});

// Register SseChunk + SseDone in components so consumers can reference them.
void SseChunk;
void SseDone;

const generator = new OpenApiGeneratorV3(registry.definitions);
const document = generator.generateDocument({
  openapi: "3.0.3",
  info: {
    title: "PS.AI — AI Service",
    version: manifest.version,
    description:
      "Assistants, RAG search, and recommendations — the single AI surface for DBP solutions. " +
      "All calls go through the AiGatewayAdapter seam (PromptOps governed, DIA.03). " +
      "Phase-2 implementation: StubGatewayAdapter — deterministic, no model SDK (ADR-0011). " +
      "Generated from the Zod schemas in @dbp/ps-ai (ADR-0013). Do not edit by hand.",
  },
  servers: [{ url: "/" }],
});

const header =
  "# GENERATED FILE — do not edit.\n" +
  "# Source of truth: Zod schemas in @dbp/ps-ai (client/types.ts).\n" +
  "# Regenerate with: pnpm --filter @dbp/ps-ai contracts:gen\n";
const yamlText = header + YAML.stringify(document);

const normalize = (text: string) => text.replace(/\r\n/g, "\n");

if (process.argv.includes("--check")) {
  if (!fs.existsSync(contractPath)) {
    console.error("contracts:check FAILED — contract.yaml is missing. Run contracts:gen.");
    process.exit(1);
  }
  const committed = normalize(fs.readFileSync(contractPath, "utf8"));
  if (committed !== normalize(yamlText)) {
    console.error(
      "contracts:check FAILED — contract.yaml is stale (drift from the Zod schemas). Run contracts:gen and commit.",
    );
    process.exit(1);
  }
  console.log("contracts:check passed — contract.yaml matches the Zod schemas.");
} else {
  fs.writeFileSync(contractPath, yamlText, "utf8");
  console.log(`contract.yaml written (${yamlText.split("\n").length} lines).`);
}
