import { getAiClientConfig } from "./config";
import { request } from "./http";
import type {
  AskRequest,
  RagResult,
  RagSearchResponse,
  Recommendation,
  RecommendResponse,
  RegisterContentRequest,
  RegisterContentResponse,
  SseEvent,
} from "./types";
import { SseEventSchema } from "./types";

export type AskOptions = {
  tenantId?: string;
  onChunk?: (delta: string) => void;
};

/**
 * POST /assistant/ask — streams the assistant response via SSE.
 * Returns the full assembled assistant message text when done.
 */
export async function ask(
  input: AskRequest,
  options: AskOptions = {},
): Promise<{ conversationId: string; message: string }> {
  const { baseUrl, fetch } = getAiClientConfig();
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (options.tenantId !== undefined) headers["x-tenant-id"] = options.tenantId;

  const response = await fetch(`${baseUrl}/assistant/ask`, {
    method: "POST",
    headers,
    body: JSON.stringify(input),
  });

  if (!response.ok) {
    const payload = (await response.json()) as unknown;
    throw new Error(
      typeof payload === "object" && payload !== null && "error" in payload
        ? String((payload as { error: unknown }).error)
        : `PS.AI ask failed with status ${response.status}`,
    );
  }

  // Consume the SSE stream and accumulate the assistant message.
  const reader = response.body!.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let conversationId = "";
  let fullMessage = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    // Process complete SSE events (separated by double newline).
    const events = buffer.split("\n\n");
    buffer = events.pop() ?? "";

    for (const raw of events) {
      const dataLine = raw
        .split("\n")
        .find((l) => l.startsWith("data: "));
      if (!dataLine) continue;
      const json = dataLine.slice("data: ".length).trim();
      if (!json) continue;
      let parsed: SseEvent;
      try {
        parsed = SseEventSchema.parse(JSON.parse(json));
      } catch {
        continue;
      }
      if (parsed.type === "chunk") {
        conversationId = parsed.conversationId;
        fullMessage += parsed.delta;
        options.onChunk?.(parsed.delta);
      } else if (parsed.type === "done") {
        conversationId = parsed.conversationId;
        fullMessage = parsed.message;
      }
    }
  }

  return { conversationId, message: fullMessage };
}

export async function ragSearch(
  query: string,
  scope?: string,
  tenantId?: string,
): Promise<RagResult[]> {
  const body = scope !== undefined ? { query, scope } : { query };
  const result = await request<RagSearchResponse>("POST", "/rag/search", {
    body,
    ...(tenantId !== undefined && { tenantId }),
  });
  return result.results;
}

export async function registerContent(
  input: RegisterContentRequest,
  tenantId?: string,
): Promise<RegisterContentResponse> {
  return request<RegisterContentResponse>("POST", "/rag/content", {
    body: input,
    ...(tenantId !== undefined && { tenantId }),
  });
}

export async function recommend(
  entity: string,
  context?: Record<string, unknown>,
  tenantId?: string,
): Promise<Recommendation[]> {
  const body = context !== undefined ? { entity, context } : { entity };
  const result = await request<RecommendResponse>("POST", "/recommend", {
    body,
    ...(tenantId !== undefined && { tenantId }),
  });
  return result.recommendations;
}
