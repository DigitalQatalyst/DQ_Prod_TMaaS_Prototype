import { getAiClientConfig } from "./config";
import { ErrorResponseSchema, type ErrorResponse } from "./types";

export class AiServiceError extends Error {
  readonly status: number;
  readonly issues: ErrorResponse["issues"];

  constructor(status: number, body: ErrorResponse) {
    super(body.error);
    this.name = "AiServiceError";
    this.status = status;
    this.issues = body.issues;
  }
}

type RequestOptions = {
  body?: unknown;
  tenantId?: string;
};

export async function request<T>(
  method: string,
  path: string,
  options: RequestOptions = {},
): Promise<T> {
  const { baseUrl, fetch } = getAiClientConfig();
  const headers: Record<string, string> = {};
  if (options.tenantId !== undefined) headers["x-tenant-id"] = options.tenantId;
  if (options.body !== undefined) headers["content-type"] = "application/json";
  const response = await fetch(`${baseUrl}${path}`, {
    method,
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : null,
  });
  if (response.status === 204) return undefined as T;
  const payload = (await response.json()) as unknown;
  if (!response.ok) {
    const parsed = ErrorResponseSchema.safeParse(payload);
    throw new AiServiceError(
      response.status,
      parsed.success
        ? parsed.data
        : { error: `PS.AI request failed with status ${response.status}` },
    );
  }
  return payload as T;
}
