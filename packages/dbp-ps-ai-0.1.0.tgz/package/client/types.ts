import { z } from "zod";

// ---------------------------------------------------------------------------
// Shared primitives
// ---------------------------------------------------------------------------

export const ValidationIssueSchema = z
  .object({ path: z.string(), message: z.string() })
  .strict();
export type ValidationIssue = z.infer<typeof ValidationIssueSchema>;

export const ErrorResponseSchema = z
  .object({
    error: z.string(),
    issues: z.array(ValidationIssueSchema).optional(),
  })
  .strict();
export type ErrorResponse = z.infer<typeof ErrorResponseSchema>;

// ---------------------------------------------------------------------------
// Assistant — ask / conversation
// ---------------------------------------------------------------------------

export const ChatRoleSchema = z.enum(["user", "assistant"]);
export type ChatRole = z.infer<typeof ChatRoleSchema>;

export const ChatMessageSchema = z
  .object({
    role: ChatRoleSchema,
    content: z.string().min(1),
  })
  .strict();
export type ChatMessage = z.infer<typeof ChatMessageSchema>;

export const AskRequestSchema = z
  .object({
    message: z.string().min(1),
    context: z.record(z.string(), z.unknown()).optional(),
    conversationId: z.string().min(1).optional(),
  })
  .strict();
export type AskRequest = z.infer<typeof AskRequestSchema>;

/**
 * SSE chunk event — streamed as `data: <JSON>\n\n`.
 * type "chunk" carries incremental text; type "done" carries the full
 * assembled message and a usage stub. Contract-fixed per ADR-0011.
 */
export const SseChunkSchema = z
  .object({
    type: z.literal("chunk"),
    delta: z.string(),
    conversationId: z.string(),
  })
  .strict();
export type SseChunk = z.infer<typeof SseChunkSchema>;

export const SseDoneSchema = z
  .object({
    type: z.literal("done"),
    conversationId: z.string(),
    message: z.string(),
    usage: z.object({ inputTokens: z.number().int(), outputTokens: z.number().int() }).strict(),
  })
  .strict();
export type SseDone = z.infer<typeof SseDoneSchema>;

export const SseEventSchema = z.discriminatedUnion("type", [SseChunkSchema, SseDoneSchema]);
export type SseEvent = z.infer<typeof SseEventSchema>;

// ---------------------------------------------------------------------------
// RAG — scope store + retrieval
// ---------------------------------------------------------------------------

export const RagDocumentSchema = z
  .object({
    id: z.string().min(1),
    title: z.string().min(1),
    content: z.string().min(1),
  })
  .strict();
export type RagDocument = z.infer<typeof RagDocumentSchema>;

export const RegisterContentRequestSchema = z
  .object({
    scope: z.string().min(1),
    docs: z.array(RagDocumentSchema).min(1),
  })
  .strict();
export type RegisterContentRequest = z.infer<typeof RegisterContentRequestSchema>;

export const RegisterContentResponseSchema = z
  .object({ registered: z.number().int().nonnegative() })
  .strict();
export type RegisterContentResponse = z.infer<typeof RegisterContentResponseSchema>;

export const RagResultSchema = z
  .object({
    id: z.string().min(1),
    scope: z.string().min(1),
    title: z.string().min(1),
    snippet: z.string(),
    score: z.number().min(0).max(1),
  })
  .strict();
export type RagResult = z.infer<typeof RagResultSchema>;

export const RagSearchRequestSchema = z
  .object({
    query: z.string().min(1),
    scope: z.string().min(1).optional(),
  })
  .strict();
export type RagSearchRequest = z.infer<typeof RagSearchRequestSchema>;

export const RagSearchResponseSchema = z
  .object({ results: z.array(RagResultSchema) })
  .strict();
export type RagSearchResponse = z.infer<typeof RagSearchResponseSchema>;

// ---------------------------------------------------------------------------
// Recommend
// ---------------------------------------------------------------------------

export const RecommendRequestSchema = z
  .object({
    entity: z.string().min(1),
    context: z.record(z.string(), z.unknown()).optional(),
  })
  .strict();
export type RecommendRequest = z.infer<typeof RecommendRequestSchema>;

export const RecommendationSchema = z
  .object({
    id: z.string().min(1),
    label: z.string().min(1),
    reason: z.string().min(1),
    score: z.number().min(0).max(1),
  })
  .strict();
export type Recommendation = z.infer<typeof RecommendationSchema>;

export const RecommendResponseSchema = z
  .object({ recommendations: z.array(RecommendationSchema) })
  .strict();
export type RecommendResponse = z.infer<typeof RecommendResponseSchema>;
