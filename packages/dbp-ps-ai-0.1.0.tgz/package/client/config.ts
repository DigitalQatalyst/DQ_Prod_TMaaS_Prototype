export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

export type AiClientConfig = {
  baseUrl: string;
  fetch: FetchLike;
};

const defaults: AiClientConfig = {
  baseUrl: "/api/platform/ai",
  fetch: (input, init) => globalThis.fetch(input, init),
};

let current: AiClientConfig = { ...defaults };

export function configureAiClient(overrides: Partial<AiClientConfig>): void {
  current = { ...current, ...overrides };
}

export function getAiClientConfig(): AiClientConfig {
  return current;
}

export function resetAiClient(): void {
  current = { ...defaults };
}
