import { useCallback, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ask,
  ragSearch,
  recommend,
  registerContent,
} from "./sdk";
import type {
  AskRequest,
  ChatMessage,
  RagResult,
  Recommendation,
  RegisterContentRequest,
  RegisterContentResponse,
} from "./types";

const aiKeys = {
  rag: (query: string, scope?: string) => ["ps-ai", "rag", query, scope ?? "__all__"] as const,
  recommend: (entity: string) => ["ps-ai", "recommend", entity] as const,
};

// ---------------------------------------------------------------------------
// useAssistant — spec-contractual hook
// ---------------------------------------------------------------------------

export type UseAssistantResult = {
  /** Append a user message and stream the assistant reply. */
  ask: (message: string) => Promise<void>;
  messages: ChatMessage[];
  streaming: boolean;
};

export function useAssistant(
  context?: Record<string, unknown>,
  tenantId?: string,
): UseAssistantResult {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [streaming, setStreaming] = useState(false);
  const conversationIdRef = useRef<string | undefined>(undefined);

  const askFn = useCallback(
    async (message: string) => {
      // Append the user message immediately.
      const userMsg: ChatMessage = { role: "user", content: message };
      setMessages((prev) => [...prev, userMsg]);
      setStreaming(true);

      const assistantPlaceholderIndex = messages.length + 1;

      // Accumulate streamed chunks into a growing assistant message.
      let accumulated = "";

      const input: AskRequest = {
        message,
        context,
        ...(conversationIdRef.current !== undefined
          ? { conversationId: conversationIdRef.current }
          : {}),
      };

      try {
        const result = await ask(input, {
          ...(tenantId !== undefined && { tenantId }),
          onChunk: (delta) => {
            accumulated += delta;
            setMessages((prev) => {
              const updated = [...prev];
              if (updated[assistantPlaceholderIndex]?.role === "assistant") {
                updated[assistantPlaceholderIndex] = {
                  role: "assistant",
                  content: accumulated,
                };
              } else {
                updated.push({ role: "assistant", content: accumulated });
              }
              return updated;
            });
          },
        });
        conversationIdRef.current = result.conversationId;
        // Ensure final message is set to the authoritative done payload.
        setMessages((prev) => {
          const updated = [...prev];
          let lastAssistant = -1;
          for (let i = updated.length - 1; i >= 0; i--) {
            if (updated[i]!.role === "assistant") {
              lastAssistant = i;
              break;
            }
          }
          if (lastAssistant >= 0) {
            updated[lastAssistant] = { role: "assistant", content: result.message };
          } else {
            updated.push({ role: "assistant", content: result.message });
          }
          return updated;
        });
      } finally {
        setStreaming(false);
      }
    },
    [context, tenantId, messages.length],
  );

  return { ask: askFn, messages, streaming };
}

// ---------------------------------------------------------------------------
// useRagSearch — TanStack Query v5 hook
// ---------------------------------------------------------------------------

export type RagSearchResult = {
  results: RagResult[];
  isLoading: boolean;
  error: Error | null;
};

export function useRagSearch(
  query: string,
  scope?: string,
  tenantId?: string,
): RagSearchResult {
  const q = useQuery<RagResult[], Error>({
    queryKey: aiKeys.rag(query, scope),
    queryFn: () => ragSearch(query, scope, tenantId),
    enabled: query.length > 0,
  });
  return { results: q.data ?? [], isLoading: q.isLoading, error: q.error };
}

// ---------------------------------------------------------------------------
// useRecommend — TanStack Query v5 hook
// ---------------------------------------------------------------------------

export type RecommendResult = {
  recommendations: Recommendation[];
  isLoading: boolean;
  error: Error | null;
};

export function useRecommend(
  entity: string,
  context?: Record<string, unknown>,
  tenantId?: string,
): RecommendResult {
  const q = useQuery<Recommendation[], Error>({
    queryKey: aiKeys.recommend(entity),
    queryFn: () => recommend(entity, context, tenantId),
    enabled: entity.length > 0,
    // Never retry on 4xx — a missing tenant header or invalid body will never
    // self-heal by retrying. Only transient 5xx failures warrant a retry.
    retry: (failureCount, error) => {
      const status = (error as { status?: number }).status;
      if (typeof status === "number" && status >= 400 && status < 500) return false;
      return failureCount < 3;
    },
  });
  return { recommendations: q.data ?? [], isLoading: q.isLoading, error: q.error };
}

// ---------------------------------------------------------------------------
// useRegisterContent — mutation
// ---------------------------------------------------------------------------

export type RegisterContentResult = {
  registerContent: (input: RegisterContentRequest) => void;
  isPending: boolean;
  error: Error | null;
};

export function useRegisterContent(tenantId?: string): RegisterContentResult {
  const queryClient = useQueryClient();
  const mutation = useMutation<RegisterContentResponse, Error, RegisterContentRequest>({
    mutationFn: (input) => registerContent(input, tenantId),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["ps-ai", "rag"] });
    },
  });
  return {
    registerContent: (input) => mutation.mutate(input),
    isPending: mutation.isPending,
    error: mutation.error,
  };
}
