import { SignJWT, jwtVerify } from "jose";
import { SessionSchema, type Session, type User } from "@dbp/contracts/session";

export const SESSION_COOKIE_NAME = "dbp_session";
export const SESSION_SECRET_ENV_VAR = "DBP_AUTH_SESSION_SECRET";
export const SESSION_TTL_ENV_VAR = "DBP_AUTH_SESSION_TTL_SECONDS";
export const DEV_ONLY_SESSION_SECRET = "dbp-dev-only-session-secret-do-not-use-in-production";

const DEFAULT_TTL_SECONDS = 3600;
const encoder = new TextEncoder();

function readEnv(name: string): string | undefined {
  return typeof process === "undefined" ? undefined : process.env?.[name];
}

function resolveSecret(): Uint8Array {
  const fromEnv = readEnv(SESSION_SECRET_ENV_VAR);
  return encoder.encode(fromEnv !== undefined && fromEnv.length > 0 ? fromEnv : DEV_ONLY_SESSION_SECRET);
}

export function resolveTtlSeconds(): number {
  const raw = readEnv(SESSION_TTL_ENV_VAR);
  const parsed = raw === undefined ? Number.NaN : Number.parseInt(raw, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : DEFAULT_TTL_SECONDS;
}

export async function signSessionToken(
  user: User,
  ttlSeconds: number = resolveTtlSeconds(),
): Promise<{ token: string; session: Session }> {
  const exp = Math.floor(Date.now() / 1000) + ttlSeconds;
  const token = await new SignJWT({
    email: user.email,
    roles: user.roles,
    tenantId: user.tenantId,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime(exp)
    .sign(resolveSecret());
  return {
    token,
    session: {
      userId: user.id,
      email: user.email,
      roles: user.roles,
      tenantId: user.tenantId,
      exp,
    },
  };
}

export async function verifySessionToken(token: string): Promise<Session | null> {
  try {
    const { payload } = await jwtVerify(token, resolveSecret(), { algorithms: ["HS256"] });
    const parsed = SessionSchema.safeParse({
      userId: payload.sub,
      email: payload.email,
      roles: payload.roles,
      tenantId: payload.tenantId,
      exp: payload.exp,
    });
    return parsed.success ? parsed.data : null;
  } catch {
    return null;
  }
}

export interface HeaderSource {
  get(name: string): string | null;
}

export function extractSessionToken(headers: HeaderSource): string | null {
  const authorization = headers.get("authorization");
  if (authorization !== null) {
    const match = /^Bearer\s+(\S+)$/i.exec(authorization.trim());
    if (match?.[1] !== undefined) return match[1];
  }
  const cookieHeader = headers.get("cookie");
  if (cookieHeader !== null) {
    for (const part of cookieHeader.split(";")) {
      const separatorIndex = part.indexOf("=");
      if (separatorIndex === -1) continue;
      const name = part.slice(0, separatorIndex).trim();
      const value = part.slice(separatorIndex + 1).trim();
      if (name === SESSION_COOKIE_NAME && value.length > 0) return decodeURIComponent(value);
    }
  }
  return null;
}
