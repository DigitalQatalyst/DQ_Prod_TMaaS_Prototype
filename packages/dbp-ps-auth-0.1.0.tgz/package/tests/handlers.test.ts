// @vitest-environment node
import { describe, expect, it } from "vitest";
import {
  AUTH_BASE_PATH,
  AuthErrorResponseSchema,
  DEV_SEED_PASSWORD,
  LoginResponseSchema,
  LogoutResponseSchema,
  ROLE_FINANCE_CLERK,
  SESSION_COOKIE_NAME,
  SessionResponseSchema,
  VerifyResponseSchema,
  loginHandler,
  logoutHandler,
  routes,
  seedUsers,
  sessionHandler,
  signSessionToken,
  verifyHandler,
} from "../server";

const approver = seedUsers.find((u) => u.id === "usr-alpha-finance-approver");
const betaClerk = seedUsers.find((u) => u.id === "usr-beta-finance-clerk");
if (approver === undefined || betaClerk === undefined) throw new Error("seed users missing");

function loginRequest(body: unknown): Request {
  return new Request(`http://test.local${AUTH_BASE_PATH}/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("POST /login", () => {
  it("issues a session for valid seeded credentials and sets an httpOnly cookie", async () => {
    const response = await loginHandler(
      loginRequest({ email: approver.email, password: DEV_SEED_PASSWORD }),
    );
    expect(response.status).toBe(200);
    const body = LoginResponseSchema.parse(await response.json());
    expect(body.session.userId).toBe(approver.id);
    expect(body.session.email).toBe(approver.email);
    expect(body.session.roles).toEqual(approver.roles);
    expect(body.session.tenantId).toBe("tenant-alpha");
    expect(body.session.exp).toBeGreaterThan(Math.floor(Date.now() / 1000));
    expect(body.user).toEqual(approver);
    const cookie = response.headers.getSetCookie().join(";");
    expect(cookie).toContain(`${SESSION_COOKIE_NAME}=`);
    expect(cookie).toContain("HttpOnly");
  });

  it("rejects a wrong password with 401 INVALID_CREDENTIALS", async () => {
    const response = await loginHandler(
      loginRequest({ email: approver.email, password: "not-the-password" }),
    );
    expect(response.status).toBe(401);
    const body = AuthErrorResponseSchema.parse(await response.json());
    expect(body.error.code).toBe("INVALID_CREDENTIALS");
  });

  it("rejects an unknown email with 401", async () => {
    const response = await loginHandler(
      loginRequest({ email: "nobody@alpha.dev.local", password: DEV_SEED_PASSWORD }),
    );
    expect(response.status).toBe(401);
  });

  it("rejects a malformed body with 400", async () => {
    const response = await loginHandler(loginRequest({ email: "not-an-email" }));
    expect(response.status).toBe(400);
    const body = AuthErrorResponseSchema.parse(await response.json());
    expect(body.error.code).toBe("INVALID_REQUEST");
  });
});

describe("GET /session", () => {
  it("resolves a session from a bearer token", async () => {
    const { token } = await signSessionToken(approver);
    const response = await sessionHandler(
      new Request(`http://test.local${AUTH_BASE_PATH}/session`, {
        headers: { authorization: `Bearer ${token}` },
      }),
    );
    expect(response.status).toBe(200);
    const body = SessionResponseSchema.parse(await response.json());
    expect(body.session?.userId).toBe(approver.id);
    expect(body.user?.id).toBe(approver.id);
  });

  it("resolves a session from the httpOnly cookie", async () => {
    const { token } = await signSessionToken(approver);
    const response = await sessionHandler(
      new Request(`http://test.local${AUTH_BASE_PATH}/session`, {
        headers: { cookie: `${SESSION_COOKIE_NAME}=${token}` },
      }),
    );
    const body = SessionResponseSchema.parse(await response.json());
    expect(body.session?.userId).toBe(approver.id);
  });

  it("propagates roles and tenant for a different tenant's user", async () => {
    const { token } = await signSessionToken(betaClerk);
    const response = await sessionHandler(
      new Request(`http://test.local${AUTH_BASE_PATH}/session`, {
        headers: { authorization: `Bearer ${token}` },
      }),
    );
    const body = SessionResponseSchema.parse(await response.json());
    expect(body.session?.tenantId).toBe("tenant-beta");
    expect(body.session?.roles).toEqual([ROLE_FINANCE_CLERK]);
  });

  it("returns null session and user when no token is presented", async () => {
    const response = await sessionHandler(new Request(`http://test.local${AUTH_BASE_PATH}/session`));
    const body = SessionResponseSchema.parse(await response.json());
    expect(body).toEqual({ session: null, user: null });
  });

  it("returns null session for a garbage token", async () => {
    const response = await sessionHandler(
      new Request(`http://test.local${AUTH_BASE_PATH}/session`, {
        headers: { authorization: "Bearer not-a-jwt" },
      }),
    );
    const body = SessionResponseSchema.parse(await response.json());
    expect(body.session).toBeNull();
  });
});

describe("POST /verify", () => {
  it("verifies a valid token", async () => {
    const { token } = await signSessionToken(approver);
    const response = await verifyHandler(
      new Request(`http://test.local${AUTH_BASE_PATH}/verify`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token }),
      }),
    );
    const body = VerifyResponseSchema.parse(await response.json());
    expect(body.valid).toBe(true);
    expect(body.session?.userId).toBe(approver.id);
  });

  it("rejects an expired token", async () => {
    const { token } = await signSessionToken(approver, -60);
    const response = await verifyHandler(
      new Request(`http://test.local${AUTH_BASE_PATH}/verify`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token }),
      }),
    );
    const body = VerifyResponseSchema.parse(await response.json());
    expect(body).toEqual({ valid: false, session: null });
  });

  it("rejects a tampered token", async () => {
    const { token } = await signSessionToken(approver);
    const tampered = `${token.slice(0, -2)}xx`;
    const response = await verifyHandler(
      new Request(`http://test.local${AUTH_BASE_PATH}/verify`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token: tampered }),
      }),
    );
    const body = VerifyResponseSchema.parse(await response.json());
    expect(body.valid).toBe(false);
  });
});

describe("POST /logout", () => {
  it("clears the session cookie", async () => {
    const response = await logoutHandler();
    expect(response.status).toBe(200);
    const body = LogoutResponseSchema.parse(await response.json());
    expect(body.ok).toBe(true);
    const cookie = response.headers.getSetCookie().join(";");
    expect(cookie).toContain(`${SESSION_COOKIE_NAME}=;`);
    expect(cookie).toContain("Max-Age=0");
  });
});

describe("routes manifest", () => {
  it("exposes the four contract endpoints under the platform base path", () => {
    expect(routes.map((r) => `${r.method} ${r.path}`)).toEqual([
      `POST ${AUTH_BASE_PATH}/login`,
      `POST ${AUTH_BASE_PATH}/logout`,
      `GET ${AUTH_BASE_PATH}/session`,
      `POST ${AUTH_BASE_PATH}/verify`,
    ]);
  });
});
