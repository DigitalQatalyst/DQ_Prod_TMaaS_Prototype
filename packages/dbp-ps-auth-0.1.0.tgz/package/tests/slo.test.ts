// @vitest-environment node
import { describe, expect, it } from "vitest";
import { seedUsers, signSessionToken, verifySessionToken } from "../server";

const user = seedUsers.find((u) => u.id === "usr-alpha-finance-clerk");
if (user === undefined) throw new Error("seed user missing");

describe("SLO: session verify p95 < 50ms", () => {
  it("verifies 200 sequential tokens with p95 under 50ms", async () => {
    const { token } = await signSessionToken(user);
    await verifySessionToken(token);
    const samples: number[] = [];
    for (let i = 0; i < 200; i += 1) {
      const start = performance.now();
      const session = await verifySessionToken(token);
      samples.push(performance.now() - start);
      expect(session).not.toBeNull();
    }
    samples.sort((a, b) => a - b);
    const p95 = samples[Math.floor(samples.length * 0.95)];
    expect(p95).toBeDefined();
    expect(p95 as number).toBeLessThan(50);
  });
});
