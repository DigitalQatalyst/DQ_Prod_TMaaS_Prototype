import { createServer } from "node:http";
import type { IncomingMessage, ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";
import { routes } from "../../server";

export interface RunningAuthServer {
  baseUrl: string;
  close(): Promise<void>;
}

async function dispatch(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const pathname = (req.url ?? "/").split("?")[0] ?? "/";
  const route = routes.find((r) => r.method === req.method && r.path === pathname);
  if (route === undefined) {
    res.statusCode = 404;
    res.end();
    return;
  }
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  const body = Buffer.concat(chunks);
  const headers = new Headers();
  for (const [name, value] of Object.entries(req.headers)) {
    if (typeof value === "string") headers.set(name, value);
    else if (Array.isArray(value)) for (const item of value) headers.append(name, item);
  }
  const request = new Request(`http://127.0.0.1${req.url ?? "/"}`, {
    method: req.method ?? "GET",
    headers,
    body: body.length > 0 ? body : null,
  });
  const response = await route.handler(request);
  res.statusCode = response.status;
  response.headers.forEach((value, name) => {
    if (name.toLowerCase() !== "set-cookie") res.setHeader(name, value);
  });
  const setCookies = response.headers.getSetCookie();
  if (setCookies.length > 0) res.setHeader("set-cookie", setCookies);
  res.end(Buffer.from(await response.arrayBuffer()));
}

export async function startAuthServer(): Promise<RunningAuthServer> {
  const server = createServer((req, res) => {
    dispatch(req, res).catch(() => {
      res.statusCode = 500;
      res.end();
    });
  });
  await new Promise<void>((resolve) => {
    server.listen(0, "127.0.0.1", resolve);
  });
  const { port } = server.address() as AddressInfo;
  return {
    baseUrl: `http://127.0.0.1:${port}`,
    close: () =>
      new Promise<void>((resolve, reject) => {
        server.close((error) => (error ? reject(error) : resolve()));
      }),
  };
}
