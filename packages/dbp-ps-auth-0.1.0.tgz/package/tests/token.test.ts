// @vitest-environment node
import { afterEach, describe, expect, it } from "vitest";
import {
  SESSION_SECRET_ENV_VAR,
  SESSION_TTL_ENV_VAR,
  resolveTtlSeconds,
  seedUsers,
  signSessionToken,
  verifySessionToken,
} from "../server";

const user = seedUsers.find((u) => u.id === "usr-alpha-platform-admin");
if (user === undefined) throw new Error("seed user missing");

afterEach(() => {
  delete process.env[SESSION_SECRET_ENV_VAR];
  delete process.env[SESSION_TTL_ENV_VAR];
});

describe("session token", () => {
  it("round-trips a session through sign and verify", async () => {
    const { token, session } = await signSessionToken(user);
    const verified = await verifySessionToken(token);
    expect(verified).toEqual(session);
  });

  it("rejects an expired token", async () => {
    const { token } = await signSessionToken(user, -10);
    expect(await verifySessionToken(token)).toBeNull();
  });

  it("rejects a token signed with a different secret", async () => {
    process.env[SESSION_SECRET_ENV_VAR] = "another-dev-secret-for-this-test";
    const { token } = await signSessionToken(user);
    delete process.env[SESSION_SECRET_ENV_VAR];
    expect(await verifySessionToken(token)).toBeNull();
  });

  it("uses the env secret when provided", async () => {
    process.env[SESSION_SECRET_ENV_VAR] = "another-dev-secret-for-this-test";
    const { token } = await signSessionToken(user);
    expect(await verifySessionToken(token)).not.toBeNull();
  });

  it("honours the TTL env var", async () => {
    process.env[SESSION_TTL_ENV_VAR] = "120";
    expect(resolveTtlSeconds()).toBe(120);
    const { session } = await signSessionToken(user);
    const now = Math.floor(Date.now() / 1000);
    expect(session.exp).toBeGreaterThanOrEqual(now + 115);
    expect(session.exp).toBeLessThanOrEqual(now + 125);
  });

  it("falls back to the default TTL for junk values", () => {
    process.env[SESSION_TTL_ENV_VAR] = "not-a-number";
    expect(resolveTtlSeconds()).toBe(3600);
  });
});
