import { afterEach, describe, expect, it } from "vitest";
import { createElement, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { cleanup, renderHook, waitFor, act } from "@testing-library/react";
import { configureAuthClient, useAuth } from "../client";
import { AUTH_BASE_PATH, DEV_SEED_PASSWORD, routes, seedUsers } from "../server";

const approver = seedUsers.find((u) => u.id === "usr-alpha-finance-approver");
if (approver === undefined) throw new Error("seed user missing");

let loginRequestCount = 0;

const dispatchFetch: typeof globalThis.fetch = async (input, init) => {
  const rawUrl =
    typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
  const url = new URL(rawUrl, "http://test.local");
  const method =
    init?.method ?? (typeof input === "object" && "method" in input ? input.method : "GET");
  const route = routes.find((r) => r.path === url.pathname && r.method === method);
  if (route === undefined) return new Response(null, { status: 404 });
  if (url.pathname.endsWith("/login")) loginRequestCount += 1;
  return route.handler(new Request(url, init));
};

configureAuthClient({ baseUrl: AUTH_BASE_PATH, fetch: dispatchFetch });

function renderUseAuth() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  const wrapper = ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, children);
  return renderHook(() => useAuth(), { wrapper });
}

afterEach(cleanup);

describe("useAuth", () => {
  it("starts loading, then resolves to unauthenticated without a session", async () => {
    const { result } = renderUseAuth();
    expect(result.current.status).toBe("loading");
    await waitFor(() => expect(result.current.status).toBe("unauthenticated"));
    expect(result.current.user).toBeNull();
  });

  it("authenticates via login() and exposes the seeded user", async () => {
    const { result } = renderUseAuth();
    await waitFor(() => expect(result.current.status).toBe("unauthenticated"));
    act(() => {
      result.current.login({ email: approver.email, password: DEV_SEED_PASSWORD });
    });
    await waitFor(() => expect(result.current.status).toBe("authenticated"));
    expect(result.current.user).toEqual(approver);
  });

  it("stays unauthenticated after a failed login", async () => {
    const { result } = renderUseAuth();
    await waitFor(() => expect(result.current.status).toBe("unauthenticated"));
    const loginRequestsBefore = loginRequestCount;
    act(() => {
      result.current.login({ email: approver.email, password: "wrong-password" });
    });
    await waitFor(() => expect(loginRequestCount).toBe(loginRequestsBefore + 1));
    await waitFor(() => expect(result.current.status).toBe("unauthenticated"));
    expect(result.current.user).toBeNull();
  });

  it("clears the user on logout()", async () => {
    const { result } = renderUseAuth();
    await waitFor(() => expect(result.current.status).toBe("unauthenticated"));
    act(() => {
      result.current.login({ email: approver.email, password: DEV_SEED_PASSWORD });
    });
    await waitFor(() => expect(result.current.status).toBe("authenticated"));
    act(() => {
      result.current.logout();
    });
    await waitFor(() => expect(result.current.status).toBe("unauthenticated"));
    expect(result.current.user).toBeNull();
  });
});
