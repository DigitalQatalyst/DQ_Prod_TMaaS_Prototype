// @vitest-environment node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { beforeAll, describe, expect, it } from "vitest";
import {
  AUTH_BASE_PATH,
  DEV_SEED_PASSWORD,
  seedUsers,
  signSessionToken,
} from "../server";
import {
  AuthRequestError,
  configureAuthClient,
  fetchSession,
  login,
  logout,
  verifyToken,
} from "../client";
import { startAuthServer } from "./helpers/node-server";

// pact-core ships native binaries for darwin-arm64/x64, linux-arm64/x64 and windows-x64
// only (verified against pact-core v16 through v20) — it cannot load on win32-arm64.
const pactSupported = !(process.platform === "win32" && process.arch === "arm64");
const pactModule = pactSupported ? await import("@pact-foundation/pact") : null;

const pactDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "pacts");
const CONSUMER = "dbp-ps-auth-client";
const PROVIDER = "dbp-ps-auth";
const pactFile = path.join(pactDir, `${CONSUMER}-${PROVIDER}.json`);

const approver = seedUsers.find((u) => u.id === "usr-alpha-finance-approver");
if (approver === undefined) throw new Error("seed user missing");

if (pactModule === null) {
  describe("PS.AUTH Pact contract", () => {
    it.skip("SKIPPED on win32-arm64: @pact-foundation/pact-core has no native binary for this platform", () => {});
  });
} else {
  const { PactV4, MatchersV3, Verifier } = pactModule;
  const { integer, like } = MatchersV3;
  const pact = new PactV4({ consumer: CONSUMER, provider: PROVIDER, dir: pactDir, logLevel: "warn" });
  const { token: bearerToken } = await signSessionToken(approver);

  describe("PS.AUTH Pact contract", () => {
    beforeAll(() => {
      for (const file of fs.readdirSync(pactDir)) {
        if (file.endsWith(".json")) fs.rmSync(path.join(pactDir, file));
      }
    });

    it("consumer: login with valid seeded credentials", async () => {
      await pact
        .addInteraction()
        .given("the default users are seeded")
        .uponReceiving("a login request with valid seeded credentials")
        .withRequest("POST", `${AUTH_BASE_PATH}/login`, (builder) => {
          builder
            .headers({ "content-type": "application/json" })
            .jsonBody({ email: approver.email, password: DEV_SEED_PASSWORD });
        })
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({
            token: like("dev-session-token"),
            session: {
              userId: approver.id,
              email: approver.email,
              roles: approver.roles,
              tenantId: approver.tenantId,
              exp: integer(1772236800),
            },
            user: {
              id: approver.id,
              email: approver.email,
              displayName: approver.displayName,
              roles: approver.roles,
              tenantId: approver.tenantId,
            },
          });
        })
        .executeTest(async (mockServer) => {
          configureAuthClient({ baseUrl: `${mockServer.url}${AUTH_BASE_PATH}` });
          const result = await login({ email: approver.email, password: DEV_SEED_PASSWORD });
          expect(result.user.id).toBe(approver.id);
          expect(result.session.tenantId).toBe(approver.tenantId);
        });
    });

    it("consumer: login with a wrong password is rejected", async () => {
      await pact
        .addInteraction()
        .given("the default users are seeded")
        .uponReceiving("a login request with a wrong password")
        .withRequest("POST", `${AUTH_BASE_PATH}/login`, (builder) => {
          builder
            .headers({ "content-type": "application/json" })
            .jsonBody({ email: approver.email, password: "not-the-password" });
        })
        .willRespondWith(401, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({
            error: {
              code: "INVALID_CREDENTIALS",
              message: like("Email or password is incorrect."),
            },
          });
        })
        .executeTest(async (mockServer) => {
          configureAuthClient({ baseUrl: `${mockServer.url}${AUTH_BASE_PATH}` });
          const failure = await login({
            email: approver.email,
            password: "not-the-password",
          }).catch((error: unknown) => error);
          expect(failure).toBeInstanceOf(AuthRequestError);
          expect((failure as AuthRequestError).status).toBe(401);
          expect((failure as AuthRequestError).code).toBe("INVALID_CREDENTIALS");
        });
    });

    it("consumer: session resolution with a bearer token", async () => {
      await pact
        .addInteraction()
        .given("an authenticated session exists for a seeded user")
        .uponReceiving("a session request with a valid bearer token")
        .withRequest("GET", `${AUTH_BASE_PATH}/session`, (builder) => {
          builder.headers({ authorization: `Bearer ${bearerToken}` });
        })
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({
            session: {
              userId: approver.id,
              email: approver.email,
              roles: approver.roles,
              tenantId: approver.tenantId,
              exp: integer(1772236800),
            },
            user: {
              id: approver.id,
              email: approver.email,
              displayName: approver.displayName,
              roles: approver.roles,
              tenantId: approver.tenantId,
            },
          });
        })
        .executeTest(async (mockServer) => {
          const bearerFetch: typeof globalThis.fetch = (input, init) =>
            globalThis.fetch(input, {
              ...init,
              headers: { ...(init?.headers ?? {}), authorization: `Bearer ${bearerToken}` },
            });
          configureAuthClient({ baseUrl: `${mockServer.url}${AUTH_BASE_PATH}`, fetch: bearerFetch });
          const result = await fetchSession();
          expect(result.session?.userId).toBe(approver.id);
          expect(result.user?.id).toBe(approver.id);
        });
    });

    it("consumer: token verification", async () => {
      await pact
        .addInteraction()
        .given("the signing secret is the dev secret")
        .uponReceiving("a verify request with a valid token")
        .withRequest("POST", `${AUTH_BASE_PATH}/verify`, (builder) => {
          builder
            .headers({ "content-type": "application/json" })
            .jsonBody({ token: like(bearerToken) });
        })
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({
            valid: true,
            session: {
              userId: approver.id,
              email: approver.email,
              roles: approver.roles,
              tenantId: approver.tenantId,
              exp: integer(1772236800),
            },
          });
        })
        .executeTest(async (mockServer) => {
          configureAuthClient({ baseUrl: `${mockServer.url}${AUTH_BASE_PATH}` });
          const result = await verifyToken(bearerToken);
          expect(result.valid).toBe(true);
          expect(result.session?.userId).toBe(approver.id);
        });
    });

    it("consumer: logout", async () => {
      await pact
        .addInteraction()
        .uponReceiving("a logout request")
        .withRequest("POST", `${AUTH_BASE_PATH}/logout`, () => {})
        .willRespondWith(200, (builder) => {
          builder.headers({ "content-type": "application/json" }).jsonBody({ ok: true });
        })
        .executeTest(async (mockServer) => {
          configureAuthClient({ baseUrl: `${mockServer.url}${AUTH_BASE_PATH}` });
          const result = await logout();
          expect(result.ok).toBe(true);
        });
    });

    it("provider: handlers on node:http verify the generated pact", async () => {
      expect(fs.existsSync(pactFile)).toBe(true);
      const server = await startAuthServer();
      try {
        const output = await new Verifier({
          provider: PROVIDER,
          providerBaseUrl: server.baseUrl,
          pactUrls: [pactFile],
          logLevel: "warn",
        }).verifyProvider();
        expect(output).toContain("finished: 0");
      } finally {
        await server.close();
      }
    });
  });
}
