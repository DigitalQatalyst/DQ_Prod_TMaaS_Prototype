import { afterEach, describe, expect, it } from "vitest";
import { createElement, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { cleanup, renderHook, waitFor, act } from "@testing-library/react";
import { configureAuthClient, humaniseRole, useSessionIdentity } from "../client";
import { AUTH_BASE_PATH, DEV_SEED_PASSWORD, routes, seedUsers } from "../server";

const approver = seedUsers.find((u) => u.id === "usr-alpha-finance-approver");
if (approver === undefined) throw new Error("seed user missing");

const dispatchFetch: typeof globalThis.fetch = async (input, init) => {
  const rawUrl =
    typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
  const url = new URL(rawUrl, "http://test.local");
  const method =
    init?.method ?? (typeof input === "object" && "method" in input ? input.method : "GET");
  const route = routes.find((r) => r.path === url.pathname && r.method === method);
  if (route === undefined) return new Response(null, { status: 404 });
  return route.handler(new Request(url, init));
};

configureAuthClient({ baseUrl: AUTH_BASE_PATH, fetch: dispatchFetch });

function renderUseSessionIdentity() {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
  const wrapper = ({ children }: { children: ReactNode }) =>
    createElement(QueryClientProvider, { client: queryClient }, children);
  return renderHook(() => useSessionIdentity(), { wrapper });
}

afterEach(cleanup);

describe("humaniseRole", () => {
  it("title-cases a hyphenated role slug", () => {
    expect(humaniseRole("finance-approver")).toBe("Finance Approver");
  });
  it("handles underscores and extra whitespace", () => {
    expect(humaniseRole("platform_admin")).toBe("Platform Admin");
  });
  it("returns an empty string for an empty input", () => {
    expect(humaniseRole("")).toBe("");
  });
});

describe("useSessionIdentity", () => {
  it("is null while loading and when unauthenticated", async () => {
    const { result } = renderUseSessionIdentity();
    expect(result.current.identity).toBeNull();
    await waitFor(() => expect(result.current.status).toBe("unauthenticated"));
    expect(result.current.identity).toBeNull();
  });

  it("derives primaryRole + displayName + tenant from a logged-in session", async () => {
    // Drive useAuth + useSessionIdentity in the SAME provider tree so they share
    // the session query cache; logging in via useAuth populates the identity.
    const queryClient = new QueryClient({
      defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
    });
    const wrapper = ({ children }: { children: ReactNode }) =>
      createElement(QueryClientProvider, { client: queryClient }, children);
    const { useAuth } = await import("../client");
    const combined = renderHook(
      () => {
        const auth = useAuth();
        const ident = useSessionIdentity();
        return { auth, ident };
      },
      { wrapper },
    );

    await waitFor(() => expect(combined.result.current.auth.status).toBe("unauthenticated"));
    act(() => {
      combined.result.current.auth.login({
        email: approver.email,
        password: DEV_SEED_PASSWORD,
      });
    });
    await waitFor(() => expect(combined.result.current.auth.status).toBe("authenticated"));

    const ident = combined.result.current.ident.identity;
    expect(ident).not.toBeNull();
    expect(ident?.displayName).toBe(approver.displayName);
    expect(ident?.tenantId).toBe(approver.tenantId);
    expect(ident?.primaryRole).toBe(humaniseRole(approver.roles[0]!));
    expect(ident?.roles).toEqual(approver.roles);
  });
});
