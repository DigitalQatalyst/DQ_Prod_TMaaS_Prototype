// @vitest-environment node
import { describe, expect, it } from "vitest";
import { UnauthorizedError, getServerSession, requireAuth } from "../client";
import type { CookieSource } from "../client/types";
import { SESSION_COOKIE_NAME, seedUsers, signSessionToken } from "../server";

const requester = seedUsers.find((u) => u.id === "usr-beta-procurement-requester");
if (requester === undefined) throw new Error("seed user missing");

describe("getServerSession", () => {
  it("reads a bearer token from an injected Request", async () => {
    const { token } = await signSessionToken(requester);
    const session = await getServerSession(
      new Request("http://test.local/page", { headers: { authorization: `Bearer ${token}` } }),
    );
    expect(session?.userId).toBe(requester.id);
    expect(session?.tenantId).toBe("tenant-beta");
  });

  it("reads the session cookie from an injected cookie source", async () => {
    const { token } = await signSessionToken(requester);
    const cookies: CookieSource = {
      get: (name) => (name === SESSION_COOKIE_NAME ? { value: token } : undefined),
    };
    const session = await getServerSession({ cookies });
    expect(session?.userId).toBe(requester.id);
  });

  it("accepts a raw token source", async () => {
    const { token } = await signSessionToken(requester);
    const session = await getServerSession({ token });
    expect(session?.roles).toEqual(requester.roles);
  });

  it("returns null without a source or with an invalid token", async () => {
    expect(await getServerSession()).toBeNull();
    expect(await getServerSession({ token: "garbage" })).toBeNull();
  });
});

describe("requireAuth", () => {
  it("returns the session when authenticated", async () => {
    const { token } = await signSessionToken(requester);
    const session = await requireAuth({ token });
    expect(session.userId).toBe(requester.id);
  });

  it("throws a typed UnauthorizedError when no session is present", async () => {
    await expect(requireAuth()).rejects.toBeInstanceOf(UnauthorizedError);
    await expect(requireAuth(new Request("http://test.local/page"))).rejects.toBeInstanceOf(
      UnauthorizedError,
    );
  });
});
