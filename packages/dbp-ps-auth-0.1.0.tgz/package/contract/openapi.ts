import { z } from "zod";
import {
  OpenAPIRegistry,
  OpenApiGeneratorV3,
  extendZodWithOpenApi,
} from "@asteasolutions/zod-to-openapi";
import { SessionSchema, UserSchema } from "@dbp/contracts/session";
import packageManifest from "../package.json";
import {
  AUTH_BASE_PATH,
  AuthErrorResponseSchema,
  LoginRequestSchema,
  LoginResponseSchema,
  LogoutResponseSchema,
  SessionResponseSchema,
  VerifyRequestSchema,
  VerifyResponseSchema,
} from "./schemas";

extendZodWithOpenApi(z);

export function buildOpenApiDocument(): ReturnType<OpenApiGeneratorV3["generateDocument"]> {
  const registry = new OpenAPIRegistry();

  registry.register("Session", SessionSchema);
  registry.register("User", UserSchema);
  const loginRequest = registry.register("LoginRequest", LoginRequestSchema);
  const loginResponse = registry.register("LoginResponse", LoginResponseSchema);
  const logoutResponse = registry.register("LogoutResponse", LogoutResponseSchema);
  const sessionResponse = registry.register("SessionResponse", SessionResponseSchema);
  const verifyRequest = registry.register("VerifyRequest", VerifyRequestSchema);
  const verifyResponse = registry.register("VerifyResponse", VerifyResponseSchema);
  const authError = registry.register("AuthErrorResponse", AuthErrorResponseSchema);

  const errorContent = (description: string) => ({
    description,
    content: { "application/json": { schema: authError } },
  });

  registry.registerPath({
    method: "post",
    path: `${AUTH_BASE_PATH}/login`,
    operationId: "login",
    summary: "Authenticate with email and password; issues a session JWT (body + httpOnly cookie).",
    request: {
      body: { content: { "application/json": { schema: loginRequest } }, required: true },
    },
    responses: {
      200: {
        description: "Authenticated. Session token returned and set as an httpOnly cookie.",
        content: { "application/json": { schema: loginResponse } },
      },
      400: errorContent("Malformed or invalid request body."),
      401: errorContent("Unknown email or wrong password."),
    },
  });

  registry.registerPath({
    method: "post",
    path: `${AUTH_BASE_PATH}/logout`,
    operationId: "logout",
    summary: "Clear the session cookie.",
    responses: {
      200: {
        description: "Session cookie cleared.",
        content: { "application/json": { schema: logoutResponse } },
      },
    },
  });

  registry.registerPath({
    method: "get",
    path: `${AUTH_BASE_PATH}/session`,
    operationId: "getSession",
    summary: "Resolve the current session from a bearer token or the session cookie.",
    responses: {
      200: {
        description: "Current session and user, both null when unauthenticated.",
        content: { "application/json": { schema: sessionResponse } },
      },
    },
  });

  registry.registerPath({
    method: "post",
    path: `${AUTH_BASE_PATH}/verify`,
    operationId: "verifyToken",
    summary: "Verify a session JWT.",
    request: {
      body: { content: { "application/json": { schema: verifyRequest } }, required: true },
    },
    responses: {
      200: {
        description: "Verification result with the decoded session when valid.",
        content: { "application/json": { schema: verifyResponse } },
      },
      400: errorContent("Malformed or invalid request body."),
    },
  });

  return new OpenApiGeneratorV3(registry.definitions).generateDocument({
    openapi: "3.0.3",
    info: {
      title: "PS.AUTH — Identity & Authentication",
      version: packageManifest.version,
      description:
        "Layer 06 platform service. Authenticates users against the IdentityProvider adapter and issues/verifies HS256 session JWTs.",
    },
  });
}
