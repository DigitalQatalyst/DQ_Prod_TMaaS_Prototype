import { z } from "zod";
import { SessionSchema, UserSchema } from "@dbp/contracts/session";

export const AUTH_BASE_PATH = "/api/platform/auth";

export const LoginRequestSchema = z
  .object({
    email: z.string().email(),
    password: z.string().min(1),
  })
  .strict();
export type LoginRequest = z.infer<typeof LoginRequestSchema>;

export const LoginResponseSchema = z
  .object({
    token: z.string().min(1),
    session: SessionSchema,
    user: UserSchema,
  })
  .strict();
export type LoginResponse = z.infer<typeof LoginResponseSchema>;

export const LogoutResponseSchema = z.object({ ok: z.literal(true) }).strict();
export type LogoutResponse = z.infer<typeof LogoutResponseSchema>;

export const SessionResponseSchema = z
  .object({
    session: SessionSchema.nullable(),
    user: UserSchema.nullable(),
  })
  .strict();
export type SessionResponse = z.infer<typeof SessionResponseSchema>;

export const VerifyRequestSchema = z
  .object({
    token: z.string().min(1),
  })
  .strict();
export type VerifyRequest = z.infer<typeof VerifyRequestSchema>;

export const VerifyResponseSchema = z
  .object({
    valid: z.boolean(),
    session: SessionSchema.nullable(),
  })
  .strict();
export type VerifyResponse = z.infer<typeof VerifyResponseSchema>;

export const AuthErrorResponseSchema = z
  .object({
    error: z
      .object({
        code: z.string().min(1),
        message: z.string().min(1),
      })
      .strict(),
  })
  .strict();
export type AuthErrorResponse = z.infer<typeof AuthErrorResponseSchema>;
