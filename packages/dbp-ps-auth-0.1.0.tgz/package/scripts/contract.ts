import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { stringify } from "yaml";
import { buildOpenApiDocument } from "../contract/openapi";

const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const contractPath = path.join(packageRoot, "contract.yaml");

const header =
  "# GENERATED FILE — do not edit by hand (ADR-0013).\n" +
  "# Regenerate: pnpm --filter @dbp/ps-auth contracts:gen\n";
const rendered = header + stringify(buildOpenApiDocument());

const normalize = (text: string): string => text.replace(/\r\n/g, "\n");
const mode = process.argv[2];

if (mode === "gen") {
  fs.writeFileSync(contractPath, rendered, "utf8");
  console.log("PASS  contract.yaml regenerated from Zod definitions.");
} else if (mode === "check") {
  const existing = fs.existsSync(contractPath) ? fs.readFileSync(contractPath, "utf8") : "";
  if (normalize(existing) !== normalize(rendered)) {
    console.error(
      "FAIL  contract.yaml is stale — regenerate with: pnpm --filter @dbp/ps-auth contracts:gen",
    );
    process.exit(1);
  }
  console.log("PASS  contract.yaml matches the Zod-defined contract.");
} else {
  console.error("Usage: tsx scripts/contract.ts <gen|check>");
  process.exit(1);
}
