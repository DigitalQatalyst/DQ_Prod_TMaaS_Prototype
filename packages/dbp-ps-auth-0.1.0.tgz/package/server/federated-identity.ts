// ---------------------------------------------------------------------------
// Federated-identity provider seam — the managed-IdP / membership-model
// interface for pre-tenant login resolution (ADR-0023).
//
// This COMPLEMENTS the existing IdentityProvider (server/identity.ts) — it
// does NOT replace it. IdentityProvider handles the current session-scoped
// authenticate(email, password) flow; FederatedIdentityProvider is the swap
// point for Entra / Supabase Auth / WorkOS in production, resolving a global
// Identity + active Memberships from an IdP subject BEFORE a tenant is chosen.
//
// No concrete production implementation lives here — import the types and
// implement against this interface in the platform-services/auth adapter layer.
// ---------------------------------------------------------------------------

import type { Identity, IdentityProviderKind } from "@dbp/contracts/identity";
import type { Membership } from "@dbp/contracts/membership";

// ---------------------------------------------------------------------------
// Interface
// ---------------------------------------------------------------------------

export interface FederatedIdentityProvider {
  /**
   * Pre-tenant login resolution (ADR-0023).
   * Given an IdP protocol kind and the subject claim from the IdP token, return
   * the global Identity and the set of active Memberships for that identity, or
   * null if no matching identity exists.
   */
  resolveLogin(
    provider: IdentityProviderKind,
    subject: string,
  ): Promise<{ identity: Identity; memberships: Membership[] } | null>;

  /**
   * Fetch a global Identity by its internal id (not tenant-scoped).
   * Returns null if the identity does not exist.
   */
  getIdentity(userId: string): Promise<Identity | null>;
}

// ---------------------------------------------------------------------------
// Dev / test stub — trivial in-memory implementation that satisfies the
// interface for local development and unit tests. NOT for production use.
// ---------------------------------------------------------------------------

export class InMemoryFederatedIdentityProvider implements FederatedIdentityProvider {
  private readonly identities = new Map<string, Identity>();
  // key: `${provider}:${subject}` → userId
  private readonly subjectIndex = new Map<string, string>();
  private readonly memberships = new Map<string, Membership[]>();

  /**
   * Seed an identity and its memberships for dev/test use.
   */
  seed(
    identity: Identity,
    memberships: Membership[],
    links: Array<{ provider: IdentityProviderKind; subject: string }>,
  ): void {
    this.identities.set(identity.id, identity);
    this.memberships.set(identity.id, memberships);
    for (const link of links) {
      this.subjectIndex.set(`${link.provider}:${link.subject}`, identity.id);
    }
  }

  resolveLogin(
    provider: IdentityProviderKind,
    subject: string,
  ): Promise<{ identity: Identity; memberships: Membership[] } | null> {
    const userId = this.subjectIndex.get(`${provider}:${subject}`);
    if (userId === undefined) return Promise.resolve(null);
    const identity = this.identities.get(userId);
    if (identity === undefined) return Promise.resolve(null);
    return Promise.resolve({
      identity,
      memberships: this.memberships.get(userId) ?? [],
    });
  }

  getIdentity(userId: string): Promise<Identity | null> {
    return Promise.resolve(this.identities.get(userId) ?? null);
  }
}
