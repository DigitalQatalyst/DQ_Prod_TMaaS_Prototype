import {
  AUTH_BASE_PATH,
  AuthErrorResponseSchema,
  LoginRequestSchema,
  LoginResponseSchema,
  LogoutResponseSchema,
  SessionResponseSchema,
  VerifyRequestSchema,
  VerifyResponseSchema,
} from "../contract/schemas";
import {
  SESSION_COOKIE_NAME,
  extractSessionToken,
  resolveTtlSeconds,
  signSessionToken,
  verifySessionToken,
} from "../core/token";
import { InMemoryIdentityProvider, type IdentityProvider } from "./identity";

let identityProvider: IdentityProvider = new InMemoryIdentityProvider();

export function configureIdentityProvider(provider: IdentityProvider): void {
  identityProvider = provider;
}

function json(body: unknown, init?: ResponseInit): Response {
  return new Response(JSON.stringify(body), {
    ...init,
    headers: { "content-type": "application/json", ...(init?.headers ?? {}) },
  });
}

function errorResponse(status: number, code: string, message: string): Response {
  return json(AuthErrorResponseSchema.parse({ error: { code, message } }), { status });
}

function sessionCookie(token: string, maxAgeSeconds: number): string {
  return `${SESSION_COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSeconds}`;
}

async function readJsonBody(req: Request): Promise<unknown | undefined> {
  try {
    return (await req.json()) as unknown;
  } catch {
    return undefined;
  }
}

export async function loginHandler(req: Request): Promise<Response> {
  const raw = await readJsonBody(req);
  if (raw === undefined) return errorResponse(400, "INVALID_JSON", "Request body must be valid JSON.");
  const parsed = LoginRequestSchema.safeParse(raw);
  if (!parsed.success) {
    return errorResponse(400, "INVALID_REQUEST", "Body must be { email, password }.");
  }
  const user = await identityProvider.authenticate(parsed.data.email, parsed.data.password);
  if (user === null) {
    return errorResponse(401, "INVALID_CREDENTIALS", "Email or password is incorrect.");
  }
  const { token, session } = await signSessionToken(user);
  const response = json(LoginResponseSchema.parse({ token, session, user }));
  response.headers.append("set-cookie", sessionCookie(token, resolveTtlSeconds()));
  return response;
}

export async function logoutHandler(): Promise<Response> {
  const response = json(LogoutResponseSchema.parse({ ok: true }));
  response.headers.append("set-cookie", sessionCookie("", 0));
  return response;
}

export async function sessionHandler(req: Request): Promise<Response> {
  const token = extractSessionToken(req.headers);
  const session = token === null ? null : await verifySessionToken(token);
  const user = session === null ? null : await identityProvider.getUserById(session.userId);
  if (session === null || user === null) {
    return json(SessionResponseSchema.parse({ session: null, user: null }));
  }
  return json(SessionResponseSchema.parse({ session, user }));
}

export async function verifyHandler(req: Request): Promise<Response> {
  const raw = await readJsonBody(req);
  if (raw === undefined) return errorResponse(400, "INVALID_JSON", "Request body must be valid JSON.");
  const parsed = VerifyRequestSchema.safeParse(raw);
  if (!parsed.success) {
    return errorResponse(400, "INVALID_REQUEST", "Body must be { token }.");
  }
  const session = await verifySessionToken(parsed.data.token);
  return json(VerifyResponseSchema.parse({ valid: session !== null, session }));
}

export type RouteHandler = (req: Request) => Promise<Response>;

export interface AuthRoute {
  method: "GET" | "POST";
  path: string;
  handler: RouteHandler;
}

export const routes: ReadonlyArray<AuthRoute> = [
  { method: "POST", path: `${AUTH_BASE_PATH}/login`, handler: loginHandler },
  { method: "POST", path: `${AUTH_BASE_PATH}/logout`, handler: logoutHandler },
  { method: "GET", path: `${AUTH_BASE_PATH}/session`, handler: sessionHandler },
  { method: "POST", path: `${AUTH_BASE_PATH}/verify`, handler: verifyHandler },
];
