import { UserSchema, type User } from "@dbp/contracts/session";

export interface IdentityProvider {
  authenticate(email: string, password: string): Promise<User | null>;
  getUserById(userId: string): Promise<User | null>;
}

export const ROLE_FINANCE_APPROVER = "finance-approver";
export const ROLE_FINANCE_CLERK = "finance-clerk";
export const ROLE_PROCUREMENT_REQUESTER = "procurement-requester";
export const ROLE_PLATFORM_ADMIN = "platform-admin";

export const SEED_TENANTS = ["tenant-alpha", "tenant-beta"] as const;
export type SeedTenant = (typeof SEED_TENANTS)[number];

export const DEV_SEED_PASSWORD = "dbp-dev-password";

export interface SeedCredential {
  user: User;
  password: string;
}

const ROLE_SEED_DEFS = [
  { role: ROLE_FINANCE_APPROVER, slug: "finance-approver", title: "Finance Approver" },
  { role: ROLE_FINANCE_CLERK, slug: "finance-clerk", title: "Finance Clerk" },
  { role: ROLE_PROCUREMENT_REQUESTER, slug: "procurement-requester", title: "Procurement Requester" },
  { role: ROLE_PLATFORM_ADMIN, slug: "platform-admin", title: "Platform Admin" },
] as const;

function tenantShortName(tenantId: SeedTenant): string {
  return tenantId.replace(/^tenant-/, "");
}

function buildSeedCredentials(): SeedCredential[] {
  const credentials: SeedCredential[] = [];
  for (const tenantId of SEED_TENANTS) {
    const short = tenantShortName(tenantId);
    const label = short.charAt(0).toUpperCase() + short.slice(1);
    for (const def of ROLE_SEED_DEFS) {
      credentials.push({
        user: UserSchema.parse({
          id: `usr-${short}-${def.slug}`,
          email: `${def.slug}@${short}.dev.local`,
          displayName: `${label} ${def.title}`,
          roles: [def.role],
          tenantId,
        }),
        password: DEV_SEED_PASSWORD,
      });
    }
  }
  return credentials;
}

export const seedCredentials: ReadonlyArray<SeedCredential> = buildSeedCredentials();
export const seedUsers: ReadonlyArray<User> = seedCredentials.map((credential) => credential.user);

export class InMemoryIdentityProvider implements IdentityProvider {
  private readonly byEmail = new Map<string, SeedCredential>();
  private readonly byId = new Map<string, User>();

  constructor(credentials: ReadonlyArray<SeedCredential> = seedCredentials) {
    for (const credential of credentials) {
      const user = UserSchema.parse(credential.user);
      this.byEmail.set(user.email.toLowerCase(), { user, password: credential.password });
      this.byId.set(user.id, user);
    }
  }

  authenticate(email: string, password: string): Promise<User | null> {
    const entry = this.byEmail.get(email.toLowerCase());
    if (entry === undefined || entry.password !== password) return Promise.resolve(null);
    return Promise.resolve(entry.user);
  }

  getUserById(userId: string): Promise<User | null> {
    return Promise.resolve(this.byId.get(userId) ?? null);
  }
}
