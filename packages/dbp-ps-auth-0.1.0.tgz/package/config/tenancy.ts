// ---------------------------------------------------------------------------
// Config-level tenancy resolution for PS.AUTH (ADR-0017 pluggable isolation).
//
// TenantConnectionResolver is the seam that answers "given this Tenant, which
// database connection parameters should the platform use?". The concrete
// implementations (Drizzle connection pool, pgBouncer routing, silo DSN lookup)
// live in the infrastructure layer — this file is config-only with NO DB code.
//
// IsolationMode values (from @dbp/contracts/tenant):
//   pooled    — shared schema + Postgres RLS on tenant_id (default)
//   schema    — one Postgres schema per tenant
//   silo      — one database per tenant (separate connection string)
//   dedicated — fully separate single-tenant stack
// ---------------------------------------------------------------------------

import type { IsolationMode, Tenant } from "@dbp/contracts/tenant";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Convenience alias — the strategy kind IS the isolation mode (ADR-0017). */
export type TenancyStrategyKind = IsolationMode;

export interface TenantConnectionResolver {
  /**
   * Given a Tenant, return the isolation mode that governs its data access and,
   * for silo/dedicated tenants, the DSN secret reference (never the DSN value).
   */
  resolve(tenant: Tenant): { mode: IsolationMode; dsnRef?: string };
}

// ---------------------------------------------------------------------------
// StaticTenantConnectionResolver — reads directly from Tenant.isolation.
// No external lookup; suitable for dev and for simple pooled deployments where
// the DSN is set centrally via DATABASE_URL rather than per-tenant.
// ---------------------------------------------------------------------------

export class StaticTenantConnectionResolver implements TenantConnectionResolver {
  resolve(tenant: Tenant): { mode: IsolationMode; dsnRef?: string } {
    return {
      mode: tenant.isolation.mode,
      dsnRef: tenant.isolation.dsnRef,
    };
  }
}
