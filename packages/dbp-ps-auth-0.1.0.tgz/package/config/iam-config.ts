// ---------------------------------------------------------------------------
// IAM wiring config for PS.AUTH — describes how the auth service is wired in
// production (ADR-0019 RS256/JWKS, ADR-0023 refresh, ADR-0017 tenancy
// isolation). Framework-agnostic; no Next.js imports. Zod is source of truth.
//
// IMPORTANT: this file holds REFERENCES to secrets (env var names / k8s secret
// refs), never the secret values themselves.
// ---------------------------------------------------------------------------

import { z } from "zod";
import { IdentityProviderKindSchema } from "@dbp/contracts/identity";
import { IsolationModeSchema } from "@dbp/contracts/tenant";

// ---------------------------------------------------------------------------
// Schema
// ---------------------------------------------------------------------------

export const IamConfigSchema = z
  .object({
    idp: z
      .object({
        // Which IdP protocol this deployment authenticates through.
        provider: IdentityProviderKindSchema, // 'entra' | 'oidc' | 'password' | 'saml'
        // OIDC/Entra issuer URL — required for RS256/JWKS validation (ADR-0019).
        issuer: z.string().url().optional(),
        // JWKS endpoint for RS256 public-key verification (ADR-0019).
        jwksUrl: z.string().url().optional(),
      })
      .strict(),

    session: z
      .object({
        // RS256 is mandatory in production (ADR-0019); HS256 is dev-only.
        algorithm: z.enum(["HS256", "RS256"]).default("HS256"),
        // Reference to the signing key secret (k8s secret name, env var name, etc.).
        // Never the key material itself.
        signingKeyRef: z.string().min(1).optional(),
        // Access-token lifetime (ADR-0023). Default: 1 hour.
        accessTtlSeconds: z.number().int().positive().default(3_600),
        // Refresh-token lifetime (ADR-0023). Default: 14 days.
        refreshTtlSeconds: z.number().int().positive().default(1_209_600),
      })
      .strict(),

    database: z
      .object({
        // Pooled connection string reference (PgBouncer / Supavisor — dbp_app role).
        // Maps to DATABASE_URL.
        urlRef: z.string().min(1),
        // Direct connection string reference (migration / DDL — dbp_owner role).
        // Maps to DIRECT_URL. Separate from urlRef to preserve the pooled/direct split.
        directUrlRef: z.string().min(1),
      })
      .strict(),

    tenancy: z
      .object({
        // Isolation mode applied to new tenants unless overridden per-tenant (ADR-0017).
        defaultMode: IsolationModeSchema.default("pooled"),
      })
      .strict(),
  })
  .strict();

export type IamConfig = z.infer<typeof IamConfigSchema>;

// ---------------------------------------------------------------------------
// Loader — maps well-known env vars to IamConfigSchema with safe dev defaults.
// Pass a custom env map for testing; defaults to process.env.
// ---------------------------------------------------------------------------

export function loadIamConfig(
  env: Record<string, string | undefined> = process.env,
): IamConfig {
  const raw = {
    idp: {
      provider: env["DBP_IDP_PROVIDER"] ?? "password",
      issuer: env["DBP_IDP_ISSUER"] ?? undefined,
      jwksUrl: env["DBP_IDP_JWKS_URL"] ?? undefined,
    },
    session: {
      algorithm: env["DBP_AUTH_ALGORITHM"] ?? "HS256",
      signingKeyRef: env["DBP_AUTH_SIGNING_KEY_REF"] ?? undefined,
      accessTtlSeconds:
        env["DBP_AUTH_ACCESS_TTL_SECONDS"] !== undefined
          ? Number.parseInt(env["DBP_AUTH_ACCESS_TTL_SECONDS"], 10)
          : 3_600,
      refreshTtlSeconds:
        env["DBP_AUTH_REFRESH_TTL_SECONDS"] !== undefined
          ? Number.parseInt(env["DBP_AUTH_REFRESH_TTL_SECONDS"], 10)
          : 1_209_600,
    },
    database: {
      urlRef: env["DATABASE_URL"] ?? "DATABASE_URL",
      directUrlRef: env["DIRECT_URL"] ?? "DIRECT_URL",
    },
    tenancy: {
      defaultMode: env["DBP_TENANCY_DEFAULT_MODE"] ?? "pooled",
    },
  };

  return IamConfigSchema.parse(raw);
}
