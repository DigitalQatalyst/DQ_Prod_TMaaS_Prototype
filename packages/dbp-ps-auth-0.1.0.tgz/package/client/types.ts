import type { Session, User } from "@dbp/contracts/session";
import type { LoginRequest } from "../contract/schemas";
import type { HeaderSource } from "../core/token";

export type {
  AuthErrorResponse,
  LoginRequest,
  LoginResponse,
  LogoutResponse,
  SessionResponse,
  VerifyRequest,
  VerifyResponse,
} from "../contract/schemas";
export type { Session, User };

export type AuthStatus = "loading" | "authenticated" | "unauthenticated";

export interface AuthClientConfig {
  baseUrl?: string;
  fetch?: typeof globalThis.fetch;
}

export interface UseAuthResult {
  user: User | null;
  login: (credentials: LoginRequest) => void;
  logout: () => void;
  status: AuthStatus;
}

/**
 * The current authenticated identity, projected into the shape the app chrome
 * (top-bar avatar / role / tenant) consumes. Derived entirely from the PS.AUTH
 * session — never hardcoded. `null` while loading or when unauthenticated.
 *
 * This is the single client-side seam the enriched top bar reads from: display
 * name + initials fallback live in `displayName`, the avatar role line in
 * `primaryRole`, the (optional) role switcher in `roles`, and the active tenant
 * (already config via IAM) in `tenantId`.
 */
export interface SessionIdentity {
  /** Active-tenant user id (legacy Session.userId / PlatformSession.sub). */
  userId: string;
  email: string;
  /** Human display name for the avatar lockup. */
  displayName: string;
  /** Humanised primary role for the avatar sub-label (first role, title-cased). */
  primaryRole: string;
  /** All roles in the active tenant — feeds an optional role switcher. */
  roles: ReadonlyArray<string>;
  /** Active tenant id (already config-driven via IAM; never a competing field). */
  tenantId: string;
}

export interface UseSessionIdentityResult {
  /** The projected identity, or null while loading / unauthenticated. */
  identity: SessionIdentity | null;
  status: AuthStatus;
}

export interface CookieSource {
  get(name: string): { value: string } | undefined;
}

export type SessionSource =
  | Request
  | { headers: HeaderSource }
  | { cookies: CookieSource }
  | { token: string };
