import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { Session } from "@dbp/contracts/session";
import {
  AUTH_BASE_PATH,
  AuthErrorResponseSchema,
  LoginRequestSchema,
  LoginResponseSchema,
  LogoutResponseSchema,
  SessionResponseSchema,
  VerifyRequestSchema,
  VerifyResponseSchema,
} from "../contract/schemas";
import { SESSION_COOKIE_NAME, extractSessionToken, verifySessionToken } from "../core/token";
import type {
  AuthClientConfig,
  AuthStatus,
  LoginRequest,
  LoginResponse,
  LogoutResponse,
  SessionIdentity,
  SessionResponse,
  SessionSource,
  UseAuthResult,
  UseSessionIdentityResult,
  VerifyResponse,
} from "./types";

export {
  AUTH_BASE_PATH,
  AuthErrorResponseSchema,
  LoginRequestSchema,
  LoginResponseSchema,
  LogoutResponseSchema,
  SessionResponseSchema,
  VerifyRequestSchema,
  VerifyResponseSchema,
};
export type * from "./types";

export class AuthRequestError extends Error {
  readonly status: number;
  readonly code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = "AuthRequestError";
    this.status = status;
    this.code = code;
  }
}

export class UnauthorizedError extends Error {
  constructor(message = "No authenticated session.") {
    super(message);
    this.name = "UnauthorizedError";
  }
}

let clientConfig: AuthClientConfig = {};

export function configureAuthClient(config: AuthClientConfig): void {
  clientConfig = { ...clientConfig, ...config };
}

function resolveBaseUrl(): string {
  return clientConfig.baseUrl ?? AUTH_BASE_PATH;
}

function resolveFetch(): typeof globalThis.fetch {
  return clientConfig.fetch ?? globalThis.fetch.bind(globalThis);
}

async function toRequestError(response: Response): Promise<AuthRequestError> {
  let code = "REQUEST_FAILED";
  let message = `Auth request failed with status ${response.status}.`;
  try {
    const parsed = AuthErrorResponseSchema.safeParse(await response.json());
    if (parsed.success) {
      code = parsed.data.error.code;
      message = parsed.data.error.message;
    }
  } catch {
    // non-JSON error body — keep the generic message
  }
  return new AuthRequestError(response.status, code, message);
}

async function requestJson(path: string, init?: RequestInit): Promise<unknown> {
  const response = await resolveFetch()(`${resolveBaseUrl()}${path}`, {
    credentials: "include",
    ...init,
  });
  if (!response.ok) throw await toRequestError(response);
  return (await response.json()) as unknown;
}

function jsonInit(body: unknown): RequestInit {
  return {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  };
}

export async function login(credentials: LoginRequest): Promise<LoginResponse> {
  return LoginResponseSchema.parse(await requestJson("/login", jsonInit(LoginRequestSchema.parse(credentials))));
}

export async function logout(): Promise<LogoutResponse> {
  return LogoutResponseSchema.parse(await requestJson("/logout", { method: "POST" }));
}

export async function fetchSession(): Promise<SessionResponse> {
  return SessionResponseSchema.parse(await requestJson("/session", { method: "GET" }));
}

export async function verifyToken(token: string): Promise<VerifyResponse> {
  return VerifyResponseSchema.parse(await requestJson("/verify", jsonInit(VerifyRequestSchema.parse({ token }))));
}

const SESSION_QUERY_KEY = ["dbp", "ps-auth", "session"] as const;

export function useAuth(): UseAuthResult {
  const queryClient = useQueryClient();
  const sessionQuery = useQuery({
    queryKey: SESSION_QUERY_KEY,
    queryFn: fetchSession,
  });
  const loginMutation = useMutation({
    mutationFn: login,
    onSuccess: (data) => {
      queryClient.setQueryData<SessionResponse>(SESSION_QUERY_KEY, {
        session: data.session,
        user: data.user,
      });
    },
  });
  const logoutMutation = useMutation({
    mutationFn: logout,
    onSuccess: () => {
      queryClient.setQueryData<SessionResponse>(SESSION_QUERY_KEY, { session: null, user: null });
    },
  });

  const user = sessionQuery.data?.user ?? null;
  const pending = sessionQuery.isPending || loginMutation.isPending || logoutMutation.isPending;
  const status: AuthStatus = pending ? "loading" : user !== null ? "authenticated" : "unauthenticated";

  return {
    user,
    login: (credentials: LoginRequest) => {
      loginMutation.mutate(credentials);
    },
    logout: () => {
      logoutMutation.mutate();
    },
    status,
  };
}

/**
 * Humanise a role slug for display — "finance-approver" → "Finance Approver".
 * Pure, deterministic, locale-neutral; used for the avatar sub-label and the
 * role switcher option labels so no role text is ever hardcoded in the chrome.
 */
export function humaniseRole(role: string): string {
  return role
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

/**
 * useSessionIdentity — the client-side seam the enriched app chrome reads from.
 *
 * Projects the PS.AUTH session `user` into the {@link SessionIdentity} shape the
 * top bar consumes (display name, humanised primary role, all roles for the
 * optional switcher, and the active tenant). Returns `identity: null` while the
 * session query is loading or when unauthenticated — the chrome then renders no
 * avatar block rather than a hardcoded placeholder.
 *
 * Built on the existing `useAuth()` query (one shared `SESSION_QUERY_KEY`), so
 * mounting it alongside `useAuth()` in the same tree triggers no extra fetch.
 */
export function useSessionIdentity(): UseSessionIdentityResult {
  const { user, status } = useAuth();
  if (user === null) return { identity: null, status };
  const roles = user.roles ?? [];
  const identity: SessionIdentity = {
    userId: user.id,
    email: user.email,
    displayName: user.displayName,
    primaryRole: roles.length > 0 ? humaniseRole(roles[0]!) : "",
    roles,
    tenantId: user.tenantId,
  };
  return { identity, status };
}

function resolveToken(source?: SessionSource): string | null {
  if (source === undefined) return null;
  if ("token" in source) return source.token;
  if ("cookies" in source) return source.cookies.get(SESSION_COOKIE_NAME)?.value ?? null;
  if ("headers" in source) return extractSessionToken(source.headers);
  return null;
}

export async function getServerSession(source?: SessionSource): Promise<Session | null> {
  const token = resolveToken(source);
  if (token === null) return null;
  return verifySessionToken(token);
}

export async function requireAuth(source?: SessionSource): Promise<Session> {
  const session = await getServerSession(source);
  if (session === null) throw new UnauthorizedError();
  return session;
}
