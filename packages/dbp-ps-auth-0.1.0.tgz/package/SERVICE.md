# PS.AUTH — Identity & Authentication

| | |
|---|---|
| Registry ID | `PS.AUTH` |
| Atomic class | Integration |
| Package | `@dbp/ps-auth` (semver, independently versioned — currently `0.1.0`) |
| Contract | `contract.yaml` (OpenAPI 3.0.3, GENERATED from Zod per ADR-0013 — never edit by hand) |
| Base path | `/api/platform/auth` |

## Purpose

Authenticate users, issue and verify sessions, federate identity. Built once at Layer 06;
solutions wire to the client SDK and never re-implement auth.

## Surface

- **Server** (`@dbp/ps-auth/server`): framework-free fetch-API handlers
  (`(req: Request) => Promise<Response>`, Next 15 route-handler compatible) plus a `routes`
  manifest — `POST /login`, `POST /logout`, `GET /session`, `POST /verify`. All bodies
  Zod-validated.
- **Client** (`@dbp/ps-auth/client`): `useAuth()` → `{ user, login(), logout(), status }`
  (TanStack Query v5), async functions (`login`, `logout`, `fetchSession`, `verifyToken`),
  `configureAuthClient({ baseUrl?, fetch? })`, `getServerSession(source?)` and
  `requireAuth(source?)` (throws typed `UnauthorizedError`). `getServerSession` takes an
  injectable request/cookie source (a `Request`, `{ headers }`, `{ cookies }` matching
  `next/headers`, or `{ token }`) so it works from Next server components without a
  framework dependency.

## Sessions

HS256 JWT via `jose` (ADR-0005). Secret from `DBP_AUTH_SESSION_SECRET` with an obvious
dev-only default; TTL from `DBP_AUTH_SESSION_TTL_SECONDS` (default 3600). Tokens are
accepted both as an httpOnly cookie (`dbp_session`) and as an `Authorization` bearer
header. Session claims: `{ userId, email, roles[], tenantId, exp }` (`SessionSchema` in
`@dbp/contracts/session` — shared with PS.RBAC and PS.AUDIT).

## Identity adapter

`IdentityProvider` (`authenticate(email, password)`, `getUserById(id)`) is the federation
seam. Phase 2 ships exactly one implementation: `InMemoryIdentityProvider` with the
deterministic seeds below (ADR-0008). Production replaces it with a real OIDC provider
behind the same interface — no fake OIDC dance is implemented now (ADR-0005); swapping the
adapter must not change the OpenAPI contract or SDK signatures.

## Seed users (dev/test fixtures — consumed by PS.RBAC and DWS.04 later)

Password for every seed user: `dbp-dev-password`. Tenants: `tenant-alpha`, `tenant-beta`.

| User ID | Email | Roles | Tenant |
|---|---|---|---|
| `usr-alpha-finance-approver` | `finance-approver@alpha.dev.local` | `finance-approver` | `tenant-alpha` |
| `usr-alpha-finance-clerk` | `finance-clerk@alpha.dev.local` | `finance-clerk` | `tenant-alpha` |
| `usr-alpha-procurement-requester` | `procurement-requester@alpha.dev.local` | `procurement-requester` | `tenant-alpha` |
| `usr-alpha-platform-admin` | `platform-admin@alpha.dev.local` | `platform-admin` | `tenant-alpha` |
| `usr-beta-finance-approver` | `finance-approver@beta.dev.local` | `finance-approver` | `tenant-beta` |
| `usr-beta-finance-clerk` | `finance-clerk@beta.dev.local` | `finance-clerk` | `tenant-beta` |
| `usr-beta-procurement-requester` | `procurement-requester@beta.dev.local` | `procurement-requester` | `tenant-beta` |
| `usr-beta-platform-admin` | `platform-admin@beta.dev.local` | `platform-admin` | `tenant-beta` |

Role constants and the full credential list are exported from `@dbp/ps-auth/server`
(`seedUsers`, `seedCredentials`, `ROLE_*`, `SEED_TENANTS`, `DEV_SEED_PASSWORD`).

## SLO

**Session verify p95 < 50ms.** Measured now by `tests/slo.test.ts`: 200 sequential
in-process `verifySessionToken` calls after warm-up, p95 computed from `performance.now()`
samples and asserted `< 50ms` on every test run. Once a deployment target exists, the same
budget moves to handler-level timing on `GET /session` measured at the gateway (APM
instrumentation is a Phase 8+ concern).

## Contract workflow

`pnpm --filter @dbp/ps-auth contracts:gen` regenerates `contract.yaml` from the Zod
endpoint definitions (`contract/openapi.ts`); `contracts:check` regenerates and diffs,
failing on drift. The generated file is committed.

## Pact

Consumer test drives this package's own SDK against a Pact mock to generate
`tests/pacts/*.json` (gitignored artefacts); provider verification replays the pact against
the real handlers on a `node:http` server (ADR-0007). Note: `@pact-foundation/pact-core`
ships no native binary for `win32-arm64` (verified v16–v20), so the Pact suite self-skips
with a notice on that platform only; it runs everywhere else (CI runners are x64).
