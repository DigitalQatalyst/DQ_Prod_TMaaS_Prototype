import eslintJs from "@eslint/js";
import globals from "globals";
import tseslint from "typescript-eslint";

const SRC = "*.{js,jsx,mjs,cjs,ts,tsx,mts,cts}";

/*
 * Import-boundary matrix from docs/TECH-DECISIONS.md §Import Boundary Rules.
 * Patterns match literal import specifiers (minimatch), so each FORBIDDEN line
 * is covered both as a workspace-package specifier and as a relative path.
 *
 * Workspace naming convention these patterns encode (binding for later phases):
 *   @dbp/ps-<service>      packages/stack/platform-services/<service>  (exports ./client, ./server)
 *   @dbp/feature-<name>    packages/stack/app-scaffolds/features/<name> (single index export)
 *   @dbp/shell-<name>      packages/stack/app-scaffolds/shells/<name>
 *   @dbp/ui | @dbp/contracts | @dbp/design-tokens   packages/shared/*
 */
const PS_SERVER_PATTERNS = [
  "@dbp/ps-*/server",
  "@dbp/ps-*/server/**",
  "**/platform-services/*/server",
  "**/platform-services/*/server/**",
  "**/platform-services/*/src/server",
  "**/platform-services/*/src/server/**",
];

const FEATURE_INTERNAL_PATTERNS = [
  "@dbp/feature-*/*",
  "@dbp/feature-*/*/**",
  "**/app-scaffolds/features/*/src/**",
];

const psServerViolation = (zone) => ({
  group: PS_SERVER_PATTERNS,
  message: `BOUNDARY: ${zone} must never import a platform service's server internals — wire via the client SDK (@dbp/ps-*/client).`,
});

const featureInternalViolation = {
  group: FEATURE_INTERNAL_PATTERNS,
  message:
    "BOUNDARY: a feature exposes exactly one typed contract — import the feature package root, never its internals.",
};

// API-mount seam exception — Phase 5 scaffold generator (P5).
//
// The generated Next.js app route handlers at apps/<sol>/app/api/platform/<svc>/
// are the ONLY sanctioned place in the apps/ layer that may import
// @dbp/ps-SVCNAME/server. This is the host-mount seam: each generated catch-all
// route dispatches incoming HTTP requests directly into the service's handler,
// acting as the network boundary. Every other file inside apps/ (pages,
// components, hooks, providers, middleware) is still forbidden.
//
// The narrow pattern `apps/*/app/api/platform/**` matches only the generated
// route handlers, leaving the general apps/** restriction fully intact.
//
// Evidence that the restriction still holds for all other app code:
//   FORBIDDEN: apps/__boundary-fixtures__/app-imports-ps-server.ts (must FAIL)
//   ALLOWED:   apps/__boundary-fixtures__/app/api/platform/auth/route.fixture.ts (must PASS)
export const API_MOUNT_SEAM_EXCEPTION = {
  name: "dbp/boundaries/apps-api-mount-seam",
  // Matches ONLY the generated API mount directory — not pages, hooks, components, etc.
  files: [`apps/*/app/api/platform/**/${SRC}`],
  rules: {
    // Override: ps-SVCNAME/server imports are explicitly allowed here, nowhere else in apps/.
    "no-restricted-imports": "off",
  },
};

// Instrumentation seam exception — Phase 6 DWS.04 (P6).
//
// Next.js instrumentation.ts runs at server start in the Node runtime. It is the
// designated bootstrap hook for registering entity schemas, seeding data, and
// configuring auth — concerns that must be centralised in the host process.
// It may import @dbp/ps-*/server directly.
//
// This is NARROW: only apps/*/instrumentation.ts|.node.ts match.
// All other app files (pages, components, hooks, middleware) remain forbidden.
//
// Boundary proof: scripts/check-boundaries.mjs ALLOWED fixture:
//   apps/__boundary-fixtures__/instrumentation.ts  (filename must match the seam pattern)
// FORBIDDEN fixture (proves restriction holds for non-seam app files):
//   apps/__boundary-fixtures__/page-imports-ps-server.fixture.ts
export const INSTRUMENTATION_SEAM_EXCEPTION = {
  name: "dbp/boundaries/apps-instrumentation-seam",
  files: [`apps/*/instrumentation.ts`, `apps/*/instrumentation.node.ts`],
  rules: {
    "no-restricted-imports": "off",
  },
};

export const boundaryConfigs = [
  // shared/ui may import ps-*/client but NEVER ps-*/server.
  {
    name: "dbp/boundaries/shared-ui",
    files: [`packages/shared/ui/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            psServerViolation("shared/ui"),
            {
              group: ["**/apps/**", "**/app-scaffolds/**"],
              message:
                "BOUNDARY: shared/ui bindings must not import from solutions or scaffolds.",
            },
          ],
        },
      ],
    },
  },
  {
    name: "dbp/boundaries/apps",
    files: [`apps/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        { patterns: [psServerViolation("apps/*"), featureInternalViolation] },
      ],
    },
  },
  {
    name: "dbp/boundaries/app-scaffolds",
    files: [`packages/stack/app-scaffolds/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            psServerViolation("app-scaffolds/*"),
            featureInternalViolation,
            {
              group: ["**/apps/**"],
              message: "BOUNDARY: Layer 07 scaffolds never import from solutions.",
            },
          ],
        },
      ],
    },
  },
  {
    name: "dbp/boundaries/platform-services",
    files: [`packages/stack/platform-services/**/${SRC}`],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["@dbp/*", "!@dbp/contracts", "!@dbp/contracts/**"],
              message:
                "BOUNDARY: platform services may import only @dbp/contracts from the workspace.",
            },
            {
              group: [
                "**/app-scaffolds/**",
                "**/apps/**",
                "**/shared/ui/**",
                "**/shared/design-tokens/**",
              ],
              message:
                "BOUNDARY: platform services may import only shared contracts — never UI, scaffolds, or solutions.",
            },
          ],
        },
      ],
    },
  },
];

// ─── Design-system compliance (ARCHETYPE-REFERENCE-SPEC §2.5) ────────────────
//
// Solution code (apps/**) composes from @dbp/ui — never raw HTML form controls
// where a library component exists. Enforced via no-restricted-syntax on the JSX
// opening element. Warn-level for now (escalate to error once the tree is clean,
// per docs/plans/2026-06-18-layout-shell-locking.md Task 7).
//
// SCOPE NOTE: the className-content checks the plan also calls for — no raw hex /
// rgb(), no Tailwind arbitrary spacing (`p-[13px]`) or type sizes (`text-[14px]`)
// in apps/** — cannot be expressed with core ESLint AST selectors (they match
// node shape, not string content). They need `eslint-plugin-tailwindcss` or a
// small custom rule and are deferred (see the plan). This block ships the part
// that IS cleanly enforceable today.
const rawControl = (tag, repl) => ({
  selector: `JSXOpeningElement[name.name='${tag}']`,
  message: `DESIGN SYSTEM: use <${repl}> from @dbp/ui, not a raw <${tag}>. Pages compose only from @dbp/ui + dq-* classes (ARCHETYPE-REFERENCE-SPEC §2.5).`,
});

export const designSystemConfigs = [
  {
    name: "dbp/design-system/apps-no-raw-controls",
    files: [`apps/**/${SRC}`],
    rules: {
      "no-restricted-syntax": [
        "warn",
        rawControl("button", "Button"),
        rawControl("input", "Input"),
        rawControl("select", "Select"),
        rawControl("textarea", "Input/textarea (dq-textarea)"),
      ],
    },
  },
];

export default tseslint.config(
  {
    name: "dbp/ignores",
    ignores: [
      "**/node_modules/**",
      "**/.turbo/**",
      "**/dist/**",
      "**/.next/**",
      "**/next-env.d.ts",
      "**/coverage/**",
      "**/__boundary-fixtures__/**",
      "docs/**",
      "workspace/**",
      "storybook-static/**",
    ],
  },
  eslintJs.configs.recommended,
  tseslint.configs.recommended,
  {
    name: "dbp/language-options",
    languageOptions: {
      globals: { ...globals.node, ...globals.browser },
    },
  },
  {
    // Honour the `_`-prefix convention for intentionally-unused bindings — e.g.
    // placeholder params (`_input`) and destructure-omit (`const { x: _omitted, ...rest }`).
    name: "dbp/unused-vars",
    rules: {
      "@typescript-eslint/no-unused-vars": [
        "error",
        {
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
          caughtErrorsIgnorePattern: "^_",
          destructuredArrayIgnorePattern: "^_",
        },
      ],
    },
  },
  ...boundaryConfigs,
  ...designSystemConfigs,
  // The API-mount seam exception must come AFTER the general apps boundary so
  // it overrides for the narrow api/platform path while leaving the general rule intact.
  API_MOUNT_SEAM_EXCEPTION,
  // The instrumentation seam exception must also come after the general apps boundary.
  INSTRUMENTATION_SEAM_EXCEPTION,
);
